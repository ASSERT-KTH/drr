import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot31.setRenderer(xYItemRenderer49);
        boolean boolean51 = xYPlot31.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat55 = null;
        dateAxis54.setDateFormatOverride(dateFormat55);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryPlot61.getAxisOffset();
        double double63 = rectangleInsets62.getTop();
        dateAxis54.setLabelInsets(rectangleInsets62);
        boolean boolean65 = dateAxis54.isTickMarksVisible();
        dateAxis54.setInverted(false);
        xYPlot31.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis54, false);
        int int70 = xYPlot31.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 4.0d + "'", double63 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        int int23 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis1.getCategoryStart(10, 5, rectangle2D26, rectangleEdge27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = dateAxis30.valueToJava2D(10.0d, rectangle2D32, rectangleEdge33);
        dateAxis30.setAutoTickUnitSelection(true);
        java.util.Date date37 = dateAxis30.getMaximumDate();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) day38);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation43, plotOrientation44);
        try {
            double double46 = categoryAxis1.getCategoryEnd((int) (byte) 10, 128, rectangle2D42, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        java.lang.String str6 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        java.util.List list14 = categoryPlot4.getAnnotations();
        categoryPlot4.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot4.setDomainAxis(0, categoryAxis19, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str23 = datasetRenderingOrder22.toString();
        java.lang.Object obj24 = null;
        boolean boolean25 = datasetRenderingOrder22.equals(obj24);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder22);
        java.awt.Image image27 = null;
        categoryPlot4.setBackgroundImage(image27);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str23.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxisForDataset((-1));
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(9.0d);
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getRangeAxisEdge(255);
        int int24 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace25, true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot0.getRangeAxisForDataset((-16777216));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot31.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        int int41 = categoryPlot39.getIndexOf(categoryItemRenderer40);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot39.setRangeAxes(valueAxisArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot39.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        categoryPlot39.rendererChanged(rendererChangeEvent46);
        java.lang.String str48 = categoryPlot39.getPlotType();
        boolean boolean49 = categoryPlot39.isRangeCrosshairVisible();
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot39.setDomainGridlineStroke(stroke50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot39.getRangeAxisLocation(9);
        try {
            xYPlot31.setRangeAxisLocation((int) (short) -1, axisLocation53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Category Plot" + "'", str48.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(axisLocation53);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        java.lang.Object obj30 = numberAxis26.clone();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = dateAxis38.java2DToValue(0.0d, rectangle2D40, rectangleEdge41);
        java.awt.Shape shape43 = dateAxis38.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis38.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, categoryItemRenderer45);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot46.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = numberAxis26.draw(graphics2D31, (double) (-1L), rectangle2D33, rectangle2D34, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.ValueAxis valueAxis46 = xYPlot35.getRangeAxis();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(valueAxis46);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateBottomInset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 11);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot10.setRangeAxes(valueAxisArray13);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray15 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray15);
        java.awt.Font font17 = categoryPlot10.getNoDataMessageFont();
        categoryAxis1.setLabelFont(font17);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 11.0f + "'", float5 == 11.0f);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(categoryAxisArray15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getUpperBound();
        objectList0.set((int) (short) 1, (java.lang.Object) dateAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot12.getIndexOf(categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot12.setRangeAxes(valueAxisArray15);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot12.setDomainAxes(categoryAxisArray17);
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.data.Range range20 = dateAxis5.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        xYPlot31.clearRangeMarkers(500);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = dateAxis56.valueToJava2D(10.0d, rectangle2D58, rectangleEdge59);
        dateAxis56.resizeRange((double) (short) 10, 0.0d);
        int int64 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        boolean boolean65 = xYPlot31.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        double double9 = dateAxis8.getUpperBound();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.valueToJava2D(10.0d, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis13.getStandardTickUnits();
        dateAxis8.setStandardTickUnits(tickUnitSource18);
        dateAxis8.setAutoRangeMinimumSize((double) 100);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis8.setLeftArrow(shape22);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range24);
        dateAxis1.setRangeWithMargins(range24);
        dateAxis1.setVisible(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis10.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline20 = dateAxis10.getTimeline();
        dateAxis1.setTimeline(timeline20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setLabelFont(font22);
        try {
            dateAxis1.zoomRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeline20);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot4.getDrawingSupplier();
        java.awt.Paint paint17 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot4.getDomainAxisLocation(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone15);
        java.lang.String str17 = dateAxis16.getLabelToolTip();
        int int18 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot23.getIndexOf(categoryItemRenderer24);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot23.setRangeAxes(valueAxisArray26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot23.getDomainAxis((int) (byte) 100);
        categoryPlot23.setDomainGridlinesVisible(false);
        boolean boolean32 = categoryPlot23.getDrawSharedDomainAxis();
        dateAxis16.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color0, paint1, paint2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str5 = color4.toString();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color4, paint6 };
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] {};
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray12 = new java.awt.Shape[] { shape10, shape11 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray7, strokeArray8, strokeArray9, shapeArray12);
        boolean boolean15 = defaultDrawingSupplier13.equals((java.lang.Object) 1L);
        boolean boolean17 = defaultDrawingSupplier13.equals((java.lang.Object) (byte) 100);
        try {
            java.awt.Stroke stroke18 = defaultDrawingSupplier13.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str5.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) ' ');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot4.setRangeGridlinesVisible(true);
        boolean boolean12 = categoryPlot4.isDomainGridlinesVisible();
        int int13 = categoryPlot4.getRangeAxisCount();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis26.setMarkerBand(markerAxisBand31);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis26.setMarkerBand(markerAxisBand33);
        java.lang.Object obj35 = numberAxis26.clone();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        double double3 = categoryAxis1.getLowerMargin();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setMaximumCategoryLabelLines((int) '4');
        categoryAxis1.setCategoryMargin((double) 11.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double11 = rectangleInsets9.calculateRightOutset((double) (short) 0);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets9.getUnitType();
        categoryAxis1.setTickLabelInsets(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertNotNull(unitType12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        java.awt.Stroke stroke23 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot24 = categoryPlot4.getRootPlot();
        plot24.setBackgroundAlpha((float) 12);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plot24);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.extendHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Shape[] shapeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean3 = objectList0.equals((java.lang.Object) shapeArray2);
        int int4 = objectList0.size();
        org.junit.Assert.assertNotNull(shapeArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot4.getRangeMarkers((int) ' ', layer17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot4.getRangeMarkers(layer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            categoryPlot4.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        java.awt.Paint paint18 = categoryPlot4.getOutlinePaint();
        categoryPlot4.setBackgroundAlpha(0.0f);
        categoryPlot4.setRangeCrosshairValue((double) 15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot11.getAxisOffset();
        java.awt.Stroke stroke13 = categoryPlot11.getDomainGridlineStroke();
        categoryPlot4.setRangeGridlineStroke(stroke13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        int int11 = categoryPlot10.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot17.getIndexOf(categoryItemRenderer18);
        int int20 = categoryPlot17.getDomainAxisCount();
        categoryPlot17.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot17.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation26, plotOrientation27);
        categoryPlot17.setDomainAxisLocation(axisLocation26, false);
        categoryPlot10.setRangeAxisLocation((int) (byte) 10, axisLocation26);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot10.getRangeAxisEdge(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = dateAxis1.draw(graphics2D6, (double) 11.0f, rectangle2D8, rectangle2D9, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        boolean boolean5 = objectList3.equals((java.lang.Object) 100L);
        int int6 = objectList3.size();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) objectList3);
        double double8 = intervalMarker2.getEndValue();
        java.awt.Font font9 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11.0d + "'", double8 == 11.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        int int39 = categoryPlot37.getIndexOf(categoryItemRenderer38);
        int int40 = categoryPlot37.getDomainAxisCount();
        categoryPlot37.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot37.getDomainMarkers(layer44);
        categoryPlot37.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot37.getLegendItems();
        xYPlot31.setFixedLegendItems(legendItemCollection47);
        boolean boolean49 = xYPlot31.isRangeZoomable();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent50 = null;
        xYPlot31.notifyListeners(plotChangeEvent50);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis54.valueToJava2D(10.0d, rectangle2D56, rectangleEdge57);
        dateAxis54.setAutoTickUnitSelection(true);
        java.util.Date date61 = dateAxis54.getMaximumDate();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        dateAxis41.setMinimumDate(date61);
        float float64 = dateAxis41.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.0f + "'", float64 == 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray22 = null;
        float[] floatArray23 = color21.getComponents(floatArray22);
        float[] floatArray24 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray23);
        float[] floatArray25 = color17.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color17, stroke26);
        categoryPlot4.setRangeCrosshairStroke(stroke26);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        float float15 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        categoryPlot4.setRangeCrosshairValue((double) 0.0f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        xYPlot31.setDomainCrosshairValue((double) (-2), false);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot31.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNull(legendItemCollection36);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot27.getAxisOffset();
        categoryPlot22.setInsets(rectangleInsets28);
        boolean boolean30 = categoryPlot22.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str33 = axisLocation32.toString();
        categoryPlot22.setRangeAxisLocation(9, axisLocation32);
        categoryPlot4.setDomainAxisLocation(0, axisLocation32, false);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = valueMarker38.getLabelOffsetType();
        java.lang.String str40 = valueMarker38.getLabel();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        float float43 = categoryAxis42.getMaximumCategoryLabelWidthRatio();
        int int44 = categoryAxis42.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = dateAxis46.valueToJava2D(10.0d, rectangle2D48, rectangleEdge49);
        dateAxis46.setAutoTickUnitSelection(true);
        java.util.Date date53 = dateAxis46.getMaximumDate();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis46.setTimeZone(timeZone54);
        java.awt.Font font56 = dateAxis46.getTickLabelFont();
        categoryAxis42.setTickLabelFont(font56);
        valueMarker38.setLabelFont(font56);
        org.jfree.chart.util.Layer layer59 = null;
        boolean boolean60 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker38, layer59);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str33.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace49, true);
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot31.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(valueAxis52);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot31.setRenderer(xYItemRenderer49);
        xYPlot31.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot13.getIndexOf(categoryItemRenderer14);
        int int16 = categoryPlot13.getDomainAxisCount();
        categoryPlot13.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot13.setRenderers(categoryItemRendererArray20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation23);
        categoryPlot13.setDomainAxisLocation(axisLocation22, false);
        java.awt.Paint paint27 = categoryPlot13.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint27);
        double double29 = categoryAxis7.getCategoryMargin();
        categoryAxis7.configure();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean33 = numberAxis32.isInverted();
        boolean boolean34 = categoryAxis7.equals((java.lang.Object) numberAxis32);
        java.text.NumberFormat numberFormat35 = null;
        numberAxis32.setNumberFormatOverride(numberFormat35);
        numberAxis32.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat39 = numberAxis32.getNumberFormatOverride();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean41 = numberAxis32.equals((java.lang.Object) paint40);
        double double42 = numberAxis32.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean45 = dateAxis44.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = dateAxis47.java2DToValue(0.0d, rectangle2D49, rectangleEdge50);
        dateAxis47.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis56, categoryItemRenderer57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        int int60 = categoryPlot58.getIndexOf(categoryItemRenderer59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        categoryPlot58.setRenderer((int) (short) 10, categoryItemRenderer62, true);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        double double70 = dateAxis66.valueToJava2D(10.0d, rectangle2D68, rectangleEdge69);
        dateAxis66.setAutoTickUnitSelection(true);
        categoryPlot58.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis66);
        java.awt.Font font74 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot58.setNoDataMessageFont(font74);
        dateAxis47.setTickLabelFont(font74);
        org.jfree.data.Range range77 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis47.setRange(range77);
        dateAxis44.setRange(range77, true, false);
        numberAxis32.setRangeWithMargins(range77);
        numberAxis1.setRange(range77, true, true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(numberFormat39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertNotNull(range77);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        dateAxis1.setUpperMargin(3.0d);
        java.lang.Object obj9 = dateAxis1.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone15);
        java.lang.String str17 = dateAxis16.getLabelToolTip();
        int int18 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot4.getRangeAxis();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis24.valueToJava2D(10.0d, rectangle2D26, rectangleEdge27);
        dateAxis24.setAutoTickUnitSelection(true);
        java.util.Date date31 = dateAxis24.getMaximumDate();
        dateAxis24.setTickMarkInsideLength((float) ' ');
        double double34 = dateAxis24.getAutoRangeMinimumSize();
        float float35 = dateAxis24.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis39.valueToJava2D(10.0d, rectangle2D41, rectangleEdge42);
        dateAxis39.setAutoTickUnitSelection(true);
        java.util.Date date46 = dateAxis39.getMaximumDate();
        dateAxis37.setMinimumDate(date46);
        double double48 = dateAxis37.getUpperBound();
        java.awt.Font font49 = dateAxis37.getLabelFont();
        dateAxis37.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer52);
        java.awt.geom.Point2D point2D54 = xYPlot53.getQuadrantOrigin();
        xYPlot53.setDomainCrosshairValue((double) (-2), false);
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot53.getRangeAxisLocation(2);
        java.awt.geom.Point2D point2D60 = xYPlot53.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        try {
            categoryPlot4.draw(graphics2D20, rectangle2D21, point2D60, plotState61, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 32.0f + "'", float35 == 32.0f);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker1.setLabel("hi!");
        java.awt.Stroke stroke4 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setTickMarkOutsideLength((float) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot11.getIndexOf(categoryItemRenderer12);
        int int14 = categoryPlot11.getDomainAxisCount();
        categoryPlot11.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot11.setBackgroundImageAlignment(12);
        int int20 = categoryPlot11.getDatasetCount();
        categoryPlot11.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge();
        try {
            double double23 = numberAxis1.java2DToValue((double) 500, rectangle2D6, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation6, plotOrientation7);
        try {
            double double9 = categoryAxis1.getCategoryMiddle(100, (int) (short) -1, rectangle2D5, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot4.getRangeAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setCategoryMargin((double) 2.0f);
        categoryAxis1.setLowerMargin((double) 4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        dateAxis1.setUpperMargin((double) 2.0f);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = dateAxis1.getTickUnit();
        java.awt.Paint paint12 = dateAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        int int5 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot4.getFixedLegendItems();
        categoryPlot4.setNoDataMessage("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendItemCollection6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.VERTICAL" + "'", str1.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset12);
        categoryPlot4.datasetChanged(datasetChangeEvent13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        int int22 = categoryPlot20.getIndexOf(categoryItemRenderer21);
        int int23 = categoryPlot20.getDomainAxisCount();
        categoryPlot20.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation30);
        categoryPlot20.setDomainAxisLocation(axisLocation29, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str35 = lengthAdjustmentType34.toString();
        boolean boolean36 = axisLocation29.equals((java.lang.Object) lengthAdjustmentType34);
        categoryPlot4.setDomainAxisLocation(0, axisLocation29, true);
        categoryPlot4.clearRangeAxes();
        categoryPlot4.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "NO_CHANGE" + "'", str35.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 10);
        double double3 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis10.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline20 = dateAxis10.getTimeline();
        dateAxis1.setTimeline(timeline20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setLabelFont(font22);
        double double24 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean27 = dateAxis26.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = dateAxis29.java2DToValue(0.0d, rectangle2D31, rectangleEdge32);
        dateAxis29.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        int int42 = categoryPlot40.getIndexOf(categoryItemRenderer41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        categoryPlot40.setRenderer((int) (short) 10, categoryItemRenderer44, true);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = dateAxis48.valueToJava2D(10.0d, rectangle2D50, rectangleEdge51);
        dateAxis48.setAutoTickUnitSelection(true);
        categoryPlot40.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        java.awt.Font font56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot40.setNoDataMessageFont(font56);
        dateAxis29.setTickLabelFont(font56);
        org.jfree.data.Range range59 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range59);
        dateAxis26.setRange(range59, true, false);
        dateAxis1.setRange(range59, true, false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeline20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        boolean boolean6 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot15.getIndexOf(categoryItemRenderer16);
        int int18 = categoryPlot15.getDomainAxisCount();
        categoryPlot15.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray22 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot15.setRenderers(categoryItemRendererArray22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation25);
        categoryPlot15.setDomainAxisLocation(axisLocation24, false);
        java.awt.Paint paint29 = categoryPlot15.getOutlinePaint();
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint29);
        double double31 = categoryAxis9.getCategoryMargin();
        categoryAxis9.configure();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean35 = numberAxis34.isInverted();
        boolean boolean36 = categoryAxis9.equals((java.lang.Object) numberAxis34);
        java.util.List list37 = categoryPlot4.getCategoriesForAxis(categoryAxis9);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        try {
            boolean boolean40 = categoryPlot4.removeAnnotation(categoryAnnotation38, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getRangeAxisEdge(255);
        int int24 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace25, true);
        boolean boolean28 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.calculateLeftOutset((double) 1L);
        double double10 = rectangleInsets5.calculateTopInset((double) (byte) 0);
        double double11 = rectangleInsets5.getBottom();
        double double13 = rectangleInsets5.calculateLeftInset(18.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        categoryPlot4.clearDomainMarkers();
        float float17 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(0, axisLocation19);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        java.lang.String str22 = dateAxis17.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis24.setLabel("");
        dateAxis24.setAutoTickUnitSelection(true);
        org.jfree.data.Range range29 = dateAxis24.getRange();
        dateAxis17.setRangeWithMargins(range29);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean79 = xYPlot31.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke80 = null;
        try {
            xYPlot31.setRangeGridlineStroke(stroke80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        java.awt.Stroke stroke23 = categoryPlot4.getOutlineStroke();
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset25);
        java.lang.String str27 = datasetChangeEvent26.toString();
        categoryPlot4.datasetChanged(datasetChangeEvent26);
        java.awt.Stroke stroke29 = categoryPlot4.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=10.0]" + "'", str27.equals("org.jfree.data.general.DatasetChangeEvent[source=10.0]"));
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot31.setRenderer(xYItemRenderer49);
        boolean boolean51 = xYPlot31.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat55 = null;
        dateAxis54.setDateFormatOverride(dateFormat55);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryPlot61.getAxisOffset();
        double double63 = rectangleInsets62.getTop();
        dateAxis54.setLabelInsets(rectangleInsets62);
        boolean boolean65 = dateAxis54.isTickMarksVisible();
        dateAxis54.setInverted(false);
        xYPlot31.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis54, false);
        dateAxis54.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 4.0d + "'", double63 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        categoryPlot4.clearDomainMarkers();
        float float17 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str7 = categoryAnchor6.toString();
        java.lang.String str8 = categoryAnchor6.toString();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot16.getIndexOf(categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot16.setRangeAxes(valueAxisArray19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot16.getDomainAxis((int) (byte) 100);
        categoryPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot16.getRangeAxisEdge();
        try {
            double double26 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor6, (-2), (int) (byte) 100, rectangle2D11, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str7.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str8.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        double double3 = categoryAxis1.getLowerMargin();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setMaximumCategoryLabelLines((int) '4');
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot11.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot11.getDomainAxisForDataset((-1));
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.setFixedDimension(0.0d);
        dateAxis1.setVerticalTickLabels(false);
        dateAxis1.setAutoRangeMinimumSize((double) 1560409200000L);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.java2DToValue(0.0d, rectangle2D23, rectangleEdge24);
        java.awt.Shape shape26 = dateAxis21.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis21.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis21, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot29.getDomainAxisEdge();
        try {
            java.util.List list31 = dateAxis1.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        org.jfree.chart.axis.DateAxis dateAxis91 = new org.jfree.chart.axis.DateAxis("hi!");
        xYPlot31.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) dateAxis91, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer94 = null;
        xYPlot31.setRenderer(xYItemRenderer94);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(9.0d);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker22);
        categoryPlot4.setRangeCrosshairValue(0.0d, false);
        categoryPlot4.configureRangeAxes();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        java.awt.Paint paint3 = categoryAxis1.getAxisLinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot8.getIndexOf(categoryItemRenderer9);
        int int11 = categoryPlot8.getDomainAxisCount();
        categoryPlot8.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot8.setBackgroundImageAlignment(12);
        int int17 = categoryPlot8.getDatasetCount();
        categoryPlot8.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot8.setDataset((int) '4', categoryDataset20);
        boolean boolean22 = categoryPlot8.isRangeZoomable();
        boolean boolean23 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        xYPlot31.setDomainAxis(valueAxis33);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot31.rendererChanged(rendererChangeEvent35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYPlot31.drawBackground(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.configureRangeAxes();
        java.lang.String str93 = xYPlot31.getPlotType();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "XY Plot" + "'", str93.equals("XY Plot"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.awt.Paint paint29 = numberAxis26.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        int int36 = categoryPlot34.getIndexOf(categoryItemRenderer35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot34.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo39, point2D40);
        numberAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        int int43 = categoryPlot34.getWeight();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot4.setDomainAxis(categoryAxis15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.calculateLeftOutset((double) 1L);
        double double10 = rectangleInsets5.calculateTopOutset((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis1.setNumberFormatOverride(numberFormat4);
        java.awt.Shape shape6 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot31.setRenderer(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        valueMarker1.setValue((double) (-2));
        java.awt.Stroke stroke5 = valueMarker1.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat8 = null;
        dateAxis7.setDateFormatOverride(dateFormat8);
        dateAxis7.setAutoTickUnitSelection(false, false);
        java.awt.Paint paint13 = dateAxis7.getLabelPaint();
        valueMarker1.setOutlinePaint(paint13);
        java.awt.Stroke stroke15 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange(100.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis1.getStandardTickUnits();
        dateAxis1.centerRange((double) 8);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot21.setBackgroundImageAlignment(12);
        int int30 = categoryPlot21.getDatasetCount();
        categoryPlot21.clearRangeMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot21.setDataset((int) '4', categoryDataset33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot21.getDomainAxisEdge();
        try {
            java.util.List list36 = dateAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        boolean boolean11 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker8, layer9, true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot4.addChangeListener(plotChangeListener12);
        float float14 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis16.configure();
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) 11);
        float float20 = categoryAxis16.getMaximumCategoryLabelWidthRatio();
        categoryPlot4.setDomainAxis(categoryAxis16);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 11.0f + "'", float20 == 11.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot8.getDomainAxis();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint11, paint12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str15 = color14.toString();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, paint16 };
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] {};
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { shape20, shape21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray17, strokeArray18, strokeArray19, shapeArray22);
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        java.lang.Object obj25 = defaultDrawingSupplier23.clone();
        java.awt.Paint paint26 = defaultDrawingSupplier23.getNextOutlinePaint();
        dateAxis1.setLabelPaint(paint26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str15.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(paint26);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
//        double double8 = dateAxis4.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
//        java.awt.Shape shape9 = dateAxis4.getUpArrow();
//        int int10 = day0.compareTo((java.lang.Object) shape9);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertNotNull(shape9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot4.getRowRenderingOrder();
        java.awt.Paint paint24 = null;
        categoryPlot4.setBackgroundPaint(paint24);
        int int26 = categoryPlot4.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(9.0d);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker22);
        valueMarker22.setValue((double) 32.0f);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        xYPlot31.setDomainAxis(valueAxis33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        int int42 = categoryPlot40.getIndexOf(categoryItemRenderer41);
        int int43 = categoryPlot40.getDomainAxisCount();
        categoryPlot40.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot40.setBackgroundImageAlignment(12);
        int int49 = categoryPlot40.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        categoryPlot40.setFixedRangeAxisSpace(axisSpace50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot40.setDomainAxis(9, categoryAxis53, true);
        java.awt.Paint paint56 = categoryPlot40.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot40.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot40.setDomainAxisLocation((int) (short) 0, axisLocation59, true);
        xYPlot31.setDomainAxisLocation(255, axisLocation59, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean79 = xYPlot31.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset80 = null;
        int int81 = xYPlot31.indexOf(xYDataset80);
        org.jfree.chart.JFreeChart jFreeChart82 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType83 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str84 = chartChangeEventType83.toString();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent85 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYDataset80, jFreeChart82, chartChangeEventType83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(chartChangeEventType83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str84.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        int int39 = categoryPlot37.getIndexOf(categoryItemRenderer38);
        int int40 = categoryPlot37.getDomainAxisCount();
        categoryPlot37.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot37.getDomainMarkers(layer44);
        categoryPlot37.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot37.getLegendItems();
        xYPlot31.setFixedLegendItems(legendItemCollection47);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        xYPlot31.drawAnnotations(graphics2D49, rectangle2D50, plotRenderingInfo51);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(legendItemCollection47);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.setTickMarkInsideLength((float) ' ');
        dateAxis1.setRangeWithMargins((double) 0, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        double double11 = dateAxis10.getUpperBound();
        dateAxis10.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis15.valueToJava2D(10.0d, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis15.getStandardTickUnits();
        dateAxis10.setStandardTickUnits(tickUnitSource20);
        java.lang.Class class22 = null;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis26.valueToJava2D(10.0d, rectangle2D28, rectangleEdge29);
        dateAxis26.setAutoTickUnitSelection(true);
        java.util.Date date33 = dateAxis26.getMaximumDate();
        dateAxis24.setMinimumDate(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date33, timeZone35);
        dateAxis10.setTimeZone(timeZone35);
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        dateAxis10.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis25.getLabelInsets();
        categoryPlot4.setDomainAxis(categoryAxis25);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot36.getIndexOf(categoryItemRenderer37);
        java.lang.Object obj39 = categoryPlot36.clone();
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot36.getFixedDomainAxisSpace();
        float float41 = categoryPlot36.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            org.jfree.chart.axis.AxisState axisState44 = categoryAxis25.draw(graphics2D28, 0.0d, rectangle2D30, rectangle2D31, rectangleEdge42, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.5f + "'", float41 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot31.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        int int47 = categoryPlot45.getIndexOf(categoryItemRenderer46);
        int int48 = categoryPlot45.getDomainAxisCount();
        categoryPlot45.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot45.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = categoryPlot45.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot45.addDomainMarker(categoryMarker56);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Font font69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot62.setNoDataMessageFont(font69);
        categoryMarker56.setLabelFont(font69);
        boolean boolean72 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker56);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection54);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        java.awt.Paint paint18 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot23.getDomainAxis();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color25, paint26, paint27 };
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str30 = color29.toString();
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color29, paint31 };
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] {};
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape35, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray28, paintArray32, strokeArray33, strokeArray34, shapeArray37);
        categoryPlot23.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier38);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        categoryPlot23.markerChanged(markerChangeEvent40);
        java.awt.Stroke stroke42 = categoryPlot23.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        int int49 = categoryPlot47.getIndexOf(categoryItemRenderer48);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot47.setRangeAxes(valueAxisArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = categoryPlot47.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent54 = null;
        categoryPlot47.rendererChanged(rendererChangeEvent54);
        java.lang.String str56 = categoryPlot47.getPlotType();
        boolean boolean57 = categoryPlot47.isRangeCrosshairVisible();
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot47.setDomainGridlineStroke(stroke58);
        org.jfree.chart.axis.AxisLocation axisLocation61 = categoryPlot47.getRangeAxisLocation(9);
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, valueAxis65, categoryItemRenderer66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryPlot67.getAxisOffset();
        java.awt.Stroke stroke69 = categoryPlot67.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = null;
        double double75 = dateAxis71.java2DToValue(0.0d, rectangle2D73, rectangleEdge74);
        java.awt.Shape shape76 = dateAxis71.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = dateAxis71.getLabelInsets();
        categoryPlot67.setInsets(rectangleInsets77, false);
        java.awt.Image image80 = null;
        categoryPlot67.setBackgroundImage(image80);
        boolean boolean82 = layer62.equals((java.lang.Object) categoryPlot67);
        java.util.Collection collection83 = categoryPlot47.getDomainMarkers(layer62);
        java.util.Collection collection84 = categoryPlot23.getRangeMarkers(layer62);
        java.util.Collection collection85 = categoryPlot4.getRangeMarkers(layer62);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str30.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNull(categoryAxis53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Category Plot" + "'", str56.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(collection83);
        org.junit.Assert.assertNotNull(collection84);
        org.junit.Assert.assertNotNull(collection85);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        dateAxis1.setUpperMargin((double) 2.0f);
        double double11 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean6 = categoryPlot4.equals((java.lang.Object) 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat10 = null;
        dateAxis9.setDateFormatOverride(dateFormat10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot16.getAxisOffset();
        double double18 = rectangleInsets17.getTop();
        dateAxis9.setLabelInsets(rectangleInsets17);
        boolean boolean20 = dateAxis9.isTickMarksVisible();
        categoryPlot4.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis9, false);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace23, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = valueMarker1.getLabelAnchor();
        double double4 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextFillPaint();
        java.lang.Object obj22 = defaultDrawingSupplier19.clone();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean79 = xYPlot31.isRangeZeroBaselineVisible();
        boolean boolean80 = xYPlot31.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        double double8 = rectangleInsets6.calculateRightOutset(0.0d);
        dateAxis0.setTickLabelInsets(rectangleInsets6);
        double double11 = rectangleInsets6.calculateLeftOutset(0.0d);
        double double13 = rectangleInsets6.calculateTopOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets6.createInsetRectangle(rectangle2D14, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double6 = rectangleInsets5.getTop();
        double double8 = rectangleInsets5.extendHeight((double) 1);
        double double10 = rectangleInsets5.trimHeight((double) 15);
        double double12 = rectangleInsets5.calculateBottomInset((double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.0d + "'", double8 == 9.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 7.0d + "'", double10 == 7.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
//        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList();
//        boolean boolean7 = objectList5.equals((java.lang.Object) 100L);
//        int int8 = objectList5.size();
//        boolean boolean9 = intervalMarker4.equals((java.lang.Object) objectList5);
//        java.awt.Color color11 = java.awt.Color.BLUE;
//        java.awt.Color color12 = java.awt.Color.getColor("hi!", color11);
//        intervalMarker4.setOutlinePaint((java.awt.Paint) color11);
//        int int14 = day0.compareTo((java.lang.Object) intervalMarker4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        org.jfree.chart.plot.Plot plot7 = dateAxis2.getPlot();
        dateAxis2.setTickMarkOutsideLength((float) (byte) -1);
        boolean boolean10 = unitType0.equals((java.lang.Object) dateAxis2);
        java.lang.String str11 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.ABSOLUTE" + "'", str11.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateLeftInset(8.0d);
        double double5 = rectangleInsets0.calculateBottomOutset(4.0d);
        double double6 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot4.getDrawingSupplier();
        java.awt.Paint paint17 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList21 = new org.jfree.chart.util.ObjectList();
        boolean boolean23 = objectList21.equals((java.lang.Object) 100L);
        int int24 = objectList21.size();
        boolean boolean25 = intervalMarker20.equals((java.lang.Object) objectList21);
        double double26 = intervalMarker20.getEndValue();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker20, layer27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot4.setRenderer(categoryItemRenderer29, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 11.0d + "'", double26 == 11.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat33 = numberAxis26.getNumberFormatOverride();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean35 = numberAxis26.equals((java.lang.Object) paint34);
        double double36 = numberAxis26.getUpperBound();
        numberAxis26.configure();
        numberAxis26.setInverted(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = numberAxis26.getMarkerBand();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand40);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot4.notifyListeners(plotChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(0, categoryDataset10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot16.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot16.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot24.getDomainAxis();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color26, paint27, paint28 };
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str31 = color30.toString();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color30, paint32 };
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] { shape36, shape37 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray29, paintArray33, strokeArray34, strokeArray35, shapeArray38);
        categoryPlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryPlot24.markerChanged(markerChangeEvent41);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot24.getRowRenderingOrder();
        categoryPlot16.setRowRenderingOrder(sortOrder43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot16.getDomainAxisLocation(11);
        categoryPlot4.setDomainAxisLocation(axisLocation46, false);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot4.getRendererForDataset(categoryDataset49);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str31.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(categoryItemRenderer50);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color2 = java.awt.Color.getColor("", (-16777216));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getComponents(floatArray5);
        float[] floatArray7 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray6);
        float[] floatArray8 = color0.getRGBColorComponents(floatArray7);
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot14.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot14.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot18 = categoryPlot14.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot14);
        java.lang.String str20 = plotChangeEvent19.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = plotChangeEvent19.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) floatArray7, jFreeChart9, chartChangeEventType21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint35 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray36 = new java.awt.Paint[] { color33, paint34, paint35 };
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str38 = color37.toString();
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color37, paint39 };
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] {};
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray45 = new java.awt.Shape[] { shape43, shape44 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray36, paintArray40, strokeArray41, strokeArray42, shapeArray45);
        java.awt.Paint paint47 = defaultDrawingSupplier46.getNextPaint();
        xYPlot31.setDomainZeroBaselinePaint(paint47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace49, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = xYPlot31.getAxisOffset();
        double double53 = rectangleInsets52.getTop();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paintArray36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str38.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shapeArray45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 4.0d + "'", double53 == 4.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color1 = color0.darker();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Image image9 = null;
        categoryPlot6.setBackgroundImage(image9);
        java.awt.Stroke stroke11 = categoryPlot6.getRangeCrosshairStroke();
        boolean boolean12 = color0.equals((java.lang.Object) stroke11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange(100.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis1.getStandardTickUnits();
        java.awt.Stroke stroke12 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot31.getDomainAxisForDataset(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot62.setRenderers(categoryItemRendererArray69);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        categoryPlot62.setDomainAxisLocation(axisLocation71, false);
        java.awt.Paint paint76 = categoryPlot62.getOutlinePaint();
        categoryAxis56.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint76);
        double double78 = categoryAxis56.getCategoryMargin();
        categoryAxis56.configure();
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean82 = numberAxis81.isInverted();
        boolean boolean83 = categoryAxis56.equals((java.lang.Object) numberAxis81);
        java.text.NumberFormat numberFormat84 = null;
        numberAxis81.setNumberFormatOverride(numberFormat84);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand86 = null;
        numberAxis81.setMarkerBand(markerAxisBand86);
        numberAxis81.setRangeWithMargins((double) 1L, (double) 9);
        xYPlot31.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis81);
        org.jfree.chart.axis.AxisSpace axisSpace92 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace92);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(valueAxis54);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.2d + "'", double78 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        double double3 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        int int23 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis1.getCategoryStart(10, 5, rectangle2D26, rectangleEdge27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = dateAxis30.valueToJava2D(10.0d, rectangle2D32, rectangleEdge33);
        dateAxis30.setAutoTickUnitSelection(true);
        java.util.Date date37 = dateAxis30.getMaximumDate();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) day38);
        java.lang.String str40 = categoryAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        categoryAxis1.setMaximumCategoryLabelLines(128);
        int int14 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot4.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke12 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabel("");
        dateAxis1.setAutoTickUnitSelection(true);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis8.java2DToValue(0.0d, rectangle2D10, rectangleEdge11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis8.getLabelInsets();
        java.awt.Stroke stroke15 = dateAxis8.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis17.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline27 = dateAxis17.getTimeline();
        dateAxis8.setTimeline(timeline27);
        dateAxis1.setTimeline(timeline27);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeline27);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder8 = categoryPlot5.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color15, paint16, paint17 };
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str20 = color19.toString();
        java.awt.Paint paint21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color19, paint21 };
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] {};
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] { shape25, shape26 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray22, strokeArray23, strokeArray24, shapeArray27);
        categoryPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        categoryPlot13.markerChanged(markerChangeEvent30);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot13.getRowRenderingOrder();
        categoryPlot5.setRowRenderingOrder(sortOrder32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot5.getDomainAxisLocation(11);
        categoryPlot5.clearDomainAxes();
        boolean boolean37 = unitType0.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str20.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot18.getIndexOf(categoryItemRenderer19);
        int int21 = categoryPlot18.getDomainAxisCount();
        categoryPlot18.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot18.getDomainMarkers(layer25);
        categoryPlot18.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        int int37 = categoryPlot35.getIndexOf(categoryItemRenderer36);
        int int38 = categoryPlot35.getDomainAxisCount();
        categoryPlot35.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot35.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot35.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot35.addDomainMarker(categoryMarker46);
        org.jfree.chart.util.Layer layer48 = null;
        categoryPlot18.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker46, layer48, false);
        boolean boolean51 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker46);
        org.jfree.data.category.CategoryDataset categoryDataset52 = categoryPlot4.getDataset();
        categoryPlot4.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(categoryDataset52);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.lang.Object obj8 = dateAxis1.clone();
        boolean boolean9 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        double double12 = dateAxis11.getUpperBound();
        dateAxis11.setAutoTickUnitSelection(false);
        java.lang.Object obj15 = dateAxis11.clone();
        java.lang.Class class16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.valueToJava2D(10.0d, rectangle2D22, rectangleEdge23);
        dateAxis20.setAutoTickUnitSelection(true);
        java.util.Date date27 = dateAxis20.getMaximumDate();
        dateAxis18.setMinimumDate(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date27, timeZone29);
        dateAxis11.setMinimumDate(date27);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date27, timeZone32);
        dateAxis1.setTimeZone(timeZone32);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SeriesRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SeriesRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getUpperBound();
        objectList0.set((int) (short) 1, (java.lang.Object) dateAxis5);
        int int8 = objectList0.size();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        objectList0.set(0, (java.lang.Object) color10);
        java.lang.Object obj13 = objectList0.get(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation16);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot0.getRangeAxisEdge(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot4.setDomainAxisLocation(axisLocation13, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot4.getOrientation();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color3, paint4, paint5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str8 = color7.toString();
        java.awt.Paint paint9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, paint9 };
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] { shape13, shape14 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray10, strokeArray11, strokeArray12, shapeArray15);
        java.lang.Class<?> wildcardClass17 = strokeArray12.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = dateAxis23.valueToJava2D(10.0d, rectangle2D25, rectangleEdge26);
        dateAxis23.setAutoTickUnitSelection(true);
        java.util.Date date30 = dateAxis23.getMaximumDate();
        dateAxis21.setMinimumDate(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date30, timeZone32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date30, timeZone34);
        boolean boolean36 = plotOrientation1.equals((java.lang.Object) timeZone34);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str8.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis8.setMinimumDate(date17);
        double double19 = dateAxis8.getUpperBound();
        java.awt.Font font20 = dateAxis8.getLabelFont();
        dateAxis8.setTickMarkOutsideLength((float) (byte) 1);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        boolean boolean24 = dateAxis8.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str1.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot35.getFixedDomainAxisSpace();
        java.awt.Paint paint47 = xYPlot35.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNull(paint47);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color2 = java.awt.Color.getColor("EXPAND", (int) ' ');
        int int3 = color2.getGreen();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = null;
        try {
            xYPlot31.setAxisOffset(rectangleInsets32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        double double3 = intervalMarker2.getStartValue();
        double double4 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue((double) 128);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        categoryAxis1.configure();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        int int26 = day24.getYear();
        java.lang.String str27 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) day24);
        double double28 = categoryAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.clearRangeAxes();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(6);
        categoryPlot0.configureRangeAxes();
        boolean boolean7 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        double double11 = categoryPlot4.getRangeCrosshairValue();
        boolean boolean12 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker14.getLabelOffsetType();
        valueMarker14.setValue((double) (-2));
        java.awt.Stroke stroke18 = valueMarker14.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat21 = null;
        dateAxis20.setDateFormatOverride(dateFormat21);
        dateAxis20.setAutoTickUnitSelection(false, false);
        java.awt.Paint paint26 = dateAxis20.getLabelPaint();
        valueMarker14.setOutlinePaint(paint26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis29.configure();
        categoryAxis29.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis34.configure();
        categoryAxis34.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions38 = categoryAxis34.getCategoryLabelPositions();
        categoryAxis29.setCategoryLabelPositions(categoryLabelPositions38);
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis29.setTickLabelFont((java.lang.Comparable) '4', font41);
        categoryAxis29.setMaximumCategoryLabelWidthRatio((float) (byte) 0);
        boolean boolean45 = valueMarker14.equals((java.lang.Object) categoryAxis29);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray46 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis29 };
        categoryPlot4.setDomainAxes(categoryAxisArray46);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(categoryLabelPositions38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray46);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone9);
        java.awt.Font font11 = dateAxis1.getTickLabelFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        int int16 = categoryPlot15.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot22.getIndexOf(categoryItemRenderer23);
        int int25 = categoryPlot22.getDomainAxisCount();
        categoryPlot22.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot22.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        categoryPlot22.setDomainAxisLocation(axisLocation31, false);
        categoryPlot15.setRangeAxisLocation((int) (byte) 10, axisLocation31);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot15.getRangeAxisEdge(255);
        try {
            java.util.List list39 = dateAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.awt.Paint paint33 = numberAxis26.getTickLabelPaint();
        boolean boolean34 = numberAxis26.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis35.valueToJava2D(10.0d, rectangle2D37, rectangleEdge38);
        dateAxis35.setAutoTickUnitSelection(true);
        java.util.Date date42 = dateAxis35.getMaximumDate();
        dateAxis33.setMinimumDate(date42);
        double double44 = dateAxis33.getUpperBound();
        java.awt.Font font45 = dateAxis33.getLabelFont();
        dateAxis33.setTickMarkOutsideLength((float) (byte) 1);
        java.awt.Paint paint48 = dateAxis33.getLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        int int58 = categoryPlot56.getIndexOf(categoryItemRenderer57);
        int int59 = categoryPlot56.getDomainAxisCount();
        categoryPlot56.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray63 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot56.setRenderers(categoryItemRendererArray63);
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation66 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation65, plotOrientation66);
        categoryPlot56.setDomainAxisLocation(axisLocation65, false);
        java.awt.Paint paint70 = categoryPlot56.getOutlinePaint();
        categoryAxis50.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint70);
        double double72 = categoryAxis50.getCategoryMargin();
        categoryAxis50.configure();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean76 = numberAxis75.isInverted();
        boolean boolean77 = categoryAxis50.equals((java.lang.Object) numberAxis75);
        java.text.NumberFormat numberFormat78 = null;
        numberAxis75.setNumberFormatOverride(numberFormat78);
        numberAxis75.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat82 = numberAxis75.getNumberFormatOverride();
        java.awt.Paint paint83 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean84 = numberAxis75.equals((java.lang.Object) paint83);
        org.jfree.data.Range range85 = numberAxis75.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray86 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33, numberAxis75 };
        xYPlot31.setDomainAxes(valueAxisArray86);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray63);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(plotOrientation66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.2d + "'", double72 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(numberFormat82);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertNotNull(valueAxisArray86);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        boolean boolean6 = dateAxis1.isPositiveArrowVisible();
        dateAxis1.setFixedAutoRange(1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj11 = numberAxis10.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.java2DToValue(0.0d, rectangle2D15, rectangleEdge16);
        java.awt.Shape shape18 = dateAxis13.getUpArrow();
        numberAxis10.setUpArrow(shape18);
        dateAxis1.setLeftArrow(shape18);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) (short) 0);
        double double4 = rectangleInsets0.extendHeight((double) 255);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) lengthAdjustmentType8);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 259.0d + "'", double4 == 259.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        java.awt.Stroke stroke8 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis10.setFixedDimension(0.0d);
        org.jfree.chart.axis.Timeline timeline20 = dateAxis10.getTimeline();
        dateAxis1.setTimeline(timeline20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        dateAxis1.setLabelFont(font22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis1.setAxisLineStroke(stroke24);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeline20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis8.setMinimumDate(date17);
        double double19 = dateAxis8.getUpperBound();
        java.awt.Font font20 = dateAxis8.getLabelFont();
        dateAxis8.setTickMarkOutsideLength((float) (byte) 1);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        boolean boolean24 = categoryPlot4.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot4.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot4.getRendererForDataset(categoryDataset11);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 11);
        java.awt.Color color5 = java.awt.Color.GREEN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean79 = xYPlot31.isRangeZeroBaselineVisible();
        xYPlot31.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot31.getDomainAxisForDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = valueMarker56.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot62.setRenderers(categoryItemRendererArray69);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        categoryPlot62.setDomainAxisLocation(axisLocation71, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType76 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str77 = lengthAdjustmentType76.toString();
        boolean boolean78 = axisLocation71.equals((java.lang.Object) lengthAdjustmentType76);
        valueMarker56.setLabelOffsetType(lengthAdjustmentType76);
        valueMarker56.setValue(10.0d);
        java.awt.Color color82 = java.awt.Color.magenta;
        boolean boolean83 = valueMarker56.equals((java.lang.Object) color82);
        xYPlot31.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        xYPlot31.configureRangeAxes();
        java.awt.Graphics2D graphics2D86 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        org.jfree.data.category.CategoryDataset categoryDataset88 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = null;
        org.jfree.chart.axis.ValueAxis valueAxis90 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer91 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot92 = new org.jfree.chart.plot.CategoryPlot(categoryDataset88, categoryAxis89, valueAxis90, categoryItemRenderer91);
        org.jfree.chart.event.PlotChangeListener plotChangeListener93 = null;
        categoryPlot92.addChangeListener(plotChangeListener93);
        categoryPlot92.clearDomainAxes();
        java.util.List list96 = categoryPlot92.getAnnotations();
        xYPlot31.drawRangeTickBands(graphics2D86, rectangle2D87, list96);
        java.awt.Paint paint98 = xYPlot31.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(valueAxis54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "NO_CHANGE" + "'", str77.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(list96);
        org.junit.Assert.assertNull(paint98);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        valueMarker33.setLabelTextAnchor(textAnchor39);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textAnchor39);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        int int3 = objectList0.size();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        objectList0.set(0, (java.lang.Object) paint5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis9.valueToJava2D(10.0d, rectangle2D11, rectangleEdge12);
        dateAxis9.setAutoTickUnitSelection(true);
        java.util.Date date16 = dateAxis9.getMaximumDate();
        dateAxis9.setTickMarkInsideLength((float) ' ');
        double double19 = dateAxis9.getAutoRangeMinimumSize();
        float float20 = dateAxis9.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis24.valueToJava2D(10.0d, rectangle2D26, rectangleEdge27);
        dateAxis24.setAutoTickUnitSelection(true);
        java.util.Date date31 = dateAxis24.getMaximumDate();
        dateAxis22.setMinimumDate(date31);
        double double33 = dateAxis22.getUpperBound();
        java.awt.Font font34 = dateAxis22.getLabelFont();
        dateAxis22.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer37);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker40.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean44 = valueMarker40.equals((java.lang.Object) rectangleInsets43);
        boolean boolean45 = xYPlot38.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
        boolean boolean46 = xYPlot38.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = dateAxis48.valueToJava2D(10.0d, rectangle2D50, rectangleEdge51);
        dateAxis48.setAutoTickUnitSelection(true);
        java.util.Date date55 = dateAxis48.getMaximumDate();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis48.setTimeZone(timeZone56);
        java.awt.Font font58 = dateAxis48.getTickLabelFont();
        xYPlot38.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis48);
        double double60 = xYPlot38.getDomainCrosshairValue();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color63 = java.awt.Color.getColor("", color62);
        int int64 = color63.getGreen();
        xYPlot38.setRangeCrosshairPaint((java.awt.Paint) color63);
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = dateAxis68.java2DToValue(0.0d, rectangle2D70, rectangleEdge71);
        java.awt.Shape shape73 = dateAxis68.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = dateAxis68.getLabelInsets();
        java.awt.Stroke stroke75 = dateAxis68.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = null;
        double double81 = dateAxis77.java2DToValue(0.0d, rectangle2D79, rectangleEdge80);
        java.awt.Shape shape82 = dateAxis77.getUpArrow();
        dateAxis68.setRightArrow(shape82);
        xYPlot38.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis68, true);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot38);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 32.0f + "'", float20 == 32.0f);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 128 + "'", int64 == 128);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(shape82);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.util.ObjectList objectList15 = new org.jfree.chart.util.ObjectList();
        boolean boolean17 = objectList15.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        double double21 = dateAxis20.getUpperBound();
        objectList15.set((int) (short) 1, (java.lang.Object) dateAxis20);
        int int23 = objectList15.size();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        objectList15.set(0, (java.lang.Object) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray28 = null;
        float[] floatArray29 = color27.getComponents(floatArray28);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray34 = null;
        float[] floatArray35 = color33.getComponents(floatArray34);
        float[] floatArray36 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray35);
        float[] floatArray37 = color27.getRGBComponents(floatArray36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray39 = null;
        float[] floatArray40 = color38.getComponents(floatArray39);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray45 = null;
        float[] floatArray46 = color44.getComponents(floatArray45);
        float[] floatArray47 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray46);
        float[] floatArray48 = color38.getRGBComponents(floatArray47);
        float[] floatArray49 = color27.getRGBComponents(floatArray48);
        float[] floatArray50 = color25.getComponents(floatArray48);
        boolean boolean51 = dateAxis1.equals((java.lang.Object) floatArray50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Paint paint54 = dateAxis53.getTickMarkPaint();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = dateAxis58.valueToJava2D(10.0d, rectangle2D60, rectangleEdge61);
        dateAxis58.setAutoTickUnitSelection(true);
        java.util.Date date65 = dateAxis58.getMaximumDate();
        dateAxis56.setMinimumDate(date65);
        dateAxis53.setMinimumDate(date65);
        dateAxis1.setMinimumDate(date65);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(date65);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setUpperMargin((double) (short) 0);
        int int15 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        try {
            java.awt.Paint paint34 = xYPlot31.getQuadrantPaint(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (15) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot4.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.valueToJava2D(10.0d, rectangle2D22, rectangleEdge23);
        dateAxis20.setAutoTickUnitSelection(true);
        java.util.Date date27 = dateAxis20.getMaximumDate();
        dateAxis20.setTickMarkInsideLength((float) ' ');
        double double30 = dateAxis20.getAutoRangeMinimumSize();
        float float31 = dateAxis20.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis35.valueToJava2D(10.0d, rectangle2D37, rectangleEdge38);
        dateAxis35.setAutoTickUnitSelection(true);
        java.util.Date date42 = dateAxis35.getMaximumDate();
        dateAxis33.setMinimumDate(date42);
        double double44 = dateAxis33.getUpperBound();
        java.awt.Font font45 = dateAxis33.getLabelFont();
        dateAxis33.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer48);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker51.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean55 = valueMarker51.equals((java.lang.Object) rectangleInsets54);
        boolean boolean56 = xYPlot49.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker51);
        boolean boolean57 = xYPlot49.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot49.getRangeAxisLocation();
        categoryPlot4.setDomainAxisLocation(500, axisLocation58);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 32.0f + "'", float31 == 32.0f);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = xYPlot31.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset90 = null;
        xYPlot31.setDataset(xYDataset90);
        org.jfree.chart.axis.ValueAxis valueAxis93 = xYPlot31.getDomainAxis((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNull(valueAxis93);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.plot.Plot plot10 = plotChangeEvent9.getPlot();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.configure();
        categoryAxis12.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis7.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent21);
        java.lang.String str23 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(6);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        java.lang.Object obj8 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.extendWidth(0.0d);
        double double5 = rectangleInsets0.calculateLeftOutset((double) 15);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        float float28 = categoryAxis27.getMaximumCategoryLabelWidthRatio();
        int int29 = categoryAxis27.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = dateAxis31.valueToJava2D(10.0d, rectangle2D33, rectangleEdge34);
        dateAxis31.setAutoTickUnitSelection(true);
        java.util.Date date38 = dateAxis31.getMaximumDate();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis31.setTimeZone(timeZone39);
        java.awt.Font font41 = dateAxis31.getTickLabelFont();
        categoryAxis27.setTickLabelFont(font41);
        categoryMarker25.setLabelFont(font41);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryPlot49.getAxisOffset();
        java.awt.Stroke stroke51 = categoryPlot49.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis53.java2DToValue(0.0d, rectangle2D55, rectangleEdge56);
        java.awt.Shape shape58 = dateAxis53.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = dateAxis53.getLabelInsets();
        categoryPlot49.setInsets(rectangleInsets59, false);
        java.awt.Image image62 = null;
        categoryPlot49.setBackgroundImage(image62);
        boolean boolean64 = layer44.equals((java.lang.Object) categoryPlot49);
        categoryPlot4.addDomainMarker(categoryMarker25, layer44);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.data.general.DatasetChangeEvent[source=10.0]", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        java.awt.Color color46 = java.awt.Color.CYAN;
        xYPlot35.setDomainTickBandPaint((java.awt.Paint) color46);
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        int int55 = categoryPlot53.getIndexOf(categoryItemRenderer54);
        int int56 = categoryPlot53.getDomainAxisCount();
        categoryPlot53.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot53.setBackgroundImageAlignment(12);
        int int62 = categoryPlot53.getDatasetCount();
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis66.setLabel("");
        categoryPlot53.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis66, false);
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, valueAxis73, categoryItemRenderer74);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = null;
        int int77 = categoryPlot75.getIndexOf(categoryItemRenderer76);
        int int78 = categoryPlot75.getDomainAxisCount();
        categoryPlot75.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot75.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection84 = categoryPlot75.getLegendItems();
        categoryPlot53.setFixedLegendItems(legendItemCollection84);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent86 = null;
        categoryPlot53.axisChanged(axisChangeEvent86);
        org.jfree.chart.axis.AxisLocation axisLocation89 = categoryPlot53.getDomainAxisLocation(8);
        try {
            xYPlot35.setRangeAxisLocation((-2), axisLocation89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection84);
        org.junit.Assert.assertNotNull(axisLocation89);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot31.getDataset(4);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot31.setDomainGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = xYPlot31.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(drawingSupplier44);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot4.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot12.getDomainAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, paint15, paint16 };
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str19 = color18.toString();
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color18, paint20 };
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] {};
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape24, shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray21, strokeArray22, strokeArray23, shapeArray26);
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        categoryPlot12.markerChanged(markerChangeEvent29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot12.getRowRenderingOrder();
        categoryPlot4.setRowRenderingOrder(sortOrder31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot4.getDomainAxisLocation(11);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation34, plotOrientation35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str19.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        xYPlot31.setDomainCrosshairValue((double) (-2), false);
        java.awt.Stroke stroke36 = xYPlot31.getRangeGridlineStroke();
        float float37 = xYPlot31.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) paint7);
        double double10 = rectangleInsets0.calculateRightOutset((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        boolean boolean7 = categoryPlot4.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot4.setDataset(5, categoryDataset9);
        java.awt.Image image11 = null;
        categoryPlot4.setBackgroundImage(image11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis26.setMarkerBand(markerAxisBand31);
        java.lang.Object obj33 = numberAxis26.clone();
        numberAxis26.configure();
        numberAxis26.setFixedAutoRange((double) 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        java.awt.Stroke stroke6 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis8.java2DToValue(0.0d, rectangle2D10, rectangleEdge11);
        java.awt.Shape shape13 = dateAxis8.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis8.getLabelInsets();
        categoryPlot4.setInsets(rectangleInsets14, false);
        java.awt.Image image17 = null;
        categoryPlot4.setBackgroundImage(image17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot23.getIndexOf(categoryItemRenderer24);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot23.setRangeAxes(valueAxisArray26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot23.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot23.rendererChanged(rendererChangeEvent30);
        double double32 = categoryPlot23.getAnchorValue();
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot23);
        categoryPlot4.notifyListeners(plotChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = plotChangeEvent34.getChart();
        java.lang.Object obj37 = plotChangeEvent34.getSource();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(jFreeChart36);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot4.addChangeListener(plotChangeListener13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis16.java2DToValue(0.0d, rectangle2D18, rectangleEdge19);
        dateAxis16.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        int int29 = categoryPlot27.getIndexOf(categoryItemRenderer28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot27.setRenderer((int) (short) 10, categoryItemRenderer31, true);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis35.valueToJava2D(10.0d, rectangle2D37, rectangleEdge38);
        dateAxis35.setAutoTickUnitSelection(true);
        categoryPlot27.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot27.setNoDataMessageFont(font43);
        dateAxis16.setTickLabelFont(font43);
        org.jfree.data.Range range46 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range46);
        double double48 = dateAxis16.getLowerBound();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        dateAxis16.setLowerBound((double) 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        double double7 = rectangleInsets5.calculateTopOutset((double) 128);
        double double9 = rectangleInsets5.calculateTopOutset((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str22 = lengthAdjustmentType21.toString();
        boolean boolean23 = axisLocation16.equals((java.lang.Object) lengthAdjustmentType21);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType21);
        valueMarker1.setValue(10.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot32.getAxisOffset();
        categoryPlot27.setInsets(rectangleInsets33);
        boolean boolean35 = categoryPlot27.getDrawSharedDomainAxis();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot27);
        categoryPlot27.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NO_CHANGE" + "'", str22.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray9 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray9);
        java.awt.Font font11 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot4.getRangeAxisForDataset((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(categoryAxisArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot31.getRangeAxisLocation();
        xYPlot31.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot4.getDomainAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, paint7, paint8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str11 = color10.toString();
        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, paint12 };
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape16, shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray9, paintArray13, strokeArray14, strokeArray15, shapeArray18);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot4.markerChanged(markerChangeEvent21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis25.getLabelInsets();
        categoryPlot4.setDomainAxis(categoryAxis25);
        boolean boolean28 = categoryPlot4.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str11.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        boolean boolean29 = numberAxis26.getAutoRangeIncludesZero();
        java.lang.Object obj30 = numberAxis26.clone();
        numberAxis26.configure();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot4.setNoDataMessageFont(font20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        int int29 = categoryPlot27.getIndexOf(categoryItemRenderer28);
        int int30 = categoryPlot27.getDomainAxisCount();
        categoryPlot27.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot27.setBackgroundImageAlignment(12);
        int int36 = categoryPlot27.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot27.setDomainAxis(9, categoryAxis40, true);
        java.awt.Paint paint43 = categoryPlot27.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot27.getDomainAxisLocation();
        categoryPlot4.setRangeAxisLocation(8, axisLocation44, true);
        categoryPlot4.zoom((double) 128);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot4.getDomainAxisLocation((-2));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = dateAxis10.valueToJava2D(10.0d, rectangle2D12, rectangleEdge13);
        dateAxis10.setAutoTickUnitSelection(true);
        java.util.Date date17 = dateAxis10.getMaximumDate();
        dateAxis8.setMinimumDate(date17);
        double double19 = dateAxis8.getUpperBound();
        java.awt.Font font20 = dateAxis8.getLabelFont();
        dateAxis8.setTickMarkOutsideLength((float) (byte) 1);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        boolean boolean24 = dateAxis8.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(10);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot7.setBackgroundImageAlignment(12);
        int int16 = categoryPlot7.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot7.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot7.setDomainAxis(9, categoryAxis20, true);
        java.awt.Paint paint23 = categoryPlot7.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot7.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot7.setDomainAxisLocation((int) (short) 0, axisLocation26, true);
        categoryPlot0.setDomainAxisLocation(axisLocation26);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) '4', font13);
        int int15 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLabelAngle((double) (-1));
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis19.valueToJava2D(10.0d, rectangle2D21, rectangleEdge22);
        dateAxis19.setAutoTickUnitSelection(true);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        java.awt.Color color31 = color30.darker();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) day27, (java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = xYPlot31.getRangeAxisEdge();
        org.jfree.data.xy.XYDataset xYDataset90 = null;
        xYPlot31.setDataset(xYDataset90);
        xYPlot31.clearRangeMarkers();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer93 = xYPlot31.getRenderer();
        java.awt.Paint paint94 = xYPlot31.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertNotNull(rectangleEdge89);
        org.junit.Assert.assertNull(xYItemRenderer93);
        org.junit.Assert.assertNotNull(paint94);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot8.getIndexOf(categoryItemRenderer9);
        int int11 = categoryPlot8.getDomainAxisCount();
        categoryPlot8.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot8.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot8.addDomainMarker(categoryMarker19);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis2.configure();
        categoryAxis2.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis7.getCategoryLabelPositions();
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions11);
        categoryAxis2.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=0,b=255]");
        java.lang.String str17 = numberAxis16.getLabel();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer18);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str17.equals("java.awt.Color[r=0,g=0,b=255]"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot4.getAxisOffset();
        java.awt.Stroke stroke6 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis15.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean22 = dateAxis21.isTickMarksVisible();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis24.java2DToValue(0.0d, rectangle2D26, rectangleEdge27);
        dateAxis24.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        int int37 = categoryPlot35.getIndexOf(categoryItemRenderer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        categoryPlot35.setRenderer((int) (short) 10, categoryItemRenderer39, true);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = dateAxis43.valueToJava2D(10.0d, rectangle2D45, rectangleEdge46);
        dateAxis43.setAutoTickUnitSelection(true);
        categoryPlot35.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis43);
        java.awt.Font font51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot35.setNoDataMessageFont(font51);
        dateAxis24.setTickLabelFont(font51);
        org.jfree.data.Range range54 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range54);
        dateAxis21.setRange(range54, true, false);
        dateAxis15.setRange(range54, true, false);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis15);
        double double63 = dateAxis15.getUpperBound();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj2 = numberAxis1.clone();
        numberAxis1.setTickMarkOutsideLength((float) (byte) 1);
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isTickMarksVisible();
        boolean boolean3 = dateAxis1.isInverted();
        dateAxis1.setFixedAutoRange((double) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        int int9 = categoryAxis7.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        java.util.Date date19 = dateAxis12.getMaximumDate();
        dateAxis12.setTickMarkInsideLength((float) ' ');
        double double22 = dateAxis12.getAutoRangeMinimumSize();
        float float23 = dateAxis12.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = dateAxis27.valueToJava2D(10.0d, rectangle2D29, rectangleEdge30);
        dateAxis27.setAutoTickUnitSelection(true);
        java.util.Date date34 = dateAxis27.getMaximumDate();
        dateAxis25.setMinimumDate(date34);
        double double36 = dateAxis25.getUpperBound();
        java.awt.Font font37 = dateAxis25.getLabelFont();
        dateAxis25.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer40);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker43.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean47 = valueMarker43.equals((java.lang.Object) rectangleInsets46);
        boolean boolean48 = xYPlot41.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker43);
        boolean boolean49 = xYPlot41.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot41.getRangeAxisLocation();
        categoryAxis7.setPlot((org.jfree.chart.plot.Plot) xYPlot41);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot41);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 32.0f + "'", float23 == 32.0f);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        dateAxis1.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot19.getDomainAxis();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color21, paint22, paint23 };
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str26 = color25.toString();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color25, paint27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape31, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray28, strokeArray29, strokeArray30, shapeArray33);
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        java.awt.Shape shape36 = defaultDrawingSupplier34.getNextShape();
        dateAxis1.setRightArrow(shape36);
        dateAxis1.setAutoRangeMinimumSize(10.0d);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getUpperBound();
        dateAxis41.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = dateAxis46.valueToJava2D(10.0d, rectangle2D48, rectangleEdge49);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis46.getStandardTickUnits();
        dateAxis41.setStandardTickUnits(tickUnitSource51);
        dateAxis41.setAutoRangeMinimumSize((double) 100);
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis41.setLeftArrow(shape55);
        dateAxis1.setRightArrow(shape55);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str26.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot31.getRenderer();
        xYPlot31.mapDatasetToDomainAxis((-2), 0);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot31.getDomainAxis(3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        categoryPlot4.clearDomainMarkers();
        float float17 = categoryPlot4.getBackgroundImageAlpha();
        categoryPlot4.mapDatasetToRangeAxis(2, 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot4.notifyListeners(plotChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(0, categoryDataset10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = categoryPlot4.getDrawingSupplier();
        categoryPlot4.setOutlineVisible(true);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(drawingSupplier12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList();
        boolean boolean5 = objectList3.equals((java.lang.Object) 100L);
        int int6 = objectList3.size();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) objectList3);
        objectList3.clear();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        dateAxis1.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot19.getDomainAxis();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray24 = new java.awt.Paint[] { color21, paint22, paint23 };
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str26 = color25.toString();
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray28 = new java.awt.Paint[] { color25, paint27 };
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] {};
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape31, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray24, paintArray28, strokeArray29, strokeArray30, shapeArray33);
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34);
        java.awt.Shape shape36 = defaultDrawingSupplier34.getNextShape();
        dateAxis1.setRightArrow(shape36);
        dateAxis1.setAutoRangeMinimumSize(10.0d);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        double double42 = dateAxis41.getUpperBound();
        dateAxis41.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = dateAxis46.valueToJava2D(10.0d, rectangle2D48, rectangleEdge49);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis46.getStandardTickUnits();
        dateAxis41.setStandardTickUnits(tickUnitSource51);
        dateAxis41.setAutoRangeMinimumSize((double) 100);
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis41.setLeftArrow(shape55);
        dateAxis1.setDownArrow(shape55);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paintArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str26.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paintArray28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot31.getDomainAxisForDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = valueMarker56.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot62.setRenderers(categoryItemRendererArray69);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        categoryPlot62.setDomainAxisLocation(axisLocation71, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType76 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str77 = lengthAdjustmentType76.toString();
        boolean boolean78 = axisLocation71.equals((java.lang.Object) lengthAdjustmentType76);
        valueMarker56.setLabelOffsetType(lengthAdjustmentType76);
        valueMarker56.setValue(10.0d);
        java.awt.Color color82 = java.awt.Color.magenta;
        boolean boolean83 = valueMarker56.equals((java.lang.Object) color82);
        xYPlot31.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType85 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean87 = chartChangeEventType85.equals((java.lang.Object) lengthAdjustmentType86);
        valueMarker56.setLabelOffsetType(lengthAdjustmentType86);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(valueAxis54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "NO_CHANGE" + "'", str77.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType85);
        org.junit.Assert.assertNotNull(lengthAdjustmentType86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 8, jFreeChart1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis(9, categoryAxis17, true);
        java.awt.Paint paint20 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot4.getDomainAxisLocation();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot4.setDomainGridlineStroke(stroke22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        xYPlot31.clearRangeMarkers(500);
        xYPlot31.setWeight((int) '4');
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) '4', font13);
        int int15 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLabelAngle((double) (-1));
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis19.configure();
        categoryAxis19.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = categoryAxis19.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getUpperBound();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot10.getIndexOf(categoryItemRenderer11);
        int int13 = categoryPlot10.getDomainAxisCount();
        categoryPlot10.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot10.setBackgroundImageAlignment(12);
        int int19 = categoryPlot10.getDatasetCount();
        java.util.List list20 = categoryPlot10.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot10.getRangeAxisForDataset(1);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot10.getRangeAxisEdge();
        try {
            double double24 = dateAxis1.lengthToJava2D((double) 128, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        double double15 = categoryPlot4.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = categoryPlot4.getDrawingSupplier();
        java.awt.Paint paint17 = categoryPlot4.getOutlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        dateAxis3.setAutoTickUnitSelection(false, false);
        java.lang.Object obj9 = dateAxis3.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        int int12 = categoryPlot11.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis(0);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot19.getAxisOffset();
        java.awt.Stroke stroke21 = categoryPlot19.getDomainGridlineStroke();
        categoryPlot11.setOutlineStroke(stroke21);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.java2DToValue(0.0d, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape8 = dateAxis3.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        java.util.Date date12 = dateAxis3.getMaximumDate();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        java.awt.Image image10 = categoryPlot4.getBackgroundImage();
        categoryPlot4.setRangeCrosshairValue((-1.0d), true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot4.setDataset(categoryDataset14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot4.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes(100.0d, (double) (-1.0f), plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        float float14 = categoryAxis13.getMaximumCategoryLabelWidthRatio();
        int int15 = categoryAxis13.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis18.valueToJava2D(10.0d, rectangle2D20, rectangleEdge21);
        dateAxis18.setAutoTickUnitSelection(true);
        java.util.Date date25 = dateAxis18.getMaximumDate();
        dateAxis18.setTickMarkInsideLength((float) ' ');
        double double28 = dateAxis18.getAutoRangeMinimumSize();
        float float29 = dateAxis18.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = dateAxis33.valueToJava2D(10.0d, rectangle2D35, rectangleEdge36);
        dateAxis33.setAutoTickUnitSelection(true);
        java.util.Date date40 = dateAxis33.getMaximumDate();
        dateAxis31.setMinimumDate(date40);
        double double42 = dateAxis31.getUpperBound();
        java.awt.Font font43 = dateAxis31.getLabelFont();
        dateAxis31.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer46);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker49.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean53 = valueMarker49.equals((java.lang.Object) rectangleInsets52);
        boolean boolean54 = xYPlot47.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker49);
        boolean boolean55 = xYPlot47.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot47.getRangeAxisLocation();
        categoryAxis13.setPlot((org.jfree.chart.plot.Plot) xYPlot47);
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot47.getRangeAxisLocation(0);
        categoryPlot4.setDomainAxisLocation(axisLocation59);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 32.0f + "'", float29 == 32.0f);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot5.getIndexOf(categoryItemRenderer6);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot5.setRangeAxes(valueAxisArray8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot5.setDomainAxes(categoryAxisArray10);
        boolean boolean12 = textAnchor0.equals((java.lang.Object) categoryAxisArray10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        int int59 = xYPlot31.getRangeAxisCount();
        boolean boolean60 = xYPlot31.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getComponents(floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray7);
        float[] floatArray9 = color1.getRGBColorComponents(floatArray8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke10);
        float float12 = valueMarker11.getAlpha();
        valueMarker11.setLabel("");
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker11.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Paint paint2 = dateAxis1.getTickMarkPaint();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis4.setMinimumDate(date13);
        dateAxis1.setMinimumDate(date13);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis19.valueToJava2D(10.0d, rectangle2D21, rectangleEdge22);
        dateAxis19.setAutoTickUnitSelection(true);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        dateAxis19.setTickMarkInsideLength((float) ' ');
        double double29 = dateAxis19.getAutoRangeMinimumSize();
        float float30 = dateAxis19.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = dateAxis34.valueToJava2D(10.0d, rectangle2D36, rectangleEdge37);
        dateAxis34.setAutoTickUnitSelection(true);
        java.util.Date date41 = dateAxis34.getMaximumDate();
        dateAxis32.setMinimumDate(date41);
        double double43 = dateAxis32.getUpperBound();
        java.awt.Font font44 = dateAxis32.getLabelFont();
        dateAxis32.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer47);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker50.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean54 = valueMarker50.equals((java.lang.Object) rectangleInsets53);
        boolean boolean55 = xYPlot48.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
        boolean boolean56 = xYPlot48.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = dateAxis58.valueToJava2D(10.0d, rectangle2D60, rectangleEdge61);
        dateAxis58.setAutoTickUnitSelection(true);
        java.util.Date date65 = dateAxis58.getMaximumDate();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis58.setTimeZone(timeZone66);
        java.awt.Font font68 = dateAxis58.getTickLabelFont();
        xYPlot48.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis58);
        double double70 = xYPlot48.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = xYPlot48.getAxisOffset();
        int int72 = xYPlot48.getDomainAxisCount();
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.data.category.CategoryDataset categoryDataset74 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = null;
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer77 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, categoryAxis75, valueAxis76, categoryItemRenderer77);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        int int80 = categoryPlot78.getIndexOf(categoryItemRenderer79);
        int int81 = categoryPlot78.getDomainAxisCount();
        categoryPlot78.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot78.setBackgroundImageAlignment(12);
        int int87 = categoryPlot78.getDatasetCount();
        categoryPlot78.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = categoryPlot78.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace90 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace91 = dateAxis1.reserveSpace(graphics2D16, (org.jfree.chart.plot.Plot) xYPlot48, rectangle2D73, rectangleEdge89, axisSpace90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 32.0f + "'", float30 == 32.0f);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge89);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.java2DToValue(0.0d, rectangle2D63, rectangleEdge64);
        java.awt.Shape shape66 = dateAxis61.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis61.getLabelInsets();
        java.awt.Stroke stroke68 = dateAxis61.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        dateAxis61.setRightArrow(shape75);
        xYPlot31.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        java.util.Date date79 = dateAxis61.getMinimumDate();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertNotNull(date79);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        double double13 = categoryPlot4.getAnchorValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot4.setRenderer(categoryItemRenderer14, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color23, paint24, paint25 };
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str28 = color27.toString();
        java.awt.Paint paint29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color27, paint29 };
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] {};
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape33, shape34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray26, paintArray30, strokeArray31, strokeArray32, shapeArray35);
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        categoryPlot21.markerChanged(markerChangeEvent38);
        java.awt.Stroke stroke40 = categoryPlot21.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        int int47 = categoryPlot45.getIndexOf(categoryItemRenderer46);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray48 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot45.setRangeAxes(valueAxisArray48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot45.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        categoryPlot45.rendererChanged(rendererChangeEvent52);
        java.lang.String str54 = categoryPlot45.getPlotType();
        boolean boolean55 = categoryPlot45.isRangeCrosshairVisible();
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot45.setDomainGridlineStroke(stroke56);
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot45.getRangeAxisLocation(9);
        org.jfree.chart.util.Layer layer60 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, categoryItemRenderer64);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = categoryPlot65.getAxisOffset();
        java.awt.Stroke stroke67 = categoryPlot65.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = dateAxis69.java2DToValue(0.0d, rectangle2D71, rectangleEdge72);
        java.awt.Shape shape74 = dateAxis69.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = dateAxis69.getLabelInsets();
        categoryPlot65.setInsets(rectangleInsets75, false);
        java.awt.Image image78 = null;
        categoryPlot65.setBackgroundImage(image78);
        boolean boolean80 = layer60.equals((java.lang.Object) categoryPlot65);
        java.util.Collection collection81 = categoryPlot45.getDomainMarkers(layer60);
        java.util.Collection collection82 = categoryPlot21.getRangeMarkers(layer60);
        java.util.Collection collection83 = categoryPlot4.getRangeMarkers(layer60);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str28.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray48);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Category Plot" + "'", str54.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(layer60);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(collection81);
        org.junit.Assert.assertNotNull(collection82);
        org.junit.Assert.assertNotNull(collection83);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot31.getAxisOffset();
        org.jfree.chart.plot.IntervalMarker intervalMarker57 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList58 = new org.jfree.chart.util.ObjectList();
        boolean boolean60 = objectList58.equals((java.lang.Object) 100L);
        int int61 = objectList58.size();
        boolean boolean62 = intervalMarker57.equals((java.lang.Object) objectList58);
        double double63 = intervalMarker57.getEndValue();
        intervalMarker57.setLabel("java.awt.Color[r=0,g=0,b=128]");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer66 = null;
        intervalMarker57.setGradientPaintTransformer(gradientPaintTransformer66);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker57, layer68);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 11.0d + "'", double63 == 11.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        int int32 = xYPlot31.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot31.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(valueAxis33);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        boolean boolean33 = xYPlot31.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = valueMarker35.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str38 = rectangleInsets37.toString();
        valueMarker35.setLabelOffset(rectangleInsets37);
        xYPlot31.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        float float41 = valueMarker35.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor42 = valueMarker35.getLabelTextAnchor();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str38.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.8f + "'", float41 == 0.8f);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        int int28 = categoryPlot26.getIndexOf(categoryItemRenderer27);
        int int29 = categoryPlot26.getDomainAxisCount();
        categoryPlot26.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot26.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot26.getLegendItems();
        categoryPlot4.setFixedLegendItems(legendItemCollection35);
        try {
            categoryPlot4.mapDatasetToRangeAxis((int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.configureRangeAxes();
        java.lang.String str93 = xYPlot31.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNull(str93);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone1);
        java.lang.String str3 = dateAxis2.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color4, paint5, paint6 };
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str9 = color8.toString();
        java.awt.Paint paint10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, paint10 };
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape14, shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray11, strokeArray12, strokeArray13, shapeArray16);
        java.lang.Class<?> wildcardClass18 = strokeArray13.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis24.valueToJava2D(10.0d, rectangle2D26, rectangleEdge27);
        dateAxis24.setAutoTickUnitSelection(true);
        java.util.Date date31 = dateAxis24.getMaximumDate();
        dateAxis22.setMinimumDate(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date31, timeZone33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date31, timeZone35);
        dateAxis2.setMinimumDate(date31);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str9.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        categoryPlot4.setNoDataMessage("");
        java.lang.String str9 = categoryPlot4.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxis(12);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Category Plot" + "'", str9.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        dateAxis1.setLabel("");
        java.util.Date date9 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot35.getRangeAxisLocation(0);
        boolean boolean48 = xYPlot35.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder49 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str50 = datasetRenderingOrder49.toString();
        java.lang.Object obj51 = null;
        boolean boolean52 = datasetRenderingOrder49.equals(obj51);
        xYPlot35.setDatasetRenderingOrder(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str50.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color1, paint2, paint3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str6 = color5.toString();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color5, paint7 };
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray10 = new java.awt.Stroke[] {};
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray13 = new java.awt.Shape[] { shape11, shape12 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray8, strokeArray9, strokeArray10, shapeArray13);
        java.awt.Stroke[] strokeArray15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot21.setBackgroundImageAlignment(12);
        int int30 = categoryPlot21.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot21.setDomainAxis(9, categoryAxis34, true);
        java.awt.Paint paint37 = categoryPlot21.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot21.getDomainAxisLocation();
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot21.setDomainGridlineStroke(stroke39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] { stroke16, stroke39, stroke41 };
        java.awt.Shape[] shapeArray43 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier44 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray8, strokeArray15, strokeArray42, shapeArray43);
        java.awt.Paint[] paintArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray46 = null;
        java.awt.Stroke[] strokeArray47 = null;
        java.awt.Shape[] shapeArray48 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray45, strokeArray46, strokeArray47, shapeArray48);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str6.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shapeArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shapeArray43);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(shapeArray48);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot31.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot31.getOrientation();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot31.setDomainGridlineStroke(stroke34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        xYPlot31.setRenderer(11, xYItemRenderer37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot31.setFixedRangeAxisSpace(axisSpace39, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        java.lang.Object obj7 = categoryPlot4.clone();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray15 = null;
        float[] floatArray16 = color14.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray16);
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke19);
        float float21 = valueMarker20.getAlpha();
        boolean boolean22 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        java.awt.Stroke stroke23 = categoryPlot4.getOutlineStroke();
        int int24 = categoryPlot4.getRangeAxisCount();
        categoryPlot4.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = regularTimePeriod2.getMiddleMillisecond();
//        java.util.Date date4 = regularTimePeriod2.getStart();
//        org.jfree.chart.JFreeChart jFreeChart5 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date4, jFreeChart5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560538799999L + "'", long3 == 1560538799999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 10.0d, dataset12);
        categoryPlot4.datasetChanged(datasetChangeEvent13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        int int22 = categoryPlot20.getIndexOf(categoryItemRenderer21);
        int int23 = categoryPlot20.getDomainAxisCount();
        categoryPlot20.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray27 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation30);
        categoryPlot20.setDomainAxisLocation(axisLocation29, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str35 = lengthAdjustmentType34.toString();
        boolean boolean36 = axisLocation29.equals((java.lang.Object) lengthAdjustmentType34);
        categoryPlot4.setDomainAxisLocation(0, axisLocation29, true);
        categoryPlot4.clearDomainMarkers(128);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "NO_CHANGE" + "'", str35.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        xYPlot31.setDomainCrosshairValue((double) 10.0f);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        int int42 = categoryPlot40.getIndexOf(categoryItemRenderer41);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray43 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot40.setRangeAxes(valueAxisArray43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot40.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation46 = axisLocation45.getOpposite();
        xYPlot31.setDomainAxisLocation((int) (byte) 0, axisLocation45, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray43);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.valueToJava2D(10.0d, rectangle2D5, rectangleEdge6);
        dateAxis3.setAutoTickUnitSelection(true);
        java.util.Date date10 = dateAxis3.getMaximumDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        categoryMarker1.setKey((java.lang.Comparable) day11);
        java.lang.Comparable comparable13 = categoryMarker1.getKey();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        xYPlot31.clearRangeMarkers();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot31.setRenderer(xYItemRenderer34);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getComponents(floatArray5);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray11 = null;
        float[] floatArray12 = color10.getComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray12);
        float[] floatArray14 = color4.getRGBComponents(floatArray13);
        float[] floatArray15 = color3.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color0.getColorComponents(floatArray15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getOutlinePaint();
        java.awt.Paint paint6 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer(500, categoryItemRenderer8, true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis17.setTickMarkInsideLength((float) ' ');
        double double27 = dateAxis17.getAutoRangeMinimumSize();
        float float28 = dateAxis17.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = dateAxis32.valueToJava2D(10.0d, rectangle2D34, rectangleEdge35);
        dateAxis32.setAutoTickUnitSelection(true);
        java.util.Date date39 = dateAxis32.getMaximumDate();
        dateAxis30.setMinimumDate(date39);
        double double41 = dateAxis30.getUpperBound();
        java.awt.Font font42 = dateAxis30.getLabelFont();
        dateAxis30.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer45);
        java.awt.geom.Point2D point2D47 = xYPlot46.getQuadrantOrigin();
        xYPlot46.setDomainCrosshairValue((double) (-2), false);
        java.awt.Stroke stroke51 = xYPlot46.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis53 = xYPlot46.getDomainAxis(2019);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot62.setRenderers(categoryItemRendererArray69);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        categoryPlot62.setDomainAxisLocation(axisLocation71, false);
        java.awt.Paint paint76 = categoryPlot62.getOutlinePaint();
        categoryAxis56.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint76);
        double double78 = categoryAxis56.getCategoryMargin();
        categoryAxis56.configure();
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean82 = numberAxis81.isInverted();
        boolean boolean83 = categoryAxis56.equals((java.lang.Object) numberAxis81);
        java.text.NumberFormat numberFormat84 = null;
        numberAxis81.setNumberFormatOverride(numberFormat84);
        numberAxis81.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat88 = numberAxis81.getNumberFormatOverride();
        java.awt.Paint paint89 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean90 = numberAxis81.equals((java.lang.Object) paint89);
        double double91 = numberAxis81.getUpperBound();
        numberAxis81.configure();
        numberAxis81.setInverted(false);
        xYPlot46.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis81);
        boolean boolean96 = dateAxis1.equals((java.lang.Object) xYPlot46);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 32.0f + "'", float28 == 32.0f);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(valueAxis53);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.2d + "'", double78 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(numberFormat88);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 1.0d + "'", double91 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo7, point2D8, true);
        categoryPlot0.clearAnnotations();
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace14);
        categoryPlot4.mapDatasetToDomainAxis(6, 31);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot4.notifyListeners(plotChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(0, categoryDataset10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot16.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot16.getRowRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot24.getDomainAxis();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color26, paint27, paint28 };
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str31 = color30.toString();
        java.awt.Paint paint32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color30, paint32 };
        java.awt.Stroke[] strokeArray34 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray35 = new java.awt.Stroke[] {};
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray38 = new java.awt.Shape[] { shape36, shape37 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray29, paintArray33, strokeArray34, strokeArray35, shapeArray38);
        categoryPlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryPlot24.markerChanged(markerChangeEvent41);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot24.getRowRenderingOrder();
        categoryPlot16.setRowRenderingOrder(sortOrder43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot16.getDomainAxisLocation(11);
        categoryPlot4.setDomainAxisLocation(axisLocation46, false);
        org.jfree.chart.util.SortOrder sortOrder49 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setColumnRenderingOrder(sortOrder49);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str31.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(strokeArray34);
        org.junit.Assert.assertNotNull(strokeArray35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shapeArray38);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(sortOrder49);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = dateAxis33.java2DToValue(0.0d, rectangle2D35, rectangleEdge36);
        dateAxis33.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot44.getIndexOf(categoryItemRenderer45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        categoryPlot44.setRenderer((int) (short) 10, categoryItemRenderer48, true);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = dateAxis52.valueToJava2D(10.0d, rectangle2D54, rectangleEdge55);
        dateAxis52.setAutoTickUnitSelection(true);
        categoryPlot44.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis52);
        java.awt.Font font60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot44.setNoDataMessageFont(font60);
        dateAxis33.setTickLabelFont(font60);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range63);
        java.lang.Object obj65 = dateAxis33.clone();
        boolean boolean66 = dateAxis33.isNegativeArrowVisible();
        int int67 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        xYPlot31.setRenderer(255, xYItemRenderer69, true);
        org.jfree.chart.axis.AxisSpace axisSpace72 = xYPlot31.getFixedRangeAxisSpace();
        int int73 = xYPlot31.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNull(axisSpace72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder32 = xYPlot31.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot31.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot38.getAxisOffset();
        xYPlot31.setInsets(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(seriesRenderingOrder32);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        java.awt.Paint paint22 = categoryPlot4.getBackgroundPaint();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis26.valueToJava2D(10.0d, rectangle2D28, rectangleEdge29);
        dateAxis26.setAutoTickUnitSelection(true);
        java.util.Date date33 = dateAxis26.getMaximumDate();
        dateAxis26.setTickMarkInsideLength((float) ' ');
        double double36 = dateAxis26.getAutoRangeMinimumSize();
        float float37 = dateAxis26.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        dateAxis39.setMinimumDate(date48);
        double double50 = dateAxis39.getUpperBound();
        java.awt.Font font51 = dateAxis39.getLabelFont();
        dateAxis39.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer54);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.java2DToValue(0.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setInverted(false);
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, categoryAxis65, valueAxis66, categoryItemRenderer67);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        int int70 = categoryPlot68.getIndexOf(categoryItemRenderer69);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        categoryPlot68.setRenderer((int) (short) 10, categoryItemRenderer72, true);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        double double80 = dateAxis76.valueToJava2D(10.0d, rectangle2D78, rectangleEdge79);
        dateAxis76.setAutoTickUnitSelection(true);
        categoryPlot68.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis76);
        java.awt.Font font84 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot68.setNoDataMessageFont(font84);
        dateAxis57.setTickLabelFont(font84);
        org.jfree.data.Range range87 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis57.setRange(range87);
        java.lang.Object obj89 = dateAxis57.clone();
        boolean boolean90 = dateAxis57.isNegativeArrowVisible();
        int int91 = xYPlot55.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis57);
        boolean boolean92 = dateAxis57.isAutoRange();
        categoryPlot4.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 32.0f + "'", float37 == 32.0f);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(font84);
        org.junit.Assert.assertNotNull(range87);
        org.junit.Assert.assertNotNull(obj89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        xYPlot31.clearRangeMarkers(500);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = dateAxis56.valueToJava2D(10.0d, rectangle2D58, rectangleEdge59);
        dateAxis56.resizeRange((double) (short) 10, 0.0d);
        int int64 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        boolean boolean65 = xYPlot31.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        java.util.List list14 = categoryPlot4.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot4.getRangeAxisForDataset(1);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot4.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot4.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateLeftInset(8.0d);
        double double5 = rectangleInsets0.calculateBottomInset((double) 500);
        double double7 = rectangleInsets0.extendHeight(9.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.0d + "'", double7 == 9.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot4.getDomainMarkers(layer11);
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        int int23 = categoryPlot21.getIndexOf(categoryItemRenderer22);
        int int24 = categoryPlot21.getDomainAxisCount();
        categoryPlot21.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot21.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot21.addDomainMarker(categoryMarker32);
        org.jfree.chart.util.Layer layer34 = null;
        categoryPlot4.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer34, false);
        categoryPlot4.setRangeCrosshairValue((double) 500, false);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryPlot4.setRangeCrosshairPaint((java.awt.Paint) color40);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str1 = categoryAnchor0.toString();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis5.valueToJava2D(10.0d, rectangle2D7, rectangleEdge8);
        dateAxis5.setAutoTickUnitSelection(true);
        java.util.Date date12 = dateAxis5.getMaximumDate();
        dateAxis3.setMinimumDate(date12);
        double double14 = dateAxis3.getUpperBound();
        java.awt.Font font15 = dateAxis3.getLabelFont();
        dateAxis3.setTickMarkOutsideLength((float) (byte) 1);
        java.awt.Paint paint18 = dateAxis3.getLabelPaint();
        boolean boolean19 = categoryAnchor0.equals((java.lang.Object) dateAxis3);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.START" + "'", str1.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateLeftInset(8.0d);
        double double5 = rectangleInsets0.calculateBottomInset((double) 500);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        dateAxis3.setAutoTickUnitSelection(false, false);
        java.lang.Object obj9 = dateAxis3.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        valueAxis12.setRightArrow(shape13);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(valueAxis12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.java2DToValue(0.0d, rectangle2D5, rectangleEdge6);
        java.awt.Shape shape8 = dateAxis3.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis3.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot11.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(valueAxis12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabel("");
        categoryPlot4.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis17, false);
        dateAxis17.setAutoRangeMinimumSize((double) (short) 100);
        java.text.DateFormat dateFormat24 = dateAxis17.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis26.java2DToValue(0.0d, rectangle2D28, rectangleEdge29);
        java.awt.Shape shape31 = dateAxis26.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = dateAxis26.getLabelInsets();
        java.awt.Stroke stroke33 = dateAxis26.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis35.java2DToValue(0.0d, rectangle2D37, rectangleEdge38);
        java.awt.Shape shape40 = dateAxis35.getUpArrow();
        dateAxis26.setRightArrow(shape40);
        dateAxis17.setDownArrow(shape40);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNull(dateFormat24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(shape40);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
//        double double8 = dateAxis4.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
//        java.awt.Shape shape9 = dateAxis4.getUpArrow();
//        int int10 = day0.compareTo((java.lang.Object) shape9);
//        int int11 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertNotNull(shape9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        double double6 = dateAxis5.getUpperBound();
        objectList0.set((int) (short) 1, (java.lang.Object) dateAxis5);
        dateAxis5.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat9 = null;
        dateAxis8.setDateFormatOverride(dateFormat9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot15.getAxisOffset();
        double double17 = rectangleInsets16.getTop();
        dateAxis8.setLabelInsets(rectangleInsets16);
        categoryPlot0.setAxisOffset(rectangleInsets16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot4.addChangeListener(plotChangeListener13);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = valueMarker16.getLabelOffsetType();
        valueMarker16.setValue((double) (-2));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.valueToJava2D(10.0d, rectangle2D24, rectangleEdge25);
        dateAxis22.setAutoTickUnitSelection(true);
        java.util.Date date29 = dateAxis22.getMaximumDate();
        dateAxis22.setTickMarkInsideLength((float) ' ');
        double double32 = dateAxis22.getAutoRangeMinimumSize();
        float float33 = dateAxis22.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = dateAxis37.valueToJava2D(10.0d, rectangle2D39, rectangleEdge40);
        dateAxis37.setAutoTickUnitSelection(true);
        java.util.Date date44 = dateAxis37.getMaximumDate();
        dateAxis35.setMinimumDate(date44);
        double double46 = dateAxis35.getUpperBound();
        java.awt.Font font47 = dateAxis35.getLabelFont();
        dateAxis35.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis35, xYItemRenderer50);
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker53.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean57 = valueMarker53.equals((java.lang.Object) rectangleInsets56);
        boolean boolean58 = xYPlot51.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker53);
        boolean boolean59 = xYPlot51.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.valueToJava2D(10.0d, rectangle2D63, rectangleEdge64);
        dateAxis61.setAutoTickUnitSelection(true);
        java.util.Date date68 = dateAxis61.getMaximumDate();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis61.setTimeZone(timeZone69);
        java.awt.Font font71 = dateAxis61.getTickLabelFont();
        xYPlot51.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis61);
        xYPlot51.clearRangeMarkers(500);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection76 = xYPlot51.getDomainMarkers(layer75);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer75);
        valueMarker16.setLabel("");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 32.0f + "'", float33 == 32.0f);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection76);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        java.util.List list14 = categoryPlot4.getAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot4.getRangeAxisForDataset(1);
        categoryPlot4.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        java.text.DateFormat dateFormat12 = null;
        dateAxis1.setDateFormatOverride(dateFormat12);
        java.text.DateFormat dateFormat14 = dateAxis1.getDateFormatOverride();
        dateAxis1.setRangeWithMargins(0.2d, (double) 2.0f);
        java.util.Date date18 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.java2DToValue(0.0d, rectangle2D22, rectangleEdge23);
        boolean boolean25 = dateAxis20.isPositiveArrowVisible();
        dateAxis20.setFixedAutoRange(1.0E-8d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = dateAxis29.valueToJava2D(10.0d, rectangle2D31, rectangleEdge32);
        dateAxis29.setAutoTickUnitSelection(true);
        java.util.Date date36 = dateAxis29.getMaximumDate();
        dateAxis29.resizeRange(100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis29.getTickUnit();
        java.util.Date date40 = dateAxis20.calculateHighestVisibleTickValue(dateTickUnit39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = dateAxis45.java2DToValue(0.0d, rectangle2D47, rectangleEdge48);
        java.awt.Shape shape50 = dateAxis45.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = dateAxis45.getLabelInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, categoryItemRenderer52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot53.getDomainAxisEdge();
        try {
            double double55 = dateAxis1.dateToJava2D(date40, rectangle2D41, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(dateFormat14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(rectangleEdge54);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        boolean boolean33 = xYPlot31.isDomainZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = valueMarker35.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str38 = rectangleInsets37.toString();
        valueMarker35.setLabelOffset(rectangleInsets37);
        xYPlot31.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder41 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color42, paint43, paint44 };
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str47 = color46.toString();
        java.awt.Paint paint48 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray49 = new java.awt.Paint[] { color46, paint48 };
        java.awt.Stroke[] strokeArray50 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray51 = new java.awt.Stroke[] {};
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape52, shape53 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray49, strokeArray50, strokeArray51, shapeArray54);
        boolean boolean57 = defaultDrawingSupplier55.equals((java.lang.Object) 1L);
        boolean boolean58 = seriesRenderingOrder41.equals((java.lang.Object) 1L);
        java.lang.String str59 = seriesRenderingOrder41.toString();
        xYPlot31.setSeriesRenderingOrder(seriesRenderingOrder41);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str38.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(seriesRenderingOrder41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str47.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(strokeArray50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str59.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat2 = null;
        dateAxis1.setDateFormatOverride(dateFormat2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot8.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        dateAxis1.setLabelInsets(rectangleInsets9);
        boolean boolean12 = dateAxis1.isTickMarksVisible();
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis16.java2DToValue(0.0d, rectangle2D18, rectangleEdge19);
        java.awt.Shape shape21 = dateAxis16.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis16.getLabelInsets();
        java.awt.Stroke stroke23 = dateAxis16.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = dateAxis25.java2DToValue(0.0d, rectangle2D27, rectangleEdge28);
        java.awt.Shape shape30 = dateAxis25.getUpArrow();
        dateAxis16.setRightArrow(shape30);
        dateAxis1.setRightArrow(shape30);
        dateAxis1.setRangeWithMargins((double) 13, (double) 1560452399999L);
        dateAxis1.setLowerMargin((double) (short) 0);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        java.awt.Stroke stroke2 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray3 = new java.awt.Paint[] { color0, paint1, paint2 };
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str5 = color4.toString();
        java.awt.Paint paint6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color4, paint6 };
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] {};
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] {};
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray12 = new java.awt.Shape[] { shape10, shape11 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray7, strokeArray8, strokeArray9, shapeArray12);
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        java.awt.Paint paint15 = defaultDrawingSupplier13.getNextPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str5.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getRangeAxisLocation(0);
        org.jfree.chart.util.SortOrder sortOrder10 = null;
        try {
            categoryPlot4.setColumnRenderingOrder(sortOrder10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        valueMarker1.setValue((double) (-2));
        java.awt.Stroke stroke5 = valueMarker1.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat8 = null;
        dateAxis7.setDateFormatOverride(dateFormat8);
        dateAxis7.setAutoTickUnitSelection(false, false);
        java.awt.Paint paint13 = dateAxis7.getLabelPaint();
        valueMarker1.setOutlinePaint(paint13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis16.configure();
        categoryAxis16.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis21.configure();
        categoryAxis21.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = categoryAxis21.getCategoryLabelPositions();
        categoryAxis16.setCategoryLabelPositions(categoryLabelPositions25);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis16.setTickLabelFont((java.lang.Comparable) '4', font28);
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) (byte) 0);
        boolean boolean32 = valueMarker1.equals((java.lang.Object) categoryAxis16);
        try {
            valueMarker1.setAlpha((float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot5.getAxisOffset();
        categoryPlot0.setInsets(rectangleInsets6);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot0.removeChangeListener(plotChangeListener9);
        java.awt.Paint paint11 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder92 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str93 = datasetRenderingOrder92.toString();
        java.lang.Object obj94 = null;
        boolean boolean95 = datasetRenderingOrder92.equals(obj94);
        boolean boolean97 = datasetRenderingOrder92.equals((java.lang.Object) (short) 10);
        xYPlot31.setDatasetRenderingOrder(datasetRenderingOrder92);
        boolean boolean99 = xYPlot31.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder92);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str93.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Image image7 = null;
        categoryPlot4.setBackgroundImage(image7);
        java.awt.Stroke stroke9 = categoryPlot4.getRangeCrosshairStroke();
        java.awt.Image image10 = null;
        categoryPlot4.setBackgroundImage(image10);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        int int57 = color56.getGreen();
        xYPlot31.setRangeCrosshairPaint((java.awt.Paint) color56);
        java.awt.Stroke stroke59 = xYPlot31.getDomainGridlineStroke();
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryPlot66.getAxisOffset();
        java.awt.Stroke stroke68 = categoryPlot66.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        double double74 = dateAxis70.java2DToValue(0.0d, rectangle2D72, rectangleEdge73);
        java.awt.Shape shape75 = dateAxis70.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = dateAxis70.getLabelInsets();
        categoryPlot66.setInsets(rectangleInsets76, false);
        java.awt.Image image79 = null;
        categoryPlot66.setBackgroundImage(image79);
        boolean boolean81 = layer61.equals((java.lang.Object) categoryPlot66);
        java.util.Collection collection82 = xYPlot31.getDomainMarkers(500, layer61);
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = xYPlot31.getInsets();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        java.awt.geom.Point2D point2D86 = null;
        xYPlot31.zoomDomainAxes((double) 0L, plotRenderingInfo85, point2D86);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(shape75);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertNotNull(rectangleInsets83);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.setTickMarkInsideLength((float) ' ');
        double double11 = dateAxis1.getAutoRangeMinimumSize();
        float float12 = dateAxis1.getTickMarkInsideLength();
        boolean boolean13 = dateAxis1.isNegativeArrowVisible();
        dateAxis1.setInverted(false);
        dateAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 32.0f + "'", float12 == 32.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        xYPlot31.clearRangeMarkers(500);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = dateAxis56.valueToJava2D(10.0d, rectangle2D58, rectangleEdge59);
        dateAxis56.resizeRange((double) (short) 10, 0.0d);
        int int64 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        java.awt.Image image65 = null;
        xYPlot31.setBackgroundImage(image65);
        boolean boolean67 = xYPlot31.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat4 = null;
        dateAxis3.setDateFormatOverride(dateFormat4);
        dateAxis3.setAutoTickUnitSelection(false, false);
        java.lang.Object obj9 = dateAxis3.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer10);
        boolean boolean12 = dateAxis3.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker17.setLabel("hi!");
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = categoryPlot4.removeRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker17, layer20, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent11);
        java.lang.String str13 = categoryPlot4.getPlotType();
        boolean boolean14 = categoryPlot4.isRangeCrosshairVisible();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setDomainGridlineStroke(stroke15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot4.getDomainAxisLocation((int) (short) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot5.getIndexOf(categoryItemRenderer6);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot5.setRangeAxes(valueAxisArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot5.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        double double14 = categoryPlot5.getAnchorValue();
        categoryPlot5.clearRangeMarkers();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot5);
        java.lang.Object obj17 = plotChangeEvent16.getSource();
        boolean boolean18 = textAnchor0.equals(obj17);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone10);
        java.awt.Font font12 = dateAxis2.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat15 = null;
        dateAxis14.setDateFormatOverride(dateFormat15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot21.getAxisOffset();
        double double23 = rectangleInsets22.getTop();
        dateAxis14.setLabelInsets(rectangleInsets22);
        java.text.DateFormat dateFormat25 = null;
        dateAxis14.setDateFormatOverride(dateFormat25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer27);
        xYPlot28.clearDomainAxes();
        float float30 = xYPlot28.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.configure();
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis4.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
        java.awt.Shape shape9 = dateAxis4.getUpArrow();
        numberAxis1.setUpArrow(shape9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        java.lang.Object obj13 = numberAxis12.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit14, true, false);
        numberAxis1.setTickUnit(numberTickUnit14);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) (byte) 100);
        categoryPlot4.setDomainGridlinesVisible(false);
        boolean boolean13 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot4.getDomainAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis21.setTickMarkInsideLength((float) ' ');
        double double31 = dateAxis21.getAutoRangeMinimumSize();
        float float32 = dateAxis21.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = dateAxis36.valueToJava2D(10.0d, rectangle2D38, rectangleEdge39);
        dateAxis36.setAutoTickUnitSelection(true);
        java.util.Date date43 = dateAxis36.getMaximumDate();
        dateAxis34.setMinimumDate(date43);
        double double45 = dateAxis34.getUpperBound();
        java.awt.Font font46 = dateAxis34.getLabelFont();
        dateAxis34.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer49);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker52.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean56 = valueMarker52.equals((java.lang.Object) rectangleInsets55);
        boolean boolean57 = xYPlot50.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker52);
        boolean boolean58 = xYPlot50.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot50.getRangeAxisLocation();
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation59);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 32.0f + "'", float32 == 32.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 12, jFreeChart1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = dateAxis47.java2DToValue(0.0d, rectangle2D49, rectangleEdge50);
        boolean boolean52 = dateAxis47.isPositiveArrowVisible();
        dateAxis47.setLabelURL("");
        org.jfree.data.Range range55 = xYPlot35.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day56.next();
        java.util.Date date59 = regularTimePeriod58.getStart();
        dateAxis47.setMinimumDate(date59);
        dateAxis47.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(range55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot4.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = dateAxis15.java2DToValue(0.0d, rectangle2D17, rectangleEdge18);
        boolean boolean20 = dateAxis15.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.java2DToValue(0.0d, rectangle2D24, rectangleEdge25);
        boolean boolean27 = dateAxis22.isPositiveArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = dateAxis22.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean31 = dateAxis30.isTickMarksVisible();
        boolean boolean32 = dateAxis30.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = dateAxis34.valueToJava2D(10.0d, rectangle2D36, rectangleEdge37);
        dateAxis34.setAutoTickUnitSelection(true);
        java.util.Date date41 = dateAxis34.getMaximumDate();
        dateAxis34.setFixedDimension(0.0d);
        dateAxis34.setVerticalTickLabels(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray46 = new org.jfree.chart.axis.ValueAxis[] { dateAxis15, dateAxis22, dateAxis30, dateAxis34 };
        categoryPlot4.setRangeAxes(valueAxisArray46);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot4.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(tickUnitSource28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(valueAxisArray46);
        org.junit.Assert.assertNotNull(categoryAnchor48);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat33 = numberAxis26.getNumberFormatOverride();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        boolean boolean35 = numberAxis26.equals((java.lang.Object) paint34);
        double double36 = numberAxis26.getUpperBound();
        numberAxis26.configure();
        numberAxis26.setInverted(false);
        numberAxis26.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(numberFormat33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot4.setRenderer((int) (short) 10, categoryItemRenderer8, true);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.valueToJava2D(10.0d, rectangle2D14, rectangleEdge15);
        dateAxis12.setAutoTickUnitSelection(true);
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateAxis12, dataset20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str4 = rectangleInsets3.toString();
        valueMarker1.setLabelOffset(rectangleInsets3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str4.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = datasetRenderingOrder0.equals(obj2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = dateAxis45.valueToJava2D(10.0d, rectangle2D47, rectangleEdge48);
        dateAxis45.setAutoTickUnitSelection(true);
        java.util.Date date52 = dateAxis45.getMaximumDate();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis45.setTimeZone(timeZone53);
        java.awt.Font font55 = dateAxis45.getTickLabelFont();
        xYPlot35.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        double double57 = xYPlot35.getDomainCrosshairValue();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color60 = java.awt.Color.getColor("", color59);
        int int61 = color60.getGreen();
        xYPlot35.setRangeCrosshairPaint((java.awt.Paint) color60);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = dateAxis65.java2DToValue(0.0d, rectangle2D67, rectangleEdge68);
        java.awt.Shape shape70 = dateAxis65.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = dateAxis65.getLabelInsets();
        java.awt.Stroke stroke72 = dateAxis65.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = dateAxis74.java2DToValue(0.0d, rectangle2D76, rectangleEdge77);
        java.awt.Shape shape79 = dateAxis74.getUpArrow();
        dateAxis65.setRightArrow(shape79);
        xYPlot35.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) dateAxis65, true);
        boolean boolean83 = datasetRenderingOrder0.equals((java.lang.Object) dateAxis65);
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = dateAxis65.getTickUnit();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 128 + "'", int61 == 128);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dateTickUnit84);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        dateAxis1.resizeRange(100.0d);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = dateAxis1.getStandardTickUnits();
        dateAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(tickUnitSource11);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.lang.Object obj32 = xYPlot31.clone();
        xYPlot31.setDomainZeroBaselineVisible(true);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot31.setRangeZeroBaselineStroke(stroke35);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot28.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot28.setRenderer((int) (short) 10, categoryItemRenderer32, true);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = dateAxis36.valueToJava2D(10.0d, rectangle2D38, rectangleEdge39);
        dateAxis36.setAutoTickUnitSelection(true);
        categoryPlot28.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryPlot28.setNoDataMessageFont(font44);
        categoryAxis1.setLabelFont(font44);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 0.05d);
        java.awt.Font font50 = categoryAxis1.getTickLabelFont((java.lang.Comparable) "DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone10);
        java.awt.Font font12 = dateAxis2.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.text.DateFormat dateFormat15 = null;
        dateAxis14.setDateFormatOverride(dateFormat15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot21.getAxisOffset();
        double double23 = rectangleInsets22.getTop();
        dateAxis14.setLabelInsets(rectangleInsets22);
        java.text.DateFormat dateFormat25 = null;
        dateAxis14.setDateFormatOverride(dateFormat25);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer27);
        java.awt.Paint paint29 = xYPlot28.getRangeTickBandPaint();
        java.awt.Stroke stroke30 = xYPlot28.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot4.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        categoryPlot4.addDomainMarker(categoryMarker15);
        org.jfree.chart.text.TextAnchor textAnchor17 = categoryMarker15.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor18 = categoryMarker15.getLabelTextAnchor();
        java.awt.Paint paint19 = categoryMarker15.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.configure();
        categoryAxis6.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setUpperMargin((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis17.setTickMarkInsideLength((float) ' ');
        double double27 = dateAxis17.getAutoRangeMinimumSize();
        float float28 = dateAxis17.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = dateAxis32.valueToJava2D(10.0d, rectangle2D34, rectangleEdge35);
        dateAxis32.setAutoTickUnitSelection(true);
        java.util.Date date39 = dateAxis32.getMaximumDate();
        dateAxis30.setMinimumDate(date39);
        double double41 = dateAxis30.getUpperBound();
        java.awt.Font font42 = dateAxis30.getLabelFont();
        dateAxis30.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer45);
        java.awt.geom.Point2D point2D47 = xYPlot46.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = xYPlot46.getOrientation();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setDomainGridlineStroke(stroke49);
        categoryAxis1.setTickMarkStroke(stroke49);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 32.0f + "'", float28 == 32.0f);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        double double53 = xYPlot31.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot31.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot31.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        numberAxis26.setAutoRangeStickyZero(false);
        java.awt.Paint paint33 = numberAxis26.getTickLabelPaint();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        boolean boolean35 = numberAxis26.equals((java.lang.Object) paint34);
        org.jfree.data.RangeType rangeType36 = null;
        try {
            numberAxis26.setRangeType(rangeType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot4.setBackgroundImageAlignment(12);
        int int13 = categoryPlot4.getDatasetCount();
        categoryPlot4.clearRangeMarkers();
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 11.0f);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        boolean boolean20 = objectList18.equals((java.lang.Object) 100L);
        int int21 = objectList18.size();
        boolean boolean22 = intervalMarker17.equals((java.lang.Object) objectList18);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker17);
        java.lang.Object obj24 = intervalMarker17.clone();
        intervalMarker17.setStartValue((double) 10);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        int int33 = categoryPlot31.getIndexOf(categoryItemRenderer32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot31.setRangeAxes(valueAxisArray34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot31.getDomainAxis((int) (byte) 100);
        categoryPlot31.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot31.getRangeAxisEdge();
        java.awt.Paint paint41 = categoryPlot31.getRangeGridlinePaint();
        intervalMarker17.setOutlinePaint(paint41);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNull(categoryAxis37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D(10.0d, rectangle2D3, rectangleEdge4);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        double double11 = dateAxis10.getUpperBound();
        dateAxis10.setAutoTickUnitSelection(false);
        java.lang.Object obj14 = dateAxis10.clone();
        org.jfree.chart.axis.Timeline timeline15 = dateAxis10.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis17.resizeRange(100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis17.getTickUnit();
        java.util.Date date28 = dateAxis10.calculateHighestVisibleTickValue(dateTickUnit27);
        java.util.Date date29 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit27);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(timeline15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.java2DToValue(0.0d, rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = dateAxis1.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis1.getLabelInsets();
        dateAxis1.resizeRange(259.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot35.getFixedDomainAxisSpace();
        xYPlot35.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace49 = xYPlot35.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNull(axisSpace49);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot31.getDomainAxisForDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = valueMarker56.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        int int64 = categoryPlot62.getIndexOf(categoryItemRenderer63);
        int int65 = categoryPlot62.getDomainAxisCount();
        categoryPlot62.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot62.setRenderers(categoryItemRendererArray69);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        categoryPlot62.setDomainAxisLocation(axisLocation71, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType76 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str77 = lengthAdjustmentType76.toString();
        boolean boolean78 = axisLocation71.equals((java.lang.Object) lengthAdjustmentType76);
        valueMarker56.setLabelOffsetType(lengthAdjustmentType76);
        valueMarker56.setValue(10.0d);
        java.awt.Color color82 = java.awt.Color.magenta;
        boolean boolean83 = valueMarker56.equals((java.lang.Object) color82);
        xYPlot31.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        boolean boolean85 = xYPlot31.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(valueAxis54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray69);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "NO_CHANGE" + "'", str77.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.extendWidth(0.0d);
        double double4 = rectangleInsets0.getLeft();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        xYPlot31.setDomainCrosshairValue((double) (-2), false);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot31.getRangeAxisLocation(2);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        int int45 = categoryPlot43.getIndexOf(categoryItemRenderer44);
        java.lang.Object obj46 = categoryPlot43.clone();
        org.jfree.chart.axis.AxisSpace axisSpace47 = categoryPlot43.getFixedDomainAxisSpace();
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray54 = null;
        float[] floatArray55 = color53.getComponents(floatArray54);
        float[] floatArray56 = java.awt.Color.RGBtoHSB(15, (int) 'a', (int) (byte) 10, floatArray55);
        float[] floatArray57 = color49.getRGBColorComponents(floatArray56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color49, stroke58);
        float float60 = valueMarker59.getAlpha();
        boolean boolean61 = categoryPlot43.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker59);
        org.jfree.chart.util.Layer layer62 = null;
        try {
            xYPlot31.addDomainMarker((-1), (org.jfree.chart.plot.Marker) valueMarker59, layer62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 1.0f + "'", float60 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.lang.String str2 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str2.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.resizeRange(100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis2.getTickUnit();
        boolean boolean13 = rectangleAnchor0.equals((java.lang.Object) dateTickUnit12);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation16);
        float float22 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getLabelInsets();
        double double4 = rectangleInsets2.extendWidth((double) 1.0f);
        double double6 = rectangleInsets2.calculateTopInset((double) 0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot4.getIndexOf(categoryItemRenderer5);
        int int7 = categoryPlot4.getDomainAxisCount();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot4.setRenderer(categoryItemRenderer13, true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        boolean boolean3 = categoryPlot0.removeDomainMarker(marker1, layer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(6);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot0.getOrientation();
        categoryPlot0.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot31.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = valueMarker36.getLabelOffsetType();
        valueMarker36.setValue((double) (-2));
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        int int46 = categoryPlot44.getIndexOf(categoryItemRenderer45);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray47 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot44.setRangeAxes(valueAxisArray47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot44.getDomainAxis((int) (byte) 100);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
        categoryPlot44.rendererChanged(rendererChangeEvent51);
        java.lang.String str53 = categoryPlot44.getPlotType();
        boolean boolean54 = categoryPlot44.isRangeCrosshairVisible();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot44.setDomainGridlineStroke(stroke55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot44.getRangeAxisLocation(9);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryPlot64.getAxisOffset();
        java.awt.Stroke stroke66 = categoryPlot64.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = dateAxis68.java2DToValue(0.0d, rectangle2D70, rectangleEdge71);
        java.awt.Shape shape73 = dateAxis68.getUpArrow();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = dateAxis68.getLabelInsets();
        categoryPlot64.setInsets(rectangleInsets74, false);
        java.awt.Image image77 = null;
        categoryPlot64.setBackgroundImage(image77);
        boolean boolean79 = layer59.equals((java.lang.Object) categoryPlot64);
        java.util.Collection collection80 = categoryPlot44.getDomainMarkers(layer59);
        xYPlot31.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker36, layer59);
        java.lang.String str82 = valueMarker36.getLabel();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray47);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Category Plot" + "'", str53.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(collection80);
        org.junit.Assert.assertNull(str82);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
//        double double8 = dateAxis4.java2DToValue(0.0d, rectangle2D6, rectangleEdge7);
//        java.awt.Shape shape9 = dateAxis4.getUpArrow();
//        int int10 = day0.compareTo((java.lang.Object) shape9);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        int int12 = day0.getMonth();
//        long long13 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertNotNull(shape9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin((double) (short) 100);
        boolean boolean5 = categoryAxis1.isVisible();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        float float10 = categoryAxis9.getMaximumCategoryLabelWidthRatio();
        int int11 = categoryAxis9.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis14.valueToJava2D(10.0d, rectangle2D16, rectangleEdge17);
        dateAxis14.setAutoTickUnitSelection(true);
        java.util.Date date21 = dateAxis14.getMaximumDate();
        dateAxis14.setTickMarkInsideLength((float) ' ');
        double double24 = dateAxis14.getAutoRangeMinimumSize();
        float float25 = dateAxis14.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = dateAxis29.valueToJava2D(10.0d, rectangle2D31, rectangleEdge32);
        dateAxis29.setAutoTickUnitSelection(true);
        java.util.Date date36 = dateAxis29.getMaximumDate();
        dateAxis27.setMinimumDate(date36);
        double double38 = dateAxis27.getUpperBound();
        java.awt.Font font39 = dateAxis27.getLabelFont();
        dateAxis27.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker45.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean49 = valueMarker45.equals((java.lang.Object) rectangleInsets48);
        boolean boolean50 = xYPlot43.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker45);
        boolean boolean51 = xYPlot43.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot43.getRangeAxisLocation();
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) xYPlot43);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = dateAxis55.java2DToValue(0.0d, rectangle2D57, rectangleEdge58);
        boolean boolean60 = dateAxis55.isPositiveArrowVisible();
        dateAxis55.setLabelURL("");
        org.jfree.data.Range range63 = xYPlot43.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis55);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day64.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day64.next();
        java.util.Date date67 = regularTimePeriod66.getStart();
        dateAxis55.setMinimumDate(date67);
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, valueAxis71, categoryItemRenderer72);
        org.jfree.chart.plot.PlotOrientation plotOrientation74 = categoryPlot73.getOrientation();
        categoryPlot73.setRangeGridlinesVisible(false);
        java.awt.Paint paint77 = categoryPlot73.getRangeGridlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) date67, paint77);
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker83 = null;
        org.jfree.chart.util.Layer layer84 = null;
        boolean boolean85 = categoryPlot82.removeDomainMarker(marker83, layer84);
        org.jfree.chart.axis.ValueAxis valueAxis87 = categoryPlot82.getRangeAxisForDataset(6);
        int int88 = categoryPlot82.getBackgroundImageAlignment();
        boolean boolean89 = categoryPlot82.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = categoryPlot82.getRangeAxisEdge(15);
        try {
            double double92 = categoryAxis1.getCategoryMiddle((int) (byte) -1, 4, rectangle2D81, rectangleEdge91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 32.0f + "'", float25 == 32.0f);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(plotOrientation74);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(valueAxis87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 15 + "'", int88 == 15);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot31.getOrientation();
        boolean boolean34 = xYPlot31.isRangeZeroBaselineVisible();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot31.render(graphics2D35, rectangle2D36, 100, plotRenderingInfo38, crosshairState39);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        int int3 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D(10.0d, rectangle2D8, rectangleEdge9);
        dateAxis6.setAutoTickUnitSelection(true);
        java.util.Date date13 = dateAxis6.getMaximumDate();
        dateAxis6.setTickMarkInsideLength((float) ' ');
        double double16 = dateAxis6.getAutoRangeMinimumSize();
        float float17 = dateAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.valueToJava2D(10.0d, rectangle2D23, rectangleEdge24);
        dateAxis21.setAutoTickUnitSelection(true);
        java.util.Date date28 = dateAxis21.getMaximumDate();
        dateAxis19.setMinimumDate(date28);
        double double30 = dateAxis19.getUpperBound();
        java.awt.Font font31 = dateAxis19.getLabelFont();
        dateAxis19.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker37.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean41 = valueMarker37.equals((java.lang.Object) rectangleInsets40);
        boolean boolean42 = xYPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37);
        boolean boolean43 = xYPlot35.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot35.getRangeAxisLocation();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot35);
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = xYPlot35.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        int int54 = categoryPlot52.getIndexOf(categoryItemRenderer53);
        int int55 = categoryPlot52.getDomainAxisCount();
        categoryPlot52.setRangeCrosshairValue((double) (short) 100, false);
        categoryPlot52.setBackgroundImageAlignment(12);
        int int61 = categoryPlot52.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        categoryPlot52.setFixedRangeAxisSpace(axisSpace62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        categoryPlot52.setDomainAxis(9, categoryAxis65, true);
        java.awt.Paint paint68 = categoryPlot52.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot52.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot52.setDomainAxisLocation((int) (short) 0, axisLocation71, true);
        xYPlot35.setRangeAxisLocation(axisLocation71, false);
        xYPlot35.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 32.0f + "'", float17 == 32.0f);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(axisLocation71);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker33.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean37 = valueMarker33.equals((java.lang.Object) rectangleInsets36);
        boolean boolean38 = xYPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33);
        boolean boolean39 = xYPlot31.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis41.valueToJava2D(10.0d, rectangle2D43, rectangleEdge44);
        dateAxis41.setAutoTickUnitSelection(true);
        java.util.Date date48 = dateAxis41.getMaximumDate();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone49);
        java.awt.Font font51 = dateAxis41.getTickLabelFont();
        xYPlot31.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.valueToJava2D(10.0d, rectangle2D59, rectangleEdge60);
        dateAxis57.setAutoTickUnitSelection(true);
        java.util.Date date64 = dateAxis57.getMaximumDate();
        dateAxis57.setTickMarkInsideLength((float) ' ');
        double double67 = dateAxis57.getAutoRangeMinimumSize();
        float float68 = dateAxis57.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = dateAxis72.valueToJava2D(10.0d, rectangle2D74, rectangleEdge75);
        dateAxis72.setAutoTickUnitSelection(true);
        java.util.Date date79 = dateAxis72.getMaximumDate();
        dateAxis70.setMinimumDate(date79);
        double double81 = dateAxis70.getUpperBound();
        java.awt.Font font82 = dateAxis70.getLabelFont();
        dateAxis70.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = null;
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis70, xYItemRenderer85);
        java.awt.geom.Point2D point2D87 = xYPlot86.getQuadrantOrigin();
        xYPlot31.zoomRangeAxes((double) 15, plotRenderingInfo54, point2D87);
        boolean boolean89 = xYPlot31.isDomainCrosshairVisible();
        xYPlot31.setDomainZeroBaselineVisible(true);
        xYPlot31.configureRangeAxes();
        xYPlot31.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray95 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot31.setDomainAxes(valueAxisArray95);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 32.0f + "'", float68 == 32.0f);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.0d + "'", double81 == 2.0d);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(point2D87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(valueAxisArray95);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo2, point2D3, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis7.configure();
        categoryAxis7.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis12.configure();
        categoryAxis12.setLowerMargin((double) (short) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis7.setCategoryLabelPositions(categoryLabelPositions16);
        categoryAxis7.setLabelToolTip("java.awt.Color[r=0,g=0,b=255]");
        java.util.List list20 = categoryPlot0.getCategoriesForAxis(categoryAxis7);
        categoryPlot0.mapDatasetToDomainAxis(8, 31);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.valueToJava2D(10.0d, rectangle2D4, rectangleEdge5);
        dateAxis2.setAutoTickUnitSelection(true);
        java.util.Date date9 = dateAxis2.getMaximumDate();
        dateAxis2.setTickMarkInsideLength((float) ' ');
        double double12 = dateAxis2.getAutoRangeMinimumSize();
        float float13 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.valueToJava2D(10.0d, rectangle2D19, rectangleEdge20);
        dateAxis17.setAutoTickUnitSelection(true);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        dateAxis15.setMinimumDate(date24);
        double double26 = dateAxis15.getUpperBound();
        java.awt.Font font27 = dateAxis15.getLabelFont();
        dateAxis15.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer30);
        java.awt.geom.Point2D point2D32 = xYPlot31.getQuadrantOrigin();
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot31.getOrientation();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot31.setDomainGridlineStroke(stroke34);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis39.valueToJava2D(10.0d, rectangle2D41, rectangleEdge42);
        dateAxis39.setAutoTickUnitSelection(true);
        java.util.Date date46 = dateAxis39.getMaximumDate();
        dateAxis39.setTickMarkInsideLength((float) ' ');
        double double49 = dateAxis39.getAutoRangeMinimumSize();
        float float50 = dateAxis39.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis54.valueToJava2D(10.0d, rectangle2D56, rectangleEdge57);
        dateAxis54.setAutoTickUnitSelection(true);
        java.util.Date date61 = dateAxis54.getMaximumDate();
        dateAxis52.setMinimumDate(date61);
        double double63 = dateAxis52.getUpperBound();
        java.awt.Font font64 = dateAxis52.getLabelFont();
        dateAxis52.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis52, xYItemRenderer67);
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker70.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean74 = valueMarker70.equals((java.lang.Object) rectangleInsets73);
        boolean boolean75 = xYPlot68.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker70);
        boolean boolean76 = xYPlot68.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = dateAxis78.valueToJava2D(10.0d, rectangle2D80, rectangleEdge81);
        dateAxis78.setAutoTickUnitSelection(true);
        java.util.Date date85 = dateAxis78.getMaximumDate();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis78.setTimeZone(timeZone86);
        java.awt.Font font88 = dateAxis78.getTickLabelFont();
        xYPlot68.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis78);
        xYPlot68.clearRangeMarkers(500);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection93 = xYPlot68.getDomainMarkers(layer92);
        java.util.Collection collection94 = xYPlot31.getRangeMarkers(0, layer92);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 32.0f + "'", float13 == 32.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 32.0f + "'", float50 == 32.0f);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.0d + "'", double63 == 2.0d);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(font88);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNull(collection93);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot7.getIndexOf(categoryItemRenderer8);
        int int10 = categoryPlot7.getDomainAxisCount();
        categoryPlot7.setRangeCrosshairValue((double) (short) 100, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation16, plotOrientation17);
        categoryPlot7.setDomainAxisLocation(axisLocation16, false);
        java.awt.Paint paint21 = categoryPlot7.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) -1, paint21);
        double double23 = categoryAxis1.getCategoryMargin();
        categoryAxis1.configure();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_LEFT");
        boolean boolean27 = numberAxis26.isInverted();
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) numberAxis26);
        java.text.NumberFormat numberFormat29 = null;
        numberAxis26.setNumberFormatOverride(numberFormat29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis26.setMarkerBand(markerAxisBand31);
        numberAxis26.setRangeWithMargins((double) 1L, (double) 9);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = dateAxis38.valueToJava2D(10.0d, rectangle2D40, rectangleEdge41);
        dateAxis38.setAutoTickUnitSelection(true);
        java.util.Date date45 = dateAxis38.getMaximumDate();
        dateAxis38.setTickMarkInsideLength((float) ' ');
        double double48 = dateAxis38.getAutoRangeMinimumSize();
        float float49 = dateAxis38.getTickMarkInsideLength();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis53.valueToJava2D(10.0d, rectangle2D55, rectangleEdge56);
        dateAxis53.setAutoTickUnitSelection(true);
        java.util.Date date60 = dateAxis53.getMaximumDate();
        dateAxis51.setMinimumDate(date60);
        double double62 = dateAxis51.getUpperBound();
        java.awt.Font font63 = dateAxis51.getLabelFont();
        dateAxis51.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer66);
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) 8);
        valueMarker69.setLabel("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean73 = valueMarker69.equals((java.lang.Object) rectangleInsets72);
        boolean boolean74 = xYPlot67.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker69);
        boolean boolean75 = xYPlot67.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis77 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = null;
        double double81 = dateAxis77.valueToJava2D(10.0d, rectangle2D79, rectangleEdge80);
        dateAxis77.setAutoTickUnitSelection(true);
        java.util.Date date84 = dateAxis77.getMaximumDate();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis77.setTimeZone(timeZone85);
        java.awt.Font font87 = dateAxis77.getTickLabelFont();
        xYPlot67.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis77);
        xYPlot67.clearRangeMarkers(500);
        org.jfree.chart.util.Layer layer91 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection92 = xYPlot67.getDomainMarkers(layer91);
        xYPlot67.setDomainCrosshairValue((double) 10L, true);
        int int96 = xYPlot67.getRangeAxisCount();
        numberAxis26.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot67);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 32.0f + "'", float49 == 32.0f);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.0d + "'", double62 == 2.0d);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNotNull(font87);
        org.junit.Assert.assertNotNull(layer91);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }
}

