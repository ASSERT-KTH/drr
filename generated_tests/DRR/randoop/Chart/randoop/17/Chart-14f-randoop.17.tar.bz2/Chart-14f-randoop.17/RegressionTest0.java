import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray6 = new float[] { '#', (-1.0f), 0L, 10 };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        try {
            valueMarker1.setAlpha((float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        try {
            int int3 = categoryPlot0.getRangeAxisIndex(valueAxis2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot0.addChangeListener(plotChangeListener3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) 100, (float) (short) 100);
        int int4 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-83) + "'", int4 == (-83));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.setBackgroundImageAlignment((int) (short) 100);
        int int4 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation4);
        try {
            double double6 = numberAxis0.valueToJava2D(0.0d, rectangle2D2, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        try {
            dateAxis2.setAutoRangeMinimumSize((double) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        categoryPlot10.configureRangeAxes();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot10.getRangeMarkers((int) (short) 100, layer15);
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker9, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            boolean boolean4 = categoryPlot0.removeAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { 10L, 1.0f, (short) 100 };
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean4 = categoryPlot0.removeAnnotation(categoryAnnotation2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo5, point2D6, true);
        org.jfree.chart.plot.Marker marker9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker(marker9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=192,g=192,b=192]"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) color3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            categoryPlot0.drawOutline(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        double double6 = rectangleInsets4.calculateRightInset((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        java.lang.String str10 = dateAxis1.getLabel();
        double double11 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        try {
            java.util.List list10 = dateAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        try {
            categoryPlot0.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test055");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day4.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        try {
            double double10 = dateAxis4.java2DToValue((double) (short) -1, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        double double6 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.util.SortOrder sortOrder11 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.setRangeAboutValue((double) (-1.0f), (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-0.5) <= upper (-1.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            categoryPlot0.drawOutline(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.SortOrder sortOrder4 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getLastMillisecond();
//        long long7 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets0.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        boolean boolean12 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot9.setDataset(categoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getDomainAxisEdge((int) (short) 100);
        try {
            java.util.List list20 = dateAxis4.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis1.setTimeline(timeline19);
        try {
            dateAxis1.zoomRange((double) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint2 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double6 = intervalMarker5.getStartValue();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker5.setLabelFont(font7);
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRangeWithMargins(range18, true, false);
        dateAxis1.setRange(range18);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis24.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis3.setLabelPaint((java.awt.Paint) color4);
        dateAxis3.setLabelAngle((double) ' ');
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRangeWithMargins(range8, true, false);
        dateAxis1.setRange(range8, false, false);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart15);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot10.setDataset(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot10.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getDomainAxisEdge((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = dateAxis1.draw(graphics2D6, (double) 100L, rectangle2D8, rectangle2D9, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets4.getUnitType();
        java.lang.String str7 = unitType6.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        try {
            java.util.Date date4 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot7.setInsets(rectangleInsets9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer11 };
        categoryPlot7.setRenderers(categoryItemRendererArray12);
        categoryPlot0.setRenderers(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone3);
//        java.util.Date date6 = day5.getEnd();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
//        java.lang.Comparable comparable9 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
//        java.awt.geom.Rectangle2D rectangle2D12 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
//        boolean boolean16 = categoryPlot13.isRangeGridlinesVisible();
//        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
//        categoryPlot13.setDataset(categoryDataset17);
//        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxisForDataset((int) ' ');
//        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot13.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getDomainAxisEdge((int) (short) 100);
//        try {
//            double double24 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) regularTimePeriod8, comparable9, categoryDataset10, 0.0d, rectangle2D12, rectangleEdge23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(axisLocation15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNull(categoryAxis20);
//        org.junit.Assert.assertNull(axisSpace21);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(255, layer5);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getRangeAxisLocation((int) (byte) 1);
        boolean boolean19 = categoryPlot16.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot16.setDataset(categoryDataset20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot16.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot16.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getDomainAxisEdge((int) (short) 100);
        double double27 = categoryAxis10.getCategoryJava2DCoordinate(categoryAnchor12, (int) (byte) -1, (int) 'a', rectangle2D15, rectangleEdge26);
        try {
            double double28 = dateAxis1.java2DToValue((double) (-1.0f), rectangle2D9, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker2.setLabelAnchor(rectangleAnchor3);
        java.lang.String str5 = rectangleAnchor3.toString();
        boolean boolean6 = lengthAdjustmentType0.equals((java.lang.Object) rectangleAnchor3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.LEFT" + "'", str5.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getRangeAxisLocation((int) (byte) 1);
        categoryPlot12.setRangeAxisLocation(axisLocation17, true);
        try {
            categoryPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit17, false, true);
        java.awt.Shape shape21 = null;
        try {
            numberAxis0.setDownArrow(shape21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        double double5 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createOutsetRectangle(rectangle2D6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit17, false, true);
        numberAxis0.setRangeWithMargins(0.0d, (double) 9);
        boolean boolean24 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean11 = dateAxis9.isHiddenValue((long) 100);
        dateAxis9.setInverted(false);
        boolean boolean14 = dateAxis9.isVisible();
        java.awt.Color color15 = java.awt.Color.YELLOW;
        dateAxis9.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = dateAxis9.getTickUnit();
        java.lang.String str18 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) dateTickUnit17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot20.getRangeAxisLocation((int) (byte) 1);
        boolean boolean23 = categoryPlot20.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot20.setDataset(categoryDataset24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot20.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot20.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot20.getDomainAxis((int) '#');
        categoryPlot20.clearRangeMarkers(173);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace36 = categoryAxis0.reserveSpace(graphics2D19, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D33, rectangleEdge34, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot0.addChangeListener(plotChangeListener8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        float float8 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            categoryPlot0.drawOutline(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double14 = intervalMarker13.getStartValue();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker13.setLabelFont(font15);
        boolean boolean17 = categoryPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        boolean boolean6 = dateAxis1.isVisible();
        dateAxis1.setLabel("13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets0.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        dateAxis1.setLabelAngle(0.0d);
        try {
            dateAxis1.setRange((double) 1.0f, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        boolean boolean6 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis8.isHiddenValue((long) 100);
        dateAxis8.setInverted(false);
        boolean boolean13 = dateAxis8.isVisible();
        java.awt.Color color14 = java.awt.Color.YELLOW;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color14);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color14);
        int int17 = color14.getRed();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer10 };
        categoryPlot6.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot6.notifyListeners(plotChangeEvent13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            org.jfree.chart.axis.AxisState axisState18 = categoryAxis0.draw(graphics2D2, (double) 5, rectangle2D4, rectangle2D5, rectangleEdge16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color0 = java.awt.Color.GRAY;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        try {
            valueMarker1.setAlpha((float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer((-83));
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        boolean boolean16 = categoryPlot13.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double20 = intervalMarker19.getStartValue();
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker19.setLabelFont(font21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot23.getRangeAxisLocation((int) (byte) 1);
        categoryPlot23.configureRangeAxes();
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers((int) (short) 100, layer28);
        boolean boolean30 = categoryPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker19, layer28);
        try {
            boolean boolean31 = categoryPlot0.removeRangeMarker((int) '4', marker12, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint3);
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot0.setDomainAxisLocation(3, axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 0, (float) 'a', (float) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-7903) + "'", int3 == (-7903));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        numberAxis5.setFixedDimension((double) 1560495599999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
//        int int8 = day4.getYear();
//        int int9 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.clearCategoryLabelToolTips();
        java.lang.Comparable comparable3 = null;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        valueMarker5.notifyListeners(markerChangeEvent6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot8.zoomRangeAxes((double) 2, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double18 = intervalMarker17.getStartValue();
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker17.setLabelFont(font19);
        categoryPlot8.setNoDataMessageFont(font19);
        valueMarker5.setLabelFont(font19);
        try {
            categoryAxis0.setTickLabelFont(comparable3, font19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = null;
        try {
            numberAxis5.setTickUnit(numberTickUnit20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot10.setDataset(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot10.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getDomainAxisEdge((int) (short) 100);
        double double21 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor6, (int) (byte) -1, (int) 'a', rectangle2D9, rectangleEdge20);
        try {
            double double22 = dateAxis1.lengthToJava2D(3.0d, rectangle2D3, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setPositiveArrowVisible(true);
        dateAxis13.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis5.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date9 = dateAxis5.calculateLowestVisibleTickValue(dateTickUnit8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint14 = categoryPlot13.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot13.setInsets(rectangleInsets15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer17 };
        categoryPlot13.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        categoryPlot13.notifyListeners(plotChangeEvent20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getDomainAxisEdge((int) (byte) 0);
        try {
            double double24 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 1, (java.lang.Comparable) date9, categoryDataset10, (double) (-1L), rectangle2D12, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double17 = intervalMarker16.getStartValue();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker16.setLabelFont(font18);
        boolean boolean20 = categoryPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot11.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection21);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        float[] floatArray4 = new float[] { (-7903) };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB((int) (short) -1, 1, 5, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double10 = intervalMarker9.getStartValue();
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker9.setLabelFont(font11);
        categoryPlot0.setNoDataMessageFont(font11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(font11);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font6);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.lang.Comparable comparable10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean14 = dateAxis12.isHiddenValue((long) 100);
        dateAxis12.setInverted(false);
        boolean boolean17 = dateAxis12.isVisible();
        java.awt.Color color18 = java.awt.Color.YELLOW;
        dateAxis12.setTickLabelPaint((java.awt.Paint) color18);
        try {
            categoryAxis0.setTickLabelPaint(comparable10, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getLastMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            day4.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRangeWithMargins(range17, true, false);
        dateAxis12.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        dateAxis12.setRange(range29);
        int int34 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot0.zoomRangeAxes((double) 3, plotRenderingInfo36, point2D37, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Color color1 = java.awt.Color.WHITE;
        boolean boolean2 = color0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray11);
        java.lang.String str13 = categoryPlot7.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot7.notifyListeners(plotChangeEvent14);
        categoryPlot7.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis26.setLabelPaint((java.awt.Paint) color27);
        dateAxis26.setLabelAngle((double) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis26.setRangeWithMargins(range31, true, false);
        dateAxis20.setDefaultAutoRange(range31);
        dateAxis20.setAutoTickUnitSelection(true);
        categoryPlot7.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        categoryPlot7.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot7.getRangeAxisEdge();
        try {
            double double42 = categoryAxis0.getCategoryStart((int) '4', 255, rectangle2D6, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        categoryPlot0.clearRangeMarkers(173);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot0.getDomainAxisForDataset(4);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint8 = categoryPlot7.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup9 = categoryPlot7.getDatasetGroup();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        boolean boolean14 = categoryPlot11.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray15 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot11.setDomainAxes(categoryAxisArray15);
        java.lang.String str17 = categoryPlot11.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        categoryPlot11.notifyListeners(plotChangeEvent18);
        categoryPlot11.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis30.setLabelPaint((java.awt.Paint) color31);
        dateAxis30.setLabelAngle((double) ' ');
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis30.setRangeWithMargins(range35, true, false);
        dateAxis24.setDefaultAutoRange(range35);
        dateAxis24.setAutoTickUnitSelection(true);
        categoryPlot11.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        categoryPlot11.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace47 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D10, rectangleEdge45, axisSpace46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean6 = rectangleInsets4.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
//        int int8 = day4.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            day4.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection38 = categoryPlot32.getRangeMarkers((int) (short) 100, layer37);
        boolean boolean39 = categoryPlot32.isDomainGridlinesVisible();
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot32);
        org.jfree.chart.axis.Timeline timeline41 = null;
        dateAxis13.setTimeline(timeline41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        double double48 = categoryAxis47.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor49 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        boolean boolean56 = categoryPlot53.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        categoryPlot53.setDataset(categoryDataset57);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = categoryPlot53.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace61 = categoryPlot53.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot53.getDomainAxisEdge((int) (short) 100);
        double double64 = categoryAxis47.getCategoryJava2DCoordinate(categoryAnchor49, (int) (byte) -1, (int) 'a', rectangle2D52, rectangleEdge63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        try {
            org.jfree.chart.axis.AxisState axisState66 = dateAxis13.draw(graphics2D43, (double) (-1.0f), rectangle2D45, rectangle2D46, rectangleEdge63, plotRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(categoryAxis60);
        org.junit.Assert.assertNull(axisSpace61);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        double double13 = rectangleInsets11.trimHeight((-1.0d));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-9.0d) + "'", double13 == (-9.0d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRangeWithMargins(range17, true, false);
        dateAxis12.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        dateAxis12.setRange(range29);
        int int34 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        dateAxis12.setAutoRange(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRangeWithMargins(range18, true, false);
        dateAxis1.setRange(range18);
        java.lang.String str23 = dateAxis1.getLabelToolTip();
        dateAxis1.setTickMarkOutsideLength(100.0f);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        java.awt.Paint paint8 = dateAxis4.getTickLabelPaint();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset((int) (byte) 1);
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        boolean boolean6 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray7 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot3.setDomainAxes(categoryAxisArray7);
        categoryPlot0.setDomainAxes(categoryAxisArray7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.zoomDomainAxes(8.0d, plotRenderingInfo11, point2D12);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.extendHeight((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.0d + "'", double7 == 6.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        java.awt.Image image9 = null;
        categoryPlot0.setBackgroundImage(image9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 1);
        boolean boolean4 = categoryPlot1.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double6 = rectangleInsets5.getBottom();
        categoryPlot1.setAxisOffset(rectangleInsets5);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = categoryAxis10.getCategoryLabelPositions();
        int int15 = categoryAxis10.getMaximumCategoryLabelLines();
        try {
            categoryPlot0.setDomainAxis((-83), categoryAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = categoryPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis18.setLabelPaint((java.awt.Paint) color19);
        dateAxis18.setLabelAngle((double) ' ');
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRangeWithMargins(range23, true, false);
        dateAxis12.setDefaultAutoRange(range23);
        numberAxis8.setRangeWithMargins(range23, false, true);
        java.awt.Font font31 = numberAxis8.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font31);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        dateAxis1.setUpperMargin(0.0d);
        float float21 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        boolean boolean6 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray7 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot3.setDomainAxes(categoryAxisArray7);
        categoryPlot0.setDomainAxes(categoryAxisArray7);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        boolean boolean15 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot22.getRangeAxisLocation((int) (byte) 1);
        categoryPlot22.configureRangeAxes();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection28 = categoryPlot22.getRangeMarkers((int) (short) 100, layer27);
        boolean boolean29 = categoryPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer27);
        try {
            categoryPlot0.addDomainMarker((int) (short) 10, categoryMarker11, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray7);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit17, false, true);
        double double21 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        java.awt.Paint paint4 = dateAxis1.getAxisLinePaint();
        dateAxis1.setVisible(true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        categoryPlot0.setRangeCrosshairValue(1.0E-8d);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset((int) '#');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (byte) 10, (double) (short) 100, (-8.0d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Image image8 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color5);
        java.lang.String str7 = color5.toString();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=128,g=0,b=0]" + "'", str7.equals("java.awt.Color[r=128,g=0,b=0]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.lang.String str7 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        int int7 = categoryPlot0.getRangeAxisCount();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot0.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        java.awt.Font font28 = numberAxis5.getTickLabelFont();
        java.awt.Shape shape29 = numberAxis5.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) -1);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent1.setChart(jFreeChart5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent1.getType();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) -1 + "'", obj2.equals((short) -1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers(0);
        categoryPlot9.setAnchorValue((double) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot9.addChangeListener(plotChangeListener19);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot9.setDataset(categoryDataset22);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        double double6 = rectangleInsets4.calculateRightInset((double) (short) 100);
        double double8 = rectangleInsets4.calculateRightOutset((double) 43629L);
        double double10 = rectangleInsets4.calculateLeftInset((double) '4');
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = layer12.equals((java.lang.Object) 2);
        java.lang.String str15 = layer12.toString();
        try {
            categoryPlot0.addDomainMarker((int) (short) 0, categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Layer.FOREGROUND" + "'", str15.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot0.setWeight((int) (short) 100);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        double double3 = dateAxis2.getFixedDimension();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) color3);
        double double6 = rectangleInsets0.calculateRightOutset(3.0d);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createOutsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        boolean boolean6 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double8 = rectangleInsets7.getBottom();
        categoryPlot3.setAxisOffset(rectangleInsets7);
        java.lang.String str10 = rectangleInsets7.toString();
        dateAxis1.setLabelInsets(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str10.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace1, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRangeWithMargins(range17, true, false);
        dateAxis12.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        dateAxis12.setRange(range29);
        int int34 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("", timeZone37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date35, timeZone37);
        java.util.Date date40 = day39.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint42 = categoryPlot41.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot41.setInsets(rectangleInsets43);
        categoryPlot41.clearDomainMarkers();
        boolean boolean46 = day39.equals((java.lang.Object) categoryPlot41);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot41.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection47);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(legendItemCollection47);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot5.setDataset((int) 'a', categoryDataset26);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot30.getRangeAxisLocation((int) (byte) 1);
        categoryPlot30.configureRangeAxes();
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection36 = categoryPlot30.getRangeMarkers((int) (short) 100, layer35);
        try {
            categoryPlot5.addDomainMarker(0, categoryMarker29, layer35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.trimHeight((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.0d + "'", double3 == 93.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        dateAxis1.setUpperMargin((double) (-7903));
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot7.setDataset(categoryDataset11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot7.getDomainAxis(15);
        try {
            dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-7902.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryAxis14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = java.awt.Color.BLACK;
        int int1 = color0.getGreen();
        org.jfree.data.general.Dataset dataset2 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        int int12 = categoryPlot5.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot5.setDomainGridlinePosition(categoryAnchor13);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot18.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.clearCategoryLabelToolTips();
        int int22 = categoryPlot18.getDomainAxisIndex(categoryAxis20);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot18.getRangeAxisEdge(9);
        try {
            double double25 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor13, (int) (byte) 0, (int) (byte) 100, rectangle2D17, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setFixedDimension((double) 'a');
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = numberAxis5.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource20);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        java.awt.Paint paint18 = null;
        try {
            categoryAxis0.setTickLabelPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createOutsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        double double6 = rectangleInsets4.calculateTopOutset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            rectangleInsets4.trim(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getComponents(colorSpace1, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 1);
        categoryPlot2.configureRangeAxes();
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = categoryPlot2.getRangeMarkers((int) (short) 100, layer7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot2.getDomainGridlinePosition();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("", timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone15);
        java.util.Date date18 = day17.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint20 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot19.setInsets(rectangleInsets21);
        categoryPlot19.clearDomainMarkers();
        boolean boolean24 = day17.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot19.getRangeAxisEdge();
        try {
            double double26 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor9, 13, 2019, rectangle2D12, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Font font2 = null;
        try {
            categoryPlot0.setNoDataMessageFont(font2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot0.getRenderer((int) (byte) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.awt.Color color10 = java.awt.Color.BLACK;
        boolean boolean11 = plotOrientation9.equals((java.lang.Object) color10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) '#', (-83), 3, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        double double3 = dateAxis2.getLowerBound();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        double double4 = rectangleInsets0.calculateTopOutset((double) '4');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        double double20 = dateAxis1.getFixedAutoRange();
        try {
            dateAxis1.setRange((double) 100.0f, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        boolean boolean11 = categoryPlot8.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot8.setDomainAxes(categoryAxisArray12);
        java.lang.String str14 = categoryPlot8.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot8.notifyListeners(plotChangeEvent15);
        categoryPlot8.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis27.setLabelPaint((java.awt.Paint) color28);
        dateAxis27.setLabelAngle((double) ' ');
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRangeWithMargins(range32, true, false);
        dateAxis21.setDefaultAutoRange(range32);
        dateAxis21.setAutoTickUnitSelection(true);
        categoryPlot8.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean40 = dateAxis1.equals((java.lang.Object) dateAxis21);
        java.awt.Shape shape41 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setDownArrow(shape41);
        dateAxis21.setLabelToolTip("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        boolean boolean12 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot9.setDataset(categoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot9.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation24 = axisLocation23.getOpposite();
        categoryPlot9.setDomainAxisLocation((int) (byte) 10, axisLocation24, true);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation28, plotOrientation29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace32 = categoryAxis0.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D27, rectangleEdge30, axisSpace31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        boolean boolean6 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean10 = dateAxis8.isHiddenValue((long) 100);
        dateAxis8.setInverted(false);
        boolean boolean13 = dateAxis8.isVisible();
        java.awt.Color color14 = java.awt.Color.YELLOW;
        dateAxis8.setTickLabelPaint((java.awt.Paint) color14);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        try {
            double double22 = dateAxis4.valueToJava2D(1.0d, rectangle2D18, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str1.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation((-1));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection38 = categoryPlot32.getRangeMarkers((int) (short) 100, layer37);
        boolean boolean39 = categoryPlot32.isDomainGridlinesVisible();
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot32);
        int int41 = categoryPlot32.getDatasetCount();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = null;
        categoryPlot32.axisChanged(axisChangeEvent42);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis4.setLabelPaint((java.awt.Paint) color5);
        dateAxis4.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis10.setLabelPaint((java.awt.Paint) color11);
        dateAxis10.setLabelAngle((double) ' ');
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRangeWithMargins(range15, true, false);
        dateAxis4.setDefaultAutoRange(range15);
        dateAxis2.setRange(range15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean24 = dateAxis22.isHiddenValue((long) 100);
        dateAxis22.setInverted(false);
        boolean boolean27 = dateAxis22.isVisible();
        java.awt.Color color28 = java.awt.Color.YELLOW;
        dateAxis22.setTickLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis22.getTickUnit();
        dateAxis2.setTickUnit(dateTickUnit30, false, true);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint37 = categoryPlot36.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot36.setInsets(rectangleInsets38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray41 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer40 };
        categoryPlot36.setRenderers(categoryItemRendererArray41);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = null;
        categoryPlot36.notifyListeners(plotChangeEvent43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot36.getDomainAxisEdge((int) (byte) 0);
        try {
            double double47 = dateAxis2.valueToJava2D((double) (-1), rectangle2D35, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(categoryItemRendererArray41);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        try {
            xYPlot30.zoomDomainAxes((double) ' ', plotRenderingInfo32, point2D33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        float float10 = numberAxis5.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.data.Range range6 = numberAxis0.getDefaultAutoRange();
        double double7 = numberAxis0.getUpperMargin();
        float float8 = numberAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        java.awt.Font font28 = numberAxis5.getTickLabelFont();
        double double29 = numberAxis5.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 1, plotRenderingInfo8, point2D9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D11, rectangle2D12, (int) ' ', plotRenderingInfo14);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        double double20 = dateAxis1.getFixedAutoRange();
        boolean boolean21 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean2 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot3 = dateAxis1.getPlot();
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double6 = intervalMarker5.getStartValue();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker5.setLabelFont(font7);
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        double double10 = intervalMarker5.getEndValue();
        intervalMarker5.setAlpha((float) 0L);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint21 = categoryPlot20.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot20.zoomRangeAxes((double) 2, plotRenderingInfo23, point2D24, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double30 = intervalMarker29.getStartValue();
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker29.setLabelFont(font31);
        categoryPlot20.setNoDataMessageFont(font31);
        numberAxis5.setLabelFont(font31);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis5.setMarkerBand(markerAxisBand35);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 0, 6.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets4.getBottom();
        categoryPlot0.setAxisOffset(rectangleInsets4);
        double double7 = rectangleInsets4.getRight();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = categoryPlot0.getDatasetRenderingOrder();
        try {
            categoryPlot0.mapDatasetToDomainAxis((-83), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation4);
        java.awt.Stroke stroke6 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRendererForDataset(categoryDataset7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double6 = rectangleInsets5.getBottom();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) rectangleInsets5);
        double double9 = rectangleInsets5.extendHeight((double) 3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 7.0d + "'", double9 == 7.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (short) 10);
        double double6 = rectangleInsets2.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets2.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean9 = unitType7.equals((java.lang.Object) textAnchor8);
        valueMarker1.setLabelTextAnchor(textAnchor8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-8.0d) + "'", double6 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray14 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray14);
        java.lang.String str16 = categoryPlot10.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        categoryPlot10.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis23.setLabelPaint((java.awt.Paint) color24);
        dateAxis23.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis29.setLabelPaint((java.awt.Paint) color30);
        dateAxis29.setLabelAngle((double) ' ');
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range34, true, false);
        dateAxis23.setDefaultAutoRange(range34);
        dateAxis23.setAutoTickUnitSelection(true);
        categoryPlot10.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        numberAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        java.awt.Paint paint43 = categoryPlot10.getOutlinePaint();
        categoryPlot10.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        boolean boolean11 = categoryPlot8.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot8.setDomainAxes(categoryAxisArray12);
        java.lang.String str14 = categoryPlot8.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot8.notifyListeners(plotChangeEvent15);
        categoryPlot8.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis27.setLabelPaint((java.awt.Paint) color28);
        dateAxis27.setLabelAngle((double) ' ');
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRangeWithMargins(range32, true, false);
        dateAxis21.setDefaultAutoRange(range32);
        dateAxis21.setAutoTickUnitSelection(true);
        categoryPlot8.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean40 = dateAxis1.equals((java.lang.Object) dateAxis21);
        try {
            dateAxis21.setRange((double) 500, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer((-83));
        int int11 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font6);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        double double10 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8);
        categoryPlot6.clearDomainMarkers();
        boolean boolean11 = day4.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot6.getRenderer();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRangeWithMargins(range18, true, false);
        dateAxis1.setRange(range18);
        java.lang.String str23 = dateAxis1.getLabelToolTip();
        java.awt.Paint paint24 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer((-83));
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot11.setInsets(rectangleInsets13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot11.setRenderers(categoryItemRendererArray16);
        categoryPlot0.setRenderers(categoryItemRendererArray16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double25 = intervalMarker24.getStartValue();
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker24.setLabelFont(font26);
        boolean boolean28 = categoryPlot19.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        java.awt.Stroke stroke29 = intervalMarker24.getOutlineStroke();
        boolean boolean30 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-1.0d) + "'", double25 == (-1.0d));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis5.configure();
        numberAxis5.setFixedAutoRange((double) 2.0f);
        numberAxis5.centerRange((double) 4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean8 = categoryPlot2.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker6, layer7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot2.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot2.setWeight((int) (short) 100);
        java.awt.Stroke stroke15 = categoryPlot2.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 3, paint1, stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        double double2 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot15.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation18 = axisLocation17.getOpposite();
        boolean boolean19 = lengthAdjustmentType14.equals((java.lang.Object) axisLocation17);
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation17, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = numberAxis5.getMarkerBand();
        java.text.NumberFormat numberFormat21 = numberAxis5.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(markerAxisBand20);
        org.junit.Assert.assertNull(numberFormat21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("", timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date8, timeZone10);
        java.util.Date date13 = day12.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot14.setInsets(rectangleInsets16);
        categoryPlot14.clearDomainMarkers();
        boolean boolean19 = day12.equals((java.lang.Object) categoryPlot14);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot14.getRangeAxisEdge();
        try {
            double double21 = categoryAxis2.getCategoryMiddle((-1), (-7903), rectangle2D7, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color1 = java.awt.Color.white;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        java.lang.Object obj10 = dateAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("", timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13, timeZone15);
        java.util.Date date18 = day17.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint20 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot19.setInsets(rectangleInsets21);
        categoryPlot19.clearDomainMarkers();
        boolean boolean24 = day17.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot19.getRangeAxisEdge();
        try {
            double double26 = dateAxis1.java2DToValue((double) 1L, rectangle2D12, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.setRangeAxisLocation((int) (short) 100, axisLocation7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot0.getRangeAxisLocation((int) (byte) -1);
        int int18 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot55.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation58 = axisLocation57.getOpposite();
        try {
            xYPlot30.setRangeAxisLocation((-7903), axisLocation57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setTickMarkInsideLength((float) 43629L);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryAxis8);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        long long7 = day4.getFirstMillisecond();
//        long long8 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str14 = chartChangeEventType13.toString();
        boolean boolean15 = datasetRenderingOrder12.equals((java.lang.Object) str14);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str14.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer4);
        boolean boolean6 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis5.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis18.setLabelPaint((java.awt.Paint) color19);
        dateAxis18.setLabelAngle((double) ' ');
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRangeWithMargins(range23, true, false);
        java.lang.String str27 = dateAxis18.getLabel();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setDownArrow(shape28);
        numberAxis5.setRightArrow(shape28);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis5.setMarkerBand(markerAxisBand31);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation36);
        try {
            double double38 = numberAxis5.java2DToValue((double) (-1), rectangle2D34, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder34 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRangeWithMargins(range17, true, false);
        dateAxis12.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        dateAxis12.setRange(range29);
        int int34 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        categoryPlot0.axisChanged(axisChangeEvent35);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        xYPlot30.setWeight(4);
        java.awt.Color color53 = java.awt.Color.cyan;
        xYPlot30.setRangeTickBandPaint((java.awt.Paint) color53);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot30.getRangeAxis(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        try {
            xYPlot30.zoomDomainAxes(7.0d, plotRenderingInfo41, point2D42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        boolean boolean8 = dateAxis4.isTickLabelsVisible();
        dateAxis4.setFixedAutoRange((double) 0.0f);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        double double6 = rectangleInsets4.getBottom();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("SortOrder.DESCENDING");
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 0L, (double) 500, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        categoryPlot0.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryPlot0.setOutlinePaint(paint14);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.data.Range range6 = numberAxis0.getDefaultAutoRange();
        numberAxis0.setRangeAboutValue(0.0d, (double) 0.0f);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis0.getTickUnit();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot14.getRangeAxisLocation((int) (byte) 1);
        boolean boolean17 = categoryPlot14.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray18);
        java.lang.String str20 = categoryPlot14.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot14.notifyListeners(plotChangeEvent21);
        categoryPlot14.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis27.setLabelPaint((java.awt.Paint) color28);
        dateAxis27.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis33.setLabelPaint((java.awt.Paint) color34);
        dateAxis33.setLabelAngle((double) ' ');
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRangeWithMargins(range38, true, false);
        dateAxis27.setDefaultAutoRange(range38);
        dateAxis27.setAutoTickUnitSelection(true);
        categoryPlot14.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        categoryPlot14.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot14.getRangeAxisEdge();
        try {
            java.util.List list49 = numberAxis0.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        boolean boolean6 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray11);
        java.lang.String str13 = categoryPlot7.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot7.notifyListeners(plotChangeEvent14);
        categoryPlot7.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis26.setLabelPaint((java.awt.Paint) color27);
        dateAxis26.setLabelAngle((double) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis26.setRangeWithMargins(range31, true, false);
        dateAxis20.setDefaultAutoRange(range31);
        dateAxis20.setAutoTickUnitSelection(true);
        categoryPlot7.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot39.configureRangeAxes();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection45 = categoryPlot39.getRangeMarkers((int) (short) 100, layer44);
        boolean boolean46 = categoryPlot39.isDomainGridlinesVisible();
        dateAxis20.setPlot((org.jfree.chart.plot.Plot) categoryPlot39);
        int int48 = categoryPlot39.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot49.getRangeAxisLocation((int) (byte) 1);
        boolean boolean52 = categoryPlot49.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        categoryPlot49.setDataset(categoryDataset53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot49.getDomainAxis(15);
        java.awt.Stroke stroke57 = categoryPlot49.getRangeCrosshairStroke();
        categoryPlot39.setOutlineStroke(stroke57);
        categoryPlot0.setRangeCrosshairStroke(stroke57);
        org.jfree.chart.LegendItemCollection legendItemCollection60 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(categoryAxis56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNull(legendItemCollection60);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(axisSpace9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset((int) '#', xYDataset37);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot40.getRangeAxisLocation((int) (byte) 1);
        categoryPlot40.configureRangeAxes();
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection46 = categoryPlot40.getRangeMarkers((int) (short) 100, layer45);
        try {
            boolean boolean47 = xYPlot30.removeRangeMarker(marker39, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        categoryAxis0.setLowerMargin((double) 100.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint13 = categoryPlot10.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot10.setOrientation(plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation14);
        try {
            java.util.List list17 = categoryAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation22);
        try {
            double double24 = categoryAxis2.getCategoryStart(4, 173, rectangle2D20, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot2.zoomRangeAxes((double) 2, plotRenderingInfo5, point2D6, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot9.notifyListeners(plotChangeEvent12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isAutoTickUnitSelection();
        org.jfree.data.Range range16 = categoryPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint18 = categoryPlot17.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot17.setInsets(rectangleInsets19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray22 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer21 };
        categoryPlot17.setRenderers(categoryItemRendererArray22);
        numberAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot17);
        categoryPlot2.notifyListeners(plotChangeEvent25);
        org.jfree.chart.plot.Plot plot27 = plotChangeEvent25.getPlot();
        categoryPlot0.notifyListeners(plotChangeEvent25);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray22);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke20 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot34.getRangeAxisLocation((int) (byte) 1);
        boolean boolean37 = categoryPlot34.isDomainGridlinesVisible();
        int int38 = categoryPlot34.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot34);
        org.jfree.chart.util.SortOrder sortOrder40 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot34.setColumnRenderingOrder(sortOrder40);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(sortOrder40);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo3, point2D4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint13 = categoryPlot10.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot10.setOrientation(plotOrientation14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation14);
        try {
            java.util.List list17 = dateAxis4.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis11.setTickLabelFont((java.lang.Comparable) true, font17);
        categoryPlot0.setNoDataMessageFont(font17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateRightInset((double) 6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot0.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection38 = categoryPlot32.getRangeMarkers((int) (short) 100, layer37);
        boolean boolean39 = categoryPlot32.isDomainGridlinesVisible();
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot32);
        org.jfree.chart.axis.Timeline timeline41 = null;
        dateAxis13.setTimeline(timeline41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean46 = dateAxis44.isHiddenValue((long) 100);
        dateAxis44.setInverted(false);
        boolean boolean49 = dateAxis44.isVisible();
        java.awt.Color color50 = java.awt.Color.YELLOW;
        dateAxis44.setTickLabelPaint((java.awt.Paint) color50);
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis44.getTickUnit();
        java.util.Date date53 = dateAxis13.calculateHighestVisibleTickValue(dateTickUnit52);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(date53);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        boolean boolean6 = dateAxis4.isInverted();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("", timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7, timeZone9);
        dateAxis4.setMaximumDate(date7);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("", timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!", timeZone15);
        dateAxis17.resizeRange((double) 100L, 10.0d);
        boolean boolean21 = dateAxis17.isTickLabelsVisible();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("", timeZone23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis26.setLabelPaint((java.awt.Paint) color27);
        dateAxis26.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis32.setLabelPaint((java.awt.Paint) color33);
        dateAxis32.setLabelAngle((double) ' ');
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis32.setRangeWithMargins(range37, true, false);
        dateAxis26.setDefaultAutoRange(range37);
        dateAxis24.setRange(range37);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean46 = dateAxis44.isHiddenValue((long) 100);
        dateAxis44.setInverted(false);
        boolean boolean49 = dateAxis44.isVisible();
        java.awt.Color color50 = java.awt.Color.YELLOW;
        dateAxis44.setTickLabelPaint((java.awt.Paint) color50);
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = dateAxis44.getTickUnit();
        dateAxis24.setTickUnit(dateTickUnit52, false, true);
        java.util.Date date56 = dateAxis17.calculateLowestVisibleTickValue(dateTickUnit52);
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation((int) (byte) 1);
        categoryPlot58.configureRangeAxes();
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection64 = categoryPlot58.getRangeMarkers((int) (short) 100, layer63);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot58.getDomainAxisEdge((int) (byte) 10);
        try {
            double double67 = dateAxis4.dateToJava2D(date56, rectangle2D57, rectangleEdge66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker2.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker2.setLabelTextAnchor(textAnchor5);
        java.lang.Object obj7 = valueMarker2.clone();
        valueMarker2.setValue((double) (-1L));
        float float10 = valueMarker2.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str12 = chartChangeEventType11.toString();
        java.awt.Color color13 = java.awt.Color.PINK;
        boolean boolean14 = chartChangeEventType11.equals((java.lang.Object) color13);
        boolean boolean15 = valueMarker2.equals((java.lang.Object) color13);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Paint paint20 = intervalMarker19.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getRangeAxisLocation((int) (byte) 1);
        categoryPlot21.configureRangeAxes();
        categoryPlot21.setRangeCrosshairLockedOnData(true);
        int int27 = categoryPlot21.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = null;
        categoryPlot21.setFixedLegendItems(legendItemCollection28);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = categoryPlot21.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker32.setLabelAnchor(rectangleAnchor33);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker32.setLabelTextAnchor(textAnchor35);
        java.awt.Stroke stroke37 = valueMarker32.getStroke();
        categoryPlot21.setRangeCrosshairStroke(stroke37);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color13, stroke16, paint20, stroke37, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str12.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        int int57 = xYPlot30.getIndexOf(xYItemRenderer56);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        double double20 = dateAxis1.getFixedAutoRange();
        java.text.DateFormat dateFormat21 = null;
        dateAxis1.setDateFormatOverride(dateFormat21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setBackgroundImageAlpha(0.0f);
        java.lang.String str29 = categoryPlot26.getNoDataMessage();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot26.getDomainAxisEdge(8);
        try {
            java.util.List list32 = dateAxis1.refreshTicks(graphics2D23, axisState24, rectangle2D25, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateBottomInset((double) (short) 10);
        double double33 = rectangleInsets29.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean36 = unitType34.equals((java.lang.Object) textAnchor35);
        valueMarker28.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot5.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker28, layer38, false);
        java.lang.Object obj41 = valueMarker28.clone();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-8.0d) + "'", double33 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis5.configure();
        numberAxis5.setFixedAutoRange((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot19.getRangeAxisLocation((int) (byte) 1);
        categoryPlot19.configureRangeAxes();
        int int23 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean25 = numberAxis24.isAutoTickUnitSelection();
        numberAxis24.setAutoRangeStickyZero(true);
        org.jfree.data.Range range28 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot29.getRangeAxisLocation((int) (byte) 1);
        boolean boolean32 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray33 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot29.setDomainAxes(categoryAxisArray33);
        java.lang.String str35 = categoryPlot29.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent36 = null;
        categoryPlot29.notifyListeners(plotChangeEvent36);
        categoryPlot29.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis42.setLabelPaint((java.awt.Paint) color43);
        dateAxis42.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis48.setLabelPaint((java.awt.Paint) color49);
        dateAxis48.setLabelAngle((double) ' ');
        org.jfree.data.Range range53 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis48.setRangeWithMargins(range53, true, false);
        dateAxis42.setDefaultAutoRange(range53);
        dateAxis42.setAutoTickUnitSelection(true);
        categoryPlot29.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis42);
        numberAxis24.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        java.awt.Paint paint62 = categoryPlot29.getOutlinePaint();
        numberAxis5.setTickMarkPaint(paint62);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        dateAxis1.setLabel("");
        dateAxis1.resizeRange((double) 500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot30.setDomainZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        try {
            xYPlot30.zoomDomainAxes((double) 1, 1.0E-8d, plotRenderingInfo38, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.05) <= upper (-0.049999989).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TextAnchor.HALF_ASCENT_RIGHT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean10 = numberAxis9.isAutoTickUnitSelection();
        org.jfree.data.Range range11 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = categoryPlot12.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot12.setInsets(rectangleInsets14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        numberAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis9.setRangeWithMargins(range20);
        numberAxis9.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = numberAxis9.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean26 = numberAxis25.isAutoTickUnitSelection();
        numberAxis25.setAutoRangeStickyZero(true);
        double double29 = numberAxis25.getAutoRangeMinimumSize();
        numberAxis25.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer32);
        int int34 = xYPlot33.getRangeAxisCount();
        xYPlot33.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = xYPlot33.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = xYPlot33.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot39.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot42.getRangeAxisLocation((int) (byte) 1);
        categoryPlot39.setRangeAxisLocation(axisLocation44, true);
        xYPlot33.setRangeAxisLocation(axisLocation44);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        double double50 = categoryAxis49.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot55.getRangeAxisLocation((int) (byte) 1);
        boolean boolean58 = categoryPlot55.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        categoryPlot55.setDataset(categoryDataset59);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = categoryPlot55.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace63 = categoryPlot55.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot55.getDomainAxisEdge((int) (short) 100);
        double double66 = categoryAxis49.getCategoryJava2DCoordinate(categoryAnchor51, (int) (byte) -1, (int) 'a', rectangle2D54, rectangleEdge65);
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace68 = numberAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) xYPlot33, rectangle2D48, rectangleEdge65, axisSpace67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(markerAxisBand24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-8d + "'", double29 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(categoryAxis62);
        org.junit.Assert.assertNull(axisSpace63);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        valueMarker1.setOutlinePaint((java.awt.Paint) color7);
        float float9 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset((-7903));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        xYPlot30.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        int int51 = xYPlot30.indexOf(xYDataset50);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        xYPlot30.setWeight(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        xYPlot30.zoomRangeAxes((double) (byte) 0, plotRenderingInfo54, point2D55, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets4.getBottom();
        categoryPlot0.setAxisOffset(rectangleInsets4);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot0.getDataset((-1));
        java.awt.Paint paint11 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean7 = unitType5.equals((java.lang.Object) textAnchor6);
        boolean boolean9 = unitType5.equals((java.lang.Object) 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean13 = dateAxis11.isHiddenValue((long) 100);
        dateAxis11.setTickMarkInsideLength((float) 43629L);
        java.awt.Shape shape16 = dateAxis11.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis18.setLabelPaint((java.awt.Paint) color19);
        dateAxis18.setLabelAngle((double) ' ');
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range23);
        dateAxis11.setRange(range23, false, true);
        boolean boolean28 = unitType5.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        categoryPlot0.clearDomainMarkers((int) '#');
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType1 = numberAxis0.getRangeType();
        java.lang.String str2 = numberAxis0.getLabel();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        boolean boolean19 = dateAxis1.isTickLabelsVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        categoryPlot20.notifyListeners(plotChangeEvent23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean26 = numberAxis25.isAutoTickUnitSelection();
        org.jfree.data.Range range27 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint29 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot28.setInsets(rectangleInsets30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer32 };
        categoryPlot28.setRenderers(categoryItemRendererArray33);
        numberAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis25.setRangeWithMargins(range36);
        dateAxis1.setRange(range36, true, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        categoryPlot0.mapDatasetToDomainAxis(175, 0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) color3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean4);
        java.lang.String str6 = chartChangeEvent5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=false]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=false]"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        dateAxis1.setLabel("");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getDomainGridlinePaint();
        dateAxis1.setTickLabelPaint(paint15);
        boolean boolean17 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.data.general.Dataset dataset8 = datasetChangeEvent5.getDataset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(dataset8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Paint paint2 = null;
        java.awt.Color color4 = java.awt.Color.BLACK;
        int int5 = color4.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot6.setDomainAxes(categoryAxisArray10);
        java.lang.String str12 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        categoryPlot6.notifyListeners(plotChangeEvent13);
        categoryPlot6.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis25.setLabelPaint((java.awt.Paint) color26);
        dateAxis25.setLabelAngle((double) ' ');
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis25.setRangeWithMargins(range30, true, false);
        dateAxis19.setDefaultAutoRange(range30);
        dateAxis19.setAutoTickUnitSelection(true);
        categoryPlot6.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot38.getRangeAxisLocation((int) (byte) 1);
        categoryPlot38.configureRangeAxes();
        categoryPlot38.setRangeCrosshairLockedOnData(true);
        int int44 = categoryPlot38.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection45 = null;
        categoryPlot38.setFixedLegendItems(legendItemCollection45);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = categoryPlot38.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker49.setLabelAnchor(rectangleAnchor50);
        org.jfree.chart.text.TextAnchor textAnchor52 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker49.setLabelTextAnchor(textAnchor52);
        java.awt.Stroke stroke54 = valueMarker49.getStroke();
        categoryPlot38.setRangeCrosshairStroke(stroke54);
        dateAxis19.setTickMarkStroke(stroke54);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((-8.0d), (java.awt.Paint) color4, stroke54);
        java.awt.Color color58 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray65 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray66 = color58.getColorComponents(floatArray65);
        java.awt.color.ColorSpace colorSpace67 = color58.getColorSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint69 = categoryPlot68.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot68.setInsets(rectangleInsets70);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray73 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer72 };
        categoryPlot68.setRenderers(categoryItemRendererArray73);
        int int75 = categoryPlot68.getRangeAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor78 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker77.setLabelAnchor(rectangleAnchor78);
        org.jfree.chart.text.TextAnchor textAnchor80 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker77.setLabelTextAnchor(textAnchor80);
        java.awt.Stroke stroke82 = valueMarker77.getStroke();
        categoryPlot68.setRangeCrosshairStroke(stroke82);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker((double) 'a', (double) (-83), paint2, stroke54, (java.awt.Paint) color58, stroke82, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 15 + "'", int44 == 15);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(colorSpace67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(categoryItemRendererArray73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor78);
        org.junit.Assert.assertNotNull(textAnchor80);
        org.junit.Assert.assertNotNull(stroke82);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        categoryPlot0.clearRangeMarkers(173);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        double double19 = rectangleInsets17.calculateTopOutset((double) 0L);
        double double21 = rectangleInsets17.calculateLeftOutset((double) 100L);
        double double23 = rectangleInsets17.calculateRightInset(4.0d);
        categoryPlot0.setInsets(rectangleInsets17);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        dateAxis1.setInverted(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot0.render(graphics2D15, rectangle2D16, (int) (short) -1, plotRenderingInfo18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        boolean boolean8 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis4.getTickMarkPosition();
        dateAxis4.setLabelToolTip("");
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        boolean boolean3 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getRangeAxisLocation((int) (byte) 1);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color17);
        dateAxis16.setLabelAngle((double) ' ');
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRangeWithMargins(range21, true, false);
        dateAxis16.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis28.setLabelPaint((java.awt.Paint) color29);
        dateAxis28.setLabelAngle((double) ' ');
        org.jfree.data.Range range33 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRangeWithMargins(range33, true, false);
        dateAxis16.setRange(range33);
        int int38 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        categoryPlot0.mapDatasetToDomainAxis((int) '4', (int) '#');
        boolean boolean8 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot14.setInsets(rectangleInsets16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer18 };
        categoryPlot14.setRenderers(categoryItemRendererArray19);
        numberAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis11.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        java.lang.String str33 = dateAxis24.getLabel();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setDownArrow(shape34);
        numberAxis11.setRightArrow(shape34);
        dateAxis1.setUpArrow(shape34);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition38 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition38);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearAnnotations();
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker12, layer13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot8.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot8.getRenderer((-83));
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot8.getDomainAxisEdge((-83));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = numberAxis0.draw(graphics2D4, (double) 10, rectangle2D6, rectangle2D7, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setValue((double) (-1L));
        float float9 = valueMarker1.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str11 = chartChangeEventType10.toString();
        java.awt.Color color12 = java.awt.Color.PINK;
        boolean boolean13 = chartChangeEventType10.equals((java.lang.Object) color12);
        boolean boolean14 = valueMarker1.equals((java.lang.Object) color12);
        java.awt.Color color15 = color12.brighter();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray23 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray24 = color16.getColorComponents(floatArray23);
        float[] floatArray25 = color15.getComponents(floatArray23);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        float float28 = numberAxis5.getTickMarkInsideLength();
        boolean boolean29 = numberAxis5.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint3);
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        int int8 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
//        dateAxis1.setLabelPaint((java.awt.Paint) color2);
//        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
//        dateAxis1.setUpperMargin((double) (-7903));
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("", timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7, timeZone9);
//        java.util.Date date12 = day11.getEnd();
//        long long13 = day11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        java.util.Date date15 = regularTimePeriod14.getStart();
//        java.awt.geom.Rectangle2D rectangle2D16 = null;
//        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("", timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17, timeZone19);
//        java.util.Date date22 = day21.getEnd();
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
//        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        categoryPlot23.setInsets(rectangleInsets25);
//        categoryPlot23.clearDomainMarkers();
//        boolean boolean28 = day21.equals((java.lang.Object) categoryPlot23);
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot23.getRangeAxisEdge();
//        try {
//            double double30 = dateAxis1.dateToJava2D(date15, rectangle2D16, rectangleEdge29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color2);
//        org.junit.Assert.assertNotNull(rectangleInsets4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertNotNull(rectangleInsets25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge29);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray11);
        java.lang.String str13 = categoryPlot7.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot7.notifyListeners(plotChangeEvent14);
        categoryPlot7.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis26.setLabelPaint((java.awt.Paint) color27);
        dateAxis26.setLabelAngle((double) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis26.setRangeWithMargins(range31, true, false);
        dateAxis20.setDefaultAutoRange(range31);
        dateAxis20.setAutoTickUnitSelection(true);
        categoryPlot7.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot39.configureRangeAxes();
        categoryPlot39.setRangeCrosshairLockedOnData(true);
        int int45 = categoryPlot39.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection46 = null;
        categoryPlot39.setFixedLegendItems(legendItemCollection46);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot39.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker50.setLabelAnchor(rectangleAnchor51);
        org.jfree.chart.text.TextAnchor textAnchor53 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker50.setLabelTextAnchor(textAnchor53);
        java.awt.Stroke stroke55 = valueMarker50.getStroke();
        categoryPlot39.setRangeCrosshairStroke(stroke55);
        dateAxis20.setTickMarkStroke(stroke55);
        categoryPlot0.setRangeGridlineStroke(stroke55);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 15 + "'", int45 == 15);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        boolean boolean6 = dateAxis1.isVisible();
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        org.jfree.data.Range range8 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis14.setLabelPaint((java.awt.Paint) color15);
        dateAxis14.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRangeWithMargins(range25, true, false);
        dateAxis14.setDefaultAutoRange(range25);
        dateAxis12.setRange(range25);
        numberAxis5.setRangeWithMargins(range25, true, false);
        boolean boolean34 = numberAxis5.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) color3);
        double double6 = rectangleInsets0.calculateRightOutset(3.0d);
        double double8 = rectangleInsets0.calculateTopInset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        int int7 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str3 = chartChangeEventType2.toString();
        java.awt.Color color4 = java.awt.Color.PINK;
        boolean boolean5 = chartChangeEventType2.equals((java.lang.Object) color4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double12 = intervalMarker11.getStartValue();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker11.setLabelFont(font13);
        boolean boolean15 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11);
        boolean boolean16 = categoryPlot6.isRangeZoomable();
        java.awt.Color color18 = java.awt.Color.RED;
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Stroke stroke22 = intervalMarker21.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets23, dataset24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_RED;
        boolean boolean27 = rectangleInsets23.equals((java.lang.Object) color26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot28.getRangeAxisLocation((int) (byte) 1);
        categoryPlot28.configureRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        int int34 = categoryPlot28.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = null;
        categoryPlot28.setFixedLegendItems(legendItemCollection35);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = categoryPlot28.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker39.setLabelAnchor(rectangleAnchor40);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker39.setLabelTextAnchor(textAnchor42);
        java.awt.Stroke stroke44 = valueMarker39.getStroke();
        categoryPlot28.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) (-1), (java.awt.Paint) color18, stroke22, (java.awt.Paint) color26, stroke44, 0.0f);
        categoryPlot6.setRangeCrosshairStroke(stroke44);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis49.clearCategoryLabelToolTips();
        java.awt.Paint paint51 = categoryAxis49.getTickLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        double double53 = categoryAxis52.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation((int) (byte) 1);
        boolean boolean61 = categoryPlot58.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        categoryPlot58.setDataset(categoryDataset62);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = categoryPlot58.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace66 = categoryPlot58.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot58.getDomainAxisEdge((int) (short) 100);
        double double69 = categoryAxis52.getCategoryJava2DCoordinate(categoryAnchor54, (int) (byte) -1, (int) 'a', rectangle2D57, rectangleEdge68);
        categoryAxis52.setCategoryLabelPositionOffset(5);
        categoryAxis52.clearCategoryLabelToolTips();
        categoryAxis52.clearCategoryLabelToolTips();
        java.awt.Stroke stroke74 = categoryAxis52.getAxisLineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker76 = new org.jfree.chart.plot.IntervalMarker((double) 0L, (double) 4, (java.awt.Paint) color4, stroke44, paint51, stroke74, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str3.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(categoryAxis65);
        org.junit.Assert.assertNull(axisSpace66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot30.getRangeAxis(12);
        double double40 = xYPlot30.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        try {
            xYPlot30.setDomainAxisLocation(axisLocation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            categoryPlot0.handleClick((int) (byte) 0, 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis5.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis5.setTickUnit(numberTickUnit17, true, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis5.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNotNull(tickUnitSource21);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        boolean boolean11 = categoryPlot8.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot8.setDomainAxes(categoryAxisArray12);
        java.lang.String str14 = categoryPlot8.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot8.notifyListeners(plotChangeEvent15);
        categoryPlot8.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis27.setLabelPaint((java.awt.Paint) color28);
        dateAxis27.setLabelAngle((double) ' ');
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis27.setRangeWithMargins(range32, true, false);
        dateAxis21.setDefaultAutoRange(range32);
        dateAxis21.setAutoTickUnitSelection(true);
        categoryPlot8.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        boolean boolean40 = dateAxis1.equals((java.lang.Object) dateAxis21);
        java.text.DateFormat dateFormat41 = null;
        dateAxis21.setDateFormatOverride(dateFormat41);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        boolean boolean6 = dateAxis4.isInverted();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) textAnchor8);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker11.setLabelAnchor(rectangleAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        java.lang.Object obj16 = valueMarker11.clone();
        valueMarker11.setValue((double) (-1L));
        float float19 = valueMarker11.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str21 = chartChangeEventType20.toString();
        java.awt.Color color22 = java.awt.Color.PINK;
        boolean boolean23 = chartChangeEventType20.equals((java.lang.Object) color22);
        boolean boolean24 = valueMarker11.equals((java.lang.Object) color22);
        java.awt.Color color25 = color22.brighter();
        boolean boolean26 = textAnchor8.equals((java.lang.Object) color22);
        dateAxis4.setAxisLinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.8f + "'", float19 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str21.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("");
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis66);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateBottomOutset((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        double double4 = categoryAxis3.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        boolean boolean12 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot9.setDataset(categoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot9.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getDomainAxisEdge((int) (short) 100);
        double double20 = categoryAxis3.getCategoryJava2DCoordinate(categoryAnchor5, (int) (byte) -1, (int) 'a', rectangle2D8, rectangleEdge19);
        categoryAxis3.setCategoryLabelPositionOffset(5);
        categoryAxis3.clearCategoryLabelToolTips();
        categoryAxis3.clearCategoryLabelToolTips();
        java.awt.Stroke stroke25 = categoryAxis3.getAxisLineStroke();
        java.awt.Color color26 = java.awt.Color.YELLOW;
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint29 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot28.setInsets(rectangleInsets30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer32 };
        categoryPlot28.setRenderers(categoryItemRendererArray33);
        int int35 = categoryPlot28.getRangeAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker37.setLabelAnchor(rectangleAnchor38);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker37.setLabelTextAnchor(textAnchor40);
        java.awt.Stroke stroke42 = valueMarker37.getStroke();
        categoryPlot28.setRangeCrosshairStroke(stroke42);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, (double) '4', (java.awt.Paint) color2, stroke25, (java.awt.Paint) color26, stroke42, (float) (-83));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        java.util.List list5 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge4);
        org.junit.Assert.assertNull(list5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=0,b=192]" + "'", str1.equals("java.awt.Color[r=192,g=0,b=192]"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateBottomInset((double) (short) 10);
        double double9 = rectangleInsets5.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets5.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean12 = unitType10.equals((java.lang.Object) textAnchor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) (-1L), (double) (byte) -1, 0.0d, 0.0d);
        intervalMarker2.setLabelOffset(rectangleInsets17);
        try {
            intervalMarker2.setAlpha((float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-8.0d) + "'", double9 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = null;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        try {
            java.awt.Stroke stroke8 = defaultDrawingSupplier6.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateBottomInset((double) (short) 10);
        double double9 = rectangleInsets5.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets5.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean12 = unitType10.equals((java.lang.Object) textAnchor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) (-1L), (double) (byte) -1, 0.0d, 0.0d);
        intervalMarker2.setLabelOffset(rectangleInsets17);
        java.awt.Stroke stroke19 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-8.0d) + "'", double9 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        int int13 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        long long7 = day4.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day4.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        xYPlot30.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        java.awt.Color color9 = java.awt.Color.BLACK;
        int int10 = color9.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        boolean boolean14 = categoryPlot11.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray15 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot11.setDomainAxes(categoryAxisArray15);
        java.lang.String str17 = categoryPlot11.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        categoryPlot11.notifyListeners(plotChangeEvent18);
        categoryPlot11.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis30.setLabelPaint((java.awt.Paint) color31);
        dateAxis30.setLabelAngle((double) ' ');
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis30.setRangeWithMargins(range35, true, false);
        dateAxis24.setDefaultAutoRange(range35);
        dateAxis24.setAutoTickUnitSelection(true);
        categoryPlot11.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis24);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot43.getRangeAxisLocation((int) (byte) 1);
        categoryPlot43.configureRangeAxes();
        categoryPlot43.setRangeCrosshairLockedOnData(true);
        int int49 = categoryPlot43.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = null;
        categoryPlot43.setFixedLegendItems(legendItemCollection50);
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = categoryPlot43.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker54.setLabelAnchor(rectangleAnchor55);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker54.setLabelTextAnchor(textAnchor57);
        java.awt.Stroke stroke59 = valueMarker54.getStroke();
        categoryPlot43.setRangeCrosshairStroke(stroke59);
        dateAxis24.setTickMarkStroke(stroke59);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((-8.0d), (java.awt.Paint) color9, stroke59);
        java.lang.String str63 = valueMarker62.getLabel();
        boolean boolean64 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker62);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 15 + "'", int49 == 15);
        org.junit.Assert.assertNotNull(plotOrientation52);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 43629L, (float) (-256), 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        categoryPlot0.setInsets(rectangleInsets11, false);
        categoryPlot0.mapDatasetToRangeAxis(12, (int) (short) -1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        int int7 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker9.setLabelAnchor(rectangleAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = valueMarker9.getStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItemCollection16);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        valueMarker1.setOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker1.notifyListeners(markerChangeEvent9);
        float float11 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.8f + "'", float11 == 0.8f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double14 = intervalMarker13.getStartValue();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker13.setLabelFont(font15);
        boolean boolean17 = categoryPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker13.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker13);
        org.jfree.chart.plot.Marker marker21 = markerChangeEvent20.getMarker();
        java.lang.Object obj22 = markerChangeEvent20.getSource();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(marker21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.setRangeAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.clearDomainMarkers(0);
        categoryPlot9.setAnchorValue((double) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo16, point2D17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot9.addChangeListener(plotChangeListener19);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        dateAxis1.setUpperMargin(0.0d);
        float float21 = dateAxis1.getTickMarkOutsideLength();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("", timeZone23);
        dateAxis1.setTimeZone(timeZone23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        java.awt.Font font5 = categoryAxis2.getLabelFont();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        double double6 = rectangleInsets4.calculateTopOutset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(15);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker3.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets6.getBottom();
        boolean boolean8 = intervalMarker3.equals((java.lang.Object) rectangleInsets6);
        categoryAxis0.setLabelInsets(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        java.awt.Shape shape6 = dateAxis4.getLeftArrow();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo5, point2D6, true);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean18 = numberAxis17.isAutoTickUnitSelection();
        org.jfree.data.Range range19 = categoryPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot20.setInsets(rectangleInsets22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray25 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer24 };
        categoryPlot20.setRenderers(categoryItemRendererArray25);
        numberAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = numberAxis17.getTickUnit();
        numberAxis11.setTickUnit(numberTickUnit28, false, true);
        numberAxis11.setRangeWithMargins(0.0d, (double) 9);
        categoryPlot0.setRangeAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) numberAxis11, false);
        java.lang.Object obj37 = numberAxis11.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray25);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) 100);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        double double6 = rectangleInsets4.calculateLeftInset((-8.0d));
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
//        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        categoryPlot6.setInsets(rectangleInsets8);
//        categoryPlot6.clearDomainMarkers();
//        boolean boolean11 = day4.equals((java.lang.Object) categoryPlot6);
//        int int12 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertNotNull(rectangleInsets8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        double double8 = dateAxis4.getFixedAutoRange();
        org.jfree.data.Range range9 = null;
        try {
            dateAxis4.setRange(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8);
        categoryPlot6.clearDomainMarkers();
        boolean boolean11 = day4.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot6.getRangeAxisEdge();
        categoryPlot6.clearRangeMarkers();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer((-83));
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getDomainAxisEdge((-83));
        float float13 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        boolean boolean3 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getRangeAxisLocation((int) (byte) 1);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color17);
        dateAxis16.setLabelAngle((double) ' ');
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRangeWithMargins(range21, true, false);
        dateAxis16.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis28.setLabelPaint((java.awt.Paint) color29);
        dateAxis28.setLabelAngle((double) ' ');
        org.jfree.data.Range range33 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRangeWithMargins(range33, true, false);
        dateAxis16.setRange(range33);
        int int38 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint46 = categoryPlot43.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot43.setOrientation(plotOrientation47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation42, plotOrientation47);
        try {
            double double50 = dateAxis16.java2DToValue((double) 3, rectangle2D41, rectangleEdge49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot3.setInsets(rectangleInsets5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray8 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer7 };
        categoryPlot3.setRenderers(categoryItemRendererArray8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace15 = dateAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot3, rectangle2D10, rectangleEdge13, axisSpace14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(categoryItemRendererArray8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        double double20 = dateAxis1.getFixedAutoRange();
        java.text.DateFormat dateFormat21 = null;
        dateAxis1.setDateFormatOverride(dateFormat21);
        org.jfree.data.Range range23 = dateAxis1.getRange();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        xYPlot30.clearDomainMarkers(10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean43 = xYPlot30.removeAnnotation(xYAnnotation41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
//        int int8 = day4.getYear();
//        int int9 = day4.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        long long11 = day4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = color1.brighter();
        boolean boolean3 = textAnchor0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range14);
        dateAxis1.setRangeWithMargins(range14, true, true);
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true, jFreeChart19);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Paint paint3 = intervalMarker2.getLabelPaint();
        java.lang.Object obj4 = intervalMarker2.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker7.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double11 = rectangleInsets10.getBottom();
        boolean boolean12 = intervalMarker7.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker7.setLabelOffsetType(lengthAdjustmentType13);
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.plot.Plot plot7 = categoryPlot0.getRootPlot();
        try {
            categoryPlot0.mapDatasetToDomainAxis((-83), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        boolean boolean8 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L), jFreeChart3);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent4.getChart();
        boolean boolean7 = rectangleAnchor1.equals((java.lang.Object) jFreeChart6);
        try {
            java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1L) + "'", obj5.equals((-1L)));
        org.junit.Assert.assertNull(jFreeChart6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str1.equals("TextAnchor.TOP_LEFT"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.lang.String str2 = plotOrientation1.toString();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.VERTICAL" + "'", str2.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot30.setDomainZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = xYPlot30.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot30.getRangeAxis((-1));
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = null;
        xYPlot30.setDrawingSupplier(drawingSupplier40);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("", timeZone45);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!", timeZone45);
        dateAxis47.resizeRange((double) 100L, 10.0d);
        boolean boolean51 = dateAxis47.isTickLabelsVisible();
        xYPlot30.setDomainAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets0, dataset1);
        double double4 = rectangleInsets0.calculateLeftInset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis5.configure();
        numberAxis5.setFixedAutoRange((double) 2.0f);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setBackgroundImageAlpha(0.0f);
        java.lang.String str26 = categoryPlot23.getNoDataMessage();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot23.getDomainAxisEdge(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = numberAxis5.draw(graphics2D19, 6.0d, rectangle2D21, rectangle2D22, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection38 = categoryPlot32.getRangeMarkers((int) (short) 100, layer37);
        boolean boolean39 = categoryPlot32.isDomainGridlinesVisible();
        dateAxis13.setPlot((org.jfree.chart.plot.Plot) categoryPlot32);
        int int41 = categoryPlot32.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot42.getRangeAxisLocation((int) (byte) 1);
        boolean boolean45 = categoryPlot42.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        categoryPlot42.setDataset(categoryDataset46);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = categoryPlot42.getDomainAxis(15);
        java.awt.Stroke stroke50 = categoryPlot42.getRangeCrosshairStroke();
        categoryPlot32.setOutlineStroke(stroke50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        try {
            categoryPlot32.drawBackground(graphics2D52, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(categoryAxis49);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone3);
        java.util.Date date6 = day5.getEnd();
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) date6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis8.getCategoryLabelPositions();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis8.setTickLabelFont((java.lang.Comparable) true, font14);
        boolean boolean16 = chartChangeEventType0.equals((java.lang.Object) true);
        java.lang.String str17 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str17.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.lang.String str10 = plotOrientation9.toString();
        java.lang.String str11 = plotOrientation9.toString();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotOrientation.VERTICAL" + "'", str10.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PlotOrientation.VERTICAL" + "'", str11.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        boolean boolean3 = categoryPlot0.getDrawSharedDomainAxis();
        double double4 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        java.awt.Font font19 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Font font21 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "SeriesRenderingOrder.REVERSE");
        boolean boolean22 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.setCategoryLabelPositionOffset((-83));
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot26.setInsets(rectangleInsets28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer30 };
        categoryPlot26.setRenderers(categoryItemRendererArray31);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        categoryPlot26.notifyListeners(plotChangeEvent33);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint40 = categoryPlot37.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot37.setOrientation(plotOrientation41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation41);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = categoryAxis0.reserveSpace(graphics2D25, (org.jfree.chart.plot.Plot) categoryPlot26, rectangle2D35, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8);
        categoryPlot6.clearDomainMarkers();
        boolean boolean11 = day4.equals((java.lang.Object) categoryPlot6);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day4.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        double double4 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean9 = categoryPlot0.removeDomainMarker((int) (short) 10, marker7, layer8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = xYPlot30.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        try {
            xYPlot30.zoomDomainAxes((double) (short) 1, (double) 0.5f, plotRenderingInfo52, point2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.05) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.setAutoTickUnitSelection(false, false);
        java.awt.Paint paint8 = dateAxis4.getLabelPaint();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double6 = intervalMarker5.getStartValue();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker5.setLabelFont(font7);
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        double double10 = intervalMarker5.getEndValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = intervalMarker5.getLabelAnchor();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.Plot plot3 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot5.getRangeAxisLocation((int) (byte) 1);
        boolean boolean8 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets9.getBottom();
        categoryPlot5.setAxisOffset(rectangleInsets9);
        categoryPlot4.setInsets(rectangleInsets9);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker14.setLabelAnchor(rectangleAnchor15);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker14.setLabelTextAnchor(textAnchor17);
        java.awt.Stroke stroke19 = valueMarker14.getStroke();
        categoryPlot4.setRangeGridlineStroke(stroke19);
        categoryPlot0.setRangeCrosshairStroke(stroke19);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        categoryPlot0.clearRangeMarkers(173);
        java.awt.Paint paint13 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        double double15 = categoryAxis14.getCategoryMargin();
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis14.getCategoryLabelPositions();
        int int19 = categoryPlot0.getDomainAxisIndex(categoryAxis14);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Paint paint1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = null;
        java.awt.Stroke[] strokeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray6 = null;
        java.awt.Shape[] shapeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray5, strokeArray6, shapeArray7);
        java.awt.Stroke stroke9 = defaultDrawingSupplier8.getNextStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 12, paint1, stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxisForDataset(4);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot0.getRangeAxisEdge((int) 'a');
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot0.getRenderer((int) (byte) 0);
        int int20 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-256), (double) 4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str5 = datasetRenderingOrder4.toString();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str5.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        categoryPlot0.setDomainAxisLocation(4, axisLocation14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        java.awt.Image image5 = null;
        categoryPlot0.setBackgroundImage(image5);
        categoryPlot0.clearRangeAxes();
        double double8 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setRangeCrosshairValue((double) 4, false);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot9.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets12, dataset13);
        java.lang.Object obj15 = datasetChangeEvent14.getSource();
        categoryPlot9.datasetChanged(datasetChangeEvent14);
        categoryPlot0.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot0.zoomDomainAxes(0.0d, (double) (short) 0, plotRenderingInfo34, point2D35);
        java.awt.Color color37 = java.awt.Color.PINK;
        int int38 = color37.getBlue();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 175 + "'", int38 == 175);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue((double) (-1));
        intervalMarker2.setStartValue((double) 3);
        java.lang.String str8 = intervalMarker2.getLabel();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        float float28 = numberAxis5.getTickMarkInsideLength();
        numberAxis5.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace39);
        java.util.List list41 = xYPlot30.getAnnotations();
        boolean boolean42 = xYPlot30.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot30.getRangeAxisLocation();
        java.awt.Paint paint37 = xYPlot30.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot0.setDataset(categoryDataset9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) textAnchor1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker4.setLabelAnchor(rectangleAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker4.setLabelTextAnchor(textAnchor7);
        java.lang.Object obj9 = valueMarker4.clone();
        valueMarker4.setValue((double) (-1L));
        float float12 = valueMarker4.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str14 = chartChangeEventType13.toString();
        java.awt.Color color15 = java.awt.Color.PINK;
        boolean boolean16 = chartChangeEventType13.equals((java.lang.Object) color15);
        boolean boolean17 = valueMarker4.equals((java.lang.Object) color15);
        java.awt.Color color18 = color15.brighter();
        boolean boolean19 = textAnchor1.equals((java.lang.Object) color15);
        java.lang.String str20 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.8f + "'", float12 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str14.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.CENTER" + "'", str20.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color1 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot2.setInsets(rectangleInsets4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        int int9 = categoryPlot2.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot2.setDomainGridlinePosition(categoryAnchor10);
        boolean boolean12 = color1.equals((java.lang.Object) categoryAnchor10);
        java.awt.Color color13 = java.awt.Color.orange;
        boolean boolean14 = categoryAnchor10.equals((java.lang.Object) color13);
        boolean boolean15 = numberAxis0.equals((java.lang.Object) categoryAnchor10);
        double double16 = numberAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        int int5 = categoryAxis2.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        categoryAxis0.setCategoryLabelPositionOffset(5);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation((int) (byte) 1);
        boolean boolean28 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot25.setDataset(categoryDataset29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot25.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace33 = categoryPlot25.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot25.getDomainAxisEdge((int) (short) 100);
        try {
            double double36 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (-1.0d), (java.lang.Comparable) '#', categoryDataset22, 0.0d, rectangle2D24, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(axisSpace33);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean56 = dateAxis54.isHiddenValue((long) 100);
        dateAxis54.setInverted(false);
        org.jfree.data.Range range59 = dateAxis54.getRange();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean64 = dateAxis62.isHiddenValue((long) 100);
        dateAxis62.setInverted(false);
        boolean boolean67 = dateAxis62.isVisible();
        java.awt.Color color68 = java.awt.Color.YELLOW;
        dateAxis62.setTickLabelPaint((java.awt.Paint) color68);
        int int70 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        java.awt.Stroke stroke71 = xYPlot30.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        boolean boolean3 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot4.getRangeAxisLocation((int) (byte) 1);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot4.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot4.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color17);
        dateAxis16.setLabelAngle((double) ' ');
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRangeWithMargins(range21, true, false);
        dateAxis16.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis28.setLabelPaint((java.awt.Paint) color29);
        dateAxis28.setLabelAngle((double) ' ');
        org.jfree.data.Range range33 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRangeWithMargins(range33, true, false);
        dateAxis16.setRange(range33);
        int int38 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis16);
        categoryPlot0.clearDomainMarkers(1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis12.setLabelPaint((java.awt.Paint) color13);
        dateAxis12.setLabelAngle((double) ' ');
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRangeWithMargins(range17, true, false);
        dateAxis12.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        dateAxis12.setRange(range29);
        int int34 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        boolean boolean35 = dateAxis12.isNegativeArrowVisible();
        dateAxis12.setVisible(true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot30.setDataset(1, xYDataset55);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation((int) (byte) 1);
        boolean boolean61 = categoryPlot58.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection64 = categoryPlot58.getDomainMarkers(255, layer63);
        java.util.Collection collection65 = xYPlot30.getRangeMarkers(8, layer63);
        xYPlot30.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNull(collection65);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        java.awt.Paint paint66 = xYPlot30.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace67 = xYPlot30.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNull(axisSpace67);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        categoryPlot9.configureRangeAxes();
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection15 = categoryPlot9.getRangeMarkers((int) (short) 100, layer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot9.getDomainAxisEdge((int) (byte) 10);
        try {
            double double18 = categoryAxis0.getCategoryMiddle(10, 0, rectangle2D8, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        boolean boolean34 = xYPlot30.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("AxisLocation.TOP_OR_LEFT");
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(255, layer5);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 100);
        java.awt.Font font12 = null;
        try {
            dateAxis1.setLabelFont(font12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot30.zoomDomainAxes((double) 2019, plotRenderingInfo52, point2D53, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot30.getRangeAxisForDataset((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 32 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        categoryPlot0.setWeight((int) (short) 100);
        java.awt.Stroke stroke13 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot0.zoomRangeAxes(0.2d, plotRenderingInfo15, point2D16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot18.getRangeAxisLocation((int) (byte) 1);
        boolean boolean21 = categoryPlot18.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot18.setDataset(categoryDataset22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot18.getDomainAxis(15);
        java.awt.Stroke stroke26 = categoryPlot18.getRangeCrosshairStroke();
        categoryPlot0.setOutlineStroke(stroke26);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        double double10 = rectangleInsets8.trimHeight((double) 0L);
        double double12 = rectangleInsets8.calculateBottomOutset(0.2d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-8.0d) + "'", double10 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint4 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot3.zoomRangeAxes((double) 2, plotRenderingInfo6, point2D7, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double13 = intervalMarker12.getStartValue();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker12.setLabelFont(font14);
        categoryPlot3.setNoDataMessageFont(font14);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 255, font14);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.extendHeight(0.0d);
        double double9 = rectangleInsets4.calculateLeftOutset(8.0d);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets4.createOutsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.0d + "'", double7 == 6.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        categoryPlot9.notifyListeners(plotChangeEvent12);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isAutoTickUnitSelection();
        org.jfree.data.Range range16 = categoryPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint18 = categoryPlot17.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot17.setInsets(rectangleInsets19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray22 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer21 };
        categoryPlot17.setRenderers(categoryItemRendererArray22);
        numberAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis14.setRangeWithMargins(range25);
        numberAxis14.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = numberAxis14.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean31 = numberAxis30.isAutoTickUnitSelection();
        numberAxis30.setAutoRangeStickyZero(true);
        double double34 = numberAxis30.getAutoRangeMinimumSize();
        numberAxis30.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer37);
        int int39 = xYPlot38.getRangeAxisCount();
        xYPlot38.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = xYPlot38.getAxisOffset();
        xYPlot38.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot45.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double51 = intervalMarker50.getStartValue();
        java.awt.Font font52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker50.setLabelFont(font52);
        boolean boolean54 = categoryPlot45.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        double double55 = intervalMarker50.getEndValue();
        xYPlot38.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        org.jfree.chart.util.Layer layer57 = null;
        boolean boolean58 = categoryPlot0.removeDomainMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker50, layer57);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNull(markerAxisBand29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E-8d + "'", double34 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-1.0d) + "'", double51 == (-1.0d));
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 4.0d + "'", double55 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopOutset(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        numberAxis5.setLabelToolTip("AxisLocation.TOP_OR_LEFT");
        java.text.NumberFormat numberFormat30 = null;
        numberAxis5.setNumberFormatOverride(numberFormat30);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot30.setDomainZeroBaselinePaint((java.awt.Paint) color34);
        java.awt.Color color36 = color34.brighter();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone3);
        java.util.Date date6 = day5.getEnd();
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) date6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis8.getCategoryLabelPositions();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis8.setTickLabelFont((java.lang.Comparable) true, font14);
        boolean boolean16 = chartChangeEventType0.equals((java.lang.Object) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint18 = categoryPlot17.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup19 = categoryPlot17.getDatasetGroup();
        boolean boolean20 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot21.getRangeAxisLocation((int) (byte) 1);
        boolean boolean24 = categoryPlot21.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot21.setDataset(categoryDataset25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot21.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot21.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis33.setLabelPaint((java.awt.Paint) color34);
        dateAxis33.setLabelAngle((double) ' ');
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRangeWithMargins(range38, true, false);
        dateAxis33.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis45.setLabelPaint((java.awt.Paint) color46);
        dateAxis45.setLabelAngle((double) ' ');
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis45.setRangeWithMargins(range50, true, false);
        dateAxis33.setRange(range50);
        int int55 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        categoryPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis33);
        boolean boolean57 = chartChangeEventType0.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = null;
        categoryPlot17.setFixedLegendItems(legendItemCollection58);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(datasetGroup19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        java.awt.Font font17 = dateAxis1.getTickLabelFont();
        java.awt.Paint paint18 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = numberAxis5.getMarkerBand();
        numberAxis5.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(markerAxisBand20);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        boolean boolean2 = rectangleInsets0.equals((java.lang.Object) textAnchor1);
        boolean boolean4 = textAnchor1.equals((java.lang.Object) "EXPAND");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer((int) (short) 100);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue(100.0d);
        java.awt.Paint paint6 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets4.getBottom();
        categoryPlot0.setAxisOffset(rectangleInsets4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.addChangeListener(plotChangeListener7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot0.addChangeListener(plotChangeListener9);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        java.lang.Object obj39 = xYPlot30.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis1.setTimeline(timeline19);
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone3);
//        java.util.Date date6 = day5.getEnd();
//        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        long long9 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(chartChangeEventType0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean56 = dateAxis54.isHiddenValue((long) 100);
        dateAxis54.setInverted(false);
        org.jfree.data.Range range59 = dateAxis54.getRange();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.axis.AxisLocation axisLocation61 = xYPlot30.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        boolean boolean6 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        boolean boolean11 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation15.getOpposite();
        boolean boolean17 = lengthAdjustmentType12.equals((java.lang.Object) axisLocation15);
        categoryPlot7.setDomainAxisLocation(axisLocation15, true);
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace21);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        org.jfree.chart.axis.AxisLocation axisLocation67 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setDomainAxisLocation(0, axisLocation67, false);
        java.awt.Color color70 = java.awt.Color.BLACK;
        int int71 = color70.getTransparency();
        int int72 = color70.getGreen();
        xYPlot30.setRangeCrosshairPaint((java.awt.Paint) color70);
        org.jfree.data.xy.XYDataset xYDataset75 = xYPlot30.getDataset((-7903));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNull(xYDataset75);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setLowerMargin(8.0d);
        categoryAxis0.setCategoryLabelPositionOffset((int) '4');
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        categoryPlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getDomainAxisEdge((int) (byte) 0);
        try {
            double double20 = categoryAxis0.getCategoryMiddle(15, 0, rectangle2D8, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        int int4 = categoryPlot0.getDomainAxisCount();
        java.util.List list5 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(list5);
    }
}

