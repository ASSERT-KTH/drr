import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        java.lang.Object obj3 = objectList1.get(0);
        java.lang.Object obj5 = objectList1.get((-1));
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker4.getLabelAnchor();
        java.lang.Class<?> wildcardClass8 = valueMarker4.getClass();
        java.lang.Object obj9 = valueMarker4.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Color color1 = java.awt.Color.BLACK;
        int int2 = color1.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        boolean boolean6 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray7 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot3.setDomainAxes(categoryAxisArray7);
        java.lang.String str9 = categoryPlot3.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot3.notifyListeners(plotChangeEvent10);
        categoryPlot3.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color17);
        dateAxis16.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis22.setLabelPaint((java.awt.Paint) color23);
        dateAxis22.setLabelAngle((double) ' ');
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRangeWithMargins(range27, true, false);
        dateAxis16.setDefaultAutoRange(range27);
        dateAxis16.setAutoTickUnitSelection(true);
        categoryPlot3.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot35.getRangeAxisLocation((int) (byte) 1);
        categoryPlot35.configureRangeAxes();
        categoryPlot35.setRangeCrosshairLockedOnData(true);
        int int41 = categoryPlot35.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = null;
        categoryPlot35.setFixedLegendItems(legendItemCollection42);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker46.setLabelAnchor(rectangleAnchor47);
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker46.setLabelTextAnchor(textAnchor49);
        java.awt.Stroke stroke51 = valueMarker46.getStroke();
        categoryPlot35.setRangeCrosshairStroke(stroke51);
        dateAxis16.setTickMarkStroke(stroke51);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((-8.0d), (java.awt.Paint) color1, stroke51);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation57 = categoryPlot55.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double61 = intervalMarker60.getStartValue();
        java.awt.Font font62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker60.setLabelFont(font62);
        boolean boolean64 = categoryPlot55.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker60);
        java.awt.Stroke stroke65 = intervalMarker60.getOutlineStroke();
        valueMarker54.setStroke(stroke65);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 15 + "'", int41 == 15);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + (-1.0d) + "'", double61 == (-1.0d));
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation6, plotOrientation7);
        categoryPlot0.setDomainAxisLocation(axisLocation6, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getDomainAxisLocation((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomDomainAxes((double) (byte) -1, plotRenderingInfo14, point2D15, true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation19, false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset((int) '#', xYDataset37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset40 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets39, dataset40);
        java.lang.Object obj42 = datasetChangeEvent41.getSource();
        xYPlot30.datasetChanged(datasetChangeEvent41);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        java.awt.Stroke stroke25 = intervalMarker2.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = categoryPlot1.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker5, layer6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker5.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint7 = categoryPlot6.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot6.setInsets(rectangleInsets8);
        categoryPlot6.clearDomainMarkers();
        boolean boolean11 = day4.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setAnchorValue((double) (-1), true);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        java.lang.Object obj12 = null;
        boolean boolean13 = valueMarker11.equals(obj12);
        java.awt.Stroke stroke14 = valueMarker11.getStroke();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot0.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker11, layer15, false);
        org.jfree.chart.text.TextAnchor textAnchor18 = valueMarker11.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range14);
        dateAxis1.setRangeWithMargins(range14, true, true);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("", timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis23.setLabelPaint((java.awt.Paint) color24);
        dateAxis23.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis29.setLabelPaint((java.awt.Paint) color30);
        dateAxis29.setLabelAngle((double) ' ');
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range34, true, false);
        dateAxis23.setDefaultAutoRange(range34);
        dateAxis21.setRange(range34);
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis21.getTickUnit();
        dateAxis1.setTickUnit(dateTickUnit40, false, true);
        java.lang.String str44 = dateAxis1.getLabel();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        xYPlot30.setWeight(4);
        java.awt.Stroke stroke53 = xYPlot30.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot30.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace54 = xYPlot30.getFixedRangeAxisSpace();
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        xYPlot30.drawAnnotations(graphics2D55, rectangle2D56, plotRenderingInfo57);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNull(axisSpace54);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double6 = intervalMarker5.getStartValue();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker5.setLabelFont(font7);
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        java.lang.Object obj12 = null;
        boolean boolean13 = valueMarker11.equals(obj12);
        boolean boolean14 = intervalMarker5.equals(obj12);
        double double15 = intervalMarker5.getStartValue();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setTickMarkInsideLength((float) 43629L);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis8.setLabelPaint((java.awt.Paint) color9);
        dateAxis8.setLabelAngle((double) ' ');
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range13);
        dateAxis1.setRange(range13, false, true);
        java.util.Date date18 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.configure();
        java.awt.Font font7 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace39);
        java.util.List list41 = xYPlot30.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        xYPlot30.setRenderer((int) (short) 100, xYItemRenderer43);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        xYPlot30.drawAnnotations(graphics2D35, rectangle2D36, plotRenderingInfo37);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot30.getRendererForDataset(xYDataset39);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(xYItemRenderer40);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        boolean boolean3 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 71999999L + "'", long7 == 71999999L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = categoryPlot3.getOrientation();
        java.awt.Image image5 = categoryPlot3.getBackgroundImage();
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot3.setRangeGridlinePaint(paint6);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot3.setNoDataMessageFont(font8);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        categoryPlot11.configureRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        int int17 = categoryPlot11.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = null;
        categoryPlot11.setFixedLegendItems(legendItemCollection18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = categoryPlot11.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot22.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation25 = axisLocation24.getOpposite();
        categoryPlot11.setDomainAxisLocation(4, axisLocation25);
        boolean boolean27 = categoryAxis0.equals((java.lang.Object) categoryPlot11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        boolean boolean37 = xYPlot30.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot38.getRangeAxisLocation((int) (byte) 1);
        boolean boolean41 = categoryPlot38.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray42 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot38.setDomainAxes(categoryAxisArray42);
        java.lang.String str44 = categoryPlot38.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent45 = null;
        categoryPlot38.notifyListeners(plotChangeEvent45);
        categoryPlot38.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis51.setLabelPaint((java.awt.Paint) color52);
        dateAxis51.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis57.setLabelPaint((java.awt.Paint) color58);
        dateAxis57.setLabelAngle((double) ' ');
        org.jfree.data.Range range62 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis57.setRangeWithMargins(range62, true, false);
        dateAxis51.setDefaultAutoRange(range62);
        dateAxis51.setAutoTickUnitSelection(true);
        categoryPlot38.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis51);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation72 = categoryPlot70.getRangeAxisLocation((int) (byte) 1);
        categoryPlot70.configureRangeAxes();
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection76 = categoryPlot70.getRangeMarkers((int) (short) 100, layer75);
        boolean boolean77 = categoryPlot70.isDomainGridlinesVisible();
        dateAxis51.setPlot((org.jfree.chart.plot.Plot) categoryPlot70);
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis51);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray42);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        xYPlot30.setRenderer(13, xYItemRenderer37);
        int int39 = xYPlot30.getDatasetCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getFixedLegendItems();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        double double4 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        boolean boolean14 = categoryPlot11.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot11.setDataset(categoryDataset15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot11.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot11.getDomainAxisEdge((int) (short) 100);
        double double22 = categoryAxis5.getCategoryJava2DCoordinate(categoryAnchor7, (int) (byte) -1, (int) 'a', rectangle2D10, rectangleEdge21);
        java.awt.Font font24 = categoryAxis5.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Font font26 = categoryAxis5.getTickLabelFont((java.lang.Comparable) "SeriesRenderingOrder.REVERSE");
        boolean boolean27 = categoryAxis5.isTickMarksVisible();
        java.util.List list28 = categoryPlot0.getCategoriesForAxis(categoryAxis5);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot30.setDataset(1, xYDataset55);
        xYPlot30.setNoDataMessage("hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        double double5 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.general.DatasetGroup datasetGroup2 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.data.general.Dataset dataset4 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleInsets3, dataset4);
        java.lang.Object obj6 = datasetChangeEvent5.getSource();
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(0);
        org.jfree.chart.plot.Plot plot11 = categoryPlot8.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        boolean boolean16 = categoryPlot13.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets17.getBottom();
        categoryPlot13.setAxisOffset(rectangleInsets17);
        categoryPlot12.setInsets(rectangleInsets17);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker22.setLabelAnchor(rectangleAnchor23);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker22.setLabelTextAnchor(textAnchor25);
        java.awt.Stroke stroke27 = valueMarker22.getStroke();
        categoryPlot12.setRangeGridlineStroke(stroke27);
        categoryPlot8.setRangeCrosshairStroke(stroke27);
        categoryPlot0.setRangeGridlineStroke(stroke27);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        dateAxis4.setTickLabelsVisible(false);
        boolean boolean10 = dateAxis4.isAutoTickUnitSelection();
        dateAxis4.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot30.setFixedDomainAxisSpace(axisSpace36, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot30.zoomDomainAxes((double) 2019, plotRenderingInfo52, point2D53, false);
        double double56 = xYPlot30.getDomainCrosshairValue();
        try {
            xYPlot30.setBackgroundImageAlpha((float) 71999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot30.getDomainAxis();
        org.jfree.chart.plot.Marker marker51 = null;
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            boolean boolean54 = xYPlot30.removeRangeMarker(0, marker51, layer52, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(layer52);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot14.setInsets(rectangleInsets16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer18 };
        categoryPlot14.setRenderers(categoryItemRendererArray19);
        numberAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis11.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        java.lang.String str33 = dateAxis24.getLabel();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setDownArrow(shape34);
        numberAxis11.setRightArrow(shape34);
        dateAxis1.setUpArrow(shape34);
        try {
            dateAxis1.setRange(0.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.clearCategoryLabelToolTips();
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        categoryPlot0.configureRangeAxes();
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
//        java.lang.Class<?> wildcardClass8 = day4.getClass();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        double double4 = categoryPlot0.getAnchorValue();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray11 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot7.setDomainAxisLocation(axisLocation13, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation13, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        java.lang.String str6 = dateAxis1.getLabelURL();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean15 = categoryPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker13, layer14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot9.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot9.getRenderer((-83));
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot9.getDomainAxisEdge((-83));
        try {
            double double22 = dateAxis1.lengthToJava2D((double) 255, rectangle2D8, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        java.awt.Font font19 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Font font21 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "SeriesRenderingOrder.REVERSE");
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot22.getRangeAxisLocation((int) (byte) 1);
        categoryPlot22.configureRangeAxes();
        int int26 = categoryPlot22.getDatasetCount();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = null;
        categoryPlot34.notifyListeners(plotChangeEvent37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean40 = numberAxis39.isAutoTickUnitSelection();
        org.jfree.data.Range range41 = categoryPlot34.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis39);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint43 = categoryPlot42.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot42.setInsets(rectangleInsets44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray47 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer46 };
        categoryPlot42.setRenderers(categoryItemRendererArray47);
        numberAxis39.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot42);
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis39.setRangeWithMargins(range50);
        numberAxis39.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = numberAxis39.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean56 = numberAxis55.isAutoTickUnitSelection();
        numberAxis55.setAutoRangeStickyZero(true);
        double double59 = numberAxis55.getAutoRangeMinimumSize();
        numberAxis55.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis55, xYItemRenderer62);
        int int64 = xYPlot63.getRangeAxisCount();
        xYPlot63.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = xYPlot63.getAxisOffset();
        xYPlot63.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation72 = categoryPlot70.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double76 = intervalMarker75.getStartValue();
        java.awt.Font font77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker75.setLabelFont(font77);
        boolean boolean79 = categoryPlot70.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker75);
        double double80 = intervalMarker75.getEndValue();
        xYPlot63.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker75);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = xYPlot63.getDomainAxisEdge();
        try {
            double double83 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) (-8.0d), (java.lang.Comparable) 1.0f, categoryDataset30, 0.05d, rectangle2D32, rectangleEdge82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(categoryItemRendererArray47);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNull(markerAxisBand54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0E-8d + "'", double59 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-1.0d) + "'", double76 == (-1.0d));
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 4.0d + "'", double80 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        java.lang.String str10 = dateAxis1.getLabel();
        boolean boolean11 = dateAxis1.isVerticalTickLabels();
        java.lang.String str12 = dateAxis1.getLabel();
        boolean boolean13 = dateAxis1.isVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setValue((double) (-1L));
        float float9 = valueMarker1.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str11 = chartChangeEventType10.toString();
        java.awt.Color color12 = java.awt.Color.PINK;
        boolean boolean13 = chartChangeEventType10.equals((java.lang.Object) color12);
        boolean boolean14 = valueMarker1.equals((java.lang.Object) color12);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker1.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        dateAxis1.setFixedAutoRange(3.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot5.getRenderer();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateBottomInset((double) (short) 10);
        double double33 = rectangleInsets29.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean36 = unitType34.equals((java.lang.Object) textAnchor35);
        valueMarker28.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot5.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker28, layer38, false);
        valueMarker28.setLabel("TextAnchor.CENTER");
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent47 = null;
        categoryPlot44.notifyListeners(plotChangeEvent47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean50 = numberAxis49.isAutoTickUnitSelection();
        org.jfree.data.Range range51 = categoryPlot44.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis49);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint53 = categoryPlot52.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot52.setInsets(rectangleInsets54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray57 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer56 };
        categoryPlot52.setRenderers(categoryItemRendererArray57);
        numberAxis49.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot52);
        org.jfree.data.Range range60 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis49.setRangeWithMargins(range60);
        numberAxis49.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = numberAxis49.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean66 = numberAxis65.isAutoTickUnitSelection();
        numberAxis65.setAutoRangeStickyZero(true);
        double double69 = numberAxis65.getAutoRangeMinimumSize();
        numberAxis65.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer72 = null;
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis65, xYItemRenderer72);
        int int74 = xYPlot73.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot75.getRangeAxisLocation((int) (byte) 1);
        categoryPlot75.configureRangeAxes();
        categoryPlot75.setRangeCrosshairLockedOnData(true);
        int int81 = categoryPlot75.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection82 = null;
        categoryPlot75.setFixedLegendItems(legendItemCollection82);
        org.jfree.chart.plot.PlotOrientation plotOrientation84 = categoryPlot75.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker86 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker86.setLabelAnchor(rectangleAnchor87);
        org.jfree.chart.text.TextAnchor textAnchor89 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker86.setLabelTextAnchor(textAnchor89);
        java.awt.Stroke stroke91 = valueMarker86.getStroke();
        categoryPlot75.setRangeCrosshairStroke(stroke91);
        xYPlot73.setRangeCrosshairStroke(stroke91);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer94 = xYPlot73.getRenderer();
        xYPlot73.clearAnnotations();
        xYPlot73.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset97 = null;
        xYPlot73.setDataset(xYDataset97);
        valueMarker28.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot73);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-8.0d) + "'", double33 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(categoryItemRendererArray57);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNull(markerAxisBand64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0E-8d + "'", double69 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 15 + "'", int81 == 15);
        org.junit.Assert.assertNotNull(plotOrientation84);
        org.junit.Assert.assertNotNull(rectangleAnchor87);
        org.junit.Assert.assertNotNull(textAnchor89);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNull(xYItemRenderer94);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker21.setLabelAnchor(rectangleAnchor22);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker21.setLabelTextAnchor(textAnchor24);
        java.lang.Object obj26 = valueMarker21.clone();
        valueMarker21.setValue((double) (-1L));
        float float29 = valueMarker21.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str31 = chartChangeEventType30.toString();
        java.awt.Color color32 = java.awt.Color.PINK;
        boolean boolean33 = chartChangeEventType30.equals((java.lang.Object) color32);
        boolean boolean34 = valueMarker21.equals((java.lang.Object) color32);
        java.awt.Color color35 = color32.brighter();
        numberAxis5.setLabelPaint((java.awt.Paint) color32);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.8f + "'", float29 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str31.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker9.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint13 = categoryPlot12.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot12.setInsets(rectangleInsets14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer16 };
        categoryPlot12.setRenderers(categoryItemRendererArray17);
        org.jfree.chart.plot.Plot plot19 = categoryPlot12.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot20.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double26 = intervalMarker25.getStartValue();
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker25.setLabelFont(font27);
        boolean boolean29 = categoryPlot20.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        boolean boolean30 = categoryPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        intervalMarker9.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot12.setDataset((int) 'a', categoryDataset33);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertNotNull(plot19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation4);
        java.awt.Stroke stroke6 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        boolean boolean10 = categoryPlot7.isDomainGridlinesVisible();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color11);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1560495599999L, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis5.getTickUnit();
        boolean boolean17 = numberAxis5.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setTickMarkInsideLength((float) 43629L);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        java.lang.String str7 = dateAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        double double4 = numberAxis0.getAutoRangeMinimumSize();
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot8.notifyListeners(plotChangeEvent11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean14 = numberAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = categoryPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot16.setInsets(rectangleInsets18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot16.setRenderers(categoryItemRendererArray21);
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRangeWithMargins(range24);
        numberAxis13.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = numberAxis13.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean30 = numberAxis29.isAutoTickUnitSelection();
        numberAxis29.setAutoRangeStickyZero(true);
        double double33 = numberAxis29.getAutoRangeMinimumSize();
        numberAxis29.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer36);
        int int38 = xYPlot37.getRangeAxisCount();
        xYPlot37.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot37.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = xYPlot37.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        xYPlot37.setDomainAxis(valueAxis43);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(markerAxisBand28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0E-8d + "'", double33 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(legendItemCollection42);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker15.setStartValue((double) 0.0f);
        double double18 = intervalMarker15.getStartValue();
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean21 = categoryPlot0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker15, layer19, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        xYPlot30.clearDomainMarkers(10);
        org.jfree.data.xy.XYDataset xYDataset42 = xYPlot30.getDataset((-83));
        org.jfree.chart.annotations.XYAnnotation xYAnnotation43 = null;
        try {
            xYPlot30.addAnnotation(xYAnnotation43, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(xYDataset42);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot36.setRangeAxisLocation(axisLocation41, true);
        xYPlot30.setRangeAxisLocation(axisLocation41);
        xYPlot30.setForegroundAlpha((float) (byte) -1);
        java.awt.Paint paint47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot30.setDomainCrosshairPaint(paint47);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.clearCategoryLabelToolTips();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection12 = categoryPlot6.getRangeMarkers((int) (short) 100, layer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot6.getDomainAxisEdge((int) (byte) 10);
        try {
            java.util.List list15 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        java.lang.Object obj3 = objectList1.get(0);
        boolean boolean5 = objectList1.equals((java.lang.Object) 7.0d);
        java.awt.Paint[] paintArray7 = null;
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray9 = null;
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray11 = null;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray8, paintArray9, strokeArray10, strokeArray11, shapeArray12);
        objectList1.set((int) (short) 1, (java.lang.Object) paintArray8);
        java.awt.Paint[] paintArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray17 = null;
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray19 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray15, paintArray16, strokeArray17, strokeArray18, shapeArray19);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        categoryPlot0.clearRangeMarkers(173);
        java.awt.Paint paint13 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setRangeCrosshairValue((double) '#', false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setValue((double) (-1L));
        float float9 = valueMarker1.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str11 = chartChangeEventType10.toString();
        java.awt.Color color12 = java.awt.Color.PINK;
        boolean boolean13 = chartChangeEventType10.equals((java.lang.Object) color12);
        boolean boolean14 = valueMarker1.equals((java.lang.Object) color12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint19 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot16.setOrientation(plotOrientation20);
        categoryPlot16.setRangeCrosshairValue((double) 0L);
        boolean boolean24 = lengthAdjustmentType15.equals((java.lang.Object) 0L);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType15);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis27.setLabelPaint((java.awt.Paint) color28);
        dateAxis27.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis33.setLabelPaint((java.awt.Paint) color34);
        dateAxis33.setLabelAngle((double) ' ');
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRangeWithMargins(range38, true, false);
        dateAxis27.setDefaultAutoRange(range38);
        dateAxis27.setAutoTickUnitSelection(true);
        boolean boolean45 = dateAxis27.isTickLabelsVisible();
        boolean boolean46 = lengthAdjustmentType15.equals((java.lang.Object) dateAxis27);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        xYPlot30.setWeight(4);
        java.lang.Object obj53 = xYPlot30.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(obj53);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.next();
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot8.clearDomainMarkers(0);
//        org.jfree.chart.plot.Plot plot11 = categoryPlot8.getRootPlot();
//        int int12 = day4.compareTo((java.lang.Object) categoryPlot8);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(plot11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean56 = dateAxis54.isHiddenValue((long) 100);
        dateAxis54.setInverted(false);
        org.jfree.data.Range range59 = dateAxis54.getRange();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("", timeZone64);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!", timeZone64);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = dateAxis66.getLabelInsets();
        boolean boolean68 = dateAxis66.isInverted();
        xYPlot30.setDomainAxis(173, (org.jfree.chart.axis.ValueAxis) dateAxis66, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = null;
        try {
            xYPlot30.setOrientation(plotOrientation71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot10.setDataset(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot10.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot10.getDomainAxisEdge((int) (short) 100);
        double double21 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor6, (int) (byte) -1, (int) 'a', rectangle2D9, rectangleEdge20);
        int int22 = categoryPlot0.getDomainAxisIndex(categoryAxis4);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        valueMarker1.setValue((double) 10);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        java.lang.Object obj20 = numberAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.RangeType rangeType22 = numberAxis21.getRangeType();
        numberAxis5.setRangeType(rangeType22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rangeType22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str33 = axisLocation32.toString();
        xYPlot30.setDomainAxisLocation(axisLocation32, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str33.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.setAutoTickUnitSelection(true);
        dateAxis1.resizeRange((double) 7);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = numberAxis5.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis5.setMarkerBand(markerAxisBand25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = categoryPlot3.getOrientation();
        java.awt.Image image5 = categoryPlot3.getBackgroundImage();
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot3.setRangeGridlinePaint(paint6);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot3.setNoDataMessageFont(font8);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font8);
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        categoryPlot0.setRangeCrosshairValue((double) 15);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot0.drawBackgroundImage(graphics2D9, rectangle2D10);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation6, plotOrientation7);
        categoryPlot0.setDomainAxisLocation(axisLocation6, true);
        org.jfree.chart.plot.Plot plot11 = null;
        categoryPlot0.setParent(plot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot0.getColumnRenderingOrder();
        java.lang.String str11 = sortOrder10.toString();
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SortOrder.ASCENDING" + "'", str11.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint3);
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        try {
            boolean boolean8 = categoryPlot0.removeAnnotation(categoryAnnotation6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double6 = rectangleInsets5.getBottom();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) rectangleInsets5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double16 = intervalMarker15.getStartValue();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker15.setLabelFont(font17);
        boolean boolean19 = categoryPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        java.awt.Stroke stroke20 = intervalMarker15.getOutlineStroke();
        boolean boolean21 = intervalMarker2.equals((java.lang.Object) stroke20);
        java.lang.Object obj22 = intervalMarker2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot23.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = categoryPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker27, layer28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker27.getLabelAnchor();
        java.lang.Class<?> wildcardClass31 = valueMarker27.getClass();
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        try {
            java.util.EventListener[] eventListenerArray33 = intervalMarker2.getListeners(class32);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class32);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.awt.Stroke stroke6 = valueMarker1.getStroke();
        valueMarker1.setValue((double) 1L);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets4.getUnitType();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker11, layer12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot7.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot7.getRenderer((-83));
        boolean boolean18 = unitType6.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot7.getDomainAxisEdge(12);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        double double20 = dateAxis1.getFixedAutoRange();
        java.text.DateFormat dateFormat21 = null;
        dateAxis1.setDateFormatOverride(dateFormat21);
        java.lang.String str23 = dateAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Color color1 = java.awt.Color.getColor("TextAnchor.HALF_ASCENT_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        java.awt.Font font66 = xYPlot30.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = xYPlot30.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        xYPlot30.setFixedDomainAxisSpace(axisSpace68);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = numberAxis5.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        numberAxis5.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        double double19 = categoryAxis18.getCategoryMargin();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis18.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setTickMarkInsideLength((float) 43629L);
        java.awt.Shape shape6 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis8.setLabelPaint((java.awt.Paint) color9);
        dateAxis8.setLabelAngle((double) ' ');
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range13);
        dateAxis1.setRange(range13, false, true);
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) -1);
        java.lang.Object obj21 = chartChangeEvent20.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent20.setType(chartChangeEventType22);
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        chartChangeEvent20.setChart(jFreeChart24);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str27 = chartChangeEventType26.toString();
        chartChangeEvent20.setType(chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) -1);
        java.lang.Object obj31 = chartChangeEvent30.getSource();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        chartChangeEvent30.setChart(jFreeChart32);
        boolean boolean34 = chartChangeEventType26.equals((java.lang.Object) chartChangeEvent30);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) range13, jFreeChart18, chartChangeEventType26);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = chartChangeEvent35.getType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + obj21 + "' != '" + (short) -1 + "'", obj21.equals((short) -1));
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str27.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + (short) -1 + "'", obj31.equals((short) -1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType36);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        java.awt.Paint paint66 = xYPlot30.getRangeTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double69 = rectangleInsets67.calculateBottomInset((double) (short) 10);
        double double71 = rectangleInsets67.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType72 = rectangleInsets67.getUnitType();
        boolean boolean73 = xYPlot30.equals((java.lang.Object) rectangleInsets67);
        java.awt.Color color75 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color76 = color75.brighter();
        try {
            xYPlot30.setQuadrantPaint((int) (short) 100, (java.awt.Paint) color75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.0d + "'", double69 == 2.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-8.0d) + "'", double71 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(color76);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) 100, (float) (short) 100);
        int int4 = color3.getBlue();
        java.awt.Color color5 = color3.darker();
        float[] floatArray6 = null;
        float[] floatArray7 = color3.getRGBColorComponents(floatArray6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 173 + "'", int4 == 173);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot56.getRangeAxisLocation((int) (byte) 1);
        boolean boolean59 = categoryPlot56.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double61 = rectangleInsets60.getBottom();
        categoryPlot56.setAxisOffset(rectangleInsets60);
        categoryPlot56.setAnchorValue((double) 10.0f);
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot56.setRangeCrosshairStroke(stroke65);
        xYPlot30.setRangeCrosshairStroke(stroke65);
        java.lang.Object obj68 = null;
        boolean boolean69 = xYPlot30.equals(obj68);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date0);
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot30.setDomainZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = xYPlot30.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot30.getRangeAxis((-1));
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis45.setLabelPaint((java.awt.Paint) color46);
        dateAxis45.setLabelAngle((double) ' ');
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis45.setRangeWithMargins(range50, true, false);
        java.lang.Object obj54 = dateAxis45.clone();
        boolean boolean55 = intervalMarker43.equals(obj54);
        org.jfree.chart.util.Layer layer56 = null;
        boolean boolean57 = xYPlot30.removeDomainMarker(0, (org.jfree.chart.plot.Marker) intervalMarker43, layer56);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        java.awt.Font font66 = xYPlot30.getNoDataMessageFont();
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        int int68 = xYPlot30.indexOf(xYDataset67);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray9 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        java.awt.color.ColorSpace colorSpace11 = color2.getColorSpace();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray19 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray20 = color12.getColorComponents(floatArray19);
        float[] floatArray21 = color1.getColorComponents(colorSpace11, floatArray20);
        java.awt.Color color22 = java.awt.Color.DARK_GRAY;
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        float[] floatArray30 = new float[] { (short) 100, 13, 0, 0L, 2.0f, (short) -1 };
        float[] floatArray31 = color23.getColorComponents(floatArray30);
        float[] floatArray32 = color22.getRGBColorComponents(floatArray31);
        float[] floatArray33 = color0.getColorComponents(colorSpace11, floatArray31);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis3.setLabelPaint((java.awt.Paint) color4);
        dateAxis3.setLabelAngle((double) ' ');
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRangeWithMargins(range8, true, false);
        dateAxis1.setRange(range8, false, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = dateAxis1.getStandardTickUnits();
        boolean boolean16 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.util.Date date5 = day4.getEnd();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
//        long long8 = day4.getLastMillisecond();
//        java.lang.Class<?> wildcardClass9 = day4.getClass();
//        long long10 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        double double6 = rectangleInsets4.calculateRightInset((double) (short) 100);
        double double8 = rectangleInsets4.calculateRightOutset((double) 43629L);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createInsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        int int53 = xYPlot30.getSeriesCount();
        int int54 = xYPlot30.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        xYPlot30.zoomRangeAxes((double) 1.0f, (double) 12, plotRenderingInfo57, point2D58);
        org.jfree.chart.plot.IntervalMarker intervalMarker62 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double63 = intervalMarker62.getStartValue();
        java.awt.Font font64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker62.setLabelFont(font64);
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot66.getRangeAxisLocation((int) (byte) 1);
        boolean boolean69 = categoryPlot66.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection72 = categoryPlot66.getDomainMarkers(255, layer71);
        boolean boolean73 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker62, layer71);
        java.lang.Object obj74 = intervalMarker62.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + (-1.0d) + "'", double63 == (-1.0d));
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(obj74);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("", timeZone11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis14.setLabelPaint((java.awt.Paint) color15);
        dateAxis14.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRangeWithMargins(range25, true, false);
        dateAxis14.setDefaultAutoRange(range25);
        dateAxis12.setRange(range25);
        numberAxis5.setRangeWithMargins(range25, true, false);
        java.awt.Stroke stroke34 = numberAxis5.getAxisLineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        boolean boolean42 = categoryPlot39.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double44 = rectangleInsets43.getBottom();
        categoryPlot39.setAxisOffset(rectangleInsets43);
        categoryPlot38.setInsets(rectangleInsets43);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker48.setLabelAnchor(rectangleAnchor49);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker48.setLabelTextAnchor(textAnchor51);
        java.awt.Stroke stroke53 = valueMarker48.getStroke();
        categoryPlot38.setRangeGridlineStroke(stroke53);
        xYPlot30.setDomainGridlineStroke(stroke53);
        boolean boolean56 = xYPlot30.isRangeCrosshairLockedOnData();
        boolean boolean57 = xYPlot30.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int int3 = java.awt.Color.HSBtoRGB(0.8f, (float) 9, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-194049) + "'", int3 == (-194049));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        int int2 = objectList1.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = categoryPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot11.setInsets(rectangleInsets13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot11.setRenderers(categoryItemRendererArray16);
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis8.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRangeWithMargins(range26, true, false);
        java.lang.String str30 = dateAxis21.getLabel();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setDownArrow(shape31);
        numberAxis8.setRightArrow(shape31);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis37.setLabelPaint((java.awt.Paint) color38);
        dateAxis37.setLabelAngle((double) ' ');
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis37.setRangeWithMargins(range42, true, false);
        dateAxis35.setRange(range42, false, false);
        numberAxis8.setRangeWithMargins(range42, false, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis53.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = dateAxis53.getLabelInsets();
        dateAxis53.setInverted(true);
        java.lang.String str59 = dateAxis53.getLabel();
        boolean boolean60 = numberAxis8.equals((java.lang.Object) str59);
        java.awt.Color color61 = java.awt.Color.WHITE;
        java.awt.Color color62 = color61.brighter();
        numberAxis8.setTickLabelPaint((java.awt.Paint) color61);
        boolean boolean64 = objectList1.equals((java.lang.Object) numberAxis8);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean66 = numberAxis65.isAutoTickUnitSelection();
        numberAxis65.setAutoRangeStickyZero(true);
        double double69 = numberAxis65.getAutoRangeMinimumSize();
        numberAxis65.setVerticalTickLabels(false);
        int int72 = objectList1.indexOf((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0E-8d + "'", double69 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        java.awt.Color color53 = java.awt.Color.BLACK;
        int int54 = color53.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint56 = categoryPlot55.getDomainGridlinePaint();
        boolean boolean57 = color53.equals((java.lang.Object) categoryPlot55);
        xYPlot30.setDomainGridlinePaint((java.awt.Paint) color53);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis61.setLabelPaint((java.awt.Paint) color62);
        dateAxis61.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color68 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis67.setLabelPaint((java.awt.Paint) color68);
        dateAxis67.setLabelAngle((double) ' ');
        org.jfree.data.Range range72 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis67.setRangeWithMargins(range72, true, false);
        dateAxis61.setDefaultAutoRange(range72);
        dateAxis61.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit80 = dateAxis61.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = dateAxis61.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline82 = null;
        dateAxis61.setTimeline(timeline82);
        try {
            xYPlot30.setDomainAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis61, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(dateTickUnit80);
        org.junit.Assert.assertNotNull(rectangleInsets81);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = null;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextStroke();
        java.lang.Object obj8 = defaultDrawingSupplier6.clone();
        try {
            java.awt.Paint paint9 = defaultDrawingSupplier6.getNextPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        int int5 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Stroke stroke52 = intervalMarker51.getOutlineStroke();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        try {
            xYPlot30.handleClick(6, (int) (short) 1, plotRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        numberAxis5.setAutoRangeStickyZero(true);
        org.jfree.data.Range range9 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray14 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray14);
        java.lang.String str16 = categoryPlot10.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        categoryPlot10.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis23.setLabelPaint((java.awt.Paint) color24);
        dateAxis23.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis29.setLabelPaint((java.awt.Paint) color30);
        dateAxis29.setLabelAngle((double) ' ');
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range34, true, false);
        dateAxis23.setDefaultAutoRange(range34);
        dateAxis23.setAutoTickUnitSelection(true);
        categoryPlot10.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        numberAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot10.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(axisSpace43);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        int int2 = objectList1.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = categoryPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot11.setInsets(rectangleInsets13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot11.setRenderers(categoryItemRendererArray16);
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis8.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRangeWithMargins(range26, true, false);
        java.lang.String str30 = dateAxis21.getLabel();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setDownArrow(shape31);
        numberAxis8.setRightArrow(shape31);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis37.setLabelPaint((java.awt.Paint) color38);
        dateAxis37.setLabelAngle((double) ' ');
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis37.setRangeWithMargins(range42, true, false);
        dateAxis35.setRange(range42, false, false);
        numberAxis8.setRangeWithMargins(range42, false, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis53.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = dateAxis53.getLabelInsets();
        dateAxis53.setInverted(true);
        java.lang.String str59 = dateAxis53.getLabel();
        boolean boolean60 = numberAxis8.equals((java.lang.Object) str59);
        java.awt.Color color61 = java.awt.Color.WHITE;
        java.awt.Color color62 = color61.brighter();
        numberAxis8.setTickLabelPaint((java.awt.Paint) color61);
        boolean boolean64 = objectList1.equals((java.lang.Object) numberAxis8);
        java.lang.Object obj66 = null;
        objectList1.set(7, obj66);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset((int) '#', xYDataset37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint40 = categoryPlot39.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot39.zoomRangeAxes((double) 2, plotRenderingInfo42, point2D43, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot39.zoomDomainAxes((double) 100.0f, plotRenderingInfo47, point2D48);
        categoryPlot39.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = categoryPlot39.getDatasetRenderingOrder();
        xYPlot30.setDatasetRenderingOrder(datasetRenderingOrder51);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        categoryPlot0.clearDomainMarkers(2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker9.setLabelAnchor(rectangleAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker9.setLabelTextAnchor(textAnchor12);
        java.lang.Object obj14 = valueMarker9.clone();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        valueMarker9.setOutlinePaint((java.awt.Paint) color15);
        valueMarker9.setValue((double) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        categoryPlot20.notifyListeners(plotChangeEvent23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean26 = numberAxis25.isAutoTickUnitSelection();
        org.jfree.data.Range range27 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint29 = categoryPlot28.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot28.setInsets(rectangleInsets30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer32 };
        categoryPlot28.setRenderers(categoryItemRendererArray33);
        numberAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis25.setRangeWithMargins(range36);
        numberAxis25.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = numberAxis25.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean42 = numberAxis41.isAutoTickUnitSelection();
        numberAxis41.setAutoRangeStickyZero(true);
        double double45 = numberAxis41.getAutoRangeMinimumSize();
        numberAxis41.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer48);
        int int50 = xYPlot49.getRangeAxisCount();
        xYPlot49.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray53 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot49.setRenderers(xYItemRendererArray53);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        xYPlot49.setRenderer(13, xYItemRenderer56);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection59 = xYPlot49.getDomainMarkers(layer58);
        boolean boolean60 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker9, layer58);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNull(markerAxisBand40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0E-8d + "'", double45 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray53);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot30.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace54 = xYPlot30.getFixedRangeAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent55 = null;
        xYPlot30.rendererChanged(rendererChangeEvent55);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNull(axisSpace54);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot7.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.clearCategoryLabelToolTips();
        int int11 = categoryPlot7.getDomainAxisIndex(categoryAxis9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getRangeAxisEdge(9);
        boolean boolean14 = dateAxis4.equals((java.lang.Object) 9);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        int int32 = xYPlot30.getIndexOf(xYItemRenderer31);
        xYPlot30.clearRangeMarkers();
        boolean boolean34 = xYPlot30.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        dateAxis4.setTickLabelsVisible(false);
        java.lang.String str10 = dateAxis4.getLabel();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        boolean boolean15 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets16.getBottom();
        categoryPlot12.setAxisOffset(rectangleInsets16);
        categoryPlot11.setInsets(rectangleInsets16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot11.getRenderer((int) (short) 100);
        java.lang.String str22 = categoryPlot11.getNoDataMessage();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date28 = dateAxis24.calculateLowestVisibleTickValue(dateTickUnit27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean30 = categoryPlot11.equals((java.lang.Object) date28);
        dateAxis4.setMaximumDate(date28);
        dateAxis4.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        boolean boolean8 = dateAxis4.isTickLabelsVisible();
        java.lang.String str9 = dateAxis4.getLabelURL();
        try {
            dateAxis4.setRange((double) 12, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setValue((double) (-1L));
        float float9 = valueMarker1.getAlpha();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str11 = chartChangeEventType10.toString();
        java.awt.Color color12 = java.awt.Color.PINK;
        boolean boolean13 = chartChangeEventType10.equals((java.lang.Object) color12);
        boolean boolean14 = valueMarker1.equals((java.lang.Object) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        valueMarker1.setPaint(paint16);
        java.awt.Paint paint18 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        xYPlot30.clearDomainMarkers(10);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot43.getOrientation();
        java.awt.Image image45 = categoryPlot43.getBackgroundImage();
        java.awt.Paint paint46 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot43.setRangeGridlinePaint(paint46);
        java.awt.Stroke stroke48 = categoryPlot43.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot43.getDomainAxisLocation();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis51.setLabelPaint((java.awt.Paint) color52);
        dateAxis51.setLabelAngle((double) ' ');
        org.jfree.data.Range range56 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis51.setRangeWithMargins(range56, true, false);
        dateAxis51.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis63.setLabelPaint((java.awt.Paint) color64);
        dateAxis63.setLabelAngle((double) ' ');
        org.jfree.data.Range range68 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis63.setRangeWithMargins(range68, true, false);
        dateAxis51.setRange(range68);
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition75 = dateAxis74.getTickMarkPosition();
        dateAxis51.setTickMarkPosition(dateTickMarkPosition75);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray77 = new org.jfree.chart.axis.ValueAxis[] { dateAxis51 };
        categoryPlot43.setRangeAxes(valueAxisArray77);
        xYPlot30.setDomainAxes(valueAxisArray77);
        org.jfree.chart.axis.AxisLocation axisLocation80 = xYPlot30.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(image45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertNotNull(dateTickMarkPosition75);
        org.junit.Assert.assertNotNull(valueAxisArray77);
        org.junit.Assert.assertNotNull(axisLocation80);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setTickMarkInsideLength((float) 1560409200000L);
        categoryAxis2.setLabelURL("DatasetRenderingOrder.REVERSE");
        float float22 = categoryAxis2.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.setAutoTickUnitSelection(false, false);
        java.awt.Color color8 = java.awt.Color.BLUE;
        dateAxis4.setLabelPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        xYPlot30.clearDomainMarkers(10);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace41);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot43.getRangeAxisLocation((int) (byte) 1);
        categoryPlot43.configureRangeAxes();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection49 = categoryPlot43.getRangeMarkers((int) (short) 100, layer48);
        boolean boolean50 = categoryPlot43.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection52 = categoryPlot43.getDomainMarkers(layer51);
        java.util.Collection collection53 = xYPlot30.getRangeMarkers(layer51);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        try {
            xYPlot30.drawBackground(graphics2D54, rectangle2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertNull(collection53);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (short) -1, 7.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        boolean boolean6 = dateAxis1.isVisible();
        java.util.Date date7 = dateAxis1.getMaximumDate();
        dateAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis11.setLabelPaint((java.awt.Paint) color12);
        dateAxis11.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis17.setLabelPaint((java.awt.Paint) color18);
        dateAxis17.setLabelAngle((double) ' ');
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRangeWithMargins(range22, true, false);
        dateAxis11.setDefaultAutoRange(range22);
        dateAxis1.setRangeWithMargins(range22, false, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        boolean boolean6 = dateAxis4.isInverted();
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("", timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7, timeZone9);
        dateAxis4.setMaximumDate(date7);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis14.setLabelPaint((java.awt.Paint) color15);
        dateAxis14.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis20.setLabelPaint((java.awt.Paint) color21);
        dateAxis20.setLabelAngle((double) ' ');
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis20.setRangeWithMargins(range25, true, false);
        dateAxis14.setDefaultAutoRange(range25);
        dateAxis14.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis14.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = dateAxis14.getTickLabelInsets();
        boolean boolean35 = dateAxis4.equals((java.lang.Object) rectangleInsets34);
        double double37 = rectangleInsets34.calculateBottomOutset((double) (short) 0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray34);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot30.getDomainAxisForDataset(173);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 173 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot8.getRangeAxisLocation((int) (byte) 1);
        boolean boolean11 = categoryPlot8.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets12.getBottom();
        categoryPlot8.setAxisOffset(rectangleInsets12);
        categoryPlot8.setAnchorValue((double) 10.0f);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke17);
        categoryPlot0.setRangeGridlineStroke(stroke17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        dateAxis1.setUpperMargin((double) (-7903));
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        categoryPlot8.notifyListeners(plotChangeEvent11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean14 = numberAxis13.isAutoTickUnitSelection();
        org.jfree.data.Range range15 = categoryPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot16.setInsets(rectangleInsets18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot16.setRenderers(categoryItemRendererArray21);
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRangeWithMargins(range24);
        numberAxis13.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = numberAxis13.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean30 = numberAxis29.isAutoTickUnitSelection();
        numberAxis29.setAutoRangeStickyZero(true);
        double double33 = numberAxis29.getAutoRangeMinimumSize();
        numberAxis29.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis29, xYItemRenderer36);
        int int38 = xYPlot37.getRangeAxisCount();
        xYPlot37.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot37.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = xYPlot37.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot46.getRangeAxisLocation((int) (byte) 1);
        categoryPlot43.setRangeAxisLocation(axisLocation48, true);
        xYPlot37.setRangeAxisLocation(axisLocation48);
        org.jfree.chart.axis.AxisSpace axisSpace52 = xYPlot37.getFixedRangeAxisSpace();
        boolean boolean53 = dateAxis1.equals((java.lang.Object) axisSpace52);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(markerAxisBand28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0E-8d + "'", double33 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(axisSpace52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color1 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint3 = categoryPlot2.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot2.setInsets(rectangleInsets4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer6 };
        categoryPlot2.setRenderers(categoryItemRendererArray7);
        int int9 = categoryPlot2.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot2.setDomainGridlinePosition(categoryAnchor10);
        boolean boolean12 = color1.equals((java.lang.Object) categoryAnchor10);
        java.awt.Color color13 = java.awt.Color.orange;
        boolean boolean14 = categoryAnchor10.equals((java.lang.Object) color13);
        boolean boolean15 = numberAxis0.equals((java.lang.Object) categoryAnchor10);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot17.getRangeAxisLocation((int) (byte) 1);
        boolean boolean20 = categoryPlot17.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray21 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot17.setDomainAxes(categoryAxisArray21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot17.getDomainAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        categoryPlot26.notifyListeners(plotChangeEvent29);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean32 = numberAxis31.isAutoTickUnitSelection();
        org.jfree.data.Range range33 = categoryPlot26.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint35 = categoryPlot34.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot34.setInsets(rectangleInsets36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray39 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer38 };
        categoryPlot34.setRenderers(categoryItemRendererArray39);
        numberAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis31.setRangeWithMargins(range42);
        numberAxis31.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = numberAxis31.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean48 = numberAxis47.isAutoTickUnitSelection();
        numberAxis47.setAutoRangeStickyZero(true);
        double double51 = numberAxis47.getAutoRangeMinimumSize();
        numberAxis47.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.axis.ValueAxis) numberAxis47, xYItemRenderer54);
        int int56 = xYPlot55.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation59 = categoryPlot57.getRangeAxisLocation((int) (byte) 1);
        categoryPlot57.configureRangeAxes();
        categoryPlot57.setRangeCrosshairLockedOnData(true);
        int int63 = categoryPlot57.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection64 = null;
        categoryPlot57.setFixedLegendItems(legendItemCollection64);
        org.jfree.chart.plot.PlotOrientation plotOrientation66 = categoryPlot57.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker68.setLabelAnchor(rectangleAnchor69);
        org.jfree.chart.text.TextAnchor textAnchor71 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker68.setLabelTextAnchor(textAnchor71);
        java.awt.Stroke stroke73 = valueMarker68.getStroke();
        categoryPlot57.setRangeCrosshairStroke(stroke73);
        xYPlot55.setRangeCrosshairStroke(stroke73);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = xYPlot55.getRenderer();
        xYPlot55.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation80 = categoryPlot78.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean84 = categoryPlot78.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker82, layer83);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = valueMarker82.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener86 = null;
        valueMarker82.addChangeListener(markerChangeListener86);
        org.jfree.chart.util.Layer layer88 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean89 = xYPlot55.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker82, layer88);
        int int90 = xYPlot55.getSeriesCount();
        java.awt.Font font91 = xYPlot55.getNoDataMessageFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge93 = xYPlot55.getRangeAxisEdge(2);
        org.jfree.chart.axis.AxisSpace axisSpace94 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace95 = numberAxis0.reserveSpace(graphics2D16, (org.jfree.chart.plot.Plot) categoryPlot17, rectangle2D24, rectangleEdge93, axisSpace94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray21);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(categoryItemRendererArray39);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(markerAxisBand46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0E-8d + "'", double51 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 15 + "'", int63 == 15);
        org.junit.Assert.assertNotNull(plotOrientation66);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNotNull(textAnchor71);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNull(xYItemRenderer76);
        org.junit.Assert.assertNotNull(axisLocation80);
        org.junit.Assert.assertNotNull(layer83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNotNull(layer88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNotNull(font91);
        org.junit.Assert.assertNotNull(rectangleEdge93);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        int int3 = categoryPlot0.getWeight();
        java.lang.String str4 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Category Plot" + "'", str4.equals("Category Plot"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot3.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.setRangeAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot0.setDataset(categoryDataset9);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis1.getTickUnit();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis25.setLabelPaint((java.awt.Paint) color26);
        dateAxis25.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis31.setLabelPaint((java.awt.Paint) color32);
        dateAxis31.setLabelAngle((double) ' ');
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRangeWithMargins(range36, true, false);
        dateAxis25.setDefaultAutoRange(range36);
        dateAxis23.setRange(range36);
        dateAxis1.setRangeWithMargins(range36);
        dateAxis1.configure();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot45.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = null;
        categoryPlot45.notifyListeners(plotChangeEvent48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean51 = numberAxis50.isAutoTickUnitSelection();
        org.jfree.data.Range range52 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis50);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint54 = categoryPlot53.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot53.setInsets(rectangleInsets55);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray58 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer57 };
        categoryPlot53.setRenderers(categoryItemRendererArray58);
        numberAxis50.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        org.jfree.data.Range range61 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis50.setRangeWithMargins(range61);
        numberAxis50.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = numberAxis50.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean67 = numberAxis66.isAutoTickUnitSelection();
        numberAxis66.setAutoRangeStickyZero(true);
        double double70 = numberAxis66.getAutoRangeMinimumSize();
        numberAxis66.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis66, xYItemRenderer73);
        int int75 = xYPlot74.getRangeAxisCount();
        xYPlot74.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = xYPlot74.getAxisOffset();
        xYPlot74.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace81 = null;
        xYPlot74.setFixedRangeAxisSpace(axisSpace81);
        xYPlot74.clearDomainMarkers(10);
        org.jfree.chart.axis.AxisSpace axisSpace85 = null;
        xYPlot74.setFixedRangeAxisSpace(axisSpace85);
        org.jfree.chart.plot.CategoryPlot categoryPlot87 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation89 = categoryPlot87.getRangeAxisLocation((int) (byte) 1);
        categoryPlot87.configureRangeAxes();
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection93 = categoryPlot87.getRangeMarkers((int) (short) 100, layer92);
        boolean boolean94 = categoryPlot87.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer95 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection96 = categoryPlot87.getDomainMarkers(layer95);
        java.util.Collection collection97 = xYPlot74.getRangeMarkers(layer95);
        boolean boolean98 = dateAxis1.equals((java.lang.Object) layer95);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(categoryItemRendererArray58);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNull(markerAxisBand65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0E-8d + "'", double70 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets78);
        org.junit.Assert.assertNotNull(axisLocation89);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNull(collection93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(layer95);
        org.junit.Assert.assertNull(collection96);
        org.junit.Assert.assertNull(collection97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot2.getRangeAxisLocation((int) (byte) 1);
        boolean boolean5 = categoryPlot2.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot2.setDataset(categoryDataset6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot2.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot2.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot2.getDomainAxis((int) '#');
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis14.setLabelPaint((java.awt.Paint) color15);
        dateAxis14.setLabelAngle((double) ' ');
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis14.setRangeWithMargins(range19, true, false);
        dateAxis14.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis26.setLabelPaint((java.awt.Paint) color27);
        dateAxis26.setLabelAngle((double) ' ');
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis26.setRangeWithMargins(range31, true, false);
        dateAxis14.setRange(range31);
        int int36 = categoryPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        boolean boolean37 = dateAxis14.isNegativeArrowVisible();
        boolean boolean38 = textAnchor0.equals((java.lang.Object) dateAxis14);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str1.equals("TextAnchor.BASELINE_CENTER"));
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100L, (double) 9, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) (-83));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        categoryPlot0.setDomainAxisLocation(4, axisLocation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot16.getRangeAxisLocation((int) (byte) 1);
        boolean boolean19 = categoryPlot16.isRangeGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis21.setLabelURL("hi!");
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        dateAxis21.setAxisLinePaint((java.awt.Paint) color24);
        categoryPlot16.setRangeGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean33 = categoryPlot27.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot27.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot27.setFixedRangeAxisSpace(axisSpace36);
        categoryPlot27.setWeight((int) (short) 100);
        java.awt.Stroke stroke40 = categoryPlot27.getRangeCrosshairStroke();
        categoryPlot16.setDomainGridlineStroke(stroke40);
        categoryPlot0.setOutlineStroke(stroke40);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot30.getRangeAxisLocation();
        java.awt.Color color56 = java.awt.Color.BLACK;
        int int57 = color56.getTransparency();
        int int58 = color56.getGreen();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker62 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Paint paint63 = intervalMarker62.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot64.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean70 = categoryPlot64.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker68, layer69);
        org.jfree.data.category.CategoryDataset categoryDataset72 = categoryPlot64.getDataset(15);
        org.jfree.chart.axis.AxisSpace axisSpace73 = null;
        categoryPlot64.setFixedRangeAxisSpace(axisSpace73);
        categoryPlot64.setWeight((int) (short) 100);
        java.awt.Stroke stroke77 = categoryPlot64.getRangeCrosshairStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker(1.0E-8d, (double) (short) 10, (java.awt.Paint) color56, stroke59, paint63, stroke77, (float) 1);
        xYPlot30.setRangeGridlineStroke(stroke77);
        xYPlot30.mapDatasetToRangeAxis(0, 2019);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(categoryDataset72);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            categoryPlot0.drawOutline(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        boolean boolean37 = xYPlot30.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean41 = dateAxis39.isHiddenValue((long) 100);
        dateAxis39.setInverted(false);
        boolean boolean44 = dateAxis39.isVisible();
        java.awt.Color color45 = java.awt.Color.YELLOW;
        dateAxis39.setTickLabelPaint((java.awt.Paint) color45);
        java.awt.Color color47 = color45.darker();
        int int48 = color45.getRGB();
        xYPlot30.setRangeZeroBaselinePaint((java.awt.Paint) color45);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-256) + "'", int48 == (-256));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        double double6 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.data.Range range6 = null;
        try {
            dateAxis1.setRange(range6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot56.getRangeAxisLocation((int) (byte) 1);
        boolean boolean59 = categoryPlot56.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double61 = rectangleInsets60.getBottom();
        categoryPlot56.setAxisOffset(rectangleInsets60);
        categoryPlot56.setAnchorValue((double) 10.0f);
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot56.setRangeCrosshairStroke(stroke65);
        xYPlot30.setRangeCrosshairStroke(stroke65);
        xYPlot30.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        categoryPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis5.configure();
        numberAxis5.setFixedAutoRange((double) 2.0f);
        double double19 = numberAxis5.getUpperMargin();
        boolean boolean20 = numberAxis5.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date5 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        dateAxis1.setInverted(true);
        dateAxis1.resizeRange((double) '#');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.data.Range range6 = numberAxis0.getDefaultAutoRange();
        double double7 = numberAxis0.getUpperMargin();
        numberAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        boolean boolean8 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis4.getTickMarkPosition();
        java.awt.Color color10 = java.awt.Color.GREEN;
        dateAxis4.setTickMarkPaint((java.awt.Paint) color10);
        dateAxis4.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        boolean boolean5 = lengthAdjustmentType0.equals((java.lang.Object) axisLocation3);
        java.awt.Color color7 = java.awt.Color.BLACK;
        int int8 = color7.getTransparency();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot9.getRangeAxisLocation((int) (byte) 1);
        boolean boolean12 = categoryPlot9.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot9.setDomainAxes(categoryAxisArray13);
        java.lang.String str15 = categoryPlot9.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        categoryPlot9.notifyListeners(plotChangeEvent16);
        categoryPlot9.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis22.setLabelPaint((java.awt.Paint) color23);
        dateAxis22.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis28.setLabelPaint((java.awt.Paint) color29);
        dateAxis28.setLabelAngle((double) ' ');
        org.jfree.data.Range range33 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRangeWithMargins(range33, true, false);
        dateAxis22.setDefaultAutoRange(range33);
        dateAxis22.setAutoTickUnitSelection(true);
        categoryPlot9.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot41.getRangeAxisLocation((int) (byte) 1);
        categoryPlot41.configureRangeAxes();
        categoryPlot41.setRangeCrosshairLockedOnData(true);
        int int47 = categoryPlot41.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection48 = null;
        categoryPlot41.setFixedLegendItems(legendItemCollection48);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = categoryPlot41.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker52.setLabelAnchor(rectangleAnchor53);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker52.setLabelTextAnchor(textAnchor55);
        java.awt.Stroke stroke57 = valueMarker52.getStroke();
        categoryPlot41.setRangeCrosshairStroke(stroke57);
        dateAxis22.setTickMarkStroke(stroke57);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((-8.0d), (java.awt.Paint) color7, stroke57);
        boolean boolean61 = lengthAdjustmentType0.equals((java.lang.Object) stroke57);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 15 + "'", int47 == 15);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot36.setRangeAxisLocation(axisLocation41, true);
        xYPlot30.setRangeAxisLocation(axisLocation41);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot30.getFixedRangeAxisSpace();
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot30.setRangeGridlineStroke(stroke46);
        xYPlot30.mapDatasetToRangeAxis((int) ' ', 3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickLabelsVisible();
        dateAxis0.resizeRange((-8.0d), (double) 175);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean8 = dateAxis6.isHiddenValue((long) 100);
        dateAxis6.setInverted(false);
        org.jfree.data.Range range11 = dateAxis6.getRange();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("", timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color17);
        dateAxis16.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis22.setLabelPaint((java.awt.Paint) color23);
        dateAxis22.setLabelAngle((double) ' ');
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRangeWithMargins(range27, true, false);
        dateAxis16.setDefaultAutoRange(range27);
        dateAxis14.setRange(range27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis14.getTickUnit();
        java.util.Date date34 = dateAxis6.calculateLowestVisibleTickValue(dateTickUnit33);
        dateAxis0.setMinimumDate(date34);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot5.setDataset((int) 'a', categoryDataset26);
        categoryPlot5.configureRangeAxes();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(15);
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis1.setTickUnit(dateTickUnit4, false, true);
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint6 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot5.setInsets(rectangleInsets7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot5.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot13.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double19 = intervalMarker18.getStartValue();
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker18.setLabelFont(font20);
        boolean boolean22 = categoryPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        boolean boolean23 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker18);
        intervalMarker2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot5);
        int int25 = categoryPlot5.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot5.setDataset(categoryDataset26);
        java.awt.Stroke stroke28 = categoryPlot5.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets4.getUnitType();
        java.lang.Object obj7 = null;
        boolean boolean8 = unitType6.equals(obj7);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot1.getRangeAxisLocation((int) (byte) 1);
        categoryPlot1.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot1.zoomRangeAxes((double) 0, plotRenderingInfo6, point2D7, true);
        boolean boolean10 = color0.equals((java.lang.Object) 0);
        int int11 = color0.getBlue();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray18 = new float[] { 4, 1560452399999L, 1560452399999L, 10.0f, 1 };
        float[] floatArray19 = color12.getRGBComponents(floatArray18);
        float[] floatArray20 = color0.getRGBColorComponents(floatArray19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int3 = java.awt.Color.HSBtoRGB((float) 255, (float) (byte) 10, 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-165) + "'", int3 == (-165));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray4 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray4);
        java.lang.String str6 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        categoryPlot0.notifyListeners(plotChangeEvent7);
        categoryPlot0.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis13.setLabelPaint((java.awt.Paint) color14);
        dateAxis13.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis19.setLabelPaint((java.awt.Paint) color20);
        dateAxis19.setLabelAngle((double) ' ');
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRangeWithMargins(range24, true, false);
        dateAxis13.setDefaultAutoRange(range24);
        dateAxis13.setAutoTickUnitSelection(true);
        categoryPlot0.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot0.zoomDomainAxes(0.0d, (double) (short) 0, plotRenderingInfo34, point2D35);
        java.awt.Color color37 = java.awt.Color.cyan;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint39 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot38.setInsets(rectangleInsets40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray43 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer42 };
        categoryPlot38.setRenderers(categoryItemRendererArray43);
        int int45 = categoryPlot38.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot38.setDomainGridlinePosition(categoryAnchor46);
        boolean boolean48 = color37.equals((java.lang.Object) categoryAnchor46);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color37);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(categoryItemRendererArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setRangeGridlinePaint(paint3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot0.getRangeAxis((-83));
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getPlotType();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Category Plot" + "'", str1.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryItemRenderer4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=false]");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setValue((double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        valueMarker1.setLabelOffset(rectangleInsets9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker13.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateBottomInset((double) (short) 10);
        double double20 = rectangleInsets16.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets16.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean23 = unitType21.equals((java.lang.Object) textAnchor22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType21, (double) (-1L), (double) (byte) -1, 0.0d, 0.0d);
        intervalMarker13.setLabelOffset(rectangleInsets28);
        java.awt.Stroke stroke30 = intervalMarker13.getOutlineStroke();
        valueMarker1.setOutlineStroke(stroke30);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-8.0d) + "'", double20 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        double double5 = rectangleInsets2.calculateRightOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = null;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextStroke();
        java.lang.Object obj8 = null;
        boolean boolean9 = defaultDrawingSupplier6.equals(obj8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray14 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray14);
        java.lang.String str16 = categoryPlot10.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        categoryPlot10.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis23.setLabelPaint((java.awt.Paint) color24);
        dateAxis23.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis29.setLabelPaint((java.awt.Paint) color30);
        dateAxis29.setLabelAngle((double) ' ');
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range34, true, false);
        dateAxis23.setDefaultAutoRange(range34);
        dateAxis23.setAutoTickUnitSelection(true);
        categoryPlot10.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot42.getRangeAxisLocation((int) (byte) 1);
        categoryPlot42.configureRangeAxes();
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection48 = categoryPlot42.getRangeMarkers((int) (short) 100, layer47);
        boolean boolean49 = categoryPlot42.isDomainGridlinesVisible();
        dateAxis23.setPlot((org.jfree.chart.plot.Plot) categoryPlot42);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent53 = null;
        valueMarker52.notifyListeners(markerChangeEvent53);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint56 = categoryPlot55.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot55.zoomRangeAxes((double) 2, plotRenderingInfo58, point2D59, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double65 = intervalMarker64.getStartValue();
        java.awt.Font font66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker64.setLabelFont(font66);
        categoryPlot55.setNoDataMessageFont(font66);
        valueMarker52.setLabelFont(font66);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation72 = categoryPlot70.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker74 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean76 = categoryPlot70.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker74, layer75);
        categoryPlot42.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker52, layer75);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot42.setRangeGridlinePaint((java.awt.Paint) color78);
        boolean boolean80 = defaultDrawingSupplier6.equals((java.lang.Object) color78);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + (-1.0d) + "'", double65 == (-1.0d));
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot36.setRangeAxisLocation(axisLocation41, true);
        xYPlot30.setRangeAxisLocation(axisLocation41);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot30.getFixedRangeAxisSpace();
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot30.setRangeGridlineStroke(stroke46);
        org.jfree.data.xy.XYDataset xYDataset48 = xYPlot30.getDataset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        xYPlot30.setRenderer(xYItemRenderer49);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(xYDataset48);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis18.setLabelPaint((java.awt.Paint) color19);
        dateAxis18.setLabelAngle((double) ' ');
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRangeWithMargins(range23, true, false);
        dateAxis1.setRange(range23, true, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis1.setTickUnit(dateTickUnit30);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Stroke stroke52 = intervalMarker51.getOutlineStroke();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker51);
        int int54 = xYPlot30.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        java.lang.String str10 = dateAxis1.getLabel();
        boolean boolean11 = dateAxis1.isVerticalTickLabels();
        java.lang.String str12 = dateAxis1.getLabel();
        dateAxis1.setAutoTickUnitSelection(false, false);
        dateAxis1.resizeRange(0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis3.setLabelPaint((java.awt.Paint) color4);
        dateAxis3.setLabelAngle((double) ' ');
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRangeWithMargins(range8, true, false);
        dateAxis1.setRange(range8, false, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = dateAxis1.getStandardTickUnits();
        boolean boolean16 = dateAxis1.isVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(tickUnitSource15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        boolean boolean66 = xYPlot30.isRangeGridlinesVisible();
        xYPlot30.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot69.getRangeAxisLocation((int) (byte) 1);
        categoryPlot69.configureRangeAxes();
        categoryPlot69.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        categoryPlot69.setRangeAxis(3, valueAxis76, false);
        categoryPlot69.clearRangeMarkers(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot69.getDomainAxisEdge((-256));
        java.awt.Paint paint83 = categoryPlot69.getNoDataMessagePaint();
        xYPlot30.setDomainCrosshairPaint(paint83);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(paint83);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        boolean boolean9 = categoryPlot6.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot6.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getDomainAxisEdge((int) (short) 100);
        double double17 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) -1, (int) 'a', rectangle2D5, rectangleEdge16);
        java.awt.Font font19 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.0d);
        java.awt.Font font21 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "SeriesRenderingOrder.REVERSE");
        boolean boolean22 = categoryAxis0.isTickMarksVisible();
        java.awt.Font font24 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "hi!");
        float float25 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker1.setLabelTextAnchor(textAnchor4);
        java.lang.String str6 = textAnchor4.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str6.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        double double5 = rectangleInsets2.trimHeight((double) 11);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.0d + "'", double5 == 7.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(legendItemCollection4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        org.jfree.data.RangeType rangeType28 = numberAxis5.getRangeType();
        numberAxis5.setFixedAutoRange((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(rangeType28);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date0, timeZone2);
//        java.lang.String str5 = day4.toString();
//        int int6 = day4.getYear();
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(serialDate7);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis1.getTickUnit();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("", timeZone22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis25.setLabelPaint((java.awt.Paint) color26);
        dateAxis25.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis31.setLabelPaint((java.awt.Paint) color32);
        dateAxis31.setLabelAngle((double) ' ');
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRangeWithMargins(range36, true, false);
        dateAxis25.setDefaultAutoRange(range36);
        dateAxis23.setRange(range36);
        dateAxis1.setRangeWithMargins(range36);
        dateAxis1.configure();
        java.awt.Shape shape44 = dateAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean7 = unitType5.equals((java.lang.Object) textAnchor6);
        boolean boolean9 = unitType5.equals((java.lang.Object) 10.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double15 = rectangleInsets14.getBottom();
        categoryPlot10.setAxisOffset(rectangleInsets14);
        boolean boolean17 = unitType5.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        double double19 = categoryAxis18.getCategoryMargin();
        java.util.List list20 = categoryPlot10.getCategoriesForAxis(categoryAxis18);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        xYPlot30.zoomDomainAxes((double) 2019, plotRenderingInfo52, point2D53, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder56 = xYPlot30.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(datasetRenderingOrder56);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue(100.0d);
        intervalMarker2.setStartValue((double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        java.lang.Object obj7 = null;
        boolean boolean8 = categoryPlot0.equals(obj7);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis11.setLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis11.getLabelInsets();
        dateAxis11.setInverted(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis11.getStandardTickUnits();
        int int18 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis20.setTickUnit(dateTickUnit23, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getRangeAxisLocation((int) (byte) 1);
        boolean boolean30 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray31 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot27.setDomainAxes(categoryAxisArray31);
        java.lang.String str33 = categoryPlot27.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        categoryPlot27.notifyListeners(plotChangeEvent34);
        categoryPlot27.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis40.setLabelPaint((java.awt.Paint) color41);
        dateAxis40.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis46.setLabelPaint((java.awt.Paint) color47);
        dateAxis46.setLabelAngle((double) ' ');
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis46.setRangeWithMargins(range51, true, false);
        dateAxis40.setDefaultAutoRange(range51);
        dateAxis40.setAutoTickUnitSelection(true);
        categoryPlot27.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis40);
        boolean boolean59 = dateAxis20.equals((java.lang.Object) dateAxis40);
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis40.setDownArrow(shape60);
        org.jfree.chart.axis.Timeline timeline62 = dateAxis40.getTimeline();
        dateAxis11.setTimeline(timeline62);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(timeline62);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        xYPlot30.clearDomainMarkers(10);
        java.awt.Paint paint41 = xYPlot30.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            xYPlot30.handleClick((int) (byte) 1, 10, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot36.setRangeAxisLocation(axisLocation41, true);
        xYPlot30.setRangeAxisLocation(axisLocation41);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot30.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot30.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNull(axisSpace46);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot0.addChangeListener(plotChangeListener10);
        categoryPlot0.clearAnnotations();
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean4 = categoryPlot0.removeAnnotation(categoryAnnotation2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis1.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline22 = null;
        dateAxis1.setTimeline(timeline22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot25.getRangeAxisLocation((int) (byte) 1);
        boolean boolean28 = categoryPlot25.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double30 = rectangleInsets29.getBottom();
        categoryPlot25.setAxisOffset(rectangleInsets29);
        categoryPlot24.setInsets(rectangleInsets29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot24.getRenderer((int) (short) 100);
        categoryPlot24.mapDatasetToRangeAxis((int) (byte) 1, 10);
        boolean boolean38 = dateAxis1.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) -1);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) -1 + "'", obj2.equals((short) -1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        java.awt.Paint paint19 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) (-194049));
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        numberAxis6.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot30.setDomainZeroBaselinePaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = xYPlot30.getOrientation();
        org.jfree.chart.plot.Plot plot38 = xYPlot30.getParent();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNull(plot38);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) true, font6);
        java.awt.Stroke stroke8 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        xYPlot30.rendererChanged(rendererChangeEvent34);
        xYPlot30.setRangeCrosshairValue((double) 12, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("", timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1, timeZone3);
        java.util.Date date6 = day5.getEnd();
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        int int9 = day8.getYear();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        boolean boolean14 = categoryPlot11.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets15.getBottom();
        categoryPlot11.setAxisOffset(rectangleInsets15);
        categoryPlot10.setInsets(rectangleInsets15);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker20.setLabelAnchor(rectangleAnchor21);
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker20.setLabelTextAnchor(textAnchor23);
        java.awt.Stroke stroke25 = valueMarker20.getStroke();
        categoryPlot10.setRangeGridlineStroke(stroke25);
        boolean boolean27 = day8.equals((java.lang.Object) stroke25);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Image image8 = categoryPlot0.getBackgroundImage();
        java.lang.String str9 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot30.setDataset(1, xYDataset55);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot58.getRangeAxisLocation((int) (byte) 1);
        boolean boolean61 = categoryPlot58.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection64 = categoryPlot58.getDomainMarkers(255, layer63);
        java.util.Collection collection65 = xYPlot30.getRangeMarkers(8, layer63);
        boolean boolean66 = xYPlot30.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNull(collection64);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setTickMarkInsideLength((float) 1560409200000L);
        categoryAxis2.setLabelURL("DatasetRenderingOrder.REVERSE");
        categoryAxis2.setLowerMargin(0.05d);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) 8, (double) 1.0f, (double) (short) 1);
        categoryPlot0.setInsets(rectangleInsets11, false);
        double double15 = rectangleInsets11.calculateTopOutset(32.0d);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!", timeZone2);
        dateAxis4.resizeRange((double) 100L, 10.0d);
        boolean boolean8 = dateAxis4.isTickLabelsVisible();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis4.getTickMarkPosition();
        java.awt.Color color10 = java.awt.Color.GREEN;
        dateAxis4.setTickMarkPaint((java.awt.Paint) color10);
        int int12 = color10.getBlue();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        xYPlot30.drawAnnotations(graphics2D35, rectangle2D36, plotRenderingInfo37);
        int int39 = xYPlot30.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint4 = categoryPlot1.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot1.setOrientation(plotOrientation5);
        categoryPlot1.setRangeCrosshairValue((double) 0L);
        boolean boolean9 = lengthAdjustmentType0.equals((java.lang.Object) 0L);
        java.lang.String str10 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NO_CHANGE" + "'", str10.equals("NO_CHANGE"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        int int65 = xYPlot30.getSeriesCount();
        boolean boolean66 = xYPlot30.isRangeGridlinesVisible();
        xYPlot30.setRangeGridlinesVisible(true);
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setLabelAngle((double) 11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis2.setLabelPaint((java.awt.Paint) color3);
        dateAxis2.setLabelAngle((double) ' ');
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRangeWithMargins(range7, true, false);
        java.lang.String str11 = dateAxis2.getLabel();
        boolean boolean12 = dateAxis2.isVerticalTickLabels();
        java.lang.String str13 = dateAxis2.getLabel();
        dateAxis2.setAutoTickUnitSelection(false, false);
        java.util.TimeZone timeZone17 = dateAxis2.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED", timeZone17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = null;
        dateAxis20.setTickUnit(dateTickUnit23, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot27.getRangeAxisLocation((int) (byte) 1);
        boolean boolean30 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray31 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot27.setDomainAxes(categoryAxisArray31);
        java.lang.String str33 = categoryPlot27.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        categoryPlot27.notifyListeners(plotChangeEvent34);
        categoryPlot27.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis40.setLabelPaint((java.awt.Paint) color41);
        dateAxis40.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis46.setLabelPaint((java.awt.Paint) color47);
        dateAxis46.setLabelAngle((double) ' ');
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis46.setRangeWithMargins(range51, true, false);
        dateAxis40.setDefaultAutoRange(range51);
        dateAxis40.setAutoTickUnitSelection(true);
        categoryPlot27.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis40);
        boolean boolean59 = dateAxis20.equals((java.lang.Object) dateAxis40);
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis40.setDownArrow(shape60);
        org.jfree.data.Range range62 = dateAxis40.getRange();
        dateAxis18.setRange(range62, true, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(range62);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        int int4 = categoryPlot0.getDatasetCount();
        java.awt.Image image5 = null;
        categoryPlot0.setBackgroundImage(image5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        java.awt.Color color8 = color7.darker();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double6 = intervalMarker5.getStartValue();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker5.setLabelFont(font7);
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5);
        categoryPlot0.setBackgroundAlpha((float) (short) 10);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        dateAxis1.setInverted(true);
        java.lang.String str7 = dateAxis1.getLabel();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis1.getTickMarkPosition();
        dateAxis1.zoomRange((double) 10.0f, (double) 100L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        java.lang.String str6 = rectangleInsets0.toString();
        double double8 = rectangleInsets0.extendWidth((double) 173);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str6.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 181.0d + "'", double8 == 181.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean56 = dateAxis54.isHiddenValue((long) 100);
        dateAxis54.setInverted(false);
        org.jfree.data.Range range59 = dateAxis54.getRange();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        xYPlot30.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range59);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRenderer((-83));
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getDomainAxisEdge((-83));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        categoryPlot15.notifyListeners(plotChangeEvent18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean21 = numberAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot23.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer27 };
        categoryPlot23.setRenderers(categoryItemRendererArray28);
        numberAxis20.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis20.setRangeWithMargins(range31);
        numberAxis20.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = numberAxis20.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean37 = numberAxis36.isAutoTickUnitSelection();
        numberAxis36.setAutoRangeStickyZero(true);
        double double40 = numberAxis36.getAutoRangeMinimumSize();
        numberAxis36.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer43);
        int int45 = xYPlot44.getRangeAxisCount();
        xYPlot44.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot44.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection49 = xYPlot44.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot44.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation((int) (short) 1, axisLocation50);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(categoryItemRendererArray28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(markerAxisBand35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0E-8d + "'", double40 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(legendItemCollection49);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isAutoTickUnitSelection();
        numberAxis0.setAutoRangeStickyZero(true);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRangeWithMargins(range26, true, false);
        dateAxis15.setDefaultAutoRange(range26);
        dateAxis15.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = dateAxis15.getTickUnit();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("", timeZone36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis39.setLabelPaint((java.awt.Paint) color40);
        dateAxis39.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis45.setLabelPaint((java.awt.Paint) color46);
        dateAxis45.setLabelAngle((double) ' ');
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis45.setRangeWithMargins(range50, true, false);
        dateAxis39.setDefaultAutoRange(range50);
        dateAxis37.setRange(range50);
        dateAxis15.setRangeWithMargins(range50);
        dateAxis7.setRange(range50, true, false);
        numberAxis0.setDefaultAutoRange(range50);
        org.jfree.chart.plot.IntervalMarker intervalMarker63 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Stroke stroke64 = intervalMarker63.getOutlineStroke();
        numberAxis0.setAxisLineStroke(stroke64);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(dateTickUnit34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(stroke64);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isAutoTickUnitSelection();
        org.jfree.data.Range range13 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint15 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot14.setInsets(rectangleInsets16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer18 };
        categoryPlot14.setRenderers(categoryItemRendererArray19);
        numberAxis11.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis11.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color25);
        dateAxis24.setLabelAngle((double) ' ');
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRangeWithMargins(range29, true, false);
        java.lang.String str33 = dateAxis24.getLabel();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setDownArrow(shape34);
        numberAxis11.setRightArrow(shape34);
        dateAxis1.setUpArrow(shape34);
        dateAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue((double) (-1));
        java.awt.Font font6 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        xYPlot30.setDomainAxis(valueAxis36);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation38 = null;
        try {
            boolean boolean39 = xYPlot30.removeAnnotation(xYAnnotation38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double6 = rectangleInsets5.getBottom();
        boolean boolean7 = intervalMarker2.equals((java.lang.Object) rectangleInsets5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double16 = intervalMarker15.getStartValue();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker15.setLabelFont(font17);
        boolean boolean19 = categoryPlot10.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        java.awt.Stroke stroke20 = intervalMarker15.getOutlineStroke();
        boolean boolean21 = intervalMarker2.equals((java.lang.Object) stroke20);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener22 = null;
        intervalMarker2.removeChangeListener(markerChangeListener22);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        int int25 = color24.getAlpha();
        intervalMarker2.setLabelPaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis6.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit17, false, true);
        numberAxis0.setRangeWithMargins(0.0d, (double) 9);
        java.text.NumberFormat numberFormat24 = null;
        numberAxis0.setNumberFormatOverride(numberFormat24);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setLowerMargin(8.0d);
        categoryAxis0.setCategoryLabelPositionOffset((int) '4');
        java.awt.Font font6 = categoryAxis0.getLabelFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.Plot plot8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot10.getRangeAxisLocation((int) (byte) 1);
        boolean boolean13 = categoryPlot10.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray14 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot10.setDomainAxes(categoryAxisArray14);
        java.lang.String str16 = categoryPlot10.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        categoryPlot10.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis23.setLabelPaint((java.awt.Paint) color24);
        dateAxis23.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis29.setLabelPaint((java.awt.Paint) color30);
        dateAxis29.setLabelAngle((double) ' ');
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRangeWithMargins(range34, true, false);
        dateAxis23.setDefaultAutoRange(range34);
        dateAxis23.setAutoTickUnitSelection(true);
        categoryPlot10.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis23);
        categoryPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot44.getRangeAxisLocation((int) (byte) 1);
        boolean boolean47 = categoryPlot44.isDomainGridlinesVisible();
        int int48 = categoryPlot44.getDomainAxisCount();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot44);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot10.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace52 = categoryAxis0.reserveSpace(graphics2D7, plot8, rectangle2D9, rectangleEdge50, axisSpace51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot30.getRenderer();
        java.awt.Stroke stroke33 = xYPlot30.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        double double5 = intervalMarker2.getEndValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot6.getRangeAxisLocation((int) (byte) 1);
        categoryPlot6.configureRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot11.getRangeAxisLocation((int) (byte) 1);
        categoryPlot6.setRangeAxisLocation((int) (short) 100, axisLocation13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot6.setBackgroundPaint(paint15);
        intervalMarker2.setLabelPaint(paint15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.LEFT;
        intervalMarker2.setLabelAnchor(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setAnchorValue((double) (-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot0.addChangeListener(plotChangeListener10);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot0.getDataset(6);
        org.junit.Assert.assertNull(categoryDataset13);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        double double5 = intervalMarker2.getEndValue();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        categoryPlot7.notifyListeners(plotChangeEvent10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean13 = numberAxis12.isAutoTickUnitSelection();
        org.jfree.data.Range range14 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot15.setInsets(rectangleInsets17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray20 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer19 };
        categoryPlot15.setRenderers(categoryItemRendererArray20);
        numberAxis12.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis12.setRangeWithMargins(range23);
        numberAxis12.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = numberAxis12.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean29 = numberAxis28.isAutoTickUnitSelection();
        numberAxis28.setAutoRangeStickyZero(true);
        double double32 = numberAxis28.getAutoRangeMinimumSize();
        numberAxis28.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer35);
        int int37 = xYPlot36.getRangeAxisCount();
        xYPlot36.setDomainCrosshairValue((double) 43629L);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        xYPlot36.setDomainZeroBaselinePaint((java.awt.Paint) color40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = xYPlot36.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection43 = xYPlot36.getFixedLegendItems();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot36);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(categoryItemRendererArray20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(markerAxisBand27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0E-8d + "'", double32 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(legendItemCollection42);
        org.junit.Assert.assertNull(legendItemCollection43);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.Class<?> wildcardClass1 = categoryPlot0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        int int2 = objectList1.size();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("", timeZone6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone6);
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        objectList1.set(10, (java.lang.Object) serialDate9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint9 = categoryPlot8.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot8.setInsets(rectangleInsets10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer12 };
        categoryPlot8.setRenderers(categoryItemRendererArray13);
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis5.setRangeWithMargins(range16);
        numberAxis5.setAutoRangeStickyZero(true);
        java.lang.Object obj20 = numberAxis5.clone();
        org.jfree.data.Range range21 = numberAxis5.getRange();
        numberAxis5.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range6, true, false);
        java.lang.String str10 = dateAxis1.getLabel();
        boolean boolean11 = dateAxis1.isVerticalTickLabels();
        java.lang.String str12 = dateAxis1.getLabel();
        dateAxis1.setAutoRangeMinimumSize((double) 175);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis(2);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot53.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = categoryPlot53.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker57.getLabelAnchor();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener61 = null;
        valueMarker57.addChangeListener(markerChangeListener61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = xYPlot30.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker57, layer63);
        xYPlot30.configureDomainAxes();
        xYPlot30.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Color color2 = java.awt.Color.getColor("", 15);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelURL("hi!");
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        dateAxis1.setAxisLinePaint((java.awt.Paint) color4);
        dateAxis1.setAutoTickUnitSelection(true);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation11);
        try {
            double double13 = dateAxis1.java2DToValue((double) 0.5f, rectangle2D9, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint14 = categoryPlot13.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot13.setInsets(rectangleInsets15);
        categoryPlot13.clearDomainMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint19 = categoryPlot18.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot18.zoomRangeAxes((double) 2, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker27 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double28 = intervalMarker27.getStartValue();
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker27.setLabelFont(font29);
        categoryPlot18.setNoDataMessageFont(font29);
        categoryPlot13.setNoDataMessageFont(font29);
        categoryPlot0.setNoDataMessageFont(font29);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(15, categoryItemRenderer5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        int int53 = xYPlot30.getSeriesCount();
        int int54 = xYPlot30.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Point2D point2D58 = null;
        xYPlot30.zoomRangeAxes((double) 1.0f, (double) 12, plotRenderingInfo57, point2D58);
        java.lang.String str60 = xYPlot30.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "XY Plot" + "'", str60.equals("XY Plot"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot0.getDomainAxis(7);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getDomainAxisLocation((int) 'a');
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.clearCategoryLabelToolTips();
//        java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint();
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
//        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("", timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone6);
//        java.util.Date date9 = day8.getEnd();
//        long long10 = day8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
//        long long12 = day8.getLastMillisecond();
//        java.lang.Class<?> wildcardClass13 = day8.getClass();
//        java.lang.String str14 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) day8);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNotNull(categoryLabelPositions3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(str14);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo8, point2D9);
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        categoryPlot0.setDataset(categoryDataset4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot12.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation15, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot0.getRenderer((int) (byte) 0);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setBackgroundImageAlpha(0.0f);
        java.lang.String str25 = categoryPlot22.getNoDataMessage();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot22.getDomainAxisEdge(8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = null;
        categoryPlot31.notifyListeners(plotChangeEvent34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean37 = numberAxis36.isAutoTickUnitSelection();
        org.jfree.data.Range range38 = categoryPlot31.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint40 = categoryPlot39.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot39.setInsets(rectangleInsets41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray44 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer43 };
        categoryPlot39.setRenderers(categoryItemRendererArray44);
        numberAxis36.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.data.Range range47 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis36.setRangeWithMargins(range47);
        numberAxis36.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = numberAxis36.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean53 = numberAxis52.isAutoTickUnitSelection();
        numberAxis52.setAutoRangeStickyZero(true);
        double double56 = numberAxis52.getAutoRangeMinimumSize();
        numberAxis52.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis52, xYItemRenderer59);
        int int61 = xYPlot60.getRangeAxisCount();
        xYPlot60.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = xYPlot60.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot60.setRangeAxisLocation(axisLocation65, false);
        java.awt.geom.Point2D point2D68 = xYPlot60.getQuadrantOrigin();
        categoryPlot22.zoomRangeAxes((double) 100, plotRenderingInfo29, point2D68);
        org.jfree.chart.plot.PlotState plotState70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            categoryPlot0.draw(graphics2D20, rectangle2D21, point2D68, plotState70, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(categoryItemRendererArray44);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(markerAxisBand51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0E-8d + "'", double56 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(point2D68);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(3, valueAxis7, false);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        java.awt.Image image2 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint3 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(15, categoryItemRenderer5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, false);
        float float11 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        categoryPlot15.notifyListeners(plotChangeEvent18);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean21 = numberAxis20.isAutoTickUnitSelection();
        org.jfree.data.Range range22 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot23.setInsets(rectangleInsets25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer27 };
        categoryPlot23.setRenderers(categoryItemRendererArray28);
        numberAxis20.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis20.setRangeWithMargins(range31);
        numberAxis20.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = numberAxis20.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean37 = numberAxis36.isAutoTickUnitSelection();
        numberAxis36.setAutoRangeStickyZero(true);
        double double40 = numberAxis36.getAutoRangeMinimumSize();
        numberAxis36.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer43);
        int int45 = xYPlot44.getRangeAxisCount();
        xYPlot44.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot44.getAxisOffset();
        xYPlot44.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        xYPlot44.setFixedRangeAxisSpace(axisSpace51);
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        xYPlot44.setFixedRangeAxisSpace(axisSpace53);
        java.util.List list55 = xYPlot44.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = xYPlot44.getRendererForDataset(xYDataset56);
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double62 = intervalMarker61.getStartValue();
        intervalMarker61.setEndValue(100.0d);
        double double65 = intervalMarker61.getEndValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot66.getRangeAxisLocation((int) (byte) 1);
        categoryPlot66.configureRangeAxes();
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection72 = categoryPlot66.getRangeMarkers((int) (short) 100, layer71);
        boolean boolean74 = xYPlot44.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker61, layer71, true);
        java.awt.geom.Point2D point2D75 = xYPlot44.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState76 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        try {
            categoryPlot0.draw(graphics2D12, rectangle2D13, point2D75, plotState76, plotRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(image2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(categoryItemRendererArray28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(markerAxisBand35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0E-8d + "'", double40 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 100.0d + "'", double65 == 100.0d);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(point2D75);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        boolean boolean3 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.clearDomainMarkers(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot39.getRangeAxisLocation((int) (byte) 1);
        categoryPlot36.setRangeAxisLocation(axisLocation41, true);
        xYPlot30.setRangeAxisLocation(axisLocation41);
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot30.getFixedRangeAxisSpace();
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot30.setRangeGridlineStroke(stroke46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot30.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(valueAxis48);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot30.getDomainAxisLocation((int) 'a');
        float float56 = xYPlot30.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.5f + "'", float56 == 0.5f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean3 = dateAxis1.isHiddenValue((long) 100);
        dateAxis1.setInverted(false);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        double double7 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers((int) (short) 100, layer5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers(layer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot30.setDataset(1, xYDataset55);
        java.awt.Paint paint57 = xYPlot30.getDomainZeroBaselinePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker61.setStartValue((double) 0.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        intervalMarker61.setGradientPaintTransformer(gradientPaintTransformer64);
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint67 = categoryPlot66.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean71 = layer69.equals((java.lang.Object) 2);
        java.lang.String str72 = layer69.toString();
        java.util.Collection collection73 = categoryPlot66.getRangeMarkers((int) (short) 100, layer69);
        boolean boolean74 = xYPlot30.removeDomainMarker(9, (org.jfree.chart.plot.Marker) intervalMarker61, layer69);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Layer.FOREGROUND" + "'", str72.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int6 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(500);
        java.awt.Image image12 = null;
        categoryPlot0.setBackgroundImage(image12);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray34);
        xYPlot30.mapDatasetToRangeAxis(173, 8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.extendHeight((double) 3);
        double double5 = rectangleInsets0.calculateTopInset((double) 10);
        double double6 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str1.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(500);
        int int2 = objectList1.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        categoryPlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isAutoTickUnitSelection();
        org.jfree.data.Range range10 = categoryPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint12 = categoryPlot11.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot11.setInsets(rectangleInsets13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer15 };
        categoryPlot11.setRenderers(categoryItemRendererArray16);
        numberAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis8.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis21.setLabelPaint((java.awt.Paint) color22);
        dateAxis21.setLabelAngle((double) ' ');
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRangeWithMargins(range26, true, false);
        java.lang.String str30 = dateAxis21.getLabel();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis21.setDownArrow(shape31);
        numberAxis8.setRightArrow(shape31);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis37.setLabelPaint((java.awt.Paint) color38);
        dateAxis37.setLabelAngle((double) ' ');
        org.jfree.data.Range range42 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis37.setRangeWithMargins(range42, true, false);
        dateAxis35.setRange(range42, false, false);
        numberAxis8.setRangeWithMargins(range42, false, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis53.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = dateAxis53.getLabelInsets();
        dateAxis53.setInverted(true);
        java.lang.String str59 = dateAxis53.getLabel();
        boolean boolean60 = numberAxis8.equals((java.lang.Object) str59);
        java.awt.Color color61 = java.awt.Color.WHITE;
        java.awt.Color color62 = color61.brighter();
        numberAxis8.setTickLabelPaint((java.awt.Paint) color61);
        boolean boolean64 = objectList1.equals((java.lang.Object) numberAxis8);
        java.awt.Stroke stroke65 = numberAxis8.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color2);
        dateAxis1.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis7.setLabelPaint((java.awt.Paint) color8);
        dateAxis7.setLabelAngle((double) ' ');
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRangeWithMargins(range12, true, false);
        dateAxis1.setDefaultAutoRange(range12);
        dateAxis1.resizeRange(0.0d, (double) 'a');
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis1.getTickUnit();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.axis.Timeline timeline22 = null;
        dateAxis1.setTimeline(timeline22);
        java.lang.String str24 = dateAxis1.getLabelURL();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelURL("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis26.setTickUnit(dateTickUnit29, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot33.getRangeAxisLocation((int) (byte) 1);
        boolean boolean36 = categoryPlot33.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray37 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot33.setDomainAxes(categoryAxisArray37);
        java.lang.String str39 = categoryPlot33.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot33.notifyListeners(plotChangeEvent40);
        categoryPlot33.setNoDataMessage("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis46.setLabelPaint((java.awt.Paint) color47);
        dateAxis46.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis52.setLabelPaint((java.awt.Paint) color53);
        dateAxis52.setLabelAngle((double) ' ');
        org.jfree.data.Range range57 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis52.setRangeWithMargins(range57, true, false);
        dateAxis46.setDefaultAutoRange(range57);
        dateAxis46.setAutoTickUnitSelection(true);
        categoryPlot33.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis46);
        boolean boolean65 = dateAxis26.equals((java.lang.Object) dateAxis46);
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis46.setDownArrow(shape66);
        org.jfree.data.Range range68 = dateAxis46.getRange();
        dateAxis1.setRangeWithMargins(range68, true, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray37);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(range68);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot30.setRenderers(xYItemRendererArray34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        xYPlot30.setRenderer(13, xYItemRenderer37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection40 = xYPlot30.getDomainMarkers(layer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        xYPlot30.setFixedDomainAxisSpace(axisSpace41, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(xYItemRendererArray34);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis57.setLabelPaint((java.awt.Paint) color58);
        org.jfree.chart.axis.DateTickUnit dateTickUnit60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date61 = dateAxis57.calculateLowestVisibleTickValue(dateTickUnit60);
        org.jfree.data.Range range62 = xYPlot30.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis57);
        xYPlot30.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(dateTickUnit60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNull(range62);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setTickMarkInsideLength((float) 1560409200000L);
        categoryAxis2.setCategoryLabelPositionOffset(175);
        categoryAxis2.clearCategoryLabelToolTips();
        categoryAxis2.setMaximumCategoryLabelLines((int) (short) 1);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis5.getCategoryLabelPositions();
        categoryAxis5.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis11.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis2.setCategoryLabelPositions(categoryLabelPositions15);
        java.awt.Font font18 = categoryAxis2.getLabelFont();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot0.getDomainAxis(7);
        int int15 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean7 = unitType5.equals((java.lang.Object) textAnchor6);
        boolean boolean9 = unitType5.equals((java.lang.Object) 10.0d);
        java.lang.String str10 = unitType5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis3.setLabelPaint((java.awt.Paint) color4);
        dateAxis3.setLabelAngle((double) ' ');
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRangeWithMargins(range8, true, false);
        dateAxis1.setRange(range8, false, false);
        org.jfree.data.Range range15 = null;
        try {
            dateAxis1.setDefaultAutoRange(range15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis9.setLabelPaint((java.awt.Paint) color10);
        dateAxis9.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis15.setLabelPaint((java.awt.Paint) color16);
        dateAxis15.setLabelAngle((double) ' ');
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRangeWithMargins(range20, true, false);
        dateAxis9.setDefaultAutoRange(range20);
        numberAxis5.setRangeWithMargins(range20, false, true);
        org.jfree.data.RangeType rangeType28 = numberAxis5.getRangeType();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("", timeZone30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis33.setLabelPaint((java.awt.Paint) color34);
        dateAxis33.setLabelAngle((double) ' ');
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis39.setLabelPaint((java.awt.Paint) color40);
        dateAxis39.setLabelAngle((double) ' ');
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis39.setRangeWithMargins(range44, true, false);
        dateAxis33.setDefaultAutoRange(range44);
        dateAxis31.setRange(range44);
        numberAxis5.setDefaultAutoRange(range44);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = numberAxis5.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(rangeType28);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot30.setRangeAxisLocation(axisLocation35, false);
        xYPlot30.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        xYPlot30.setDataset(1, xYDataset55);
        java.awt.Paint paint57 = null;
        try {
            xYPlot30.setDomainGridlinePaint(paint57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets4.getUnitType();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot7.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean13 = categoryPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker11, layer12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot7.getDataset(15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot7.getRenderer((-83));
        boolean boolean18 = unitType6.equals((java.lang.Object) categoryPlot7);
        java.awt.Paint paint19 = categoryPlot7.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot7.getRowRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = null;
        try {
            categoryPlot7.setAxisOffset(rectangleInsets21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(sortOrder20);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace39);
        java.util.List list41 = xYPlot30.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = xYPlot30.getRendererForDataset(xYDataset42);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double48 = intervalMarker47.getStartValue();
        intervalMarker47.setEndValue(100.0d);
        double double51 = intervalMarker47.getEndValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot52.getRangeAxisLocation((int) (byte) 1);
        categoryPlot52.configureRangeAxes();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection58 = categoryPlot52.getRangeMarkers((int) (short) 100, layer57);
        boolean boolean60 = xYPlot30.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker47, layer57, true);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.Color color64 = org.jfree.chart.ChartColor.DARK_RED;
        dateAxis63.setLabelPaint((java.awt.Paint) color64);
        dateAxis63.setLabelAngle((double) ' ');
        org.jfree.data.Range range68 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis63.setRangeWithMargins(range68, true, false);
        java.lang.String str72 = dateAxis63.getLabel();
        java.awt.Shape shape73 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis63.setDownArrow(shape73);
        xYPlot30.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) dateAxis63);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNull(xYItemRenderer43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.0d + "'", double51 == 100.0d);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
        org.junit.Assert.assertNotNull(shape73);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = categoryPlot3.getOrientation();
        java.awt.Image image5 = categoryPlot3.getBackgroundImage();
        java.awt.Paint paint6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot3.setRangeGridlinePaint(paint6);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot3.setNoDataMessageFont(font8);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font8);
        categoryAxis0.setLabelURL("XY Plot");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = categoryPlot0.getRenderer();
        boolean boolean2 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset4 = categoryPlot0.getDataset((-1));
        org.junit.Assert.assertNull(categoryItemRenderer1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(categoryDataset4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot56.getRangeAxisLocation((int) (byte) 1);
        boolean boolean59 = categoryPlot56.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double61 = rectangleInsets60.getBottom();
        categoryPlot56.setAxisOffset(rectangleInsets60);
        categoryPlot56.setAnchorValue((double) 10.0f);
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot56.setRangeCrosshairStroke(stroke65);
        xYPlot30.setRangeCrosshairStroke(stroke65);
        xYPlot30.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (short) 10);
        double double4 = rectangleInsets0.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        java.lang.String str6 = rectangleInsets0.toString();
        double double7 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str6.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        categoryPlot0.notifyListeners(plotChangeEvent3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean6 = numberAxis5.isAutoTickUnitSelection();
        org.jfree.data.Range range7 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getDomainAxisLocation((-1));
        categoryPlot0.clearRangeMarkers(11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot0.setRenderers(categoryItemRendererArray5);
        int int7 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor8);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker13.setStartValue((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot16.setInsets(rectangleInsets18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot16.setRenderers(categoryItemRendererArray21);
        org.jfree.chart.plot.Plot plot23 = categoryPlot16.getRootPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot24.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double30 = intervalMarker29.getStartValue();
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker29.setLabelFont(font31);
        boolean boolean33 = categoryPlot24.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker29);
        boolean boolean34 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker29);
        intervalMarker13.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot16.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        double double39 = categoryAxis38.getCategoryMargin();
        categoryAxis38.setMaximumCategoryLabelWidthRatio((float) 10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions42 = categoryAxis38.getCategoryLabelPositions();
        categoryAxis38.configure();
        categoryPlot16.setDomainAxis(100, categoryAxis38);
        categoryPlot0.setDomainAxis(0, categoryAxis38);
        categoryAxis38.setLabelURL("RectangleAnchor.CENTER");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions42);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Color color2 = java.awt.Color.getColor("EXPAND", 6);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = categoryPlot0.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean6 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker4, layer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        boolean boolean11 = categoryPlot0.render(graphics2D7, rectangle2D8, 5, plotRenderingInfo10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        xYPlot30.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        xYPlot30.setDataset(xYDataset54);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        xYPlot30.setDataset(xYDataset56);
        xYPlot30.setForegroundAlpha((float) 2019);
        org.jfree.chart.axis.ValueAxis valueAxis61 = xYPlot30.getDomainAxis((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        xYPlot30.setFixedDomainAxisSpace(axisSpace62);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNull(valueAxis61);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setLowerMargin(8.0d);
        java.lang.Comparable comparable4 = null;
        try {
            java.lang.String str5 = categoryAxis0.getCategoryLabelToolTip(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot32.getRangeAxisLocation((int) (byte) 1);
        categoryPlot32.configureRangeAxes();
        categoryPlot32.setRangeCrosshairLockedOnData(true);
        int int38 = categoryPlot32.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = null;
        categoryPlot32.setFixedLegendItems(legendItemCollection39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = categoryPlot32.getOrientation();
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker43.setLabelAnchor(rectangleAnchor44);
        org.jfree.chart.text.TextAnchor textAnchor46 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker43.setLabelTextAnchor(textAnchor46);
        java.awt.Stroke stroke48 = valueMarker43.getStroke();
        categoryPlot32.setRangeCrosshairStroke(stroke48);
        xYPlot30.setRangeCrosshairStroke(stroke48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot30.getRenderer();
        xYPlot30.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean56 = dateAxis54.isHiddenValue((long) 100);
        dateAxis54.setInverted(false);
        org.jfree.data.Range range59 = dateAxis54.getRange();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis54);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        boolean boolean64 = dateAxis62.isHiddenValue((long) 100);
        dateAxis62.setInverted(false);
        boolean boolean67 = dateAxis62.isVisible();
        java.awt.Color color68 = java.awt.Color.YELLOW;
        dateAxis62.setTickLabelPaint((java.awt.Paint) color68);
        int int70 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis62);
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        xYPlot30.setFixedDomainAxisSpace(axisSpace71, false);
        xYPlot30.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        xYPlot30.setDomainAxis(1, valueAxis76, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.CENTER");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color3 = color2.brighter();
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) color3);
        java.lang.Comparable comparable5 = null;
        try {
            categoryAxis1.addCategoryLabelToolTip(comparable5, "java.awt.Color[r=192,g=0,b=192]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot30.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        xYPlot30.setDataset((int) '#', xYDataset37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot30.setRenderer(12, xYItemRenderer40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        try {
            xYPlot30.handleClick((int) '#', (int) (byte) -1, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(legendItemCollection35);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        intervalMarker2.setStartValue((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateBottomInset((double) (short) 10);
        double double9 = rectangleInsets5.trimWidth((double) 0.0f);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets5.getUnitType();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        boolean boolean12 = unitType10.equals((java.lang.Object) textAnchor11);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType10, (double) (-1L), (double) (byte) -1, 0.0d, 0.0d);
        intervalMarker2.setLabelOffset(rectangleInsets17);
        double double20 = rectangleInsets17.extendWidth(7.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-8.0d) + "'", double9 == (-8.0d));
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 6.0d + "'", double20 == 6.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker1.setLabelAnchor(rectangleAnchor2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.extendHeight(0.0d);
        double double9 = rectangleInsets4.calculateLeftOutset(8.0d);
        double double11 = rectangleInsets4.trimHeight((double) (-1L));
        double double12 = rectangleInsets4.getTop();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 6.0d + "'", double7 == 6.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) 2, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double10 = intervalMarker9.getStartValue();
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker9.setLabelFont(font11);
        categoryPlot0.setNoDataMessageFont(font11);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double18 = intervalMarker17.getStartValue();
        intervalMarker17.setEndValue((double) (-1));
        intervalMarker17.setStartValue((double) 3);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean25 = layer23.equals((java.lang.Object) 2);
        boolean boolean27 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) intervalMarker17, layer23, true);
        intervalMarker17.setStartValue((double) 100L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot37.getRangeAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        double double43 = intervalMarker42.getStartValue();
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        intervalMarker42.setLabelFont(font44);
        boolean boolean46 = categoryPlot37.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        double double47 = intervalMarker42.getEndValue();
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((-1.0d), 4.0d);
        java.awt.Stroke stroke52 = intervalMarker51.getOutlineStroke();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker51);
        java.lang.Object obj54 = xYPlot30.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.clearCategoryLabelToolTips();
        int int4 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        boolean boolean11 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        categoryPlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isAutoTickUnitSelection();
        org.jfree.data.Range range8 = categoryPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint10 = categoryPlot9.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot9.setInsets(rectangleInsets11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot9.setRenderers(categoryItemRendererArray14);
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis6.setRangeWithMargins(range17);
        numberAxis6.setFixedDimension((double) 'a');
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = numberAxis6.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isAutoTickUnitSelection();
        numberAxis22.setAutoRangeStickyZero(true);
        double double26 = numberAxis22.getAutoRangeMinimumSize();
        numberAxis22.setVerticalTickLabels(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer29);
        int int31 = xYPlot30.getRangeAxisCount();
        xYPlot30.setDomainCrosshairValue((double) 43629L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot30.getAxisOffset();
        xYPlot30.setDomainCrosshairValue((double) 2.0f);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker39.setLabelAnchor(rectangleAnchor40);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        valueMarker39.setLabelTextAnchor(textAnchor42);
        java.lang.Object obj44 = valueMarker39.clone();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        valueMarker39.setOutlinePaint((java.awt.Paint) color45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot47.getRangeAxisLocation((int) (byte) 1);
        categoryPlot47.configureRangeAxes();
        categoryPlot47.setRangeCrosshairLockedOnData(true);
        int int53 = categoryPlot47.getBackgroundImageAlignment();
        org.jfree.chart.LegendItemCollection legendItemCollection54 = null;
        categoryPlot47.setFixedLegendItems(legendItemCollection54);
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (short) 0);
        java.lang.Object obj59 = null;
        boolean boolean60 = valueMarker58.equals(obj59);
        java.awt.Stroke stroke61 = valueMarker58.getStroke();
        org.jfree.chart.util.Layer layer62 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = categoryPlot47.removeDomainMarker(2, (org.jfree.chart.plot.Marker) valueMarker58, layer62, false);
        boolean boolean65 = xYPlot30.removeDomainMarker(5, (org.jfree.chart.plot.Marker) valueMarker39, layer62);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(markerAxisBand21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0E-8d + "'", double26 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 15 + "'", int53 == 15);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(layer62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }
}

