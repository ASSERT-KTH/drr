import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 1, (double) (-1.0f), (int) (short) -1, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "hi!", 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, (float) (short) 100, (float) (byte) -1, textAnchor4, (double) 1L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.Axis axis1 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            axisCollection0.add(axis1, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Stroke stroke3 = null;
        try {
            barRenderer0.setBaseOutlineStroke(stroke3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener9 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 1L };
        try {
            float[] floatArray4 = color0.getComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) (-1), (float) '4', (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        java.lang.String str6 = chartEntity5.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor3, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        org.jfree.chart.event.RendererChangeListener rendererChangeListener6 = null;
        try {
            barRenderer0.addChangeListener(rendererChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            barRenderer0.drawDomainGridline(graphics2D3, categoryPlot4, rectangle2D5, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color1 = java.awt.Color.RED;
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        java.awt.Paint paint6 = barRenderer3.getBaseOutlinePaint();
        java.awt.Stroke stroke7 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke2, paint6, stroke7, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (double) 1, (float) 100L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer0.getToolTipGenerator(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.awt.Stroke stroke26 = barRenderer0.getSeriesStroke((-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(stroke26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        java.lang.Object obj3 = objectList0.get((int) (byte) 1);
        objectList0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.Plot plot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace10 = categoryAxis1.reserveSpace(graphics2D5, plot6, rectangle2D7, rectangleEdge8, axisSpace9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            textTitle2.setMargin(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        double double3 = barRenderer0.getItemMargin();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            barRenderer0.drawRangeGridline(graphics2D4, categoryPlot5, valueAxis6, rectangle2D7, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            categoryPlot0.handleClick((int) (short) 10, (int) '#', plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (byte) 10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setSeriesToolTipGenerator((int) '4', categoryToolTipGenerator5, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) 0L, paint12);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("", font16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle17.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        java.awt.Shape shape30 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean33 = barRenderer31.isSeriesVisibleInLegend(1);
        boolean boolean34 = barRenderer31.getBaseCreateEntities();
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        barRenderer31.setBaseFillPaint((java.awt.Paint) color35);
        double double37 = barRenderer31.getItemLabelAnchorOffset();
        java.awt.Stroke stroke39 = barRenderer31.lookupSeriesStroke((int) (byte) 1);
        java.awt.Color color40 = java.awt.Color.RED;
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", false, shape7, true, paint12, false, (java.awt.Paint) color18, stroke28, false, shape30, stroke39, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer1.getSeriesPaint((int) '#');
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer1.setSeriesOutlinePaint(0, paint8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        java.awt.Color color19 = java.awt.Color.RED;
        java.awt.Stroke stroke20 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1, paint8, stroke18, (java.awt.Paint) color19, stroke20, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            categoryPlot0.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            categoryPlot0.drawOutline(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 10, (double) 0L, (int) 'a', (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double13 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor8, (int) ' ', (int) 'a', rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        java.awt.Paint paint37 = null;
        try {
            categoryPlot2.setRangeGridlinePaint(paint37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape6, "hi!", "");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer11.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer23.isSeriesVisibleInLegend(1);
        boolean boolean26 = barRenderer23.getBaseCreateEntities();
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer23.setBaseFillPaint((java.awt.Paint) color27);
        double double29 = barRenderer23.getItemLabelAnchorOffset();
        java.awt.Stroke stroke31 = barRenderer23.lookupSeriesStroke((int) (byte) 1);
        barRenderer15.setSeriesOutlineStroke(255, stroke31, true);
        barRenderer11.setSeriesStroke(0, stroke31);
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        try {
            org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "", shape10, stroke31, (java.awt.Paint) color35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (double) (-1), (float) '#', 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener15 = null;
        try {
            jFreeChart14.removeChangeListener(chartChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot2.getRangeAxis();
        org.jfree.chart.util.SortOrder sortOrder38 = null;
        try {
            categoryPlot2.setColumnRenderingOrder(sortOrder38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            categoryPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1.0f), 10.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        double double3 = barRenderer0.getItemMargin();
        java.awt.Stroke stroke5 = barRenderer0.getSeriesOutlineStroke(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        boolean boolean9 = itemLabelPosition7.equals((java.lang.Object) 0L);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition7, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, false);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "hi!", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        chartEntity5.setArea(shape12);
        java.lang.Object obj14 = chartEntity5.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (short) 1, (double) ' ', rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) categoryPlot9, false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot9.getFixedLegendItems();
        double double23 = categoryPlot9.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        java.awt.Stroke stroke31 = categoryAxis26.getTickMarkStroke();
        java.awt.Font font32 = categoryAxis26.getTickLabelFont();
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D6, categoryPlot9, categoryAxis26, categoryMarker33, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = null;
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, 1.0d);
        org.jfree.data.Range range34 = org.jfree.data.Range.expandToInclude(range30, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint29.toRangeHeight(range34);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.util.List list11 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.SortOrder sortOrder12 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("CategoryLabelWidthType.RANGE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.lang.Boolean boolean42 = barRenderer16.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) 0L, paint47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement50 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) columnArrangement50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer16, (org.jfree.chart.block.Arrangement) flowArrangement43, (org.jfree.chart.block.Arrangement) columnArrangement50);
        jFreeChart14.addLegend(legendTitle52);
        java.awt.Color color54 = java.awt.Color.GRAY;
        legendTitle52.setItemPaint((java.awt.Paint) color54);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color54);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.lang.Boolean boolean42 = barRenderer16.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) 0L, paint47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement50 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) columnArrangement50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer16, (org.jfree.chart.block.Arrangement) flowArrangement43, (org.jfree.chart.block.Arrangement) columnArrangement50);
        jFreeChart14.addLegend(legendTitle52);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = legendTitle52.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        java.lang.Number number37 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        try {
            org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset33, (java.lang.Comparable) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0d) + "'", number37.equals((-1.0d)));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.clearCategoryLabelToolTips();
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        categoryPlot2.configureRangeAxes();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.clearSubtitles();
        java.lang.Object obj25 = null;
        boolean boolean26 = jFreeChart14.equals(obj25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        try {
            float float7 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "LGPL");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Color color1 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer0.getToolTipGenerator(0, 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = barRenderer0.getURLGenerator((-1), (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot2.getRangeAxis();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        boolean boolean42 = categoryPlot2.render(graphics2D38, rectangle2D39, (int) (byte) 10, plotRenderingInfo41);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list16 = categoryAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        double double7 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        boolean boolean20 = categoryPlot9.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str23 = rectangleEdge22.toString();
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace25 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D21, rectangleEdge22, axisSpace24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.BOTTOM" + "'", str23.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot0.setForegroundAlpha((float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) 100L, (float) (short) 100, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        double double13 = barRenderer7.getItemLabelAnchorOffset();
        java.awt.Stroke stroke15 = barRenderer7.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(100, stroke15, true);
        boolean boolean19 = barRenderer0.isSeriesItemLabelsVisible(10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { 0.5f, 0.5f, 1L, 255, 100.0f, (-1.0f) };
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        java.awt.Stroke stroke6 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer9.isSeriesVisibleInLegend(1);
        boolean boolean12 = barRenderer9.getBaseCreateEntities();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        barRenderer9.setBaseFillPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = barRenderer9.getBaseItemLabelPaint();
        boolean boolean18 = barRenderer9.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean22 = barRenderer20.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        boolean boolean24 = barRenderer20.removeAnnotation(categoryAnnotation23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor25, textAnchor26);
        boolean boolean29 = itemLabelPosition27.equals((java.lang.Object) 0L);
        barRenderer20.setBaseNegativeItemLabelPosition(itemLabelPosition27, true);
        barRenderer9.setSeriesNegativeItemLabelPosition(1, itemLabelPosition27);
        boolean boolean33 = categoryAxis1.equals((java.lang.Object) barRenderer9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.awt.Stroke stroke11 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot0.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.fireChartChanged();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str11 = itemLabelAnchor10.toString();
        boolean boolean12 = categoryAxis1.equals((java.lang.Object) itemLabelAnchor10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean15 = barRenderer13.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke17 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        categoryAxis1.setTickMarkStroke(stroke17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str11.equals("ItemLabelAnchor.INSIDE10"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (byte) 10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot2.getInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace7 = categoryAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) categoryPlot2, rectangle2D4, rectangleEdge5, axisSpace6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.lang.Object obj5 = null;
        java.lang.Object obj6 = textTitle2.draw(graphics2D3, rectangle2D4, obj5);
        textTitle2.setToolTipText("hi!");
        java.lang.Object obj9 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        int int7 = barRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        java.lang.String str9 = legendItemEntity3.getURLText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets6);
        double double9 = rectangleInsets6.trimHeight((double) (byte) -1);
        double double10 = rectangleInsets6.getLeft();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-5.0d) + "'", double9 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleAnchor.TOP", "RectangleEdge.BOTTOM", "CategoryLabelWidthType.RANGE", "RectangleConstraintType.RANGE");
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = barRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = null;
        try {
            java.awt.Shape shape17 = textBlock9.calculateBounds(graphics2D10, 0.0f, (float) (short) 10, textBlockAnchor13, 100.0f, (float) ' ', (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.util.List list11 = categoryPlot0.getAnnotations();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot0.addRangeMarker(marker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(layer13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, (double) 1.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str11 = rectangleEdge10.toString();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis1.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.BOTTOM" + "'", str11.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        java.awt.Stroke stroke6 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot9.getRangeAxisLocation((int) (short) 10);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        int int23 = categoryPlot9.getDatasetCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE4" + "'", str1.equals("ItemLabelAnchor.OUTSIDE4"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke8 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setIncludeBaseInRange(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.setAntiAlias(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            java.awt.image.BufferedImage bufferedImage30 = jFreeChart14.createBufferedImage((int) '#', (int) (short) 10, (int) (byte) 0, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.lang.Boolean boolean42 = barRenderer16.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) 0L, paint47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement50 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) columnArrangement50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer16, (org.jfree.chart.block.Arrangement) flowArrangement43, (org.jfree.chart.block.Arrangement) columnArrangement50);
        jFreeChart14.addLegend(legendTitle52);
        java.awt.Paint paint54 = legendTitle52.getItemPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets1.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis5.setTickLabelPaint((java.lang.Comparable) 0L, paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 0, (double) 0.0f, (double) (-1.0f), paint7);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            blockBorder9.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.AffineTransform affineTransform36 = null;
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean42 = barRenderer40.isSeriesVisibleInLegend(1);
        boolean boolean43 = barRenderer40.getBaseCreateEntities();
        java.awt.Color color44 = java.awt.Color.LIGHT_GRAY;
        barRenderer40.setBaseFillPaint((java.awt.Paint) color44);
        double double46 = barRenderer40.getItemLabelAnchorOffset();
        java.awt.Stroke stroke48 = barRenderer40.lookupSeriesStroke((int) (byte) 1);
        categoryPlot39.setDomainGridlineStroke(stroke48);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", font38, (org.jfree.chart.plot.Plot) categoryPlot39, false);
        java.awt.Image image52 = jFreeChart51.getBackgroundImage();
        jFreeChart51.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = null;
        java.awt.image.BufferedImage bufferedImage58 = jFreeChart51.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo57);
        jFreeChart51.setNotify(true);
        jFreeChart51.setAntiAlias(false);
        java.awt.RenderingHints renderingHints63 = jFreeChart51.getRenderingHints();
        java.awt.PaintContext paintContext64 = color0.createContext(colorModel33, rectangle34, rectangle2D35, affineTransform36, renderingHints63);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(image52);
        org.junit.Assert.assertNotNull(bufferedImage58);
        org.junit.Assert.assertNotNull(renderingHints63);
        org.junit.Assert.assertNotNull(paintContext64);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        double double13 = barRenderer7.getItemLabelAnchorOffset();
        java.awt.Stroke stroke15 = barRenderer7.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(100, stroke15, true);
        java.awt.Stroke stroke20 = barRenderer0.getItemOutlineStroke((int) (byte) 100, 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer22.isSeriesVisibleInLegend(1);
        boolean boolean25 = barRenderer22.getBaseCreateEntities();
        java.awt.Color color26 = java.awt.Color.LIGHT_GRAY;
        barRenderer22.setBaseFillPaint((java.awt.Paint) color26);
        barRenderer22.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer22.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.awt.Paint paint40 = barRenderer35.getSeriesPaint((int) '#');
        java.awt.Paint paint42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer35.setSeriesOutlinePaint(0, paint42);
        barRenderer22.setBaseOutlinePaint(paint42, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = barRenderer22.getSeriesPositiveItemLabelPosition(0);
        try {
            barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition47, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        legendItemEntity7.setURLText("LGPL");
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13, "hi!", "");
        legendItemEntity7.setArea(shape13);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setBaseOutlinePaint(paint4, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        java.lang.Object obj22 = jFreeChart14.clone();
        jFreeChart14.setBackgroundImageAlignment((int) (byte) 1);
        try {
            org.jfree.chart.title.Title title26 = jFreeChart14.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        boolean boolean5 = barRenderer0.isSeriesItemLabelsVisible((int) '4');
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", font8, (org.jfree.chart.plot.Plot) categoryPlot9, false);
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot9.getFixedLegendItems();
        double double23 = categoryPlot9.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        categoryAxis26.setCategoryMargin(0.0d);
        double double32 = categoryAxis26.getLowerMargin();
        java.awt.Font font33 = categoryAxis26.getLabelFont();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D6, categoryPlot9, categoryAxis26, categoryMarker34, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, (double) (-12566464), (double) 0.5f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraintType.RANGE");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.BOTTOM_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray28, numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset40);
        org.jfree.data.Range range42 = barRenderer18.findRangeBounds(categoryDataset40);
        java.lang.Boolean boolean44 = barRenderer18.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis47.setTickLabelPaint((java.lang.Comparable) 0L, paint49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryAxis47.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean53 = rectangleInsets51.equals((java.lang.Object) columnArrangement52);
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer18, (org.jfree.chart.block.Arrangement) flowArrangement45, (org.jfree.chart.block.Arrangement) columnArrangement52);
        java.lang.Number[] numberArray61 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray61, numberArray66, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray72);
        java.lang.Number number74 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset73);
        boolean boolean75 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset73);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer77 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement52, (org.jfree.data.general.Dataset) categoryDataset73, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        boolean boolean78 = jFreeChart14.equals((java.lang.Object) columnArrangement52);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (-1.0d) + "'", number41.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + (-1.0d) + "'", number74.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Object obj4 = legendItemEntity3.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        double double16 = categoryPlot2.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot2.getLegendItems();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 10, (float) (short) 0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke4 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.LegendItem legendItem7 = barRenderer0.getLegendItem(255, 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 1, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (byte) 0);
        try {
            java.awt.GradientPaint gradientPaint4 = standardGradientPaintTransformer0.transform(gradientPaint1, shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot8 = categoryAxis1.getPlot();
        java.lang.Object obj9 = categoryAxis1.clone();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double15 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor10, (-1), 100, rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint13 = barRenderer0.getItemPaint(255, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 10L, true, (-1.0f), 100, "CategoryLabelWidthType.RANGE" };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { 10.0d };
        double[] doubleArray13 = new double[] { 8.0d, (-1L), 4.0d, (byte) 10, 100.0d };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray7, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        float float33 = categoryPlot15.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean39 = barRenderer37.isSeriesVisibleInLegend(1);
        boolean boolean40 = barRenderer37.getBaseCreateEntities();
        java.awt.Color color41 = java.awt.Color.LIGHT_GRAY;
        barRenderer37.setBaseFillPaint((java.awt.Paint) color41);
        double double43 = barRenderer37.getItemLabelAnchorOffset();
        java.awt.Stroke stroke45 = barRenderer37.lookupSeriesStroke((int) (byte) 1);
        categoryPlot36.setDomainGridlineStroke(stroke45);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font35, (org.jfree.chart.plot.Plot) categoryPlot36, false);
        categoryPlot36.setBackgroundAlpha(0.0f);
        int int51 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation52);
        categoryPlot15.setRangeAxisLocation(255, axisLocation52, true);
        categoryPlot15.setRangeCrosshairValue((double) 1.0f, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.plot.Plot plot37 = categoryPlot2.getRootPlot();
        java.lang.String str38 = plot37.getNoDataMessage();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        categoryPlot2.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent27);
        categoryPlot2.clearRangeAxes();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        double double16 = categoryPlot2.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot2.getDrawingSupplier();
        categoryPlot2.setRangeCrosshairValue(0.05d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart14.createBufferedImage(1, (int) '4');
        jFreeChart14.setTextAntiAlias(false);
        java.util.List list23 = jFreeChart14.getSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.shrink(rectangle2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            tickUnits0.add(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'unit' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Stroke stroke10 = barRenderer2.lookupSeriesStroke((int) (byte) 1);
        categoryPlot1.setDomainGridlineStroke(stroke10);
        boolean boolean12 = categoryPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot1.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Font font17 = categoryPlot1.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font17);
        java.lang.Object obj19 = labelBlock18.clone();
        java.awt.Font font20 = null;
        try {
            labelBlock18.setFont(font20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Paint paint6 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset32);
        org.jfree.data.Range range34 = barRenderer10.findRangeBounds(categoryDataset32);
        java.lang.Boolean boolean36 = barRenderer10.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) 0L, paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis39.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean45 = rectangleInsets43.equals((java.lang.Object) columnArrangement44);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer10, (org.jfree.chart.block.Arrangement) flowArrangement37, (org.jfree.chart.block.Arrangement) columnArrangement44);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer47.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor52 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor53 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor52, textAnchor53);
        boolean boolean56 = itemLabelPosition54.equals((java.lang.Object) 0L);
        barRenderer47.setNegativeItemLabelPositionFallback(itemLabelPosition54);
        barRenderer10.setBasePositiveItemLabelPosition(itemLabelPosition54);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition54, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor52);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean7 = rectangleInsets5.equals((java.lang.Object) columnArrangement6);
        double double9 = rectangleInsets5.calculateLeftOutset((double) 10.0f);
        double double10 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceName();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
//        java.lang.String str3 = projectInfo0.toString();
//        projectInfo0.setLicenceText("RectangleAnchor.BOTTOM_LEFT");
//        java.lang.String str6 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LGPL" + "'", str1.equals("LGPL"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT" + "'", str3.equals("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str6.equals("RectangleAnchor.BOTTOM_LEFT"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        double double13 = barRenderer7.getItemLabelAnchorOffset();
        java.awt.Stroke stroke15 = barRenderer7.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(100, stroke15, true);
        java.awt.Stroke stroke20 = barRenderer0.getItemOutlineStroke((int) (byte) 100, 0);
        barRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.lang.Boolean boolean42 = barRenderer16.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) 0L, paint47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement50 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) columnArrangement50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer16, (org.jfree.chart.block.Arrangement) flowArrangement43, (org.jfree.chart.block.Arrangement) columnArrangement50);
        jFreeChart14.addLegend(legendTitle52);
        jFreeChart14.fireChartChanged();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        barRenderer2.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint14 = barRenderer2.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Paint paint17 = barRenderer2.getItemFillPaint((int) (byte) 1, 0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor18, textAnchor19);
        double double21 = itemLabelPosition20.getAngle();
        barRenderer2.setPositiveItemLabelPositionFallback(itemLabelPosition20);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape25, "hi!", "");
        barRenderer2.setBaseShape(shape25);
        try {
            shapeList0.setShape((-12566464), shape25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean15 = barRenderer13.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer13.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Paint paint19 = barRenderer13.getBaseOutlinePaint();
        categoryPlot0.setRangeGridlinePaint(paint19);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Paint paint10 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemURLGenerator();
        barRenderer0.setBaseCreateEntities(true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        java.awt.Font font24 = barRenderer0.getBaseItemLabelFont();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) (short) 0, (java.awt.Paint) color26);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color26);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceName();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
//        java.lang.String str3 = projectInfo0.toString();
//        projectInfo0.setLicenceText("RectangleEdge.BOTTOM");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LGPL" + "'", str1.equals("LGPL"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT" + "'", str3.equals("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Class class2 = null;
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass5 = paint4.getClass();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass7 = paint6.getClass();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelWidthType.RANGE", class2, (java.lang.Class) wildcardClass7);
        try {
            java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT", class2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        java.awt.Font font16 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Paint paint23 = barRenderer18.getSeriesPaint((int) '#');
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer18.setSeriesOutlinePaint(0, paint25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = barRenderer18.getBaseURLGenerator();
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        boolean boolean29 = barRenderer18.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryURLGenerator27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double15 = categoryAxis1.getCategoryStart(255, (int) 'a', rectangle2D13, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine1.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = barRenderer0.getSeriesItemLabelGenerator((int) (short) -1);
        boolean boolean9 = barRenderer0.getBaseSeriesVisible();
        java.lang.Boolean boolean11 = barRenderer0.getSeriesVisible(1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot0.getDatasetRenderingOrder();
        float float17 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot0.getLegendItems();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean43 = barRenderer41.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean47 = barRenderer45.isSeriesVisibleInLegend(1);
        boolean boolean48 = barRenderer45.getBaseCreateEntities();
        java.awt.Paint paint51 = barRenderer45.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean55 = barRenderer53.isSeriesVisibleInLegend(1);
        boolean boolean56 = barRenderer53.getBaseCreateEntities();
        java.awt.Color color57 = java.awt.Color.LIGHT_GRAY;
        barRenderer53.setBaseFillPaint((java.awt.Paint) color57);
        double double59 = barRenderer53.getItemLabelAnchorOffset();
        java.awt.Stroke stroke61 = barRenderer53.lookupSeriesStroke((int) (byte) 1);
        barRenderer45.setSeriesOutlineStroke(255, stroke61, true);
        barRenderer41.setSeriesStroke(0, stroke61);
        java.awt.Paint paint65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape39, stroke61, paint65);
        legendItem66.setSeriesIndex(10);
        legendItemCollection32.add(legendItem66);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 2.0d + "'", double59 == 2.0d);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis38.setTickLabelPaint((java.lang.Comparable) 0L, paint40);
        categoryAxis38.setCategoryMargin(0.0d);
        categoryAxis38.clearCategoryLabelToolTips();
        java.lang.String str46 = categoryAxis38.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis38.setTickMarksVisible(true);
        java.lang.Object obj49 = categoryAxis38.clone();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean53 = barRenderer51.isSeriesVisibleInLegend(1);
        boolean boolean54 = barRenderer51.getBaseCreateEntities();
        java.awt.Color color55 = java.awt.Color.LIGHT_GRAY;
        barRenderer51.setBaseFillPaint((java.awt.Paint) color55);
        java.awt.Paint paint57 = barRenderer51.getBaseItemLabelPaint();
        boolean boolean60 = barRenderer51.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean64 = barRenderer62.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation65 = null;
        boolean boolean66 = barRenderer62.removeAnnotation(categoryAnnotation65);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor67 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor67, textAnchor68);
        boolean boolean71 = itemLabelPosition69.equals((java.lang.Object) 0L);
        barRenderer62.setBaseNegativeItemLabelPosition(itemLabelPosition69, true);
        barRenderer51.setSeriesNegativeItemLabelPosition(1, itemLabelPosition69);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis38, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer51);
        boolean boolean76 = barRenderer51.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(boolean64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor67);
        org.junit.Assert.assertNotNull(textAnchor68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "", "RectangleEdge.BOTTOM", categoryDataset27, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) false);
        java.lang.String str33 = categoryItemEntity32.toString();
        categoryItemEntity32.setRowKey((java.lang.Comparable) (byte) 1);
        java.lang.String str36 = categoryItemEntity32.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem34 = legendItemCollection32.get((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection32);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "", "RectangleEdge.BOTTOM", categoryDataset27, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) false);
        java.lang.String str33 = categoryItemEntity32.toString();
        java.lang.String str34 = categoryItemEntity32.toString();
        java.lang.Comparable comparable35 = categoryItemEntity32.getColumnKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + false + "'", comparable35.equals(false));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        boolean boolean25 = barRenderer15.isSeriesVisibleInLegend((int) (short) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        boolean boolean15 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes(0.0d, plotRenderingInfo17, point2D18);
        java.awt.Font font20 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer22.isSeriesVisibleInLegend(1);
        boolean boolean25 = barRenderer22.getBaseCreateEntities();
        java.awt.Color color26 = java.awt.Color.LIGHT_GRAY;
        barRenderer22.setBaseFillPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = barRenderer22.getBaseItemLabelPaint();
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("CategoryLabelWidthType.RANGE", font20, paint28);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean32 = barRenderer30.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation33 = null;
        boolean boolean34 = barRenderer30.removeAnnotation(categoryAnnotation33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = barRenderer30.getLegendItems();
        java.awt.Paint paint38 = barRenderer30.getItemOutlinePaint(0, 255);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment40, verticalAlignment41, (double) 255, (double) (short) -1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis47.setTickLabelPaint((java.lang.Comparable) 0L, paint49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryAxis47.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("", font20, paint38, rectangleEdge39, horizontalAlignment40, verticalAlignment45, rectangleInsets51);
        try {
            double double53 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = barRenderer0.removeAnnotation(categoryAnnotation6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        categoryPlot11.setDomainGridlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot11.getFixedLegendItems();
        java.awt.Font font25 = categoryPlot11.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer27.isSeriesVisibleInLegend(1);
        boolean boolean30 = barRenderer27.getBaseCreateEntities();
        java.awt.Paint paint32 = barRenderer27.getSeriesPaint((int) '#');
        java.awt.Paint paint34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer27.setSeriesOutlinePaint(0, paint34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = barRenderer27.getBaseURLGenerator();
        categoryPlot11.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer27);
        java.lang.String str38 = categoryPlot11.getNoDataMessage();
        categoryPlot11.clearRangeMarkers(255);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            barRenderer0.drawOutline(graphics2D8, categoryPlot11, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryURLGenerator36);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart14.removeChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.text.AttributedString attributedString34 = legendItem33.getAttributedLabel();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = legendItem33.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(attributedString34);
        org.junit.Assert.assertNotNull(gradientPaintTransformer35);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = barRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        try {
            java.awt.Shape shape17 = textBlock9.calculateBounds(graphics2D10, (float) (byte) 10, (float) 1, textBlockAnchor13, 0.0f, (float) 100, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.awt.Image image17 = jFreeChart16.getBackgroundImage();
        jFreeChart16.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        java.awt.image.BufferedImage bufferedImage23 = jFreeChart16.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo22);
        jFreeChart16.setNotify(true);
        jFreeChart16.setAntiAlias(false);
        java.awt.RenderingHints renderingHints28 = jFreeChart16.getRenderingHints();
        java.awt.Font font30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("", font30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.lang.Object obj34 = null;
        java.lang.Object obj35 = textTitle31.draw(graphics2D32, rectangle2D33, obj34);
        jFreeChart16.addSubtitle((org.jfree.chart.title.Title) textTitle31);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(bufferedImage23);
        org.junit.Assert.assertNotNull(renderingHints28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(obj35);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        java.lang.String str8 = categoryTick7.toString();
        double double9 = categoryTick7.getAngle();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset32);
        org.jfree.data.Range range34 = barRenderer10.findRangeBounds(categoryDataset32);
        java.lang.Boolean boolean36 = barRenderer10.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) 0L, paint41);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = categoryAxis39.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean45 = rectangleInsets43.equals((java.lang.Object) columnArrangement44);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer10, (org.jfree.chart.block.Arrangement) flowArrangement37, (org.jfree.chart.block.Arrangement) columnArrangement44);
        java.awt.Paint paint49 = barRenderer10.getItemOutlinePaint(0, (int) ' ');
        boolean boolean50 = categoryTick7.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getFixedDimension();
        int int5 = categoryPlot0.getDomainAxisIndex(categoryAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isDomainGridlinesVisible();
        categoryPlot0.setRangeCrosshairValue((double) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) 0L, paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis3.getTickLabelInsets();
        java.awt.Stroke stroke8 = categoryAxis3.getTickMarkStroke();
        java.awt.Font font9 = categoryAxis3.getTickLabelFont();
        categoryAxis1.setTickLabelFont(font9);
        categoryAxis1.setLabel("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer58 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) 0.2d);
        java.lang.Number number59 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset55);
        try {
            java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset55);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 100.0d + "'", number59.equals(100.0d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset(4.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("", font3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Object obj7 = null;
        java.lang.Object obj8 = textTitle4.draw(graphics2D5, rectangle2D6, obj7);
        textTitle4.setToolTipText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle4.getPadding();
        textTitle4.setURLText("RectangleEdge.BOTTOM");
        java.awt.Font font14 = textTitle4.getFont();
        boolean boolean15 = datasetRenderingOrder0.equals((java.lang.Object) font14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        categoryPlot2.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = categoryPlot2.getDrawingSupplier();
        categoryPlot2.clearAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        double double36 = barRenderer30.getItemLabelAnchorOffset();
        java.awt.Font font37 = barRenderer30.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE10", font37);
        categoryPlot2.setNoDataMessageFont(font37);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean43 = barRenderer41.isSeriesVisibleInLegend(1);
        boolean boolean44 = barRenderer41.getBaseCreateEntities();
        java.awt.Color color45 = java.awt.Color.LIGHT_GRAY;
        barRenderer41.setBaseFillPaint((java.awt.Paint) color45);
        double double47 = barRenderer41.getItemLabelAnchorOffset();
        java.awt.Stroke stroke49 = barRenderer41.lookupSeriesStroke((int) (byte) 1);
        categoryPlot40.setDomainGridlineStroke(stroke49);
        boolean boolean51 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        java.awt.geom.Point2D point2D54 = null;
        categoryPlot40.zoomDomainAxes(0.0d, plotRenderingInfo53, point2D54);
        java.awt.Font font56 = categoryPlot40.getNoDataMessageFont();
        categoryPlot2.setNoDataMessageFont(font56);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(font56);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.lang.String str3 = textTitle2.getToolTipText();
        java.lang.String str4 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer58 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) 0.2d);
        java.lang.Object obj59 = legendItemBlockContainer58.clone();
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        try {
            legendItemBlockContainer58.draw(graphics2D60, rectangle2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj59);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        java.lang.Object obj10 = categoryAxis1.clone();
        int int11 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray59);
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset60);
        org.jfree.data.Range range62 = barRenderer38.findRangeBounds(categoryDataset60);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint(range62, (double) 100.0f);
        org.jfree.chart.util.Size2D size2D65 = legendTitle36.arrange(graphics2D37, rectangleConstraint64);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean68 = barRenderer66.isSeriesVisibleInLegend(1);
        boolean boolean69 = barRenderer66.getBaseCreateEntities();
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        barRenderer66.setBaseFillPaint((java.awt.Paint) color70);
        barRenderer66.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator76 = barRenderer66.getLegendItemURLGenerator();
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        barRenderer66.setSeriesFillPaint((int) (short) 10, paint78, false);
        boolean boolean81 = size2D65.equals((java.lang.Object) barRenderer66);
        size2D65.setWidth((double) 100L);
        double double84 = size2D65.getHeight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1.0d) + "'", number61.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        float float17 = categoryPlot2.getBackgroundImageAlpha();
        categoryPlot2.configureRangeAxes();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray59);
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset60);
        org.jfree.data.Range range62 = barRenderer38.findRangeBounds(categoryDataset60);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint(range62, (double) 100.0f);
        org.jfree.chart.util.Size2D size2D65 = legendTitle36.arrange(graphics2D37, rectangleConstraint64);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean68 = barRenderer66.isSeriesVisibleInLegend(1);
        boolean boolean69 = barRenderer66.getBaseCreateEntities();
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        barRenderer66.setBaseFillPaint((java.awt.Paint) color70);
        barRenderer66.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator76 = barRenderer66.getLegendItemURLGenerator();
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        barRenderer66.setSeriesFillPaint((int) (short) 10, paint78, false);
        boolean boolean81 = size2D65.equals((java.lang.Object) barRenderer66);
        size2D65.setWidth((double) 100L);
        double double84 = size2D65.width;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1.0d) + "'", number61.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 100.0d + "'", double84 == 100.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean39 = barRenderer37.isSeriesVisibleInLegend(1);
        boolean boolean40 = barRenderer37.getBaseCreateEntities();
        java.awt.Color color41 = java.awt.Color.LIGHT_GRAY;
        barRenderer37.setBaseFillPaint((java.awt.Paint) color41);
        double double43 = barRenderer37.getItemLabelAnchorOffset();
        java.awt.Stroke stroke45 = barRenderer37.lookupSeriesStroke((int) (byte) 1);
        categoryPlot36.setDomainGridlineStroke(stroke45);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font35, (org.jfree.chart.plot.Plot) categoryPlot36, false);
        categoryPlot36.setBackgroundAlpha(0.0f);
        int int51 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation52);
        categoryPlot15.setRangeAxisLocation(255, axisLocation52, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation52, plotOrientation56);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean9 = barRenderer0.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean13 = barRenderer11.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        boolean boolean15 = barRenderer11.removeAnnotation(categoryAnnotation14);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor17);
        boolean boolean20 = itemLabelPosition18.equals((java.lang.Object) 0L);
        barRenderer11.setBaseNegativeItemLabelPosition(itemLabelPosition18, true);
        barRenderer0.setSeriesNegativeItemLabelPosition(1, itemLabelPosition18);
        java.awt.Paint paint25 = barRenderer0.getSeriesItemLabelPaint(10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot0.getLegendItems();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.plot.PlotState plotState36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        try {
            categoryPlot0.draw(graphics2D33, rectangle2D34, point2D35, plotState36, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        int int10 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        java.lang.Boolean boolean8 = barRenderer0.getSeriesCreateEntities(10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean6 = textAnchor3.equals((java.lang.Object) textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5);
        double double8 = categoryLabelPosition7.getAngle();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.BOTTOM", "");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        java.awt.Font font16 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean19 = barRenderer17.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke21 = barRenderer17.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setRangeCrosshairStroke(stroke21);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        boolean boolean14 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot3.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17);
        java.awt.Font font19 = categoryPlot3.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        java.awt.Paint paint27 = barRenderer21.getBaseItemLabelPaint();
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("CategoryLabelWidthType.RANGE", font19, paint27);
        textBlock0.addLine(textLine28);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("", font31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle32.setBackgroundPaint((java.awt.Paint) color33);
        java.lang.Object obj35 = textTitle32.clone();
        java.awt.Paint paint36 = textTitle32.getBackgroundPaint();
        boolean boolean37 = textBlock0.equals((java.lang.Object) textTitle32);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.shrink(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer7.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer7.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = barRenderer20.getSeriesPaint((int) '#');
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer20.setSeriesOutlinePaint(0, paint27);
        barRenderer7.setBaseOutlinePaint(paint27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer7.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition32, true);
        java.awt.Paint paint36 = barRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNull(paint36);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
        double double2 = numberTickUnit1.getSize();
        java.lang.String str4 = numberTickUnit1.valueToString((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNull(categoryDataset21);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Paint paint22 = barRenderer16.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot3.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16, true);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        categoryPlot3.drawBackgroundImage(graphics2D25, rectangle2D26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = categoryPlot3.getDrawingSupplier();
        categoryPlot3.clearAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean33 = barRenderer31.isSeriesVisibleInLegend(1);
        boolean boolean34 = barRenderer31.getBaseCreateEntities();
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        barRenderer31.setBaseFillPaint((java.awt.Paint) color35);
        double double37 = barRenderer31.getItemLabelAnchorOffset();
        java.awt.Font font38 = barRenderer31.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE10", font38);
        categoryPlot3.setNoDataMessageFont(font38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.text.TextMeasurer textMeasurer44 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock45 = org.jfree.chart.text.TextUtilities.createTextBlock("ItemLabelAnchor.OUTSIDE4", font38, (java.awt.Paint) color41, (float) 255, (int) '4', textMeasurer44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(drawingSupplier28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.0d + "'", double37 == 2.0d);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.jfree.chart.JFreeChart jFreeChart11 = axisChangeEvent10.getChart();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(jFreeChart11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis1.getLabelInsets();
        double double11 = rectangleInsets10.getBottom();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets10.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            blockBorder12.draw(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        barRenderer6.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color15);
        boolean boolean17 = chartEntity5.equals((java.lang.Object) color15);
        java.lang.String str18 = chartEntity5.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-53,51,51,-53,0,-73,-51,-53,53,51,73,0,53,-51,-51,53,0,73,51,53,-53,-51,-73,0,-73,0" + "'", str18.equals("-53,51,51,-53,0,-73,-51,-53,53,51,73,0,53,-51,-51,53,0,73,51,53,-53,-51,-73,0,-73,0"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot7.getRangeAxisLocation((int) (short) 10);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke20);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot7);
        int int23 = categoryPlot7.getDomainAxisCount();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean30 = barRenderer28.isSeriesVisibleInLegend(1);
        boolean boolean31 = barRenderer28.getBaseCreateEntities();
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        barRenderer28.setBaseFillPaint((java.awt.Paint) color32);
        double double34 = barRenderer28.getItemLabelAnchorOffset();
        java.awt.Stroke stroke36 = barRenderer28.lookupSeriesStroke((int) (byte) 1);
        categoryPlot27.setDomainGridlineStroke(stroke36);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("hi!", font26, (org.jfree.chart.plot.Plot) categoryPlot27, false);
        categoryPlot27.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean45 = barRenderer43.isSeriesVisibleInLegend(1);
        boolean boolean46 = barRenderer43.getBaseCreateEntities();
        java.awt.Color color47 = java.awt.Color.LIGHT_GRAY;
        barRenderer43.setBaseFillPaint((java.awt.Paint) color47);
        double double49 = barRenderer43.getItemLabelAnchorOffset();
        java.awt.Stroke stroke51 = barRenderer43.lookupSeriesStroke((int) (byte) 1);
        categoryPlot42.setDomainGridlineStroke(stroke51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot42.getRangeAxisLocation((int) (short) 10);
        categoryPlot27.setDomainAxisLocation(axisLocation54, true);
        categoryPlot7.setRangeAxisLocation((int) '#', axisLocation54);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getLabelInsets();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer11.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer23.isSeriesVisibleInLegend(1);
        boolean boolean26 = barRenderer23.getBaseCreateEntities();
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer23.setBaseFillPaint((java.awt.Paint) color27);
        double double29 = barRenderer23.getItemLabelAnchorOffset();
        java.awt.Stroke stroke31 = barRenderer23.lookupSeriesStroke((int) (byte) 1);
        barRenderer15.setSeriesOutlineStroke(255, stroke31, true);
        barRenderer11.setSeriesStroke(0, stroke31);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape9, stroke31, paint35);
        boolean boolean37 = rectangleInsets2.equals((java.lang.Object) legendItem36);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        double double2 = numberTickUnit1.getSize();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Font font9 = barRenderer2.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE10", font9);
        org.jfree.chart.plot.Plot plot11 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.OUTSIDE4", font9, plot11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(0);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.setAntiAlias(false);
        java.awt.RenderingHints renderingHints26 = jFreeChart14.getRenderingHints();
        org.jfree.chart.ui.ProjectInfo projectInfo27 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str28 = projectInfo27.getLicenceName();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) str28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: LGPL incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(renderingHints26);
        org.junit.Assert.assertNotNull(projectInfo27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "LGPL" + "'", str28.equals("LGPL"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        java.lang.Comparable comparable3 = null;
        keyedObjects2D0.removeColumn(comparable3);
        int int6 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke8 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, true);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("", font15);
        barRenderer0.setSeriesItemLabelFont(100, font15, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle14.setBackgroundPaint((java.awt.Paint) color15);
        java.lang.Object obj17 = textTitle14.clone();
        java.awt.Paint paint18 = textTitle14.getBackgroundPaint();
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) paint18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        barRenderer20.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint32 = barRenderer20.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape36, "hi!", "");
        java.awt.Shape shape40 = chartEntity39.getArea();
        barRenderer20.setSeriesShape(0, shape40, true);
        boolean boolean43 = categoryAxis1.equals((java.lang.Object) barRenderer20);
        java.awt.Shape shape46 = barRenderer20.getItemShape((int) (byte) 1, (int) '#');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseItemLabelsVisible(true);
        java.awt.Stroke stroke10 = barRenderer0.lookupSeriesOutlineStroke((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean3 = barRenderer1.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer1.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer1.getLegendItems();
        boolean boolean7 = horizontalAlignment0.equals((java.lang.Object) legendItemCollection6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment8, (double) 0L, (double) (short) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "NOID");
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis38.setTickLabelPaint((java.lang.Comparable) 0L, paint40);
        categoryAxis38.setCategoryMargin(0.0d);
        categoryAxis38.clearCategoryLabelToolTips();
        java.lang.String str46 = categoryAxis38.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis38.setTickMarksVisible(true);
        java.lang.Object obj49 = categoryAxis38.clone();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean53 = barRenderer51.isSeriesVisibleInLegend(1);
        boolean boolean54 = barRenderer51.getBaseCreateEntities();
        java.awt.Color color55 = java.awt.Color.LIGHT_GRAY;
        barRenderer51.setBaseFillPaint((java.awt.Paint) color55);
        java.awt.Paint paint57 = barRenderer51.getBaseItemLabelPaint();
        boolean boolean60 = barRenderer51.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean64 = barRenderer62.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation65 = null;
        boolean boolean66 = barRenderer62.removeAnnotation(categoryAnnotation65);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor67 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor68 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor67, textAnchor68);
        boolean boolean71 = itemLabelPosition69.equals((java.lang.Object) 0L);
        barRenderer62.setBaseNegativeItemLabelPosition(itemLabelPosition69, true);
        barRenderer51.setSeriesNegativeItemLabelPosition(1, itemLabelPosition69);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis38, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer51);
        boolean boolean76 = barRenderer51.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(boolean64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor67);
        org.junit.Assert.assertNotNull(textAnchor68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray59);
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset60);
        org.jfree.data.Range range62 = barRenderer38.findRangeBounds(categoryDataset60);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint(range62, (double) 100.0f);
        org.jfree.chart.util.Size2D size2D65 = legendTitle36.arrange(graphics2D37, rectangleConstraint64);
        double double66 = rectangleConstraint64.getHeight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1.0d) + "'", number61.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 100.0d + "'", double66 == 100.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        double double24 = barRenderer18.getItemLabelAnchorOffset();
        java.awt.Stroke stroke26 = barRenderer18.lookupSeriesStroke((int) (byte) 1);
        categoryPlot17.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot17.getRangeAxisLocation((int) (short) 10);
        categoryPlot2.setDomainAxisLocation(axisLocation29, true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        categoryPlot2.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot2.getRenderer(0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(categoryItemRenderer35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer37.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor42 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor42, textAnchor43);
        boolean boolean46 = itemLabelPosition44.equals((java.lang.Object) 0L);
        barRenderer37.setNegativeItemLabelPositionFallback(itemLabelPosition44);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition44);
        boolean boolean49 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset28);
        org.jfree.data.Range range30 = barRenderer6.findRangeBounds(categoryDataset28);
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color32);
        java.awt.Paint paint34 = barRenderer6.getBaseItemLabelPaint();
        textTitle3.setPaint(paint34);
        java.lang.Object obj36 = null;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj36);
        java.awt.Paint paint38 = textTitle3.getPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1.0d) + "'", number29.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = barRenderer1.getBaseItemLabelPaint();
        boolean boolean10 = barRenderer1.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean14 = barRenderer12.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        boolean boolean16 = barRenderer12.removeAnnotation(categoryAnnotation15);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        boolean boolean21 = itemLabelPosition19.equals((java.lang.Object) 0L);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition19, true);
        barRenderer1.setSeriesNegativeItemLabelPosition(1, itemLabelPosition19);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = itemLabelPosition19.getItemLabelAnchor();
        boolean boolean26 = axisSpace0.equals((java.lang.Object) itemLabelAnchor25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D29 = axisSpace0.expand(rectangle2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot8 = categoryAxis1.getPlot();
        java.lang.Object obj9 = categoryAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
        double double12 = numberTickUnit11.getSize();
        java.awt.Font font13 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        boolean boolean15 = numberTickUnit11.equals((java.lang.Object) color14);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.util.List list11 = categoryPlot0.getAnnotations();
        categoryPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke14 = null;
        try {
            categoryPlot0.setRangeCrosshairStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Point2D point2D2 = null;
        try {
            int int3 = plotRenderingInfo1.getSubplotIndex(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets30.createOutsetRectangle(rectangle2D33, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        java.awt.Stroke stroke6 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font7 = categoryAxis1.getTickLabelFont();
        categoryAxis1.setUpperMargin((-5.0d));
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        float float17 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot2.getFixedDomainAxisSpace();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Color color21 = color19.darker();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot3.getRendererForDataset(categoryDataset34);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot3.getRangeAxis();
        categoryPlot3.clearDomainMarkers();
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean45 = barRenderer43.isSeriesVisibleInLegend(1);
        boolean boolean46 = barRenderer43.getBaseCreateEntities();
        java.awt.Color color47 = java.awt.Color.LIGHT_GRAY;
        barRenderer43.setBaseFillPaint((java.awt.Paint) color47);
        double double49 = barRenderer43.getItemLabelAnchorOffset();
        java.awt.Stroke stroke51 = barRenderer43.lookupSeriesStroke((int) (byte) 1);
        categoryPlot42.setDomainGridlineStroke(stroke51);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", font41, (org.jfree.chart.plot.Plot) categoryPlot42, false);
        categoryPlot42.setBackgroundAlpha(0.0f);
        int int57 = categoryPlot42.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot42.setRangeAxisLocation(axisLocation58);
        categoryPlot3.setRangeAxisLocation(axisLocation58, false);
        boolean boolean62 = itemLabelAnchor0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color27);
        java.awt.Paint paint29 = barRenderer1.getBaseItemLabelPaint();
        boolean boolean30 = lineBorder0.equals((java.lang.Object) paint29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean26 = barRenderer24.isSeriesVisibleInLegend(1);
        boolean boolean27 = barRenderer24.getBaseCreateEntities();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray45);
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset46);
        org.jfree.data.Range range48 = barRenderer24.findRangeBounds(categoryDataset46);
        categoryPlot2.setDataset(categoryDataset46);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.0d) + "'", number47.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range48);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) 0L, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis21.getTickLabelInsets();
        java.awt.Stroke stroke26 = categoryAxis21.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke26, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean31 = barRenderer29.isSeriesVisibleInLegend(1);
        boolean boolean32 = barRenderer29.getBaseCreateEntities();
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] { numberArray39, numberArray44, numberArray49 };
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray50);
        java.lang.Number number52 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset51);
        org.jfree.data.Range range53 = barRenderer29.findRangeBounds(categoryDataset51);
        java.lang.Boolean boolean55 = barRenderer29.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint60 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis58.setTickLabelPaint((java.lang.Comparable) 0L, paint60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryAxis58.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement63 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean64 = rectangleInsets62.equals((java.lang.Object) columnArrangement63);
        org.jfree.chart.title.LegendTitle legendTitle65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer29, (org.jfree.chart.block.Arrangement) flowArrangement56, (org.jfree.chart.block.Arrangement) columnArrangement63);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer66.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor71 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor72 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition73 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor71, textAnchor72);
        boolean boolean75 = itemLabelPosition73.equals((java.lang.Object) 0L);
        barRenderer66.setNegativeItemLabelPositionFallback(itemLabelPosition73);
        barRenderer29.setBasePositiveItemLabelPosition(itemLabelPosition73);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-1.0d) + "'", number52.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNull(boolean55);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor71);
        org.junit.Assert.assertNotNull(textAnchor72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleEdge.BOTTOM", "LGPL");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LGPL" + "'", str3.equals("LGPL"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        java.lang.Object obj19 = barRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        double double24 = barRenderer18.getItemLabelAnchorOffset();
        java.awt.Stroke stroke26 = barRenderer18.lookupSeriesStroke((int) (byte) 1);
        categoryPlot17.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot17.getRangeAxisLocation((int) (short) 10);
        categoryPlot2.setDomainAxisLocation(axisLocation29, true);
        java.awt.Stroke stroke32 = categoryPlot2.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (byte) -1);
        int int6 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        java.lang.Comparable comparable7 = null;
        java.lang.Comparable comparable8 = null;
        keyedObjects2D0.removeObject(comparable7, comparable8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset18);
        double double20 = range19.getCentralValue();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 49.5d + "'", double20 == 49.5d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        categoryAxis1.setTickMarkStroke(stroke14);
        categoryAxis1.setLabelAngle((-1.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "hi!", textAnchor6, textAnchor7, (double) (short) -1);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT", graphics2D1, (float) 1L, 0.0f, textAnchor6, (double) (-12566464), textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass3 = paint2.getClass();
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass5 = paint4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ItemLabelAnchor.INSIDE10", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass2 = paint1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer17.isSeriesVisibleInLegend(1);
        boolean boolean20 = barRenderer17.getBaseCreateEntities();
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        barRenderer17.setBaseFillPaint((java.awt.Paint) color21);
        double double23 = barRenderer17.getItemLabelAnchorOffset();
        java.awt.Stroke stroke25 = barRenderer17.lookupSeriesStroke((int) (byte) 1);
        barRenderer17.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, true);
        java.awt.Paint paint30 = barRenderer17.getBaseOutlinePaint();
        categoryPlot0.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Color color32 = java.awt.Color.magenta;
        barRenderer17.setBaseItemLabelPaint((java.awt.Paint) color32, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = categoryTick7.getLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNull(textBlockAnchor8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        boolean boolean9 = itemLabelPosition7.equals((java.lang.Object) 0L);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition7, true);
        barRenderer0.removeAnnotations();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot2.getRangeAxis();
        categoryPlot2.clearDomainMarkers();
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean44 = barRenderer42.isSeriesVisibleInLegend(1);
        boolean boolean45 = barRenderer42.getBaseCreateEntities();
        java.awt.Color color46 = java.awt.Color.LIGHT_GRAY;
        barRenderer42.setBaseFillPaint((java.awt.Paint) color46);
        double double48 = barRenderer42.getItemLabelAnchorOffset();
        java.awt.Stroke stroke50 = barRenderer42.lookupSeriesStroke((int) (byte) 1);
        categoryPlot41.setDomainGridlineStroke(stroke50);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("hi!", font40, (org.jfree.chart.plot.Plot) categoryPlot41, false);
        categoryPlot41.setBackgroundAlpha(0.0f);
        int int56 = categoryPlot41.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot41.setRangeAxisLocation(axisLocation57);
        categoryPlot2.setRangeAxisLocation(axisLocation57, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot61);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(axisLocation57);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass3 = paint2.getClass();
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass5 = paint4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("100", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(uRL7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray5 = new double[] { (-12566464), 100, 2.0f };
        double[] doubleArray9 = new double[] { (-12566464), 100, 2.0f };
        double[] doubleArray13 = new double[] { (-12566464), 100, 2.0f };
        double[] doubleArray17 = new double[] { (-12566464), 100, 2.0f };
        double[] doubleArray21 = new double[] { (-12566464), 100, 2.0f };
        double[] doubleArray25 = new double[] { (-12566464), 100, 2.0f };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraintType.RANGE", "100", doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 101.0d, (float) (byte) 100, (float) 100L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color27);
        java.awt.Color color29 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", color27);
        float[] floatArray32 = new float[] { (short) 1, 500 };
        try {
            float[] floatArray33 = color29.getRGBColorComponents(floatArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        int int16 = jFreeChart14.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        jFreeChart14.setAntiAlias(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Image image32 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace33 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertNull(axisSpace33);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) 0L, paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis3.getTickLabelInsets();
        java.awt.Stroke stroke8 = categoryAxis3.getTickMarkStroke();
        java.awt.Font font9 = categoryAxis3.getTickLabelFont();
        java.awt.Color color10 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleAnchor.BOTTOM_LEFT", font9, (java.awt.Paint) color10);
        textLine0.removeFragment(textFragment11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        boolean boolean14 = categoryPlot3.isRangeGridlinesVisible();
        java.awt.Color color15 = java.awt.Color.RED;
        categoryPlot3.setRangeCrosshairPaint((java.awt.Paint) color15);
        java.lang.String str17 = categoryPlot3.getNoDataMessage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.lang.Object obj21 = plotRenderingInfo20.clone();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = barRenderer0.initialise(graphics2D1, rectangle2D2, categoryPlot3, 500, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot8 = categoryAxis1.getPlot();
        java.lang.Object obj9 = categoryAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
        double double12 = numberTickUnit11.getSize();
        java.awt.Font font13 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        org.jfree.chart.plot.Plot plot14 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(plot14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Paint paint6 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        java.awt.Color color10 = java.awt.Color.BLACK;
        barRenderer0.setSeriesFillPaint(15, (java.awt.Paint) color10, true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, 1.0d);
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range0, 4.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets30.createOutsetRectangle(rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
        double double4 = numberTickUnit3.getSize();
        try {
            org.jfree.chart.axis.TickUnit tickUnit5 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Paint paint39 = barRenderer0.getItemOutlinePaint(0, (int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = barRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryPlot40);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Font font7 = barRenderer0.getBaseItemLabelFont();
        barRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.awt.Image image17 = jFreeChart16.getBackgroundImage();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("", font19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.lang.Object obj23 = null;
        java.lang.Object obj24 = textTitle20.draw(graphics2D21, rectangle2D22, obj23);
        textTitle20.setToolTipText("hi!");
        jFreeChart16.removeSubtitle((org.jfree.chart.title.Title) textTitle20);
        java.awt.Paint paint28 = jFreeChart16.getBackgroundPaint();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotRenderingInfo0, jFreeChart16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        double double7 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        int int33 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 128 + "'", int33 == 128);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Stroke stroke10 = barRenderer2.lookupSeriesStroke((int) (byte) 1);
        categoryPlot1.setDomainGridlineStroke(stroke10);
        boolean boolean12 = categoryPlot1.isRangeGridlinesVisible();
        java.awt.Color color13 = java.awt.Color.RED;
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color13);
        categoryPlot1.setRangeCrosshairVisible(true);
        boolean boolean17 = horizontalAlignment0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        java.lang.Object obj9 = legendItemEntity3.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray31);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset32);
        org.jfree.data.Range range34 = barRenderer10.findRangeBounds(categoryDataset32);
        legendItemEntity3.setDataset((org.jfree.data.general.Dataset) categoryDataset32);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) 0L, paint17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis15.getTickLabelInsets();
        categoryPlot13.setAxisOffset(rectangleInsets19);
        double double22 = rectangleInsets19.trimHeight((double) (byte) -1);
        categoryPlot0.setInsets(rectangleInsets19, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            boolean boolean26 = categoryPlot0.removeAnnotation(categoryAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-5.0d) + "'", double22 == (-5.0d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot3.getRendererForDataset(categoryDataset34);
        java.awt.Paint paint38 = categoryPlot3.getRangeCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("RectangleAnchor.BOTTOM_LEFT", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        boolean boolean10 = textTitle2.equals((java.lang.Object) false);
        java.awt.Color color11 = java.awt.Color.darkGray;
        int int12 = color11.getRGB();
        textTitle2.setBackgroundPaint((java.awt.Paint) color11);
        double double14 = textTitle2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-12566464) + "'", int12 == (-12566464));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        double double16 = categoryPlot2.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot2);
        org.jfree.chart.JFreeChart jFreeChart18 = plotChangeEvent17.getChart();
        org.jfree.chart.JFreeChart jFreeChart19 = plotChangeEvent17.getChart();
        java.lang.Object obj20 = plotChangeEvent17.getSource();
        java.lang.Object obj21 = plotChangeEvent17.getSource();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(jFreeChart18);
        org.junit.Assert.assertNull(jFreeChart19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 10, plotRenderingInfo17, point2D18);
        java.lang.String str20 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", font4, (org.jfree.chart.plot.Plot) categoryPlot5, false);
        java.awt.Image image18 = jFreeChart17.getBackgroundImage();
        jFreeChart17.setBackgroundImageAlignment(0);
        java.awt.image.BufferedImage bufferedImage23 = jFreeChart17.createBufferedImage(1, (int) '4');
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("", "CategoryLabelWidthType.RANGE", "RectangleEdge.BOTTOM", (java.awt.Image) bufferedImage23, "DatasetRenderingOrder.FORWARD", "VerticalAlignment.BOTTOM", "LGPL");
        projectInfo27.addOptionalLibrary("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(bufferedImage23);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = barRenderer0.removeAnnotation(categoryAnnotation6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer9.isSeriesVisibleInLegend(1);
        boolean boolean12 = barRenderer9.getBaseCreateEntities();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        barRenderer9.setBaseFillPaint((java.awt.Paint) color13);
        double double15 = barRenderer9.getItemLabelAnchorOffset();
        java.awt.Stroke stroke17 = barRenderer9.lookupSeriesStroke((int) (byte) 1);
        categoryPlot8.setDomainGridlineStroke(stroke17);
        boolean boolean19 = categoryPlot8.isRangeGridlinesVisible();
        java.awt.Color color20 = java.awt.Color.RED;
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color20);
        java.lang.String str22 = categoryPlot8.getNoDataMessage();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot8);
        barRenderer0.setBase((double) 1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean6 = textAnchor3.equals((java.lang.Object) textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5);
        java.lang.String str8 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str8.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        org.jfree.data.KeyToGroupMap keyToGroupMap25 = null;
        try {
            org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset22, keyToGroupMap25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer17.isSeriesVisibleInLegend(1);
        boolean boolean20 = barRenderer17.getBaseCreateEntities();
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        barRenderer17.setBaseFillPaint((java.awt.Paint) color21);
        barRenderer17.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint29 = barRenderer17.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape33, "hi!", "");
        java.awt.Shape shape37 = chartEntity36.getArea();
        barRenderer17.setSeriesShape(0, shape37, true);
        categoryPlot0.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) '4', (float) 100L, (float) (short) 10);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        barRenderer18.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color27);
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = jFreeChart14.getCategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean34 = barRenderer32.isSeriesVisibleInLegend(1);
        boolean boolean35 = barRenderer32.getBaseCreateEntities();
        java.lang.Number[] numberArray42 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray47 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray53 = new java.lang.Number[][] { numberArray42, numberArray47, numberArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray53);
        java.lang.Number number55 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset54);
        org.jfree.data.Range range56 = barRenderer32.findRangeBounds(categoryDataset54);
        java.awt.Color color58 = java.awt.Color.LIGHT_GRAY;
        barRenderer32.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color58);
        java.awt.Color color60 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", color58);
        categoryPlot30.setDomainGridlinePaint((java.awt.Paint) color58);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(categoryPlot30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + (-1.0d) + "'", number55.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot0.getRangeAxis((int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator29, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNull(categoryItemLabelGenerator27);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        double double3 = barRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        boolean boolean8 = itemLabelPosition6.equals((java.lang.Object) 0L);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        org.jfree.chart.plot.Plot plot22 = jFreeChart14.getPlot();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(plot22);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color27);
        java.awt.Color color29 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", color27);
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        int int17 = categoryPlot2.getDomainAxisCount();
        categoryPlot2.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        barRenderer18.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color27);
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = jFreeChart14.getCategoryPlot();
        java.awt.Image image31 = jFreeChart14.getBackgroundImage();
        java.lang.Object obj32 = jFreeChart14.getTextAntiAlias();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(categoryPlot30);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot0.getDatasetRenderingOrder();
        float float17 = categoryPlot0.getBackgroundAlpha();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color18);
        float float20 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color27);
        java.awt.Color color29 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", color27);
        float[] floatArray35 = new float[] { (byte) 0, (short) 0, 0.5f, 500, 1L };
        float[] floatArray36 = color27.getRGBColorComponents(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Stroke stroke10 = barRenderer2.lookupSeriesStroke((int) (byte) 1);
        categoryPlot1.setDomainGridlineStroke(stroke10);
        boolean boolean12 = categoryPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot1.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Font font17 = categoryPlot1.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean20 = labelBlock18.equals((java.lang.Object) categoryAnchor19);
        java.lang.String str21 = labelBlock18.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        java.awt.Stroke stroke6 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot9.getRangeAxisLocation((int) (short) 10);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        axisSpace23.setLeft(100.0d);
        categoryPlot9.setFixedRangeAxisSpace(axisSpace23);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(2.0d, 3.0d, (double) 128, 0.2d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        categoryPlot19.setDomainGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        barRenderer35.setBaseFillPaint((java.awt.Paint) color39);
        double double41 = barRenderer35.getItemLabelAnchorOffset();
        java.awt.Stroke stroke43 = barRenderer35.lookupSeriesStroke((int) (byte) 1);
        categoryPlot34.setDomainGridlineStroke(stroke43);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("hi!", font33, (org.jfree.chart.plot.Plot) categoryPlot34, false);
        categoryPlot34.setBackgroundAlpha(0.0f);
        int int49 = categoryPlot34.getDomainAxisCount();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot34);
        boolean boolean51 = categoryPlot34.isOutlineVisible();
        barRenderer0.setPlot(categoryPlot34);
        boolean boolean53 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        org.jfree.data.Range range27 = org.jfree.data.Range.expand(range24, (double) 1.0f, 1.0d);
        double double29 = range27.constrain((double) 0.0f);
        boolean boolean32 = range27.intersects((-1.0d), (double) 0.5f);
        org.jfree.data.Range range33 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean36 = barRenderer34.isSeriesVisibleInLegend(1);
        boolean boolean37 = barRenderer34.getBaseCreateEntities();
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray44, numberArray49, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray55);
        java.lang.Number number57 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset56);
        org.jfree.data.Range range58 = barRenderer34.findRangeBounds(categoryDataset56);
        org.jfree.data.Range range61 = org.jfree.data.Range.expand(range58, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint(range33, range61);
        org.jfree.data.Range range63 = rectangleConstraint62.getWidthRange();
        org.jfree.data.Range range64 = rectangleConstraint62.getWidthRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean67 = barRenderer65.isSeriesVisibleInLegend(1);
        boolean boolean68 = barRenderer65.getBaseCreateEntities();
        java.lang.Number[] numberArray75 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray80 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray85 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray86 = new java.lang.Number[][] { numberArray75, numberArray80, numberArray85 };
        org.jfree.data.category.CategoryDataset categoryDataset87 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray86);
        java.lang.Number number88 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset87);
        org.jfree.data.Range range89 = barRenderer65.findRangeBounds(categoryDataset87);
        org.jfree.data.Range range92 = org.jfree.data.Range.expand(range89, (double) 1.0f, 1.0d);
        double double94 = range92.constrain((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint95 = rectangleConstraint62.toRangeHeight(range92);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint96 = new org.jfree.chart.block.RectangleConstraint(range27, range92);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + (-1.0d) + "'", number57.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray80);
        org.junit.Assert.assertNotNull(numberArray85);
        org.junit.Assert.assertNotNull(numberArray86);
        org.junit.Assert.assertNotNull(categoryDataset87);
        org.junit.Assert.assertTrue("'" + number88 + "' != '" + (-1.0d) + "'", number88.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertNotNull(range92);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint95);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        legendItemEntity7.setURLText("LGPL");
        legendItemEntity7.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        java.lang.String str13 = legendItemEntity7.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "poly" + "'", str13.equals("poly"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.lang.Boolean boolean42 = barRenderer16.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement43 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis45.setTickLabelPaint((java.lang.Comparable) 0L, paint47);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement50 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean51 = rectangleInsets49.equals((java.lang.Object) columnArrangement50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer16, (org.jfree.chart.block.Arrangement) flowArrangement43, (org.jfree.chart.block.Arrangement) columnArrangement50);
        jFreeChart14.addLegend(legendTitle52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = null;
        try {
            legendTitle52.setPadding(rectangleInsets54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNull(boolean42);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass3 = paint2.getClass();
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass5 = paint4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("poly", (java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) (byte) -1);
        double double4 = rectangleInsets0.calculateBottomOutset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        double double6 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        boolean boolean15 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes(0.0d, plotRenderingInfo17, point2D18);
        java.awt.Font font20 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        barRenderer21.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color30);
        java.awt.Color color32 = color30.brighter();
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", font20, (java.awt.Paint) color32, 0.0f);
        boolean boolean35 = plotRenderingInfo1.equals((java.lang.Object) textFragment34);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getWidthRange();
        double double31 = rectangleConstraint29.getWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        double double16 = categoryPlot2.getRangeCrosshairValue();
        java.awt.Stroke stroke17 = categoryPlot2.getRangeCrosshairStroke();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot2.setDataset(categoryDataset18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        double double24 = barRenderer18.getItemLabelAnchorOffset();
        java.awt.Stroke stroke26 = barRenderer18.lookupSeriesStroke((int) (byte) 1);
        categoryPlot17.setDomainGridlineStroke(stroke26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot17.getRangeAxisLocation((int) (short) 10);
        categoryPlot2.setDomainAxisLocation(axisLocation29, true);
        try {
            categoryPlot2.mapDatasetToDomainAxis((-12566464), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis1.setTickMarksVisible(true);
        categoryAxis1.setCategoryMargin(1.0d);
        boolean boolean14 = categoryAxis1.isTickMarksVisible();
        java.lang.Object obj15 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.util.SortOrder sortOrder16 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        double double13 = barRenderer7.getItemLabelAnchorOffset();
        java.awt.Stroke stroke15 = barRenderer7.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(100, stroke15, true);
        java.awt.Stroke stroke20 = barRenderer0.getItemStroke(2, 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke4 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        boolean boolean18 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot7.getDatasetRenderingOrder();
        float float24 = categoryPlot7.getBackgroundAlpha();
        boolean boolean25 = standardCategorySeriesLabelGenerator5.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot7.getDomainMarkers(layer26);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        java.lang.String str14 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        org.jfree.data.Range range40 = barRenderer16.findRangeBounds(categoryDataset38);
        java.awt.Color color42 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color42);
        categoryPlot0.setRenderer((int) (byte) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator48 = barRenderer16.getItemLabelGenerator(0, 128);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(categoryItemLabelGenerator48);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        java.awt.Font font16 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis1.getLabelInsets();
        double double11 = rectangleInsets10.getBottom();
        double double13 = rectangleInsets10.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "hi!", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        chartEntity5.setArea(shape12);
        java.lang.String str14 = chartEntity5.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "poly" + "'", str14.equals("poly"));
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addOptionalLibrary("");
//        projectInfo0.setCopyright("");
//        java.lang.String str5 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str5.equals("RectangleAnchor.BOTTOM_LEFT"));
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        java.awt.geom.Point2D point2D3 = null;
        try {
            int int4 = plotRenderingInfo1.getSubplotIndex(point2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = barRenderer0.removeAnnotation(categoryAnnotation6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer9.isSeriesVisibleInLegend(1);
        boolean boolean12 = barRenderer9.getBaseCreateEntities();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        barRenderer9.setBaseFillPaint((java.awt.Paint) color13);
        double double15 = barRenderer9.getItemLabelAnchorOffset();
        java.awt.Stroke stroke17 = barRenderer9.lookupSeriesStroke((int) (byte) 1);
        categoryPlot8.setDomainGridlineStroke(stroke17);
        boolean boolean19 = categoryPlot8.isRangeGridlinesVisible();
        java.awt.Color color20 = java.awt.Color.RED;
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color20);
        java.lang.String str22 = categoryPlot8.getNoDataMessage();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot8);
        boolean boolean24 = categoryPlot8.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        boolean boolean13 = categoryPlot2.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16);
        java.awt.Font font18 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer19.isSeriesVisibleInLegend(1);
        boolean boolean22 = barRenderer19.getBaseCreateEntities();
        java.awt.Color color23 = java.awt.Color.LIGHT_GRAY;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color23);
        barRenderer19.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color28);
        java.awt.Color color30 = color28.brighter();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", font18, (java.awt.Paint) color30, 0.0f);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean38 = barRenderer36.isSeriesVisibleInLegend(1);
        boolean boolean39 = barRenderer36.getBaseCreateEntities();
        java.awt.Color color40 = java.awt.Color.LIGHT_GRAY;
        barRenderer36.setBaseFillPaint((java.awt.Paint) color40);
        double double42 = barRenderer36.getItemLabelAnchorOffset();
        java.awt.Stroke stroke44 = barRenderer36.lookupSeriesStroke((int) (byte) 1);
        categoryPlot35.setDomainGridlineStroke(stroke44);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) categoryPlot35, false);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot35.getFixedLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean51 = barRenderer49.isSeriesVisibleInLegend(1);
        boolean boolean52 = barRenderer49.getBaseCreateEntities();
        java.awt.Color color53 = java.awt.Color.LIGHT_GRAY;
        barRenderer49.setBaseFillPaint((java.awt.Paint) color53);
        java.awt.Paint paint55 = barRenderer49.getBaseItemLabelPaint();
        categoryPlot35.setDomainGridlinePaint(paint55);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM", font18, paint55);
        java.lang.String str58 = labelBlock57.getURLText();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(legendItemCollection48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(str58);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        boolean boolean14 = categoryPlot3.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot3.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17);
        java.awt.Font font19 = categoryPlot3.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        java.awt.Paint paint27 = barRenderer21.getBaseItemLabelPaint();
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("CategoryLabelWidthType.RANGE", font19, paint27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean31 = barRenderer29.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        boolean boolean33 = barRenderer29.removeAnnotation(categoryAnnotation32);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = barRenderer29.getLegendItems();
        java.awt.Paint paint37 = barRenderer29.getItemOutlinePaint(0, 255);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment40 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement43 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment39, verticalAlignment40, (double) 255, (double) (short) -1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis46.setTickLabelPaint((java.lang.Comparable) 0L, paint48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryAxis46.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("", font19, paint37, rectangleEdge38, horizontalAlignment39, verticalAlignment44, rectangleInsets50);
        textTitle51.setToolTipText("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "");
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (-12566464), (double) 0.5f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "hi!", "");
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, (double) (-12566464), (double) 0.5f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        barRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint42 = barRenderer30.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape46, "hi!", "");
        java.awt.Shape shape50 = chartEntity49.getArea();
        barRenderer30.setSeriesShape(0, shape50, true);
        java.awt.Shape[] shapeArray53 = new java.awt.Shape[] { shape7, shape16, shape19, shape29, shape50 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray53);
        java.lang.Object obj55 = defaultDrawingSupplier54.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shapeArray53);
        org.junit.Assert.assertNotNull(obj55);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "", "", "ItemLabelAnchor.OUTSIDE4", shape6, (java.awt.Paint) color8);
        java.lang.Comparable comparable10 = legendItem9.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) 0L, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis21.getTickLabelInsets();
        java.awt.Stroke stroke26 = categoryAxis21.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke26, true);
        barRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        boolean boolean10 = textTitle2.equals((java.lang.Object) false);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = textTitle2.getVerticalAlignment();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis33.setTickLabelPaint((java.lang.Comparable) 0L, paint35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis33.getTickLabelInsets();
        java.awt.Stroke stroke38 = categoryAxis33.getTickMarkStroke();
        barRenderer12.setSeriesOutlineStroke((int) (byte) 0, stroke38, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = barRenderer12.getPlot();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator42 = null;
        barRenderer12.setBaseURLGenerator(categoryURLGenerator42);
        boolean boolean44 = verticalAlignment11.equals((java.lang.Object) categoryURLGenerator42);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(categoryPlot41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        barRenderer0.setBaseSeriesVisible(true);
        java.awt.Paint paint9 = null;
        barRenderer0.setSeriesPaint((int) (short) 100, paint9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer7.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer7.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = barRenderer20.getSeriesPaint((int) '#');
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer20.setSeriesOutlinePaint(0, paint27);
        barRenderer7.setBaseOutlinePaint(paint27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer7.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition32, true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setSeriesShape((int) (short) 1, shape38);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary("");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.TOP", "ItemLabelAnchor.OUTSIDE4", "", "RectangleEdge.BOTTOM");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.setBackgroundAlpha((float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        boolean boolean5 = barRenderer0.isSeriesItemLabelsVisible((int) '4');
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) 0L, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis21.getTickLabelInsets();
        java.awt.Stroke stroke26 = categoryAxis21.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke26, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean31 = barRenderer29.isSeriesVisibleInLegend(1);
        boolean boolean32 = barRenderer29.getBaseCreateEntities();
        java.awt.Color color33 = java.awt.Color.LIGHT_GRAY;
        barRenderer29.setBaseFillPaint((java.awt.Paint) color33);
        barRenderer29.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer29.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean44 = barRenderer42.isSeriesVisibleInLegend(1);
        boolean boolean45 = barRenderer42.getBaseCreateEntities();
        java.awt.Paint paint47 = barRenderer42.getSeriesPaint((int) '#');
        java.awt.Paint paint49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer42.setSeriesOutlinePaint(0, paint49);
        barRenderer29.setBaseOutlinePaint(paint49, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = barRenderer29.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition54);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(paint47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.setAntiAlias(false);
        java.awt.RenderingHints renderingHints26 = jFreeChart14.getRenderingHints();
        jFreeChart14.setAntiAlias(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(renderingHints26);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.awt.Color color2 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE10", (int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer17.isSeriesVisibleInLegend(1);
        boolean boolean20 = barRenderer17.getBaseCreateEntities();
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        barRenderer17.setBaseFillPaint((java.awt.Paint) color21);
        double double23 = barRenderer17.getItemLabelAnchorOffset();
        java.awt.Stroke stroke25 = barRenderer17.lookupSeriesStroke((int) (byte) 1);
        barRenderer17.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, true);
        java.awt.Paint paint30 = barRenderer17.getBaseOutlinePaint();
        categoryPlot0.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        int int32 = barRenderer17.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 100, "hi!", textAnchor2, textAnchor3, (double) (short) -1);
        org.jfree.chart.axis.TickType tickType6 = numberTick5.getTickType();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(tickType6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        barRenderer0.setSeriesFillPaint((int) (short) 10, paint12, false);
        java.awt.Stroke stroke17 = barRenderer0.getItemStroke((int) (byte) 1, 0);
        java.lang.Class<?> wildcardClass18 = barRenderer0.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 100, categoryToolTipGenerator20);
        int int22 = barRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        barRenderer0.setBaseSeriesVisible(true, true);
        java.awt.Paint paint10 = null;
        try {
            barRenderer0.setBaseOutlinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        boolean boolean26 = shapeList0.equals((java.lang.Object) range25);
        java.lang.Object obj27 = shapeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis5.setTickLabelPaint((java.lang.Comparable) 0L, paint7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 0, (double) 0.0f, (double) (-1.0f), paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.BOTTOM", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        barRenderer0.setMinimumBarLength((double) 15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation6 = null;
        boolean boolean7 = barRenderer0.removeAnnotation(categoryAnnotation6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer9.isSeriesVisibleInLegend(1);
        boolean boolean12 = barRenderer9.getBaseCreateEntities();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        barRenderer9.setBaseFillPaint((java.awt.Paint) color13);
        double double15 = barRenderer9.getItemLabelAnchorOffset();
        java.awt.Stroke stroke17 = barRenderer9.lookupSeriesStroke((int) (byte) 1);
        categoryPlot8.setDomainGridlineStroke(stroke17);
        boolean boolean19 = categoryPlot8.isRangeGridlinesVisible();
        java.awt.Color color20 = java.awt.Color.RED;
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color20);
        java.lang.String str22 = categoryPlot8.getNoDataMessage();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        boolean boolean25 = barRenderer0.removeAnnotation(categoryAnnotation24);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle5.setBackgroundPaint((java.awt.Paint) color6);
        boolean boolean8 = textLine1.equals((java.lang.Object) textTitle5);
        org.jfree.chart.text.TextFragment textFragment9 = textLine1.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment10 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(textFragment10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint5 = valueMarker1.getLabelPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str7 = rectangleAnchor6.toString();
        valueMarker1.setLabelAnchor(rectangleAnchor6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str7.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 1.0d, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray3 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray4 = null;
        java.awt.Stroke[] strokeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape11, "hi!", "");
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape11, (double) (-12566464), (double) 0.5f);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape24, "hi!", "");
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, (double) (-12566464), (double) 0.5f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean33 = barRenderer31.isSeriesVisibleInLegend(1);
        boolean boolean34 = barRenderer31.getBaseCreateEntities();
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        barRenderer31.setBaseFillPaint((java.awt.Paint) color35);
        barRenderer31.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint43 = barRenderer31.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity(shape47, "hi!", "");
        java.awt.Shape shape51 = chartEntity50.getArea();
        barRenderer31.setSeriesShape(0, shape51, true);
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape8, shape17, shape20, shape30, shape51 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray4, strokeArray5, shapeArray54);
        boolean boolean56 = categoryAnchor0.equals((java.lang.Object) shapeArray54);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) 0L, paint23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis21.getTickLabelInsets();
        java.awt.Stroke stroke26 = categoryAxis21.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke26, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = barRenderer0.getToolTipGenerator((int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        java.lang.Object obj2 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        textTitle2.setURLText("");
        textTitle2.setHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        int int2 = objectList0.indexOf((java.lang.Object) axisLocation1);
        objectList0.clear();
        java.lang.Object obj5 = objectList0.get((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        java.lang.String str14 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color17);
        categoryPlot0.setNoDataMessage("LGPL");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM_LEFT", "RectangleAnchor.TOP", "", "hi!", "RectangleAnchor.BOTTOM_LEFT");
        basicProjectInfo5.setName("NOID");
        basicProjectInfo5.setInfo("100");
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        java.awt.Font font24 = barRenderer0.getBaseItemLabelFont();
        barRenderer0.setAutoPopulateSeriesPaint(true);
        boolean boolean27 = barRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 100, categoryURLGenerator29, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator25, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        java.awt.Font font16 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Paint paint23 = barRenderer18.getSeriesPaint((int) '#');
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer18.setSeriesOutlinePaint(0, paint25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = barRenderer18.getBaseURLGenerator();
        categoryPlot2.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.lang.String str29 = categoryPlot2.getNoDataMessage();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            categoryPlot2.drawOutline(graphics2D30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryURLGenerator27);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.lang.Class class2 = null;
        java.awt.Paint paint4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass5 = paint4.getClass();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass7 = paint6.getClass();
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LGPL", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass7);
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelWidthType.RANGE", class2, (java.lang.Class) wildcardClass7);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(inputStream10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "", "RectangleEdge.BOTTOM", categoryDataset27, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) false);
        java.lang.Comparable comparable33 = categoryItemEntity32.getRowKey();
        categoryItemEntity32.setToolTipText("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (byte) 0 + "'", comparable33.equals((byte) 0));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "", "RectangleEdge.BOTTOM", categoryDataset27, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) false);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, 0.0d, (double) 1L);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateY((double) '#');
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) 100, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis3.addChangeListener(axisChangeListener4);
        java.lang.String str6 = categoryAxis3.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis3.getCategoryJava2DCoordinate(categoryAnchor7, 8, (int) (byte) 1, rectangle2D11, rectangleEdge12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis15.setTickLabelPaint((java.lang.Comparable) 0L, paint17);
        categoryAxis15.setCategoryMargin(0.0d);
        categoryAxis15.clearCategoryLabelToolTips();
        categoryAxis15.setVisible(false);
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("", font27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle28.setBackgroundPaint((java.awt.Paint) color29);
        java.lang.Object obj31 = textTitle28.clone();
        java.awt.Paint paint32 = textTitle28.getBackgroundPaint();
        boolean boolean33 = categoryAxis15.equals((java.lang.Object) paint32);
        try {
            java.lang.Object obj34 = blockContainer0.draw(graphics2D1, rectangle2D11, (java.lang.Object) categoryAxis15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.plot.Plot plot37 = categoryPlot2.getRootPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = null;
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean45 = barRenderer43.isSeriesVisibleInLegend(1);
        boolean boolean46 = barRenderer43.getBaseCreateEntities();
        java.awt.Color color47 = java.awt.Color.LIGHT_GRAY;
        barRenderer43.setBaseFillPaint((java.awt.Paint) color47);
        double double49 = barRenderer43.getItemLabelAnchorOffset();
        java.awt.Stroke stroke51 = barRenderer43.lookupSeriesStroke((int) (byte) 1);
        categoryPlot42.setDomainGridlineStroke(stroke51);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("hi!", font41, (org.jfree.chart.plot.Plot) categoryPlot42, false);
        java.lang.Number[] numberArray61 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray71 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] { numberArray61, numberArray66, numberArray71 };
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray72);
        java.lang.Number number74 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset73);
        boolean boolean75 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer76 = categoryPlot42.getRendererForDataset(categoryDataset73);
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection79 = categoryPlot42.getRangeMarkers((int) (byte) 100, layer78);
        try {
            categoryPlot2.addDomainMarker(0, categoryMarker39, layer78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + (-1.0d) + "'", number74.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(categoryItemRenderer76);
        org.junit.Assert.assertNotNull(layer78);
        org.junit.Assert.assertNull(collection79);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        java.lang.Object obj22 = jFreeChart14.clone();
        jFreeChart14.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        try {
            java.awt.image.BufferedImage bufferedImage28 = jFreeChart14.createBufferedImage(100, 0, chartRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean11 = barRenderer9.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke13 = barRenderer9.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation33 = null;
        try {
            categoryPlot15.setDomainAxisLocation(axisLocation33, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray22, numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray33);
        java.lang.Number number35 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot3.getRendererForDataset(categoryDataset34);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection40 = categoryPlot3.getRangeMarkers((int) (byte) 100, layer39);
        boolean boolean41 = numberTickUnit0.equals((java.lang.Object) layer39);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot7.getRangeAxisLocation((int) (short) 10);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot7.setDomainGridlineStroke(stroke20);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot7);
        int int23 = categoryPlot7.getDomainAxisCount();
        java.awt.Paint paint24 = categoryPlot7.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = rectangleConstraint29.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(lengthConstraintType30);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle14.setBackgroundPaint((java.awt.Paint) color15);
        java.lang.Object obj17 = textTitle14.clone();
        java.awt.Paint paint18 = textTitle14.getBackgroundPaint();
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) paint18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        barRenderer20.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint32 = barRenderer20.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape36, "hi!", "");
        java.awt.Shape shape40 = chartEntity39.getArea();
        barRenderer20.setSeriesShape(0, shape40, true);
        boolean boolean43 = categoryAxis1.equals((java.lang.Object) barRenderer20);
        java.awt.Stroke stroke44 = null;
        try {
            categoryAxis1.setAxisLineStroke(stroke44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        boolean boolean34 = legendItem33.isLineVisible();
        int int35 = legendItem33.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.lang.Comparable comparable34 = legendItem33.getSeriesKey();
        legendItem33.setSeriesKey((java.lang.Comparable) 500);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(comparable34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.plot.Plot plot37 = categoryPlot2.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis39.setTickLabelPaint((java.lang.Comparable) 0L, paint41);
        categoryAxis39.setCategoryMargin(0.0d);
        categoryAxis39.clearCategoryLabelToolTips();
        java.lang.String str47 = categoryAxis39.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis39.setTickMarksVisible(true);
        categoryAxis39.setCategoryMargin(1.0d);
        int int52 = categoryPlot2.getDomainAxisIndex(categoryAxis39);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot0.getLegendItems();
        int int33 = legendItemCollection32.getItemCount();
        int int34 = legendItemCollection32.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer0.getLegendItems();
        java.lang.Object obj6 = legendItemCollection5.clone();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setBaseShape(shape12, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.lang.String str16 = legendItemEntity15.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str16.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        java.lang.String str9 = legendItemEntity7.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str9.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }
}

