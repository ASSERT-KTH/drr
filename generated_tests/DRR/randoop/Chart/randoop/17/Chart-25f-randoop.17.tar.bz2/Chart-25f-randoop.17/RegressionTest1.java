import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        java.awt.Font font24 = barRenderer0.getBaseItemLabelFont();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer0.setSeriesItemLabelPaint((int) (short) 0, (java.awt.Paint) color26);
        java.awt.Paint paint29 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.LegendItem legendItem9 = barRenderer0.getLegendItem(1, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke4 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        barRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        float float3 = categoryLabelPosition2.getWidthRatio();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.95f + "'", float3 == 0.95f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryTick7.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryTick7.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity32 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "", "RectangleEdge.BOTTOM", categoryDataset27, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) false);
        java.lang.String str33 = categoryItemEntity32.toString();
        java.lang.String str34 = categoryItemEntity32.toString();
        categoryItemEntity32.setColumnKey((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list2);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        boolean boolean34 = legendItem33.isLineVisible();
        boolean boolean35 = legendItem33.isShapeVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot4.getFixedLegendItems();
        double double18 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.JFreeChart jFreeChart20 = plotChangeEvent19.getChart();
        org.jfree.chart.plot.Plot plot21 = plotChangeEvent19.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = plotChangeEvent19.getType();
        org.jfree.data.Range range23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean26 = barRenderer24.isSeriesVisibleInLegend(1);
        boolean boolean27 = barRenderer24.getBaseCreateEntities();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray45);
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset46);
        org.jfree.data.Range range48 = barRenderer24.findRangeBounds(categoryDataset46);
        org.jfree.data.Range range51 = org.jfree.data.Range.expand(range48, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint(range23, range51);
        org.jfree.data.Range range53 = rectangleConstraint52.getWidthRange();
        org.jfree.data.Range range54 = rectangleConstraint52.getWidthRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean57 = barRenderer55.isSeriesVisibleInLegend(1);
        boolean boolean58 = barRenderer55.getBaseCreateEntities();
        java.lang.Number[] numberArray65 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray70 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray75 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray76 = new java.lang.Number[][] { numberArray65, numberArray70, numberArray75 };
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray76);
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset77);
        org.jfree.data.Range range79 = barRenderer55.findRangeBounds(categoryDataset77);
        org.jfree.data.Range range82 = org.jfree.data.Range.expand(range79, (double) 1.0f, 1.0d);
        double double84 = range82.constrain((double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint85 = rectangleConstraint52.toRangeHeight(range82);
        boolean boolean86 = chartChangeEventType22.equals((java.lang.Object) rectangleConstraint52);
        boolean boolean87 = datasetRenderingOrder0.equals((java.lang.Object) boolean86);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(jFreeChart20);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.0d) + "'", number47.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray75);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + (-1.0d) + "'", number78.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(range82);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        org.jfree.data.general.Dataset dataset60 = legendItemBlockContainer59.getDataset();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener64 = null;
        categoryAxis63.addChangeListener(axisChangeListener64);
        java.lang.String str66 = categoryAxis63.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor67 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D71 = textTitle70.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = categoryAxis63.getCategoryJava2DCoordinate(categoryAnchor67, 8, (int) (byte) 1, rectangle2D71, rectangleEdge72);
        try {
            java.lang.Object obj75 = legendItemBlockContainer59.draw(graphics2D61, rectangle2D71, (java.lang.Object) "-53,51,51,-53,0,-73,-51,-53,53,51,73,0,53,-51,-51,53,0,73,51,53,-53,-51,-73,0,-73,0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dataset60);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(categoryAnchor67);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 100L);
        try {
            org.jfree.chart.axis.TickUnit tickUnit4 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        try {
            jFreeChart14.addSubtitle(128, (org.jfree.chart.title.Title) textTitle20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets10.createOutsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getHeightRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean33 = barRenderer31.isSeriesVisibleInLegend(1);
        boolean boolean34 = barRenderer31.getBaseCreateEntities();
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray41, numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray52);
        java.lang.Number number54 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset53);
        org.jfree.data.Range range55 = barRenderer31.findRangeBounds(categoryDataset53);
        org.jfree.data.Range range58 = org.jfree.data.Range.expand(range55, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = rectangleConstraint29.toRangeWidth(range55);
        org.jfree.data.Range range61 = org.jfree.data.Range.shift(range55, (double) 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(rectangleConstraint59);
        org.junit.Assert.assertNotNull(range61);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        java.util.List list60 = legendItemBlockContainer59.getBlocks();
        java.lang.String str61 = legendItemBlockContainer59.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        double double34 = rectangleInsets30.calculateBottomInset((double) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.lang.Comparable comparable34 = legendItem33.getSeriesKey();
        org.jfree.data.general.Dataset dataset35 = legendItem33.getDataset();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(comparable34);
        org.junit.Assert.assertNull(dataset35);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean6 = textAnchor3.equals((java.lang.Object) textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean9 = categoryLabelPosition7.equals((java.lang.Object) rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        boolean boolean34 = legendItem33.isLineVisible();
        boolean boolean35 = legendItem33.isShapeFilled();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("100", "ItemLabelAnchor.INSIDE10");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "CategoryLabelWidthType.RANGE");
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) (byte) 1, 0.0f, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        java.lang.Comparable comparable3 = null;
        keyedObjects2D0.removeColumn(comparable3);
        int int6 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) "DatasetRenderingOrder.FORWARD");
        int int8 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.util.List list11 = categoryPlot0.getAnnotations();
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        categoryAxis2.setCategoryMargin(0.0d);
        double double8 = categoryAxis2.getLowerMargin();
        java.awt.Font font9 = categoryAxis2.getLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean13 = barRenderer11.isSeriesVisibleInLegend(1);
        boolean boolean14 = barRenderer11.getBaseCreateEntities();
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        barRenderer11.setBaseFillPaint((java.awt.Paint) color15);
        double double17 = barRenderer11.getItemLabelAnchorOffset();
        java.awt.Stroke stroke19 = barRenderer11.lookupSeriesStroke((int) (byte) 1);
        categoryPlot10.setDomainGridlineStroke(stroke19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot10.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean28 = barRenderer26.isSeriesVisibleInLegend(1);
        boolean boolean29 = barRenderer26.getBaseCreateEntities();
        java.awt.Color color30 = java.awt.Color.LIGHT_GRAY;
        barRenderer26.setBaseFillPaint((java.awt.Paint) color30);
        double double32 = barRenderer26.getItemLabelAnchorOffset();
        java.awt.Stroke stroke34 = barRenderer26.lookupSeriesStroke((int) (byte) 1);
        categoryPlot25.setDomainGridlineStroke(stroke34);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("hi!", font24, (org.jfree.chart.plot.Plot) categoryPlot25, false);
        categoryPlot25.setBackgroundAlpha(0.0f);
        int int40 = categoryPlot25.getDomainAxisCount();
        categoryPlot10.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        java.awt.Image image42 = categoryPlot10.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("GradientPaintTransformType.HORIZONTAL", font9, (org.jfree.chart.plot.Plot) categoryPlot10, true);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = categoryPlot10.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(image42);
        org.junit.Assert.assertNull(legendItemCollection45);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        barRenderer6.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color15);
        boolean boolean17 = chartEntity5.equals((java.lang.Object) color15);
        int int18 = color15.getTransparency();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        java.awt.Image image16 = jFreeChart15.getBackgroundImage();
        jFreeChart15.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart15.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo21);
        java.awt.Stroke stroke23 = jFreeChart15.getBorderStroke();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 10, jFreeChart15);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean30 = barRenderer28.isSeriesVisibleInLegend(1);
        boolean boolean31 = barRenderer28.getBaseCreateEntities();
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        barRenderer28.setBaseFillPaint((java.awt.Paint) color32);
        double double34 = barRenderer28.getItemLabelAnchorOffset();
        java.awt.Stroke stroke36 = barRenderer28.lookupSeriesStroke((int) (byte) 1);
        categoryPlot27.setDomainGridlineStroke(stroke36);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("hi!", font26, (org.jfree.chart.plot.Plot) categoryPlot27, false);
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray46, numberArray51, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray57);
        java.lang.Number number59 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset58);
        boolean boolean60 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset58);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = categoryPlot27.getRendererForDataset(categoryDataset58);
        try {
            jFreeChart15.setTextAntiAlias((java.lang.Object) categoryPlot27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.CategoryPlot@5acd3e74 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + (-1.0d) + "'", number59.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(categoryItemRenderer61);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        boolean boolean45 = legendItemEntity40.equals((java.lang.Object) legendItemEntity44);
        legendItemEntity44.setURLText("LGPL");
        legendItemEntity44.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean50 = legendTitle36.equals((java.lang.Object) legendItemEntity44);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle36.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle36.setHorizontalAlignment(horizontalAlignment52);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean57 = barRenderer55.isSeriesVisibleInLegend(1);
        boolean boolean58 = barRenderer55.getBaseCreateEntities();
        java.awt.Color color59 = java.awt.Color.LIGHT_GRAY;
        barRenderer55.setBaseFillPaint((java.awt.Paint) color59);
        double double61 = barRenderer55.getItemLabelAnchorOffset();
        java.awt.Stroke stroke63 = barRenderer55.lookupSeriesStroke((int) (byte) 1);
        categoryPlot54.setDomainGridlineStroke(stroke63);
        boolean boolean65 = categoryPlot54.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        categoryPlot54.zoomDomainAxes(0.0d, plotRenderingInfo67, point2D68);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder70 = categoryPlot54.getDatasetRenderingOrder();
        float float71 = categoryPlot54.getBackgroundAlpha();
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot54.setOutlinePaint((java.awt.Paint) color72);
        legendTitle36.setBackgroundPaint((java.awt.Paint) color72);
        int int75 = color72.getGreen();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder70);
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 1.0f + "'", float71 == 1.0f);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 128 + "'", int75 == 128);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.OUTSIDE4", graphics2D1, (double) 1L, (float) (-1), 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setCategoryMargin((double) 10L);
        java.lang.String str10 = categoryAxis1.getLabelToolTip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray23, numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray34);
        java.lang.Number number36 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset35);
        org.jfree.data.Range range37 = barRenderer13.findRangeBounds(categoryDataset35);
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color39);
        java.awt.Color color41 = java.awt.Color.getColor("CategoryLabelWidthType.RANGE", color39);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (short) 1, (java.awt.Paint) color39);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (-1.0d) + "'", number36.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        java.lang.String str8 = categoryTick7.toString();
        double double9 = categoryTick7.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor10 = categoryTick7.getTextAnchor();
        double double11 = categoryTick7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle14.setBackgroundPaint((java.awt.Paint) color15);
        java.lang.Object obj17 = textTitle14.clone();
        java.awt.Paint paint18 = textTitle14.getBackgroundPaint();
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) paint18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        barRenderer20.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint32 = barRenderer20.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape36, "hi!", "");
        java.awt.Shape shape40 = chartEntity39.getArea();
        barRenderer20.setSeriesShape(0, shape40, true);
        boolean boolean43 = categoryAxis1.equals((java.lang.Object) barRenderer20);
        java.awt.Font font45 = barRenderer20.getSeriesItemLabelFont((int) ' ');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(font45);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        double double7 = categoryAxis1.getLowerMargin();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        categoryAxis1.setLabelURL("100");
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        java.awt.Stroke stroke7 = categoryAxis2.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis2.getTickLabelFont();
        java.awt.Color color9 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("RectangleAnchor.BOTTOM_LEFT", font8, (java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D11 = null;
        java.lang.Comparable comparable14 = null;
        org.jfree.chart.text.TextBlock textBlock15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        org.jfree.chart.axis.CategoryTick categoryTick21 = new org.jfree.chart.axis.CategoryTick(comparable14, textBlock15, textBlockAnchor16, textAnchor18, 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor22 = categoryTick21.getTextAnchor();
        try {
            textFragment10.draw(graphics2D11, (float) ' ', (float) 128, textAnchor22, (float) 500, 0.0f, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getFixedLegendItems();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer19.isSeriesVisibleInLegend(1);
        boolean boolean22 = barRenderer19.getBaseCreateEntities();
        java.awt.Color color23 = java.awt.Color.LIGHT_GRAY;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color23);
        double double25 = barRenderer19.getItemLabelAnchorOffset();
        java.awt.Stroke stroke27 = barRenderer19.lookupSeriesStroke((int) (byte) 1);
        categoryPlot18.setDomainGridlineStroke(stroke27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", font17, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        java.awt.Image image31 = jFreeChart30.getBackgroundImage();
        jFreeChart30.setBackgroundImageAlignment(0);
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart30.createBufferedImage(1, (int) '4');
        categoryPlot2.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot2.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(bufferedImage36);
        org.junit.Assert.assertNull(axisSpace38);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = barRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean17 = textAnchor14.equals((java.lang.Object) textBlockAnchor16);
        try {
            textBlock9.draw(graphics2D10, (float) 0, 0.5f, textBlockAnchor16, (-1.0f), 2.0f, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        barRenderer18.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color27);
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = jFreeChart14.getCategoryPlot();
        categoryPlot30.clearDomainAxes();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(categoryPlot30);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets6);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Paint paint6 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        barRenderer0.setBaseCreateEntities(false);
        boolean boolean11 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 1, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, 0.0d);
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        org.junit.Assert.assertNull(range5);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str2 = projectInfo1.getLicenceName();
//        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo1.getOptionalLibraries();
//        java.lang.String str4 = projectInfo1.toString();
//        projectInfo1.setLicenceText("RectangleAnchor.BOTTOM_LEFT");
//        boolean boolean7 = blockBorder0.equals((java.lang.Object) projectInfo1);
//        projectInfo1.setVersion("RectangleAnchor.BOTTOM");
//        org.junit.Assert.assertNotNull(blockBorder0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LGPL" + "'", str2.equals("LGPL"));
//        org.junit.Assert.assertNotNull(libraryArray3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT" + "'", str4.equals("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("GradientPaintTransformType.HORIZONTAL", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Paint paint37 = legendTitle36.getItemPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) 0L, paint5);
        valueMarker1.setLabelPaint(paint5);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint26 = barRenderer20.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean30 = barRenderer28.isSeriesVisibleInLegend(1);
        boolean boolean31 = barRenderer28.getBaseCreateEntities();
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        barRenderer28.setBaseFillPaint((java.awt.Paint) color32);
        double double34 = barRenderer28.getItemLabelAnchorOffset();
        java.awt.Stroke stroke36 = barRenderer28.lookupSeriesStroke((int) (byte) 1);
        barRenderer20.setSeriesOutlineStroke(255, stroke36, true);
        barRenderer16.setSeriesStroke(0, stroke36);
        java.awt.Paint paint40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape14, stroke36, paint40);
        java.lang.Comparable comparable42 = legendItem41.getSeriesKey();
        legendItem41.setSeriesKey((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke45 = legendItem41.getOutlineStroke();
        valueMarker1.setStroke(stroke45);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType47);
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity52 = new org.jfree.chart.entity.LegendItemEntity(shape51);
        boolean boolean53 = valueMarker1.equals((java.lang.Object) legendItemEntity52);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(comparable42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(lengthAdjustmentType47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot2.getRangeAxis();
        categoryPlot2.clearDomainMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection39 = categoryPlot2.getFixedLegendItems();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNull(legendItemCollection39);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0f, "", textAnchor2, textAnchor3, (double) 0.95f);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot0.getDataset((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot5.getRangeAxisLocation((int) (short) 10);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot5.setDomainGridlineStroke(stroke18);
        valueMarker1.setOutlineStroke(stroke18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        barRenderer0.setSeriesVisible((int) (short) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer9.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Paint paint19 = barRenderer13.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        double double27 = barRenderer21.getItemLabelAnchorOffset();
        java.awt.Stroke stroke29 = barRenderer21.lookupSeriesStroke((int) (byte) 1);
        barRenderer13.setSeriesOutlineStroke(255, stroke29, true);
        barRenderer9.setSeriesStroke(0, stroke29);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean36 = barRenderer34.isSeriesVisibleInLegend(1);
        boolean boolean37 = barRenderer34.getBaseCreateEntities();
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        barRenderer34.setBaseFillPaint((java.awt.Paint) color38);
        barRenderer34.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer34.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean49 = barRenderer47.isSeriesVisibleInLegend(1);
        boolean boolean50 = barRenderer47.getBaseCreateEntities();
        java.awt.Paint paint52 = barRenderer47.getSeriesPaint((int) '#');
        java.awt.Paint paint54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer47.setSeriesOutlinePaint(0, paint54);
        barRenderer34.setBaseOutlinePaint(paint54, false);
        barRenderer9.setSeriesFillPaint((int) (byte) 100, paint54);
        java.awt.Stroke stroke60 = barRenderer9.lookupSeriesStroke(100);
        barRenderer0.setBaseOutlineStroke(stroke60, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(paint52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleAnchor.BOTTOM_LEFT", "RectangleAnchor.TOP", "", "hi!", "RectangleAnchor.BOTTOM_LEFT");
        basicProjectInfo5.setName("NOID");
        java.lang.String str8 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        try {
            org.jfree.data.general.PieDataset pieDataset38 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset33, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraintType.RANGE" + "'", str1.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("hi!", font6, (org.jfree.chart.plot.Plot) categoryPlot7, false);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray26, numberArray31, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray37);
        java.lang.Number number39 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset38);
        boolean boolean40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot7.getRendererForDataset(categoryDataset38);
        org.jfree.chart.plot.Plot plot42 = categoryPlot7.getRootPlot();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) plot42);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (-1.0d) + "'", number39.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(categoryItemRenderer41);
        org.junit.Assert.assertNotNull(plot42);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        boolean boolean8 = legendItemEntity3.equals((java.lang.Object) legendItemEntity7);
        java.lang.Object obj9 = legendItemEntity3.clone();
        java.lang.String str10 = legendItemEntity3.getURLText();
        org.jfree.data.general.Dataset dataset11 = legendItemEntity3.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(dataset11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        boolean boolean16 = categoryPlot5.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot5.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19);
        java.awt.Font font21 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer23.isSeriesVisibleInLegend(1);
        boolean boolean26 = barRenderer23.getBaseCreateEntities();
        java.awt.Color color27 = java.awt.Color.LIGHT_GRAY;
        barRenderer23.setBaseFillPaint((java.awt.Paint) color27);
        java.awt.Paint paint29 = barRenderer23.getBaseItemLabelPaint();
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("CategoryLabelWidthType.RANGE", font21, paint29);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean33 = barRenderer31.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        boolean boolean35 = barRenderer31.removeAnnotation(categoryAnnotation34);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = barRenderer31.getLegendItems();
        java.awt.Paint paint39 = barRenderer31.getItemOutlinePaint(0, 255);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement45 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment41, verticalAlignment42, (double) 255, (double) (short) -1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis48.setTickLabelPaint((java.lang.Comparable) 0L, paint50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis48.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("", font21, paint39, rectangleEdge40, horizontalAlignment41, verticalAlignment46, rectangleInsets52);
        textBlock0.setLineAlignment(horizontalAlignment41);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(verticalAlignment46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color3);
        double double5 = textTitle2.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textTitle2.getTextAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot7.getInsets();
        textTitle2.setMargin(rectangleInsets8);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        double double6 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = barRenderer0.getSeriesItemLabelGenerator((int) (short) -1);
        java.awt.Paint paint9 = barRenderer0.getBaseOutlinePaint();
        barRenderer0.setSeriesItemLabelsVisible(128, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer58 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) 0.2d);
        java.lang.String str59 = legendItemBlockContainer58.getID();
        legendItemBlockContainer58.setToolTipText("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertNull(str59);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setCategoryMargin((double) 10L);
        java.lang.String str10 = categoryAxis1.getLabelToolTip();
        java.awt.Paint paint11 = categoryAxis1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        barRenderer6.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint18 = barRenderer6.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Paint paint21 = barRenderer6.getItemFillPaint((int) (byte) 1, 0);
        barRenderer0.setBaseItemLabelPaint(paint21);
        java.lang.Boolean boolean24 = barRenderer0.getSeriesCreateEntities((int) (short) 100);
        java.awt.Stroke stroke26 = barRenderer0.lookupSeriesStroke((int) (short) 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart14.createBufferedImage(1, (int) '4');
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity28 = new org.jfree.chart.entity.LegendItemEntity(shape27);
        boolean boolean29 = legendItemEntity24.equals((java.lang.Object) legendItemEntity28);
        legendItemEntity28.setURLText("LGPL");
        legendItemEntity28.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) 0L, paint37);
        categoryAxis35.setCategoryMargin(0.0d);
        categoryAxis35.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot42 = categoryAxis35.getPlot();
        java.lang.Object obj43 = categoryAxis35.clone();
        boolean boolean44 = legendItemEntity28.equals(obj43);
        boolean boolean45 = jFreeChart14.equals((java.lang.Object) legendItemEntity28);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(plot42);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        barRenderer4.setBaseFillPaint((java.awt.Paint) color8);
        double double10 = barRenderer4.getItemLabelAnchorOffset();
        java.awt.Stroke stroke12 = barRenderer4.lookupSeriesStroke((int) (byte) 1);
        categoryPlot3.setDomainGridlineStroke(stroke12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", font2, (org.jfree.chart.plot.Plot) categoryPlot3, false);
        java.awt.Image image16 = jFreeChart15.getBackgroundImage();
        jFreeChart15.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart15.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo21);
        java.awt.Stroke stroke23 = jFreeChart15.getBorderStroke();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 10, jFreeChart15);
        java.lang.String str25 = chartChangeEvent24.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(image16);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10]" + "'", str25.equals("org.jfree.chart.event.ChartChangeEvent[source=10]"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = barRenderer1.getBaseItemLabelPaint();
        boolean boolean10 = barRenderer1.isItemLabelVisible((int) 'a', (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean14 = barRenderer12.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        boolean boolean16 = barRenderer12.removeAnnotation(categoryAnnotation15);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        boolean boolean21 = itemLabelPosition19.equals((java.lang.Object) 0L);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition19, true);
        barRenderer1.setSeriesNegativeItemLabelPosition(1, itemLabelPosition19);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = itemLabelPosition19.getItemLabelAnchor();
        boolean boolean26 = axisSpace0.equals((java.lang.Object) itemLabelAnchor25);
        double double27 = axisSpace0.getLeft();
        axisSpace0.setTop(4.0d);
        axisSpace0.setRight((double) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("CategoryLabelWidthType.RANGE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        java.awt.Paint paint7 = barRenderer0.getItemLabelPaint(0, (int) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle8.getSources();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        boolean boolean45 = legendItemEntity40.equals((java.lang.Object) legendItemEntity44);
        legendItemEntity44.setURLText("LGPL");
        legendItemEntity44.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean50 = legendTitle36.equals((java.lang.Object) legendItemEntity44);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray51 = legendTitle36.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = null;
        legendTitle36.setLegendItemGraphicLocation(rectangleAnchor52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray51);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Paint paint4 = barRenderer0.lookupSeriesOutlinePaint(15);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray59);
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset60);
        org.jfree.data.Range range62 = barRenderer38.findRangeBounds(categoryDataset60);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint(range62, (double) 100.0f);
        org.jfree.chart.util.Size2D size2D65 = legendTitle36.arrange(graphics2D37, rectangleConstraint64);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean68 = barRenderer66.isSeriesVisibleInLegend(1);
        boolean boolean69 = barRenderer66.getBaseCreateEntities();
        java.awt.Color color70 = java.awt.Color.LIGHT_GRAY;
        barRenderer66.setBaseFillPaint((java.awt.Paint) color70);
        barRenderer66.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator76 = barRenderer66.getLegendItemURLGenerator();
        java.awt.Paint paint78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        barRenderer66.setSeriesFillPaint((int) (short) 10, paint78, false);
        boolean boolean81 = size2D65.equals((java.lang.Object) barRenderer66);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition83 = barRenderer66.getSeriesPositiveItemLabelPosition(10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1.0d) + "'", number61.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition83);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean27 = barRenderer25.isSeriesVisibleInLegend(1);
        boolean boolean28 = barRenderer25.getBaseCreateEntities();
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        barRenderer25.setBaseFillPaint((java.awt.Paint) color29);
        barRenderer25.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer25.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.awt.Paint paint43 = barRenderer38.getSeriesPaint((int) '#');
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer38.setSeriesOutlinePaint(0, paint45);
        barRenderer25.setBaseOutlinePaint(paint45, false);
        barRenderer0.setSeriesFillPaint((int) (byte) 100, paint45);
        java.awt.Stroke stroke51 = barRenderer0.lookupSeriesStroke(100);
        barRenderer0.setBase((double) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "CategoryLabelWidthType.RANGE");
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, 101.0d, (float) 2, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        boolean boolean9 = itemLabelPosition7.equals((java.lang.Object) 0L);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer7.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer7.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = barRenderer20.getSeriesPaint((int) '#');
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer20.setSeriesOutlinePaint(0, paint27);
        barRenderer7.setBaseOutlinePaint(paint27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer7.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition32, true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setSeriesShape((int) (short) 1, shape38);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation40 = null;
        boolean boolean41 = barRenderer0.removeAnnotation(categoryAnnotation40);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        int int17 = categoryPlot2.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot2.setRangeAxisLocation(axisLocation18);
        int int20 = categoryPlot2.getDomainAxisCount();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.TOP", graphics2D1, (double) 0.5f, 0.95f, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke4 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        boolean boolean18 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot7.getDatasetRenderingOrder();
        float float24 = categoryPlot7.getBackgroundAlpha();
        boolean boolean25 = standardCategorySeriesLabelGenerator5.equals((java.lang.Object) categoryPlot7);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity(shape32);
        boolean boolean34 = legendItemEntity29.equals((java.lang.Object) legendItemEntity33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray56);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset57);
        org.jfree.data.Range range59 = barRenderer35.findRangeBounds(categoryDataset57);
        java.lang.Boolean boolean61 = barRenderer35.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement62 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis64.setTickLabelPaint((java.lang.Comparable) 0L, paint66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = categoryAxis64.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement69 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean70 = rectangleInsets68.equals((java.lang.Object) columnArrangement69);
        org.jfree.chart.title.LegendTitle legendTitle71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer35, (org.jfree.chart.block.Arrangement) flowArrangement62, (org.jfree.chart.block.Arrangement) columnArrangement69);
        java.awt.Shape shape74 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity75 = new org.jfree.chart.entity.LegendItemEntity(shape74);
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity79 = new org.jfree.chart.entity.LegendItemEntity(shape78);
        boolean boolean80 = legendItemEntity75.equals((java.lang.Object) legendItemEntity79);
        legendItemEntity79.setURLText("LGPL");
        legendItemEntity79.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean85 = legendTitle71.equals((java.lang.Object) legendItemEntity79);
        org.jfree.chart.util.RectangleInsets rectangleInsets86 = legendTitle71.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment87 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle71.setHorizontalAlignment(horizontalAlignment87);
        boolean boolean89 = legendItemEntity29.equals((java.lang.Object) legendTitle71);
        boolean boolean90 = standardCategorySeriesLabelGenerator5.equals((java.lang.Object) boolean89);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1.0d) + "'", number58.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNull(boolean61);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(rectangleInsets86);
        org.junit.Assert.assertNotNull(horizontalAlignment87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer23.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer27.isSeriesVisibleInLegend(1);
        boolean boolean30 = barRenderer27.getBaseCreateEntities();
        java.awt.Paint paint33 = barRenderer27.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        barRenderer35.setBaseFillPaint((java.awt.Paint) color39);
        double double41 = barRenderer35.getItemLabelAnchorOffset();
        java.awt.Stroke stroke43 = barRenderer35.lookupSeriesStroke((int) (byte) 1);
        barRenderer27.setSeriesOutlineStroke(255, stroke43, true);
        barRenderer23.setSeriesStroke(0, stroke43);
        java.awt.Font font47 = barRenderer23.getBaseItemLabelFont();
        barRenderer23.setAutoPopulateSeriesPaint(true);
        barRenderer23.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke52 = barRenderer23.getBaseStroke();
        jFreeChart14.setBorderStroke(stroke52);
        org.jfree.chart.plot.Plot plot54 = jFreeChart14.getPlot();
        jFreeChart14.clearSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(plot54);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = barRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str14 = textBlockAnchor13.toString();
        try {
            java.awt.Shape shape18 = textBlock9.calculateBounds(graphics2D10, 1.0f, (float) '#', textBlockAnchor13, 0.95f, (float) (byte) 1, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str14.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.lang.Boolean boolean7 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) 0L, paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getTickLabelInsets();
        java.awt.Stroke stroke15 = categoryAxis10.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) '4', stroke15, false);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(itemLabelPosition20);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) (byte) 100);
        axisSpace0.setRight((double) (byte) 100);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((-1.0d));
        axisState0.cursorRight((double) '4');
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean39 = barRenderer37.isSeriesVisibleInLegend(1);
        boolean boolean40 = barRenderer37.getBaseCreateEntities();
        java.awt.Color color41 = java.awt.Color.LIGHT_GRAY;
        barRenderer37.setBaseFillPaint((java.awt.Paint) color41);
        double double43 = barRenderer37.getItemLabelAnchorOffset();
        java.awt.Stroke stroke45 = barRenderer37.lookupSeriesStroke((int) (byte) 1);
        categoryPlot36.setDomainGridlineStroke(stroke45);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font35, (org.jfree.chart.plot.Plot) categoryPlot36, false);
        categoryPlot36.setBackgroundAlpha(0.0f);
        int int51 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation52);
        categoryPlot15.setRangeAxisLocation(255, axisLocation52, true);
        boolean boolean56 = categoryPlot15.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle7.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean12 = barRenderer10.isSeriesVisibleInLegend(1);
        boolean boolean13 = barRenderer10.getBaseCreateEntities();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        barRenderer10.setBaseFillPaint((java.awt.Paint) color14);
        double double16 = barRenderer10.getItemLabelAnchorOffset();
        java.awt.Stroke stroke18 = barRenderer10.lookupSeriesStroke((int) (byte) 1);
        categoryPlot9.setDomainGridlineStroke(stroke18);
        boolean boolean20 = categoryPlot9.isRangeGridlinesVisible();
        java.awt.Color color21 = java.awt.Color.RED;
        categoryPlot9.setRangeCrosshairPaint((java.awt.Paint) color21);
        categoryPlot9.setRangeCrosshairValue(1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot9.getRendererForDataset(categoryDataset25);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = barRenderer0.initialise(graphics2D6, rectangle2D8, categoryPlot9, 255, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(categoryItemRenderer26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint29.toFixedWidth((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        double double24 = barRenderer0.getLowerClip();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        boolean boolean45 = legendItemEntity40.equals((java.lang.Object) legendItemEntity44);
        legendItemEntity44.setURLText("LGPL");
        legendItemEntity44.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean50 = legendTitle36.equals((java.lang.Object) legendItemEntity44);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray51 = legendTitle36.getSources();
        boolean boolean52 = legendTitle36.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color2 = java.awt.Color.getColor("TextBlockAnchor.BOTTOM_LEFT", 2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelWidthType.RANGE");
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color3);
        java.lang.Object obj5 = textTitle2.clone();
        java.awt.Paint paint6 = textTitle2.getBackgroundPaint();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM", font8);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        textTitle9.setPaint(paint10);
        textTitle2.setPaint(paint10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        java.lang.Comparable comparable1 = null;
        org.jfree.chart.text.TextBlock textBlock2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.axis.CategoryTick categoryTick8 = new org.jfree.chart.axis.CategoryTick(comparable1, textBlock2, textBlockAnchor3, textAnchor5, 0.0d);
        java.lang.String str9 = categoryTick8.toString();
        boolean boolean10 = itemLabelAnchor0.equals((java.lang.Object) categoryTick8);
        java.lang.Object obj11 = categoryTick8.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        boolean boolean26 = shapeList0.equals((java.lang.Object) range25);
        java.awt.Shape shape28 = shapeList0.getShape(10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(shape28);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        barRenderer0.setSeriesVisible(15, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator28, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color1 = java.awt.Color.getColor("NOID");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis1.setTickMarksVisible(true);
        java.awt.Font font13 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 255);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = barRenderer0.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Paint paint15 = barRenderer0.getItemFillPaint((int) (byte) 1, 0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor17);
        double double19 = itemLabelPosition18.getAngle();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition18);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor21 = itemLabelPosition18.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor21);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = null;
        barRenderer15.setLegendItemURLGenerator(categorySeriesLabelGenerator24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        org.jfree.data.general.Dataset dataset60 = legendItemBlockContainer59.getDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis63.setTickLabelPaint((java.lang.Comparable) 0L, paint65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryAxis63.getTickLabelInsets();
        categoryPlot61.setAxisOffset(rectangleInsets67);
        double double70 = rectangleInsets67.trimHeight((double) (byte) -1);
        double double72 = rectangleInsets67.calculateLeftOutset(100.0d);
        legendItemBlockContainer59.setPadding(rectangleInsets67);
        java.awt.Graphics2D graphics2D74 = null;
        org.jfree.chart.text.TextLine textLine76 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment77 = textLine76.getLastTextFragment();
        java.awt.Font font79 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle80 = new org.jfree.chart.title.TextTitle("", font79);
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle80.setBackgroundPaint((java.awt.Paint) color81);
        boolean boolean83 = textLine76.equals((java.lang.Object) textTitle80);
        java.awt.Graphics2D graphics2D84 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis86 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener87 = null;
        categoryAxis86.addChangeListener(axisChangeListener87);
        java.lang.String str89 = categoryAxis86.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor90 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle93 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D94 = textTitle93.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = null;
        double double96 = categoryAxis86.getCategoryJava2DCoordinate(categoryAnchor90, 8, (int) (byte) 1, rectangle2D94, rectangleEdge95);
        textTitle80.draw(graphics2D84, rectangle2D94);
        try {
            legendItemBlockContainer59.draw(graphics2D74, rectangle2D94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dataset60);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-5.0d) + "'", double70 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 4.0d + "'", double72 == 4.0d);
        org.junit.Assert.assertNotNull(textFragment77);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertNotNull(categoryAnchor90);
        org.junit.Assert.assertNotNull(rectangle2D94);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        float float17 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot2.getFixedDomainAxisSpace();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot2.getParent();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean27 = barRenderer25.isSeriesVisibleInLegend(1);
        boolean boolean28 = barRenderer25.getBaseCreateEntities();
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        barRenderer25.setBaseFillPaint((java.awt.Paint) color29);
        double double31 = barRenderer25.getItemLabelAnchorOffset();
        java.awt.Stroke stroke33 = barRenderer25.lookupSeriesStroke((int) (byte) 1);
        categoryPlot24.setDomainGridlineStroke(stroke33);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("hi!", font23, (org.jfree.chart.plot.Plot) categoryPlot24, false);
        java.awt.Image image37 = jFreeChart36.getBackgroundImage();
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("", font39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.lang.Object obj43 = null;
        java.lang.Object obj44 = textTitle40.draw(graphics2D41, rectangle2D42, obj43);
        textTitle40.setToolTipText("hi!");
        jFreeChart36.removeSubtitle((org.jfree.chart.title.Title) textTitle40);
        boolean boolean48 = jFreeChart36.isNotify();
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean51 = barRenderer49.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean55 = barRenderer53.isSeriesVisibleInLegend(1);
        boolean boolean56 = barRenderer53.getBaseCreateEntities();
        java.awt.Paint paint59 = barRenderer53.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer61 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean63 = barRenderer61.isSeriesVisibleInLegend(1);
        boolean boolean64 = barRenderer61.getBaseCreateEntities();
        java.awt.Color color65 = java.awt.Color.LIGHT_GRAY;
        barRenderer61.setBaseFillPaint((java.awt.Paint) color65);
        double double67 = barRenderer61.getItemLabelAnchorOffset();
        java.awt.Stroke stroke69 = barRenderer61.lookupSeriesStroke((int) (byte) 1);
        barRenderer53.setSeriesOutlineStroke(255, stroke69, true);
        barRenderer49.setSeriesStroke(0, stroke69);
        java.awt.Font font73 = barRenderer49.getBaseItemLabelFont();
        barRenderer49.setAutoPopulateSeriesPaint(true);
        barRenderer49.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke78 = barRenderer49.getBaseStroke();
        jFreeChart36.setBorderStroke(stroke78);
        categoryPlot2.setRangeGridlineStroke(stroke78);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(image37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.0d + "'", double67 == 2.0d);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setBaseShape(shape12, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.lang.Object obj16 = legendItemEntity15.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 100);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("", font13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle14.setBackgroundPaint((java.awt.Paint) color15);
        java.lang.Object obj17 = textTitle14.clone();
        java.awt.Paint paint18 = textTitle14.getBackgroundPaint();
        boolean boolean19 = categoryAxis1.equals((java.lang.Object) paint18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        barRenderer20.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint32 = barRenderer20.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape36, "hi!", "");
        java.awt.Shape shape40 = chartEntity39.getArea();
        barRenderer20.setSeriesShape(0, shape40, true);
        boolean boolean43 = categoryAxis1.equals((java.lang.Object) barRenderer20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean46 = barRenderer44.isSeriesVisibleInLegend(1);
        boolean boolean47 = barRenderer44.getBaseCreateEntities();
        java.awt.Color color48 = java.awt.Color.LIGHT_GRAY;
        barRenderer44.setBaseFillPaint((java.awt.Paint) color48);
        barRenderer44.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer44.setBaseFillPaint((java.awt.Paint) color53);
        java.awt.Color color55 = color53.brighter();
        org.jfree.chart.block.BlockBorder blockBorder56 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color55);
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color55);
        java.awt.Font font58 = categoryAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(font58);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot0.setRangeCrosshairValue(1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot0.getRendererForDataset(categoryDataset16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean20 = barRenderer18.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer18.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        barRenderer18.setSeriesURLGenerator(0, categoryURLGenerator25);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        categoryAxis1.addChangeListener(axisChangeListener2);
        java.lang.String str4 = categoryAxis1.getLabelToolTip();
        double double5 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Stroke stroke10 = barRenderer2.lookupSeriesStroke((int) (byte) 1);
        categoryPlot1.setDomainGridlineStroke(stroke10);
        boolean boolean12 = categoryPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot1.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Font font17 = categoryPlot1.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font17);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = org.jfree.chart.axis.CategoryAnchor.START;
        boolean boolean20 = labelBlock18.equals((java.lang.Object) categoryAnchor19);
        java.lang.Comparable comparable21 = null;
        org.jfree.chart.text.TextBlock textBlock22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25);
        org.jfree.chart.axis.CategoryTick categoryTick28 = new org.jfree.chart.axis.CategoryTick(comparable21, textBlock22, textBlockAnchor23, textAnchor25, 0.0d);
        java.lang.String str29 = categoryTick28.toString();
        double double30 = categoryTick28.getAngle();
        boolean boolean31 = labelBlock18.equals((java.lang.Object) categoryTick28);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean35 = barRenderer33.isSeriesVisibleInLegend(1);
        boolean boolean36 = barRenderer33.getBaseCreateEntities();
        java.awt.Color color37 = java.awt.Color.LIGHT_GRAY;
        barRenderer33.setBaseFillPaint((java.awt.Paint) color37);
        double double39 = barRenderer33.getItemLabelAnchorOffset();
        java.awt.Stroke stroke41 = barRenderer33.lookupSeriesStroke((int) (byte) 1);
        categoryPlot32.setDomainGridlineStroke(stroke41);
        boolean boolean43 = categoryPlot32.isRangeGridlinesVisible();
        java.awt.Color color44 = java.awt.Color.RED;
        categoryPlot32.setRangeCrosshairPaint((java.awt.Paint) color44);
        categoryPlot32.setRangeCrosshairValue(1.0d);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot32.getRendererForDataset(categoryDataset48);
        categoryPlot32.setAnchorValue((-1.0d), true);
        boolean boolean53 = categoryTick28.equals((java.lang.Object) true);
        org.jfree.chart.text.TextBlock textBlock54 = categoryTick28.getLabel();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(textBlock54);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot2.zoomRangeAxes((double) 0, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot2.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            categoryPlot2.setDomainAxisLocation((-1), axisLocation43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis1.getLabelInsets();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean16 = barRenderer14.isSeriesVisibleInLegend(1);
        boolean boolean17 = barRenderer14.getBaseCreateEntities();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        barRenderer14.setBaseFillPaint((java.awt.Paint) color18);
        double double20 = barRenderer14.getItemLabelAnchorOffset();
        java.awt.Stroke stroke22 = barRenderer14.lookupSeriesStroke((int) (byte) 1);
        categoryPlot13.setDomainGridlineStroke(stroke22);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("hi!", font12, (org.jfree.chart.plot.Plot) categoryPlot13, false);
        java.awt.Image image26 = jFreeChart25.getBackgroundImage();
        jFreeChart25.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        java.awt.image.BufferedImage bufferedImage32 = jFreeChart25.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo31);
        java.awt.Stroke stroke33 = jFreeChart25.getBorderStroke();
        categoryAxis1.setTickMarkStroke(stroke33);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertNotNull(bufferedImage32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Class<?> wildcardClass2 = paint1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("poly", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = barRenderer0.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Paint paint15 = barRenderer0.getItemFillPaint((int) (byte) 1, 0);
        barRenderer0.setMinimumBarLength(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.lang.Comparable comparable34 = legendItem33.getSeriesKey();
        legendItem33.setSeriesKey((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke37 = legendItem33.getOutlineStroke();
        java.lang.String str38 = legendItem33.getURLText();
        java.awt.Shape shape39 = legendItem33.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(comparable34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.BOTTOM" + "'", str38.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setBaseShape(shape12, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer22.isSeriesVisibleInLegend(1);
        boolean boolean25 = barRenderer22.getBaseCreateEntities();
        java.awt.Paint paint28 = barRenderer22.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        double double36 = barRenderer30.getItemLabelAnchorOffset();
        java.awt.Stroke stroke38 = barRenderer30.lookupSeriesStroke((int) (byte) 1);
        barRenderer22.setSeriesOutlineStroke(255, stroke38, true);
        barRenderer18.setSeriesStroke(0, stroke38);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis43.setTickLabelPaint((java.lang.Comparable) 0L, paint45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryAxis43.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType48 = rectangleInsets47.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke38, rectangleInsets47);
        java.awt.Paint paint50 = lineBorder49.getPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic51 = new org.jfree.chart.title.LegendGraphic(shape12, paint50);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(unitType48);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer7.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer7.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = barRenderer20.getSeriesPaint((int) '#');
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer20.setSeriesOutlinePaint(0, paint27);
        barRenderer7.setBaseOutlinePaint(paint27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer7.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition32, true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setSeriesShape((int) (short) 1, shape38);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity42 = new org.jfree.chart.entity.TickLabelEntity(shape38, "NOID", "NOID");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        try {
            barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) -1, itemLabelPosition28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color9);
        java.awt.Color color11 = color9.brighter();
        float[] floatArray13 = new float[] { 100L };
        try {
            float[] floatArray14 = color11.getRGBComponents(floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("RectangleAnchor.TOP");
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset18);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1.0d) + "'", number19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 100.0d + "'", number20.equals(100.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.plot.Plot plot8 = categoryAxis1.getPlot();
        java.lang.Object obj9 = categoryAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1);
        double double12 = numberTickUnit11.getSize();
        java.awt.Font font13 = categoryAxis1.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        int int14 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D1, "DatasetRenderingOrder.FORWARD", "RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(rectangle2D1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) (short) -1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer37.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor42 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor42, textAnchor43);
        boolean boolean46 = itemLabelPosition44.equals((java.lang.Object) 0L);
        barRenderer37.setNegativeItemLabelPositionFallback(itemLabelPosition44);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition44);
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean51 = barRenderer49.isSeriesVisibleInLegend(1);
        boolean boolean52 = barRenderer49.getBaseCreateEntities();
        java.awt.Color color53 = java.awt.Color.LIGHT_GRAY;
        barRenderer49.setBaseFillPaint((java.awt.Paint) color53);
        barRenderer49.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint61 = barRenderer49.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Stroke stroke62 = barRenderer49.getBaseOutlineStroke();
        boolean boolean63 = itemLabelPosition44.equals((java.lang.Object) stroke62);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        categoryPlot11.setDomainGridlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        java.awt.Image image24 = jFreeChart23.getBackgroundImage();
        boolean boolean25 = barRenderer0.hasListener((java.util.EventListener) jFreeChart23);
        jFreeChart23.clearSubtitles();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis4.setTickLabelPaint((java.lang.Comparable) 0L, paint6);
        categoryAxis4.setCategoryMargin(0.0d);
        categoryAxis4.clearCategoryLabelToolTips();
        categoryAxis4.setVisible(false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str14 = itemLabelAnchor13.toString();
        boolean boolean15 = categoryAxis4.equals((java.lang.Object) itemLabelAnchor13);
        java.awt.Paint paint16 = categoryAxis4.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis18.setTickLabelPaint((java.lang.Comparable) 0L, paint20);
        categoryAxis18.setCategoryMargin(0.0d);
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setVisible(false);
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) 100);
        org.jfree.chart.text.TextLine textLine32 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment33 = textLine32.getLastTextFragment();
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("", font35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle36.setBackgroundPaint((java.awt.Paint) color37);
        boolean boolean39 = textLine32.equals((java.lang.Object) textTitle36);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener43 = null;
        categoryAxis42.addChangeListener(axisChangeListener43);
        java.lang.String str45 = categoryAxis42.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor46 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle49.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = categoryAxis42.getCategoryJava2DCoordinate(categoryAnchor46, 8, (int) (byte) 1, rectangle2D50, rectangleEdge51);
        textTitle36.draw(graphics2D40, rectangle2D50);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        double double55 = categoryAxis18.getCategoryEnd((int) (short) -1, 8, rectangle2D50, rectangleEdge54);
        axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis4, rectangleEdge54);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str14.equals("ItemLabelAnchor.INSIDE10"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(textFragment33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(categoryAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        boolean boolean45 = legendItemEntity40.equals((java.lang.Object) legendItemEntity44);
        legendItemEntity44.setURLText("LGPL");
        legendItemEntity44.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean50 = legendTitle36.equals((java.lang.Object) legendItemEntity44);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray51 = legendTitle36.getSources();
        legendTitle36.setNotify(true);
        org.jfree.chart.block.BlockContainer blockContainer54 = legendTitle36.getItemContainer();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray51);
        org.junit.Assert.assertNotNull(blockContainer54);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot5.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        double double27 = barRenderer21.getItemLabelAnchorOffset();
        java.awt.Stroke stroke29 = barRenderer21.lookupSeriesStroke((int) (byte) 1);
        categoryPlot20.setDomainGridlineStroke(stroke29);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", font19, (org.jfree.chart.plot.Plot) categoryPlot20, false);
        categoryPlot20.setBackgroundAlpha(0.0f);
        int int35 = categoryPlot20.getDomainAxisCount();
        categoryPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        barRenderer0.setPlot(categoryPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot5.setDomainAxisLocation(128, axisLocation39, true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Paint paint10 = barRenderer0.getBaseOutlinePaint();
        boolean boolean12 = barRenderer0.isSeriesItemLabelsVisible(2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setBaseShape(shape12, true);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity15 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape12, "", "RectangleAnchor.TOP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        java.lang.Comparable comparable3 = null;
        keyedObjects2D0.removeColumn(comparable3);
        int int6 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) "DatasetRenderingOrder.FORWARD");
        java.lang.Object obj7 = keyedObjects2D0.clone();
        try {
            java.lang.Comparable comparable9 = keyedObjects2D0.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0.5f, (double) (-12566464));
        size2D2.setWidth((double) (short) 1);
        size2D2.height = '#';
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getInsets();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (-1.0f), plotRenderingInfo3, point2D4);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        categoryPlot2.setBackgroundAlpha(0.0f);
        float float17 = categoryPlot2.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace18 = categoryPlot2.getFixedDomainAxisSpace();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean24 = barRenderer22.isSeriesVisibleInLegend(1);
        boolean boolean25 = barRenderer22.getBaseCreateEntities();
        java.awt.Color color26 = java.awt.Color.LIGHT_GRAY;
        barRenderer22.setBaseFillPaint((java.awt.Paint) color26);
        double double28 = barRenderer22.getItemLabelAnchorOffset();
        java.awt.Stroke stroke30 = barRenderer22.lookupSeriesStroke((int) (byte) 1);
        categoryPlot21.setDomainGridlineStroke(stroke30);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("hi!", font20, (org.jfree.chart.plot.Plot) categoryPlot21, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean36 = barRenderer34.isSeriesVisibleInLegend(1);
        boolean boolean37 = barRenderer34.getBaseCreateEntities();
        java.awt.Paint paint40 = barRenderer34.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer34, true);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        categoryPlot21.drawBackgroundImage(graphics2D43, rectangle2D44);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = categoryPlot21.getDrawingSupplier();
        categoryPlot2.setDrawingSupplier(drawingSupplier46);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNull(axisSpace18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(drawingSupplier46);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        java.lang.Object obj2 = tickUnits0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getFixedDimension();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis1.getCategoryLabelPositions();
        double double4 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot2.getRangeAxis();
        categoryPlot2.clearDomainMarkers();
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean44 = barRenderer42.isSeriesVisibleInLegend(1);
        boolean boolean45 = barRenderer42.getBaseCreateEntities();
        java.awt.Color color46 = java.awt.Color.LIGHT_GRAY;
        barRenderer42.setBaseFillPaint((java.awt.Paint) color46);
        double double48 = barRenderer42.getItemLabelAnchorOffset();
        java.awt.Stroke stroke50 = barRenderer42.lookupSeriesStroke((int) (byte) 1);
        categoryPlot41.setDomainGridlineStroke(stroke50);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("hi!", font40, (org.jfree.chart.plot.Plot) categoryPlot41, false);
        categoryPlot41.setBackgroundAlpha(0.0f);
        int int56 = categoryPlot41.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot41.setRangeAxisLocation(axisLocation57);
        categoryPlot2.setRangeAxisLocation(axisLocation57, false);
        boolean boolean61 = categoryPlot2.isRangeZoomable();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        java.awt.Paint paint18 = jFreeChart14.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(2.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = jFreeChart14.getCategoryPlot();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(categoryPlot18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) 100L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) (byte) 100);
        axisSpace0.setRight((double) 1L);
        double double5 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        java.lang.String str8 = categoryTick7.toString();
        double double9 = categoryTick7.getAngle();
        double double10 = categoryTick7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.setAntiAlias(false);
        java.awt.RenderingHints renderingHints26 = jFreeChart14.getRenderingHints();
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("", font28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.lang.Object obj32 = null;
        java.lang.Object obj33 = textTitle29.draw(graphics2D30, rectangle2D31, obj32);
        jFreeChart14.addSubtitle((org.jfree.chart.title.Title) textTitle29);
        org.jfree.chart.event.ChartChangeListener chartChangeListener35 = null;
        try {
            jFreeChart14.addChangeListener(chartChangeListener35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(renderingHints26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getHeightRange();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean33 = barRenderer31.isSeriesVisibleInLegend(1);
        boolean boolean34 = barRenderer31.getBaseCreateEntities();
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray41, numberArray46, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray52);
        java.lang.Number number54 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset53);
        org.jfree.data.Range range55 = barRenderer31.findRangeBounds(categoryDataset53);
        java.lang.Boolean boolean57 = barRenderer31.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement58 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis60.setTickLabelPaint((java.lang.Comparable) 0L, paint62);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryAxis60.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement65 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean66 = rectangleInsets64.equals((java.lang.Object) columnArrangement65);
        org.jfree.chart.title.LegendTitle legendTitle67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer31, (org.jfree.chart.block.Arrangement) flowArrangement58, (org.jfree.chart.block.Arrangement) columnArrangement65);
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer69 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean71 = barRenderer69.isSeriesVisibleInLegend(1);
        boolean boolean72 = barRenderer69.getBaseCreateEntities();
        java.lang.Number[] numberArray79 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray84 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray89 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray90 = new java.lang.Number[][] { numberArray79, numberArray84, numberArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray90);
        java.lang.Number number92 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset91);
        org.jfree.data.Range range93 = barRenderer69.findRangeBounds(categoryDataset91);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint95 = new org.jfree.chart.block.RectangleConstraint(range93, (double) 100.0f);
        org.jfree.chart.util.Size2D size2D96 = legendTitle67.arrange(graphics2D68, rectangleConstraint95);
        try {
            org.jfree.chart.util.Size2D size2D97 = rectangleConstraint29.calculateConstrainedSize(size2D96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertTrue("'" + number54 + "' != '" + (-1.0d) + "'", number54.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNull(boolean57);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray84);
        org.junit.Assert.assertNotNull(numberArray89);
        org.junit.Assert.assertNotNull(numberArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + (-1.0d) + "'", number92.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range93);
        org.junit.Assert.assertNotNull(size2D96);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryPlot0.getInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (short) 0);
        double double5 = rectangleInsets1.calculateRightOutset((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color1, stroke2);
        java.lang.Object obj4 = valueMarker3.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        boolean boolean13 = categoryPlot2.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16);
        java.awt.Font font18 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font18);
        java.awt.Paint paint20 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleAnchor.BOTTOM", font18, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        boolean boolean32 = categoryPlot15.isOutlineVisible();
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean39 = barRenderer37.isSeriesVisibleInLegend(1);
        boolean boolean40 = barRenderer37.getBaseCreateEntities();
        java.awt.Color color41 = java.awt.Color.LIGHT_GRAY;
        barRenderer37.setBaseFillPaint((java.awt.Paint) color41);
        double double43 = barRenderer37.getItemLabelAnchorOffset();
        java.awt.Stroke stroke45 = barRenderer37.lookupSeriesStroke((int) (byte) 1);
        categoryPlot36.setDomainGridlineStroke(stroke45);
        org.jfree.chart.JFreeChart jFreeChart48 = new org.jfree.chart.JFreeChart("hi!", font35, (org.jfree.chart.plot.Plot) categoryPlot36, false);
        categoryPlot36.setBackgroundAlpha(0.0f);
        int int51 = categoryPlot36.getDomainAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot36.setRangeAxisLocation(axisLocation52);
        categoryPlot15.setRangeAxisLocation(255, axisLocation52, true);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor56 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        axisSpace57.setRight((double) (byte) 100);
        categoryPlot15.setFixedDomainAxisSpace(axisSpace57);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(categoryAnchor56);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker2.setLabelFont(font3);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer10.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, false);
        boolean boolean15 = textTitle7.equals((java.lang.Object) false);
        java.awt.Color color16 = java.awt.Color.darkGray;
        int int17 = color16.getRGB();
        textTitle7.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("VerticalAlignment.BOTTOM", font3, (java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-12566464) + "'", int17 == (-12566464));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        boolean boolean13 = categoryPlot2.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16);
        java.awt.Font font18 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer19.isSeriesVisibleInLegend(1);
        boolean boolean22 = barRenderer19.getBaseCreateEntities();
        java.awt.Color color23 = java.awt.Color.LIGHT_GRAY;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color23);
        barRenderer19.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color28);
        java.awt.Color color30 = color28.brighter();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", font18, (java.awt.Paint) color30, 0.0f);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean38 = barRenderer36.isSeriesVisibleInLegend(1);
        boolean boolean39 = barRenderer36.getBaseCreateEntities();
        java.awt.Color color40 = java.awt.Color.LIGHT_GRAY;
        barRenderer36.setBaseFillPaint((java.awt.Paint) color40);
        double double42 = barRenderer36.getItemLabelAnchorOffset();
        java.awt.Stroke stroke44 = barRenderer36.lookupSeriesStroke((int) (byte) 1);
        categoryPlot35.setDomainGridlineStroke(stroke44);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) categoryPlot35, false);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot35.getFixedLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean51 = barRenderer49.isSeriesVisibleInLegend(1);
        boolean boolean52 = barRenderer49.getBaseCreateEntities();
        java.awt.Color color53 = java.awt.Color.LIGHT_GRAY;
        barRenderer49.setBaseFillPaint((java.awt.Paint) color53);
        java.awt.Paint paint55 = barRenderer49.getBaseItemLabelPaint();
        categoryPlot35.setDomainGridlinePaint(paint55);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM", font18, paint55);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean60 = barRenderer58.isSeriesVisibleInLegend(1);
        boolean boolean61 = barRenderer58.getBaseCreateEntities();
        java.awt.Paint paint64 = barRenderer58.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        labelBlock57.setPaint(paint64);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(legendItemCollection48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor4, 0.0d);
        java.lang.String str8 = categoryTick7.toString();
        java.lang.Object obj9 = categoryTick7.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setBaseFillPaint((java.awt.Paint) color9);
        double double11 = barRenderer5.getItemLabelAnchorOffset();
        java.awt.Stroke stroke13 = barRenderer5.lookupSeriesStroke((int) (byte) 1);
        categoryPlot4.setDomainGridlineStroke(stroke13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", font3, (org.jfree.chart.plot.Plot) categoryPlot4, false);
        java.awt.Image image17 = jFreeChart16.getBackgroundImage();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] { numberArray28, numberArray33, numberArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset40);
        org.jfree.data.Range range42 = barRenderer18.findRangeBounds(categoryDataset40);
        java.lang.Boolean boolean44 = barRenderer18.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis47.setTickLabelPaint((java.lang.Comparable) 0L, paint49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryAxis47.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement52 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean53 = rectangleInsets51.equals((java.lang.Object) columnArrangement52);
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer18, (org.jfree.chart.block.Arrangement) flowArrangement45, (org.jfree.chart.block.Arrangement) columnArrangement52);
        jFreeChart16.addLegend(legendTitle54);
        java.lang.Object obj56 = null;
        boolean boolean57 = legendTitle54.equals(obj56);
        flowArrangement0.add(block1, (java.lang.Object) boolean57);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (-1.0d) + "'", number41.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(boolean44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Color color9 = java.awt.Color.CYAN;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 0, (java.awt.Paint) color9);
        java.awt.Paint paint11 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle5.setBackgroundPaint((java.awt.Paint) color6);
        boolean boolean8 = textLine1.equals((java.lang.Object) textTitle5);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis11.addChangeListener(axisChangeListener12);
        java.lang.String str14 = categoryAxis11.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis11.getCategoryJava2DCoordinate(categoryAnchor15, 8, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        textTitle5.draw(graphics2D9, rectangle2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.TOP;
        double double24 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge23);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        categoryPlot2.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = categoryPlot2.getDrawingSupplier();
        categoryPlot2.clearAnnotations();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        double double36 = barRenderer30.getItemLabelAnchorOffset();
        java.awt.Font font37 = barRenderer30.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("ItemLabelAnchor.INSIDE10", font37);
        categoryPlot2.setNoDataMessageFont(font37);
        boolean boolean40 = categoryPlot2.getDrawSharedDomainAxis();
        categoryPlot2.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        java.awt.Font font24 = barRenderer0.getBaseItemLabelFont();
        barRenderer0.setAutoPopulateSeriesPaint(true);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        java.awt.Stroke stroke29 = barRenderer0.getBaseStroke();
        java.awt.Paint paint32 = barRenderer0.getItemOutlinePaint((int) (short) 10, 128);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        chartEntity5.setURLText("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset28);
        org.jfree.data.Range range30 = barRenderer6.findRangeBounds(categoryDataset28);
        java.awt.Color color32 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color32);
        java.awt.Paint paint34 = barRenderer6.getBaseItemLabelPaint();
        textTitle3.setPaint(paint34);
        java.lang.Object obj36 = null;
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = textTitle3.getTextAlignment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1.0d) + "'", number29.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray32);
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset33);
        boolean boolean35 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot2.getRendererForDataset(categoryDataset33);
        java.awt.Paint paint37 = categoryPlot2.getRangeCrosshairPaint();
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean43 = barRenderer41.isSeriesVisibleInLegend(1);
        boolean boolean44 = barRenderer41.getBaseCreateEntities();
        java.awt.Color color45 = java.awt.Color.LIGHT_GRAY;
        barRenderer41.setBaseFillPaint((java.awt.Paint) color45);
        double double47 = barRenderer41.getItemLabelAnchorOffset();
        java.awt.Stroke stroke49 = barRenderer41.lookupSeriesStroke((int) (byte) 1);
        categoryPlot40.setDomainGridlineStroke(stroke49);
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("hi!", font39, (org.jfree.chart.plot.Plot) categoryPlot40, false);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = categoryPlot40.getFixedLegendItems();
        java.awt.Font font54 = categoryPlot40.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean58 = barRenderer56.isSeriesVisibleInLegend(1);
        boolean boolean59 = barRenderer56.getBaseCreateEntities();
        java.awt.Paint paint61 = barRenderer56.getSeriesPaint((int) '#');
        java.awt.Paint paint63 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer56.setSeriesOutlinePaint(0, paint63);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = barRenderer56.getBaseURLGenerator();
        categoryPlot40.setRenderer((int) (short) 10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer56);
        java.lang.String str67 = categoryPlot40.getNoDataMessage();
        categoryPlot40.clearRangeMarkers(255);
        org.jfree.chart.renderer.category.BarRenderer barRenderer70 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean72 = barRenderer70.isSeriesVisibleInLegend(1);
        boolean boolean73 = barRenderer70.getBaseCreateEntities();
        java.awt.Color color74 = java.awt.Color.LIGHT_GRAY;
        barRenderer70.setBaseFillPaint((java.awt.Paint) color74);
        double double76 = barRenderer70.getItemLabelAnchorOffset();
        java.awt.Font font77 = barRenderer70.getBaseItemLabelFont();
        java.awt.Paint paint79 = barRenderer70.lookupSeriesOutlinePaint((int) (short) 1);
        categoryPlot40.setRangeCrosshairPaint(paint79);
        categoryPlot2.setDomainGridlinePaint(paint79);
        org.jfree.chart.axis.AxisLocation axisLocation82 = categoryPlot2.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryItemRenderer36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(legendItemCollection53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNull(categoryURLGenerator65);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 2.0d + "'", double76 == 2.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(axisLocation82);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray3 = null;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape10, "hi!", "");
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (-12566464), (double) 0.5f);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape23, "hi!", "");
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, (double) (-12566464), (double) 0.5f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        barRenderer30.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint42 = barRenderer30.getItemLabelPaint(1, (int) (short) 0);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity(shape46, "hi!", "");
        java.awt.Shape shape50 = chartEntity49.getArea();
        barRenderer30.setSeriesShape(0, shape50, true);
        java.awt.Shape[] shapeArray53 = new java.awt.Shape[] { shape7, shape16, shape19, shape29, shape50 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier54 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray53);
        java.awt.Stroke stroke55 = defaultDrawingSupplier54.getNextOutlineStroke();
        try {
            java.awt.Stroke stroke56 = defaultDrawingSupplier54.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shapeArray53);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer0.setSeriesOutlinePaint(0, paint7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        categoryPlot11.setDomainGridlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        java.awt.Image image24 = jFreeChart23.getBackgroundImage();
        boolean boolean25 = barRenderer0.hasListener((java.util.EventListener) jFreeChart23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.String str30 = rectangleEdge29.toString();
        java.lang.String str31 = rectangleEdge29.toString();
        double double32 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D28, rectangleEdge29);
        java.awt.geom.Point2D point2D33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        try {
            jFreeChart23.draw(graphics2D26, rectangle2D28, point2D33, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleEdge.BOTTOM" + "'", str30.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleEdge.BOTTOM" + "'", str31.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        double double3 = categoryItemRendererState2.getBarWidth();
        double double4 = categoryItemRendererState2.getBarWidth();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = categoryItemRendererState2.getInfo();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        java.lang.String str14 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer19.isSeriesVisibleInLegend(1);
        boolean boolean22 = barRenderer19.getBaseCreateEntities();
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] { numberArray29, numberArray34, numberArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray40);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset41);
        org.jfree.data.Range range43 = barRenderer19.findRangeBounds(categoryDataset41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot0.getRendererForDataset(categoryDataset41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (-1.0d) + "'", number42.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNull(categoryItemRenderer44);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot0.getDatasetRenderingOrder();
        float float17 = categoryPlot0.getBackgroundAlpha();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (byte) -1);
        int int6 = keyedObjects2D0.getRowIndex((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        int int8 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!", "");
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, (float) '4');
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "hi!", "");
        java.awt.Shape shape12 = chartEntity11.getArea();
        chartEntity5.setArea(shape12);
        java.lang.String str14 = chartEntity5.getURLText();
        java.awt.Shape shape15 = chartEntity5.getArea();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity40 = new org.jfree.chart.entity.LegendItemEntity(shape39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        boolean boolean45 = legendItemEntity40.equals((java.lang.Object) legendItemEntity44);
        legendItemEntity44.setURLText("LGPL");
        legendItemEntity44.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean50 = legendTitle36.equals((java.lang.Object) legendItemEntity44);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = legendTitle36.getPadding();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        legendTitle36.setHorizontalAlignment(horizontalAlignment52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = legendTitle36.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        legendTitle36.setLegendItemGraphicPadding(rectangleInsets55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = legendTitle36.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        try {
            org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset22, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.lang.Comparable comparable34 = legendItem33.getSeriesKey();
        legendItem33.setSeriesKey((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke37 = legendItem33.getOutlineStroke();
        legendItem33.setSeriesKey((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint40 = legendItem33.getLinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(comparable34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        java.lang.Object obj22 = jFreeChart14.clone();
        jFreeChart14.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean27 = barRenderer25.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer25.getPositiveItemLabelPosition((int) (short) 1, (int) ' ');
        java.awt.Paint paint31 = barRenderer25.getBaseOutlinePaint();
        jFreeChart14.setBackgroundPaint(paint31);
        jFreeChart14.setBackgroundImageAlpha((float) (short) 10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer4.isSeriesVisibleInLegend(1);
        boolean boolean7 = barRenderer4.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer4.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        barRenderer4.setSeriesOutlineStroke(255, stroke20, true);
        barRenderer0.setSeriesStroke(0, stroke20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean27 = barRenderer25.isSeriesVisibleInLegend(1);
        boolean boolean28 = barRenderer25.getBaseCreateEntities();
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        barRenderer25.setBaseFillPaint((java.awt.Paint) color29);
        barRenderer25.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer25.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean40 = barRenderer38.isSeriesVisibleInLegend(1);
        boolean boolean41 = barRenderer38.getBaseCreateEntities();
        java.awt.Paint paint43 = barRenderer38.getSeriesPaint((int) '#');
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer38.setSeriesOutlinePaint(0, paint45);
        barRenderer25.setBaseOutlinePaint(paint45, false);
        barRenderer0.setSeriesFillPaint((int) (byte) 100, paint45);
        java.awt.Paint paint52 = barRenderer0.getItemFillPaint((int) '#', 500);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Stroke stroke16 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        categoryPlot19.setDomainGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        barRenderer35.setBaseFillPaint((java.awt.Paint) color39);
        double double41 = barRenderer35.getItemLabelAnchorOffset();
        java.awt.Stroke stroke43 = barRenderer35.lookupSeriesStroke((int) (byte) 1);
        categoryPlot34.setDomainGridlineStroke(stroke43);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("hi!", font33, (org.jfree.chart.plot.Plot) categoryPlot34, false);
        categoryPlot34.setBackgroundAlpha(0.0f);
        int int49 = categoryPlot34.getDomainAxisCount();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot34);
        boolean boolean51 = categoryPlot34.isOutlineVisible();
        barRenderer0.setPlot(categoryPlot34);
        java.lang.Boolean boolean54 = barRenderer0.getSeriesItemLabelsVisible(0);
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity58 = new org.jfree.chart.entity.LegendItemEntity(shape57);
        barRenderer0.setBaseShape(shape57);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNull(boolean54);
        org.junit.Assert.assertNotNull(shape57);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        java.lang.Boolean boolean26 = barRenderer0.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement27 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis29.setTickLabelPaint((java.lang.Comparable) 0L, paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean35 = rectangleInsets33.equals((java.lang.Object) columnArrangement34);
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, (org.jfree.chart.block.Arrangement) flowArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement34);
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset55);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.data.general.Dataset) categoryDataset55, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset55);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis62.setTickLabelPaint((java.lang.Comparable) 0L, paint64);
        categoryAxis62.setCategoryMargin(0.0d);
        categoryAxis62.clearCategoryLabelToolTips();
        java.lang.String str70 = categoryAxis62.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis62.setTickMarksVisible(true);
        java.lang.String str74 = categoryAxis62.getCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer76 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean78 = barRenderer76.isSeriesVisibleInLegend(1);
        java.awt.Paint paint79 = barRenderer76.getBaseOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis62, valueAxis75, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer76);
        java.awt.Paint paint81 = categoryPlot80.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(paint81);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean26 = barRenderer24.isSeriesVisibleInLegend(1);
        boolean boolean27 = barRenderer24.getBaseCreateEntities();
        java.lang.Number[] numberArray34 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray34, numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray45);
        java.lang.Number number47 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset46);
        org.jfree.data.Range range48 = barRenderer24.findRangeBounds(categoryDataset46);
        java.lang.Boolean boolean50 = barRenderer24.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis53.setTickLabelPaint((java.lang.Comparable) 0L, paint55);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = categoryAxis53.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement58 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean59 = rectangleInsets57.equals((java.lang.Object) columnArrangement58);
        org.jfree.chart.title.LegendTitle legendTitle60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer24, (org.jfree.chart.block.Arrangement) flowArrangement51, (org.jfree.chart.block.Arrangement) columnArrangement58);
        java.lang.Number[] numberArray67 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray72 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray77 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray78 = new java.lang.Number[][] { numberArray67, numberArray72, numberArray77 };
        org.jfree.data.category.CategoryDataset categoryDataset79 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray78);
        java.lang.Number number80 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset79);
        boolean boolean81 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset79);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer83 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement58, (org.jfree.data.general.Dataset) categoryDataset79, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        java.util.List list84 = legendItemBlockContainer83.getBlocks();
        jFreeChart14.setSubtitles(list84);
        org.jfree.chart.title.TextTitle textTitle86 = jFreeChart14.getTitle();
        org.jfree.chart.axis.CategoryAxis categoryAxis88 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener89 = null;
        categoryAxis88.addChangeListener(axisChangeListener89);
        java.lang.String str91 = categoryAxis88.getLabelToolTip();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor92 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.title.TextTitle textTitle95 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D96 = textTitle95.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge97 = null;
        double double98 = categoryAxis88.getCategoryJava2DCoordinate(categoryAnchor92, 8, (int) (byte) 1, rectangle2D96, rectangleEdge97);
        textTitle86.setBounds(rectangle2D96);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (-1.0d) + "'", number47.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNull(boolean50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(numberArray77);
        org.junit.Assert.assertNotNull(numberArray78);
        org.junit.Assert.assertNotNull(categoryDataset79);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + (-1.0d) + "'", number80.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(list84);
        org.junit.Assert.assertNotNull(textTitle86);
        org.junit.Assert.assertNull(str91);
        org.junit.Assert.assertNotNull(categoryAnchor92);
        org.junit.Assert.assertNotNull(rectangle2D96);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 0.0d + "'", double98 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        categoryPlot12.setDomainGridlineStroke(stroke21);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", font11, (org.jfree.chart.plot.Plot) categoryPlot12, false);
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray31, numberArray36, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray42);
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset43);
        boolean boolean45 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot12.getRendererForDataset(categoryDataset43);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        int int48 = categoryPlot12.getRangeAxisIndex(valueAxis47);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker51.setLabelFont(font52);
        java.awt.Paint paint54 = valueMarker51.getOutlinePaint();
        java.awt.Font font56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean60 = barRenderer58.isSeriesVisibleInLegend(1);
        boolean boolean61 = barRenderer58.getBaseCreateEntities();
        java.awt.Color color62 = java.awt.Color.LIGHT_GRAY;
        barRenderer58.setBaseFillPaint((java.awt.Paint) color62);
        double double64 = barRenderer58.getItemLabelAnchorOffset();
        java.awt.Stroke stroke66 = barRenderer58.lookupSeriesStroke((int) (byte) 1);
        categoryPlot57.setDomainGridlineStroke(stroke66);
        org.jfree.chart.JFreeChart jFreeChart69 = new org.jfree.chart.JFreeChart("hi!", font56, (org.jfree.chart.plot.Plot) categoryPlot57, false);
        java.lang.Number[] numberArray76 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray81 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray86 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray87 = new java.lang.Number[][] { numberArray76, numberArray81, numberArray86 };
        org.jfree.data.category.CategoryDataset categoryDataset88 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray87);
        java.lang.Number number89 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset88);
        boolean boolean90 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset88);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer91 = categoryPlot57.getRendererForDataset(categoryDataset88);
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection94 = categoryPlot57.getRangeMarkers((int) (byte) 100, layer93);
        categoryPlot12.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker51, layer93);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        categoryPlot12.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-1.0d) + "'", number44.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray86);
        org.junit.Assert.assertNotNull(numberArray87);
        org.junit.Assert.assertNotNull(categoryDataset88);
        org.junit.Assert.assertTrue("'" + number89 + "' != '" + (-1.0d) + "'", number89.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(categoryItemRenderer91);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNull(collection94);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition2.getRotationAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        boolean boolean4 = barRenderer0.removeAnnotation(categoryAnnotation3);
        java.awt.Paint paint7 = barRenderer0.getItemLabelPaint(0, (int) (byte) 10);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = barRenderer0.getToolTipGenerator(10, (int) (byte) 0);
        barRenderer0.setMinimumBarLength((double) (short) 1);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer0.getItemVisible((int) ' ', (int) (short) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean9 = barRenderer7.isSeriesVisibleInLegend(1);
        boolean boolean10 = barRenderer7.getBaseCreateEntities();
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        barRenderer7.setBaseFillPaint((java.awt.Paint) color11);
        barRenderer7.setSeriesVisibleInLegend((int) '#', (java.lang.Boolean) true, true);
        barRenderer7.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Paint paint25 = barRenderer20.getSeriesPaint((int) '#');
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer20.setSeriesOutlinePaint(0, paint27);
        barRenderer7.setBaseOutlinePaint(paint27, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer7.getSeriesPositiveItemLabelPosition(0);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 0, itemLabelPosition32, true);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        barRenderer0.setSeriesShape((int) (short) 1, shape38);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation40 = null;
        boolean boolean41 = barRenderer0.removeAnnotation(categoryAnnotation40);
        barRenderer0.setMinimumBarLength(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.lang.String str3 = textFragment2.getText();
        java.lang.String str4 = textFragment2.getText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean10 = textAnchor7.equals((java.lang.Object) textBlockAnchor9);
        try {
            float float11 = textFragment2.calculateBaselineOffset(graphics2D5, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getWidthRange();
        org.jfree.data.Range range31 = rectangleConstraint29.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint29.toFixedWidth(3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        java.awt.Paint paint8 = barRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", font1, paint8);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        categoryPlot12.setDomainGridlineStroke(stroke21);
        boolean boolean23 = categoryPlot12.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot12.zoomDomainAxes(0.0d, plotRenderingInfo25, point2D26);
        java.awt.Font font28 = categoryPlot12.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font28);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean32 = barRenderer30.isSeriesVisibleInLegend(1);
        boolean boolean33 = barRenderer30.getBaseCreateEntities();
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        barRenderer30.setBaseFillPaint((java.awt.Paint) color34);
        java.awt.Paint paint36 = barRenderer30.getBaseItemLabelPaint();
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("CategoryLabelWidthType.RANGE", font28, paint36);
        textBlock9.addLine(textLine37);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textBlock9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.title.TextTitle textTitle15 = null;
        jFreeChart14.setTitle(textTitle15);
        java.awt.Paint paint17 = jFreeChart14.getBackgroundPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer18.isSeriesVisibleInLegend(1);
        boolean boolean21 = barRenderer18.getBaseCreateEntities();
        java.awt.Color color22 = java.awt.Color.LIGHT_GRAY;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color22);
        barRenderer18.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer18.setBaseFillPaint((java.awt.Paint) color27);
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = jFreeChart14.getCategoryPlot();
        java.awt.Image image31 = jFreeChart14.getBackgroundImage();
        org.jfree.chart.event.ChartChangeListener chartChangeListener32 = null;
        try {
            jFreeChart14.addChangeListener(chartChangeListener32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(categoryPlot30);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        double double7 = categoryAxis1.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) 0L, paint11);
        categoryAxis9.setCategoryMargin(0.0d);
        categoryAxis9.clearCategoryLabelToolTips();
        java.lang.String str17 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        double double27 = barRenderer21.getItemLabelAnchorOffset();
        java.awt.Stroke stroke29 = barRenderer21.lookupSeriesStroke((int) (byte) 1);
        categoryPlot20.setDomainGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot20.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) 0L, paint37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryAxis35.getTickLabelInsets();
        categoryPlot33.setAxisOffset(rectangleInsets39);
        double double42 = rectangleInsets39.trimHeight((double) (byte) -1);
        categoryPlot20.setInsets(rectangleInsets39, false);
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) categoryPlot20);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        categoryAxis1.setAxisLineVisible(true);
        boolean boolean49 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-5.0d) + "'", double42 == (-5.0d));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.awt.Paint paint11 = barRenderer5.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean15 = barRenderer13.isSeriesVisibleInLegend(1);
        boolean boolean16 = barRenderer13.getBaseCreateEntities();
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        barRenderer13.setBaseFillPaint((java.awt.Paint) color17);
        double double19 = barRenderer13.getItemLabelAnchorOffset();
        java.awt.Stroke stroke21 = barRenderer13.lookupSeriesStroke((int) (byte) 1);
        barRenderer5.setSeriesOutlineStroke(255, stroke21, true);
        barRenderer1.setSeriesStroke(0, stroke21);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis26.setTickLabelPaint((java.lang.Comparable) 0L, paint28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke21, rectangleInsets30);
        java.awt.Paint paint33 = lineBorder32.getPaint();
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState();
        boolean boolean35 = lineBorder32.equals((java.lang.Object) axisState34);
        java.util.List list36 = axisState34.getTicks();
        double double37 = axisState34.getCursor();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        boolean boolean4 = itemLabelPosition2.equals((java.lang.Object) 0L);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition2.getTextAnchor();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        barRenderer6.setSeriesItemLabelsVisible(255, (java.lang.Boolean) false, true);
        java.awt.Paint paint19 = barRenderer6.getBaseOutlinePaint();
        boolean boolean20 = itemLabelPosition2.equals((java.lang.Object) paint19);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelWidthType.RANGE");
        categoryAxis1.setMaximumCategoryLabelLines(128);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        textTitle2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer5.isSeriesVisibleInLegend(1);
        boolean boolean8 = barRenderer5.getBaseCreateEntities();
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset27);
        org.jfree.data.Range range29 = barRenderer5.findRangeBounds(categoryDataset27);
        java.awt.Color color31 = java.awt.Color.LIGHT_GRAY;
        barRenderer5.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color31);
        java.awt.Paint paint33 = barRenderer5.getBaseItemLabelPaint();
        textTitle2.setPaint(paint33);
        textTitle2.setText("");
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.lang.Object obj40 = textTitle2.draw(graphics2D37, rectangle2D38, (java.lang.Object) paint39);
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle2.getBounds();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis2.setTickLabelPaint((java.lang.Comparable) 0L, paint4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets6);
        double double9 = rectangleInsets6.trimHeight((double) (byte) -1);
        double double11 = rectangleInsets6.calculateLeftOutset(100.0d);
        double double13 = rectangleInsets6.calculateTopOutset(0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-5.0d) + "'", double9 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        double double7 = categoryAxis1.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis9.setTickLabelPaint((java.lang.Comparable) 0L, paint11);
        categoryAxis9.setCategoryMargin(0.0d);
        categoryAxis9.clearCategoryLabelToolTips();
        java.lang.String str17 = categoryAxis9.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.awt.Color color25 = java.awt.Color.LIGHT_GRAY;
        barRenderer21.setBaseFillPaint((java.awt.Paint) color25);
        double double27 = barRenderer21.getItemLabelAnchorOffset();
        java.awt.Stroke stroke29 = barRenderer21.lookupSeriesStroke((int) (byte) 1);
        categoryPlot20.setDomainGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot20.getRangeAxisLocation((int) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis35.setTickLabelPaint((java.lang.Comparable) 0L, paint37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryAxis35.getTickLabelInsets();
        categoryPlot33.setAxisOffset(rectangleInsets39);
        double double42 = rectangleInsets39.trimHeight((double) (byte) -1);
        categoryPlot20.setInsets(rectangleInsets39, false);
        categoryAxis9.setPlot((org.jfree.chart.plot.Plot) categoryPlot20);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection48 = categoryPlot20.getRangeMarkers(layer47);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("hi!");
        boolean boolean51 = layer47.equals((java.lang.Object) textLine50);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.0d + "'", double27 == 2.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-5.0d) + "'", double42 == (-5.0d));
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNotNull(collection48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        java.awt.Stroke stroke22 = jFreeChart14.getBorderStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean25 = barRenderer23.isSeriesVisibleInLegend(1);
        boolean boolean26 = barRenderer23.getBaseCreateEntities();
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray38 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray33, numberArray38, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray44);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset45);
        org.jfree.data.Range range47 = barRenderer23.findRangeBounds(categoryDataset45);
        java.lang.Boolean boolean49 = barRenderer23.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis52.setTickLabelPaint((java.lang.Comparable) 0L, paint54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = categoryAxis52.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement57 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean58 = rectangleInsets56.equals((java.lang.Object) columnArrangement57);
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer23, (org.jfree.chart.block.Arrangement) flowArrangement50, (org.jfree.chart.block.Arrangement) columnArrangement57);
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity63 = new org.jfree.chart.entity.LegendItemEntity(shape62);
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity67 = new org.jfree.chart.entity.LegendItemEntity(shape66);
        boolean boolean68 = legendItemEntity63.equals((java.lang.Object) legendItemEntity67);
        legendItemEntity67.setURLText("LGPL");
        legendItemEntity67.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean73 = legendTitle59.equals((java.lang.Object) legendItemEntity67);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray74 = legendTitle59.getSources();
        jFreeChart14.addLegend(legendTitle59);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (-1.0d) + "'", number46.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(boolean49);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(legendItemSourceArray74);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        legendItem33.setSeriesIndex(10);
        java.lang.String str36 = legendItem33.getDescription();
        org.jfree.data.general.Dataset dataset37 = legendItem33.getDataset();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "LGPL" + "'", str36.equals("LGPL"));
        org.junit.Assert.assertNull(dataset37);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.0d, 4.0d, 0.0d, (double) (byte) 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray21 = new java.lang.Number[][] { numberArray10, numberArray15, numberArray20 };
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray21);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset22);
        org.jfree.data.Range range24 = barRenderer0.findRangeBounds(categoryDataset22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, (double) 100.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = rectangleConstraint26.getWidthConstraintType();
        java.lang.String str28 = lengthConstraintType27.toString();
        java.lang.String str29 = lengthConstraintType27.toString();
        java.lang.String str30 = lengthConstraintType27.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleConstraintType.RANGE" + "'", str28.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleConstraintType.RANGE" + "'", str29.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraintType.RANGE" + "'", str30.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean18 = barRenderer16.isSeriesVisibleInLegend(1);
        boolean boolean19 = barRenderer16.getBaseCreateEntities();
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        barRenderer16.setBaseFillPaint((java.awt.Paint) color20);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        java.awt.Stroke stroke24 = barRenderer16.lookupSeriesStroke((int) (byte) 1);
        categoryPlot15.setDomainGridlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("hi!", font14, (org.jfree.chart.plot.Plot) categoryPlot15, false);
        categoryPlot15.setBackgroundAlpha(0.0f);
        int int30 = categoryPlot15.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        java.awt.Image image32 = categoryPlot0.getBackgroundImage();
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray51 = new java.lang.Number[][] { numberArray40, numberArray45, numberArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray51);
        org.jfree.data.Range range53 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset52);
        categoryPlot0.setDataset((int) (byte) 1, categoryDataset52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(image32);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range53);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean6 = textAnchor3.equals((java.lang.Object) textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = categoryLabelPosition7.getWidthType();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font2);
        java.awt.Font font4 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(itemLabelPosition21);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        java.lang.Comparable comparable34 = legendItem33.getSeriesKey();
        legendItem33.setSeriesKey((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke37 = legendItem33.getOutlineStroke();
        java.lang.String str38 = legendItem33.getURLText();
        legendItem33.setSeriesKey((java.lang.Comparable) (short) 1);
        java.lang.String str41 = legendItem33.getDescription();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(comparable34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.BOTTOM" + "'", str38.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "LGPL" + "'", str41.equals("LGPL"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 100, (float) 255);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) (byte) 0, (float) (short) -1, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, 1.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range0, range28);
        org.jfree.data.Range range30 = rectangleConstraint29.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint29.toFixedWidth((double) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean3 = barRenderer1.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = barRenderer1.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = barRenderer1.getLegendItems();
        boolean boolean7 = horizontalAlignment0.equals((java.lang.Object) legendItemCollection6);
        try {
            org.jfree.chart.LegendItem legendItem9 = legendItemCollection6.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        java.util.List list11 = categoryPlot0.getAnnotations();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation14, false);
        double double17 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.lang.Object obj5 = null;
        java.lang.Object obj6 = textTitle2.draw(graphics2D3, rectangle2D4, obj5);
        textTitle2.setToolTipText("hi!");
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color16);
        double double18 = barRenderer12.getItemLabelAnchorOffset();
        java.awt.Stroke stroke20 = barRenderer12.lookupSeriesStroke((int) (byte) 1);
        categoryPlot11.setDomainGridlineStroke(stroke20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", font10, (org.jfree.chart.plot.Plot) categoryPlot11, false);
        org.jfree.chart.title.TextTitle textTitle24 = null;
        jFreeChart23.setTitle(textTitle24);
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        org.jfree.chart.block.BlockFrame blockFrame27 = textTitle2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(blockFrame27);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        boolean boolean13 = categoryPlot2.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16);
        java.awt.Font font18 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean21 = barRenderer19.isSeriesVisibleInLegend(1);
        boolean boolean22 = barRenderer19.getBaseCreateEntities();
        java.awt.Color color23 = java.awt.Color.LIGHT_GRAY;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color23);
        barRenderer19.setSeriesItemLabelsVisible((int) (short) 100, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer19.setBaseFillPaint((java.awt.Paint) color28);
        java.awt.Color color30 = color28.brighter();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("RectangleConstraintType.RANGE", font18, (java.awt.Paint) color30, 0.0f);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean38 = barRenderer36.isSeriesVisibleInLegend(1);
        boolean boolean39 = barRenderer36.getBaseCreateEntities();
        java.awt.Color color40 = java.awt.Color.LIGHT_GRAY;
        barRenderer36.setBaseFillPaint((java.awt.Paint) color40);
        double double42 = barRenderer36.getItemLabelAnchorOffset();
        java.awt.Stroke stroke44 = barRenderer36.lookupSeriesStroke((int) (byte) 1);
        categoryPlot35.setDomainGridlineStroke(stroke44);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("hi!", font34, (org.jfree.chart.plot.Plot) categoryPlot35, false);
        org.jfree.chart.LegendItemCollection legendItemCollection48 = categoryPlot35.getFixedLegendItems();
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean51 = barRenderer49.isSeriesVisibleInLegend(1);
        boolean boolean52 = barRenderer49.getBaseCreateEntities();
        java.awt.Color color53 = java.awt.Color.LIGHT_GRAY;
        barRenderer49.setBaseFillPaint((java.awt.Paint) color53);
        java.awt.Paint paint55 = barRenderer49.getBaseItemLabelPaint();
        categoryPlot35.setDomainGridlinePaint(paint55);
        org.jfree.chart.block.LabelBlock labelBlock57 = new org.jfree.chart.block.LabelBlock("JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM", font18, paint55);
        java.lang.Object obj58 = labelBlock57.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(legendItemCollection48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(obj58);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] { numberArray12, numberArray17, numberArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset24);
        org.jfree.data.Range range26 = barRenderer2.findRangeBounds(categoryDataset24);
        org.jfree.data.Range range29 = org.jfree.data.Range.expand(range26, (double) 1.0f, 1.0d);
        boolean boolean30 = categoryLabelWidthType0.equals((java.lang.Object) 1.0d);
        boolean boolean32 = categoryLabelWidthType0.equals((java.lang.Object) 4.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str1.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray18);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset19);
        double double21 = range20.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) 10L, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 101.0d + "'", double21 == 101.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint6 = barRenderer0.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        barRenderer0.setSeriesOutlineStroke(255, stroke16, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        categoryPlot19.setDomainGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean37 = barRenderer35.isSeriesVisibleInLegend(1);
        boolean boolean38 = barRenderer35.getBaseCreateEntities();
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        barRenderer35.setBaseFillPaint((java.awt.Paint) color39);
        double double41 = barRenderer35.getItemLabelAnchorOffset();
        java.awt.Stroke stroke43 = barRenderer35.lookupSeriesStroke((int) (byte) 1);
        categoryPlot34.setDomainGridlineStroke(stroke43);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("hi!", font33, (org.jfree.chart.plot.Plot) categoryPlot34, false);
        categoryPlot34.setBackgroundAlpha(0.0f);
        int int49 = categoryPlot34.getDomainAxisCount();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot34);
        boolean boolean51 = categoryPlot34.isOutlineVisible();
        barRenderer0.setPlot(categoryPlot34);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getFixedDimension();
        try {
            categoryPlot34.setDomainAxis((-1), categoryAxis55, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0L, paint3);
        categoryAxis1.setCategoryMargin(0.0d);
        categoryAxis1.clearCategoryLabelToolTips();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) true);
        categoryAxis1.setTickMarksVisible(true);
        categoryAxis1.setCategoryMargin(1.0d);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) ' ', "JFreeChart version 1.0.6.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleEdge.BOTTOM");
        categoryAxis1.setFixedDimension((double) (-1L));
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Number[] numberArray8 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray8, numberArray13, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray19);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset20);
        double double22 = range21.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) 10L, range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 500, range21);
        double double25 = range21.getLength();
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 101.0d + "'", double22 == 101.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 101.0d + "'", double25 == 101.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        barRenderer1.setBaseFillPaint((java.awt.Paint) color5);
        double double7 = barRenderer1.getItemLabelAnchorOffset();
        java.awt.Stroke stroke9 = barRenderer1.lookupSeriesStroke((int) (byte) 1);
        categoryPlot0.setDomainGridlineStroke(stroke9);
        boolean boolean11 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot0.getDatasetRenderingOrder();
        float float17 = categoryPlot0.getBackgroundAlpha();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color18);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str2 = projectInfo1.getLicenceName();
//        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo1.getOptionalLibraries();
//        java.lang.String str4 = projectInfo1.toString();
//        projectInfo1.setLicenceText("RectangleAnchor.BOTTOM_LEFT");
//        boolean boolean7 = blockBorder0.equals((java.lang.Object) projectInfo1);
//        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("");
//        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getLastTextFragment();
//        boolean boolean11 = blockBorder0.equals((java.lang.Object) textFragment10);
//        org.junit.Assert.assertNotNull(blockBorder0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LGPL" + "'", str2.equals("LGPL"));
//        org.junit.Assert.assertNotNull(libraryArray3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version RectangleAnchor.BOTTOM.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT" + "'", str4.equals("JFreeChart version RectangleAnchor.BOTTOM.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:None\nJFreeChart LICENCE TERMS:\nRectangleAnchor.BOTTOM_LEFT"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(textFragment10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateX();
        double double3 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 0, (float) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        java.awt.Paint paint3 = barRenderer0.getBaseOutlinePaint();
        java.lang.Boolean boolean5 = barRenderer0.getSeriesItemLabelsVisible((-1));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator6, true);
        java.awt.Paint paint10 = barRenderer0.lookupSeriesPaint(2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 'a');
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker1.setLabelFont(font2);
        java.awt.Paint paint4 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint5 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis8.setTickLabelPaint((java.lang.Comparable) 0L, paint10);
        categoryAxis8.setCategoryMargin(0.0d);
        double double14 = categoryAxis8.getLowerMargin();
        java.awt.Font font15 = categoryAxis8.getLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer17.isSeriesVisibleInLegend(1);
        boolean boolean20 = barRenderer17.getBaseCreateEntities();
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        barRenderer17.setBaseFillPaint((java.awt.Paint) color21);
        double double23 = barRenderer17.getItemLabelAnchorOffset();
        java.awt.Stroke stroke25 = barRenderer17.lookupSeriesStroke((int) (byte) 1);
        categoryPlot16.setDomainGridlineStroke(stroke25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot16.getRangeAxisLocation((int) (short) 10);
        java.awt.Font font30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean34 = barRenderer32.isSeriesVisibleInLegend(1);
        boolean boolean35 = barRenderer32.getBaseCreateEntities();
        java.awt.Color color36 = java.awt.Color.LIGHT_GRAY;
        barRenderer32.setBaseFillPaint((java.awt.Paint) color36);
        double double38 = barRenderer32.getItemLabelAnchorOffset();
        java.awt.Stroke stroke40 = barRenderer32.lookupSeriesStroke((int) (byte) 1);
        categoryPlot31.setDomainGridlineStroke(stroke40);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("hi!", font30, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        categoryPlot31.setBackgroundAlpha(0.0f);
        int int46 = categoryPlot31.getDomainAxisCount();
        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot31);
        java.awt.Image image48 = categoryPlot16.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("GradientPaintTransformType.HORIZONTAL", font15, (org.jfree.chart.plot.Plot) categoryPlot16, true);
        valueMarker1.setLabelFont(font15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNull(image48);
        org.junit.Assert.assertNotNull(lengthAdjustmentType52);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer1.isSeriesVisibleInLegend(1);
        boolean boolean4 = barRenderer1.getBaseCreateEntities();
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray22);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset23);
        org.jfree.data.Range range25 = barRenderer1.findRangeBounds(categoryDataset23);
        org.jfree.data.Range range28 = org.jfree.data.Range.expand(range25, (double) 1.0f, (double) 'a');
        double double30 = range28.constrain((double) (short) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean35 = barRenderer33.isSeriesVisibleInLegend(1);
        boolean boolean36 = barRenderer33.getBaseCreateEntities();
        java.lang.Number[] numberArray43 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] { numberArray43, numberArray48, numberArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray54);
        java.lang.Number number56 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset55);
        org.jfree.data.Range range57 = barRenderer33.findRangeBounds(categoryDataset55);
        org.jfree.data.Range range60 = org.jfree.data.Range.expand(range57, (double) 1.0f, 1.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer61 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean63 = barRenderer61.isSeriesVisibleInLegend(1);
        boolean boolean64 = barRenderer61.getBaseCreateEntities();
        java.lang.Number[] numberArray71 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray76 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray81 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray82 = new java.lang.Number[][] { numberArray71, numberArray76, numberArray81 };
        org.jfree.data.category.CategoryDataset categoryDataset83 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray82);
        java.lang.Number number84 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset83);
        org.jfree.data.Range range85 = barRenderer61.findRangeBounds(categoryDataset83);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint87 = new org.jfree.chart.block.RectangleConstraint(range85, (double) 100.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType88 = rectangleConstraint87.getWidthConstraintType();
        java.lang.String str89 = lengthConstraintType88.toString();
        java.lang.String str90 = lengthConstraintType88.toString();
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint91 = new org.jfree.chart.block.RectangleConstraint((double) 1, range28, lengthConstraintType31, 2.0d, range57, lengthConstraintType88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(numberArray76);
        org.junit.Assert.assertNotNull(numberArray81);
        org.junit.Assert.assertNotNull(numberArray82);
        org.junit.Assert.assertNotNull(categoryDataset83);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (-1.0d) + "'", number84.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertNotNull(lengthConstraintType88);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "RectangleConstraintType.RANGE" + "'", str89.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "RectangleConstraintType.RANGE" + "'", str90.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean2 = barRenderer0.isSeriesVisibleInLegend(1);
        boolean boolean3 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint5 = barRenderer0.getSeriesPaint((int) '#');
        java.lang.Boolean boolean7 = barRenderer0.getSeriesItemLabelsVisible((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) 0L, paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getTickLabelInsets();
        java.awt.Stroke stroke15 = categoryAxis10.getTickMarkStroke();
        barRenderer0.setSeriesOutlineStroke((int) '4', stroke15, false);
        barRenderer0.setBaseSeriesVisible(false);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible((-12566464));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        java.awt.Image image15 = jFreeChart14.getBackgroundImage();
        jFreeChart14.setBackgroundImageAlignment(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        java.awt.image.BufferedImage bufferedImage21 = jFreeChart14.createBufferedImage((int) 'a', (int) (short) 1, chartRenderingInfo20);
        jFreeChart14.setNotify(true);
        jFreeChart14.setAntiAlias(false);
        boolean boolean26 = jFreeChart14.getAntiAlias();
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart14.createBufferedImage(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(bufferedImage21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((int) (short) 10);
        java.awt.Stroke stroke4 = barRenderer0.lookupSeriesStroke((int) (byte) 1);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        boolean boolean11 = barRenderer8.getBaseCreateEntities();
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        barRenderer8.setBaseFillPaint((java.awt.Paint) color12);
        double double14 = barRenderer8.getItemLabelAnchorOffset();
        java.awt.Stroke stroke16 = barRenderer8.lookupSeriesStroke((int) (byte) 1);
        categoryPlot7.setDomainGridlineStroke(stroke16);
        boolean boolean18 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot7.getDatasetRenderingOrder();
        float float24 = categoryPlot7.getBackgroundAlpha();
        boolean boolean25 = standardCategorySeriesLabelGenerator5.equals((java.lang.Object) categoryPlot7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean28 = barRenderer26.isSeriesVisibleInLegend(1);
        boolean boolean29 = barRenderer26.getBaseCreateEntities();
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray46 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray47 = new java.lang.Number[][] { numberArray36, numberArray41, numberArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray47);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset48);
        org.jfree.data.Range range50 = barRenderer26.findRangeBounds(categoryDataset48);
        java.lang.Boolean boolean52 = barRenderer26.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement53 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis55.setTickLabelPaint((java.lang.Comparable) 0L, paint57);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis55.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement60 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean61 = rectangleInsets59.equals((java.lang.Object) columnArrangement60);
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer26, (org.jfree.chart.block.Arrangement) flowArrangement53, (org.jfree.chart.block.Arrangement) columnArrangement60);
        java.lang.Number[] numberArray69 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray74 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray79 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray80 = new java.lang.Number[][] { numberArray69, numberArray74, numberArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray80);
        java.lang.Number number82 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset81);
        boolean boolean83 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset81);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer85 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement60, (org.jfree.data.general.Dataset) categoryDataset81, (java.lang.Comparable) "VerticalAlignment.BOTTOM");
        columnArrangement60.clear();
        org.jfree.chart.block.Arrangement arrangement87 = null;
        org.jfree.chart.title.LegendTitle legendTitle88 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot7, (org.jfree.chart.block.Arrangement) columnArrangement60, arrangement87);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(numberArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0d) + "'", number49.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNull(boolean52);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(numberArray69);
        org.junit.Assert.assertNotNull(numberArray74);
        org.junit.Assert.assertNotNull(numberArray79);
        org.junit.Assert.assertNotNull(numberArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (-1.0d) + "'", number82.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Color color3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleEdge.BOTTOM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer2.isSeriesVisibleInLegend(1);
        boolean boolean5 = barRenderer2.getBaseCreateEntities();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        barRenderer2.setBaseFillPaint((java.awt.Paint) color6);
        double double8 = barRenderer2.getItemLabelAnchorOffset();
        java.awt.Stroke stroke10 = barRenderer2.lookupSeriesStroke((int) (byte) 1);
        categoryPlot1.setDomainGridlineStroke(stroke10);
        boolean boolean12 = categoryPlot1.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot1.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Font font17 = categoryPlot1.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("RectangleAnchor.BOTTOM_LEFT", font17);
        java.lang.String str19 = labelBlock18.getURLText();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean23 = barRenderer21.isSeriesVisibleInLegend(1);
        boolean boolean24 = barRenderer21.getBaseCreateEntities();
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[] numberArray41 = new java.lang.Number[] { (byte) 100, 1, (-1), (-1.0f) };
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] { numberArray31, numberArray36, numberArray41 };
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", numberArray42);
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset43);
        org.jfree.data.Range range45 = barRenderer21.findRangeBounds(categoryDataset43);
        java.lang.Boolean boolean47 = barRenderer21.getSeriesVisibleInLegend(255);
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint52 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        categoryAxis50.setTickLabelPaint((java.lang.Comparable) 0L, paint52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = categoryAxis50.getTickLabelInsets();
        org.jfree.chart.block.ColumnArrangement columnArrangement55 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean56 = rectangleInsets54.equals((java.lang.Object) columnArrangement55);
        org.jfree.chart.title.LegendTitle legendTitle57 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer21, (org.jfree.chart.block.Arrangement) flowArrangement48, (org.jfree.chart.block.Arrangement) columnArrangement55);
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity61 = new org.jfree.chart.entity.LegendItemEntity(shape60);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity65 = new org.jfree.chart.entity.LegendItemEntity(shape64);
        boolean boolean66 = legendItemEntity61.equals((java.lang.Object) legendItemEntity65);
        legendItemEntity65.setURLText("LGPL");
        legendItemEntity65.setSeriesKey((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        boolean boolean71 = legendTitle57.equals((java.lang.Object) legendItemEntity65);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = legendTitle57.getPadding();
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D74 = textTitle73.getBounds();
        java.awt.geom.Rectangle2D rectangle2D75 = rectangleInsets72.createInsetRectangle(rectangle2D74);
        org.jfree.chart.renderer.category.BarRenderer barRenderer76 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean78 = barRenderer76.getSeriesVisibleInLegend((int) (short) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation79 = null;
        boolean boolean80 = barRenderer76.removeAnnotation(categoryAnnotation79);
        java.awt.Paint paint83 = barRenderer76.getItemLabelPaint(0, (int) (byte) 10);
        double double84 = barRenderer76.getItemMargin();
        try {
            java.lang.Object obj85 = labelBlock18.draw(graphics2D20, rectangle2D75, (java.lang.Object) double84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (-1.0d) + "'", number44.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNull(boolean78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.2d + "'", double84 == 0.2d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean8 = barRenderer6.isSeriesVisibleInLegend(1);
        boolean boolean9 = barRenderer6.getBaseCreateEntities();
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        barRenderer6.setBaseFillPaint((java.awt.Paint) color10);
        double double12 = barRenderer6.getItemLabelAnchorOffset();
        java.awt.Stroke stroke14 = barRenderer6.lookupSeriesStroke((int) (byte) 1);
        categoryPlot5.setDomainGridlineStroke(stroke14);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", font4, (org.jfree.chart.plot.Plot) categoryPlot5, false);
        java.awt.Image image18 = jFreeChart17.getBackgroundImage();
        jFreeChart17.setBackgroundImageAlignment(0);
        java.awt.image.BufferedImage bufferedImage23 = jFreeChart17.createBufferedImage(1, (int) '4');
        org.jfree.chart.ui.ProjectInfo projectInfo27 = new org.jfree.chart.ui.ProjectInfo("", "CategoryLabelWidthType.RANGE", "RectangleEdge.BOTTOM", (java.awt.Image) bufferedImage23, "DatasetRenderingOrder.FORWARD", "VerticalAlignment.BOTTOM", "LGPL");
        java.lang.String str28 = projectInfo27.getName();
        java.util.List list29 = projectInfo27.getContributors();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(bufferedImage23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNull(list29);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean5 = barRenderer3.isSeriesVisibleInLegend(1);
        boolean boolean6 = barRenderer3.getBaseCreateEntities();
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        barRenderer3.setBaseFillPaint((java.awt.Paint) color7);
        double double9 = barRenderer3.getItemLabelAnchorOffset();
        java.awt.Stroke stroke11 = barRenderer3.lookupSeriesStroke((int) (byte) 1);
        categoryPlot2.setDomainGridlineStroke(stroke11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean17 = barRenderer15.isSeriesVisibleInLegend(1);
        boolean boolean18 = barRenderer15.getBaseCreateEntities();
        java.awt.Paint paint21 = barRenderer15.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        double double24 = categoryPlot2.getAnchorValue();
        boolean boolean25 = categoryPlot2.getDrawSharedDomainAxis();
        org.jfree.chart.plot.Plot plot26 = null;
        categoryPlot2.setParent(plot26);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity7 = new org.jfree.chart.entity.LegendItemEntity(shape6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean10 = barRenderer8.isSeriesVisibleInLegend(1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer12.isSeriesVisibleInLegend(1);
        boolean boolean15 = barRenderer12.getBaseCreateEntities();
        java.awt.Paint paint18 = barRenderer12.getItemFillPaint((int) (short) 0, (int) (byte) 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer20.isSeriesVisibleInLegend(1);
        boolean boolean23 = barRenderer20.getBaseCreateEntities();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        barRenderer20.setBaseFillPaint((java.awt.Paint) color24);
        double double26 = barRenderer20.getItemLabelAnchorOffset();
        java.awt.Stroke stroke28 = barRenderer20.lookupSeriesStroke((int) (byte) 1);
        barRenderer12.setSeriesOutlineStroke(255, stroke28, true);
        barRenderer8.setSeriesStroke(0, stroke28);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("RectangleEdge.BOTTOM", "LGPL", "RectangleConstraintType.RANGE", "RectangleEdge.BOTTOM", shape6, stroke28, paint32);
        boolean boolean34 = legendItem33.isShapeOutlineVisible();
        boolean boolean35 = legendItem33.isLineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }
}

