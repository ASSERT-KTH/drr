import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        int int18 = timeSeries16.getItemCount();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond2, (java.lang.Object) timeSeries16);
        long long20 = fixedMillisecond2.getFirstMillisecond();
        java.util.Calendar calendar21 = null;
        fixedMillisecond2.peg(calendar21);
        long long23 = fixedMillisecond2.getMiddleMillisecond();
        java.util.Date date24 = fixedMillisecond2.getTime();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        int int6 = month2.compareTo((java.lang.Object) class4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        timeSeriesDataItem3.setValue((java.lang.Number) 1560440871544L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        long long10 = fixedMillisecond9.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.next();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.util.Date date15 = month14.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.next();
//        java.lang.Class<?> wildcardClass18 = day16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "Oct", "2019", (java.lang.Class) wildcardClass18);
//        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass18);
//        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass18);
//        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass18);
//        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass18);
//        int int24 = timeSeriesDataItem3.compareTo((java.lang.Object) uRL23);
//        java.lang.Number number25 = timeSeriesDataItem3.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440926870L + "'", long1 == 1560440926870L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440926871L + "'", long10 == 1560440926871L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNull(inputStream20);
//        org.junit.Assert.assertNull(inputStream21);
//        org.junit.Assert.assertNotNull(classLoader22);
//        org.junit.Assert.assertNull(uRL23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1560440871544L + "'", number25.equals(1560440871544L));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        boolean boolean10 = timeSeries5.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class12);
        timeSeries13.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries5.addAndOrUpdate(timeSeries13);
        java.util.Collection collection16 = timeSeries5.getTimePeriods();
        java.util.Collection collection17 = org.jfree.chart.util.ObjectUtilities.deepClone(collection16);
        boolean boolean18 = day2.equals((java.lang.Object) collection17);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        long long5 = day4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        java.util.List list13 = timeSeries10.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate3.setDescription("");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(6, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, serialDate6);
        serialDate6.setDescription("May");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(12);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
        int int17 = spreadsheetDate16.toSerial();
        boolean boolean18 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate24.setDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(6, serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate20.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str31 = serialDate30.getDescription();
        boolean boolean33 = spreadsheetDate16.isInRange(serialDate28, serialDate30, 6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(12);
        int int36 = spreadsheetDate35.getDayOfWeek();
        int int37 = spreadsheetDate35.toSerial();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate40);
        serialDate41.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        boolean boolean44 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(12);
        int int47 = spreadsheetDate46.toSerial();
        boolean boolean48 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        try {
            org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate1.getPreviousDayOfWeek((-447));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month3.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date4 = spreadsheetDate2.toDate();
        int int5 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        long long3 = fixedMillisecond2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        fixedMillisecond2.peg(calendar4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        int int28 = timeSeries26.getItemCount();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond12, (java.lang.Object) timeSeries26);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries2.removeAgedItems(true);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries2.getDomainDescription();
        timeSeries2.setNotify(false);
        timeSeries2.setRangeDescription("30-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries2.removeChangeListener(seriesChangeListener14);
        java.lang.String str16 = timeSeries2.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "30-June-2019" + "'", str16.equals("30-June-2019"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        java.lang.Class<?> wildcardClass4 = day2.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("Value", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        int int5 = day2.getYear();
        long long6 = day2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43646L + "'", long6 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        long long11 = year10.getLastMillisecond();
        boolean boolean13 = year10.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year10.previous();
        int int15 = year10.getYear();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 1560440891005L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560440876199L);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        timeSeriesDataItem3.setValue((java.lang.Number) 100.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) 1560440926871L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.560440876199E12d + "'", number4.equals(1.560440876199E12d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getSerialIndex();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        timeSeries5.setMaximumItemCount(2147483647);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries5.addAndOrUpdate(timeSeries20);
        boolean boolean22 = month0.equals((java.lang.Object) timeSeries5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries5.getTimePeriod((-447));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
//        long long9 = timeSeries2.getMaximumItemAge();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year24 = month23.getYear();
//        long long25 = year24.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
//        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
//        int int28 = timeSeries26.getItemCount();
//        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond12, (java.lang.Object) timeSeries26);
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries2.setDomainDescription("ThreadContext");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        long long34 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1);
//        int int38 = timeSeriesDataItem36.compareTo((java.lang.Object) 10.0f);
//        timeSeriesDataItem36.setValue((java.lang.Number) 1560668399999L);
//        try {
//            timeSeries2.add(timeSeriesDataItem36, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNull(class27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560440928327L + "'", long34 == 1560440928327L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        long long5 = year1.getLastMillisecond();
        java.lang.String str6 = year1.toString();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = month7.getLastMillisecond();
        long long10 = month7.getFirstMillisecond();
        org.jfree.data.time.Year year11 = month7.getYear();
        java.lang.String str12 = year11.toString();
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str6, (java.lang.Object) str12);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561964399999L + "'", long9 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("Mar");
        boolean boolean8 = year4.equals((java.lang.Object) "Mar");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        long long3 = day2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            day2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43646L + "'", long3 == 43646L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries2.getDomainDescription();
        java.lang.String str10 = timeSeries2.getDescription();
        java.lang.String str11 = timeSeries2.getDomainDescription();
        timeSeries2.setDescription("Thu Jun 13 08:48:11 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.lang.Object obj4 = timeSeriesDataItem3.clone();
//        boolean boolean6 = timeSeriesDataItem3.equals((java.lang.Object) 24234L);
//        java.lang.Number number7 = timeSeriesDataItem3.getValue();
//        timeSeriesDataItem3.setValue((java.lang.Number) 1560440913252L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440928642L + "'", long1 == 1560440928642L);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1 + "'", number7.equals(1));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.getDayOfWeek();
        int int7 = spreadsheetDate5.getMonth();
        int int8 = spreadsheetDate5.getDayOfWeek();
        int int9 = spreadsheetDate5.getDayOfMonth();
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.Date date11 = spreadsheetDate5.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.setMaximumItemCount(2147483647);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        boolean boolean15 = month8.equals((java.lang.Object) fixedMillisecond12);
//        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.String str17 = timeSeries2.getRangeDescription();
//        try {
//            timeSeries2.setMaximumItemCount((-435));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440929157L + "'", long13 == 1560440929157L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) timePeriodFormatException7);
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException7.getSuppressed();
//        java.lang.String str11 = timePeriodFormatException7.toString();
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str15 = timePeriodFormatException14.toString();
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        java.lang.String str17 = timePeriodFormatException14.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440929173L + "'", long1 == 1560440929173L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440929173L + "'", long5 == 1560440929173L);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getLastMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        java.lang.String str7 = seriesChangeEvent5.toString();
        java.lang.String str8 = seriesChangeEvent5.toString();
        java.lang.Object obj9 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        int int18 = timeSeries16.getItemCount();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond2, (java.lang.Object) timeSeries16);
        timeSeries16.setDescription("30-June-2027");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries4.removeChangeListener(seriesChangeListener7);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
//        boolean boolean19 = month12.equals((java.lang.Object) fixedMillisecond16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries4.addChangeListener(seriesChangeListener23);
//        java.lang.Class class25 = timeSeries4.getTimePeriodClass();
//        boolean boolean26 = timeSeries4.isEmpty();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440929634L + "'", long17 == 1560440929634L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        long long7 = month5.getFirstMillisecond();
        int int8 = month5.getMonth();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries2.getTimePeriodClass();
        org.junit.Assert.assertNull(class6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1561921199999]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        int int27 = spreadsheetDate26.toSerial();
        boolean boolean28 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean30 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        int int33 = spreadsheetDate32.getDayOfWeek();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        boolean boolean38 = spreadsheetDate32.isOnOrAfter(serialDate37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        java.util.Date date40 = month39.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.next();
        java.lang.Class<?> wildcardClass43 = day41.getClass();
        int int44 = day41.getMonth();
        org.jfree.data.time.SerialDate serialDate45 = day41.getSerialDate();
        boolean boolean46 = spreadsheetDate32.isAfter(serialDate45);
        boolean boolean47 = spreadsheetDate20.isOn(serialDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(12);
        int int50 = spreadsheetDate49.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate53.setDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(6, serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate49.getEndOfCurrentMonth(serialDate56);
        boolean boolean58 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getYear();
        long long4 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getMonth();
        java.lang.String str4 = day2.toString();
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "30-June-2019" + "'", str4.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.previous();
        boolean boolean26 = month20.equals((java.lang.Object) month23);
        long long27 = month20.getSerialIndex();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560440916789L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        long long5 = day2.getSerialIndex();
        long long6 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 100.0d);
        int int5 = year1.getYear();
        int int6 = year1.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) month23);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) year31);
        boolean boolean34 = timeSeries33.getNotify();
        timeSeries33.clear();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries19.addAndOrUpdate(timeSeries33);
        java.util.Collection collection37 = timeSeries33.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.util.Date date19 = spreadsheetDate9.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-435) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        int int18 = timeSeries16.getItemCount();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond2, (java.lang.Object) timeSeries16);
        long long20 = fixedMillisecond2.getFirstMillisecond();
        java.util.Date date21 = fixedMillisecond2.getEnd();
        long long22 = fixedMillisecond2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ThreadContext");
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
//        timeSeriesDataItem4.setValue((java.lang.Number) 1560440871544L);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.util.Date date8 = month7.getStart();
//        boolean boolean9 = timeSeriesDataItem4.equals((java.lang.Object) month7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int12 = spreadsheetDate11.getDayOfWeek();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.util.Date date14 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
//        boolean boolean17 = spreadsheetDate11.isOnOrAfter(serialDate16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        java.lang.Class<?> wildcardClass22 = day20.getClass();
//        int int23 = day20.getMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        boolean boolean25 = spreadsheetDate11.isAfter(serialDate24);
//        int int26 = timeSeriesDataItem4.compareTo((java.lang.Object) serialDate24);
//        try {
//            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 10, serialDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440931649L + "'", long2 == 1560440931649L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) month7);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries6.getDomainDescription();
        timeSeries6.setNotify(false);
        timeSeries6.setRangeDescription("30-June-2019");
        timeSeries6.setMaximumItemAge(1560440888005L);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.SerialDate serialDate24 = day23.getSerialDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(5, serialDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
        long long29 = fixedMillisecond28.getFirstMillisecond();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day26.next();
        try {
            int int34 = spreadsheetDate1.compareTo((java.lang.Object) regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        boolean boolean12 = spreadsheetDate6.isOnOrAfter(serialDate11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.lang.Class<?> wildcardClass17 = day15.getClass();
        int int18 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
        boolean boolean20 = spreadsheetDate6.isAfter(serialDate19);
        boolean boolean21 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int22 = spreadsheetDate1.getMonth();
        int int23 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        int int27 = spreadsheetDate26.toSerial();
        boolean boolean28 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean30 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(0, serialDate37);
        int int39 = fixedMillisecond32.compareTo((java.lang.Object) serialDate38);
        java.lang.String str40 = serialDate38.toString();
        boolean boolean41 = spreadsheetDate5.isAfter(serialDate38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-January-1900" + "'", str40.equals("10-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.Class<?> wildcardClass2 = month0.getClass();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        int int5 = spreadsheetDate4.getDayOfWeek();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
        boolean boolean10 = spreadsheetDate4.isOnOrAfter(serialDate9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        java.util.Date date12 = month11.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.next();
        java.lang.Class<?> wildcardClass15 = day13.getClass();
        int int16 = day13.getMonth();
        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
        boolean boolean18 = spreadsheetDate4.isAfter(serialDate17);
        boolean boolean19 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int20 = spreadsheetDate4.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year11, (java.lang.Object) date15);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15);
        int int20 = day19.getDayOfMonth();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day19.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 30 + "'", int20 == 30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        boolean boolean13 = timeSeries2.getNotify();
        java.util.Collection collection14 = timeSeries2.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        int int5 = day2.getYear();
        long long6 = day2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day2.next();
        boolean boolean10 = day2.equals((java.lang.Object) 1560440919923L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43646L + "'", long6 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        boolean boolean7 = timeSeries2.getNotify();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        boolean boolean23 = month16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
//        timeSeries10.setKey((java.lang.Comparable) month16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
//        try {
//            timeSeries10.delete(regularTimePeriod26);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440932862L + "'", long21 == 1560440932862L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        timeSeries2.setNotify(true);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "ERROR : Relative To String", "January", class18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
        java.lang.String str22 = timeSeries19.getRangeDescription();
        timeSeries19.setDomainDescription("October");
        java.lang.String str25 = timeSeries19.getDomainDescription();
        int int26 = timeSeries19.getItemCount();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        long long30 = month29.getLastMillisecond();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month29);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(6);
        boolean boolean35 = month29.equals((java.lang.Object) 6);
        java.lang.String str36 = month29.toString();
        int int37 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month29);
        timeSeries19.setDomainDescription("Time");
        java.util.Collection collection40 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January" + "'", str22.equals("January"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October" + "'", str25.equals("October"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(collection40);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        java.lang.String str10 = timeSeries4.getDomainDescription();
        int int11 = timeSeries4.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October" + "'", str10.equals("October"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(12);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate3.getPreviousDayOfWeek(3);
        try {
            org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate3.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1);
        long long5 = day4.getSerialIndex();
        long long6 = day4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class8);
        timeSeries9.setMaximumItemCount(100);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
        timeSeries9.setKey((java.lang.Comparable) serialDate15);
        java.lang.String str17 = serialDate15.getDescription();
        int int18 = fixedMillisecond5.compareTo((java.lang.Object) serialDate15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.String str4 = timeSeries2.getDescription();
        int int5 = timeSeries2.getMaximumItemCount();
        timeSeries2.setMaximumItemCount(12);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        boolean boolean14 = month8.equals((java.lang.Object) month11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month8.previous();
        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        org.jfree.data.time.Year year17 = month8.getYear();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month21);
        boolean boolean25 = timeSeries20.getNotify();
        long long26 = timeSeries20.getMaximumItemAge();
        java.lang.String str27 = timeSeries20.getDomainDescription();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class29);
        timeSeries30.setMaximumItemCount(2147483647);
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) month36);
        boolean boolean40 = timeSeries35.getNotify();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class42);
        timeSeries43.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries35.addAndOrUpdate(timeSeries43);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries30.addAndOrUpdate(timeSeries45);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries20.addAndOrUpdate(timeSeries30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries49.removeChangeListener(seriesChangeListener50);
        boolean boolean52 = year17.equals((java.lang.Object) seriesChangeListener50);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(timeSeries49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440933896L + "'", long1 == 1560440933896L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440933896L + "'", long2 == 1560440933896L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440933896L + "'", long4 == 1560440933896L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440933896L + "'", long5 == 1560440933896L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440933896L + "'", long6 == 1560440933896L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440933896L + "'", long9 == 1560440933896L);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 2019L);
        java.util.Calendar calendar6 = null;
        try {
            year1.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        boolean boolean10 = month3.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month3.next();
//        long long12 = month3.getLastMillisecond();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "ERROR : Relative To String", "January", class16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.Object obj20 = timeSeries17.clone();
//        int int21 = month3.compareTo((java.lang.Object) timeSeries17);
//        try {
//            java.lang.Number number23 = timeSeries17.getValue(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440934113L + "'", long8 == 1560440934113L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(100);
        timeSeries2.removeAgedItems(true);
        try {
            timeSeries2.update(0, (java.lang.Number) 1560668399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        boolean boolean7 = timeSeries2.getNotify();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        boolean boolean23 = month16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
//        timeSeries10.setKey((java.lang.Comparable) month16);
//        org.jfree.data.time.Year year26 = month16.getYear();
//        long long27 = month16.getSerialIndex();
//        long long28 = month16.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440934153L + "'", long21 == 1560440934153L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 24234L + "'", long27 == 24234L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        timeSeries4.setMaximumItemAge(2019L);
        long long9 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 1560440891437L);
        java.lang.String str27 = day24.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 1560440919184L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30-June-2019" + "'", str27.equals("30-June-2019"));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "Oct", "2019", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass12);
//        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("October", (java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader17 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader17);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440935066L + "'", long4 == 1560440935066L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(uRL16);
//        org.junit.Assert.assertNotNull(classLoader17);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("October");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
        long long12 = month0.getMiddleMillisecond();
        int int13 = month0.getYearValue();
        java.lang.String str14 = month0.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(2147483647);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.addAndOrUpdate(timeSeries17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries2.removeChangeListener(seriesChangeListener21);
        int int23 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) timeSeries15);
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class20);
        timeSeries21.setMaximumItemCount(100);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        java.util.Date date25 = month24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
        timeSeries21.setKey((java.lang.Comparable) serialDate27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.addAndOrUpdate(timeSeries21);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) month33);
        long long37 = timeSeries32.getMaximumItemAge();
        int int38 = timeSeries32.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(0L);
        int int41 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        int int42 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate21.setDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate27.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(6, serialDate27);
        java.lang.String str31 = serialDate27.toString();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate27);
        boolean boolean34 = spreadsheetDate9.isInRange(serialDate21, serialDate27, (int) (byte) 0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(12);
        int int37 = spreadsheetDate36.getDayOfWeek();
        int int38 = spreadsheetDate36.getMonth();
        int int39 = spreadsheetDate36.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        int int42 = spreadsheetDate41.getDayOfWeek();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        java.util.Date date44 = month43.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date44);
        boolean boolean47 = spreadsheetDate41.isOnOrAfter(serialDate46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        java.util.Date date49 = month48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.next();
        java.lang.Class<?> wildcardClass52 = day50.getClass();
        int int53 = day50.getMonth();
        org.jfree.data.time.SerialDate serialDate54 = day50.getSerialDate();
        boolean boolean55 = spreadsheetDate41.isAfter(serialDate54);
        boolean boolean56 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(2);
        boolean boolean59 = spreadsheetDate36.isAfter(serialDate58);
        boolean boolean60 = spreadsheetDate9.isOnOrAfter(serialDate58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 5 + "'", int42 == 5);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        int int15 = timeSeries13.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.next();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) month21);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener25);
        java.lang.String str27 = timeSeries20.getDomainDescription();
        timeSeries20.setNotify(false);
        timeSeries20.setRangeDescription("30-June-2019");
        timeSeries20.setMaximumItemAge(1560440888005L);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        java.util.Date date36 = month35.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(5, serialDate38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        long long43 = fixedMillisecond42.getFirstMillisecond();
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond42.getMiddleMillisecond(calendar44);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) day40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day40, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(timeSeries46);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
//        long long4 = day2.getLastMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
//        int int7 = day2.compareTo((java.lang.Object) day5);
//        try {
//            java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) day5);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 17 + "'", int7 == 17);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.createCopy(1, (int) 'a');
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener12);
        java.util.Collection collection14 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(collection14);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.next();
//        java.util.Date date9 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440936292L + "'", long1 == 1560440936292L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440936292L + "'", long5 == 1560440936292L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440936292L + "'", long7 == 1560440936292L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
        java.util.List list12 = timeSeries11.getItems();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "ERROR : Relative To String", "January", class16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.Calendar calendar21 = null;
        try {
            month18.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        int int18 = timeSeries16.getItemCount();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond2, (java.lang.Object) timeSeries16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries16.addChangeListener(seriesChangeListener20);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        boolean boolean13 = timeSeries2.getNotify();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        boolean boolean17 = timeSeries2.equals((java.lang.Object) throwableArray16);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears(8, serialDate4);
        java.lang.String str6 = serialDate5.toString();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
        java.lang.String str8 = serialDate5.getDescription();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "30-June-2027" + "'", str6.equals("30-June-2027"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        long long8 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries2.delete(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        java.lang.Class<?> wildcardClass4 = day2.getClass();
        int int5 = day2.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.String str4 = timeSeries2.getDescription();
        int int5 = timeSeries2.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.addChangeListener(seriesChangeListener6);
        timeSeries2.setDomainDescription("30-June-2027");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getFirstMillisecond();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.previous();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.previous();
        boolean boolean22 = month16.equals((java.lang.Object) month19);
        int int23 = month19.getYearValue();
        boolean boolean24 = year11.equals((java.lang.Object) int23);
        java.lang.Object obj25 = null;
        boolean boolean26 = year11.equals(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560440908610L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getFollowingDayOfWeek(1);
        int int6 = spreadsheetDate1.getYYYY();
        int int7 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (-447), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Mar", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        java.util.Date date4 = month3.getEnd();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
//        int int8 = fixedMillisecond0.compareTo((java.lang.Object) month7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440938047L + "'", long1 == 1560440938047L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        int int3 = timeSeries2.getMaximumItemCount();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.addChangeListener(seriesChangeListener5);
        java.util.Collection collection7 = timeSeries2.getTimePeriods();
        timeSeries2.setNotify(true);
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("2019");
        long long12 = year11.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1560440900298L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNull(class4);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("11-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440938164L + "'", long1 == 1560440938164L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440938164L + "'", long9 == 1560440938164L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries2.getDomainDescription();
        timeSeries2.setNotify(false);
        timeSeries2.setRangeDescription("30-June-2019");
        timeSeries2.setMaximumItemAge(1560440888005L);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.util.Date date18 = month17.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(5, serialDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
        long long25 = fixedMillisecond24.getFirstMillisecond();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getMiddleMillisecond(calendar26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year30 = month29.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 43646L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
        timeSeries28.delete(regularTimePeriod33);
        timeSeries28.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "Oct", "2019", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=June 2019]", (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440884171L, (java.lang.Class) wildcardClass12);
//        try {
//            java.lang.Number number18 = timeSeries16.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440938393L + "'", long4 == 1560440938393L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNull(inputStream15);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.setMaximumItemCount(2147483647);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        boolean boolean15 = month8.equals((java.lang.Object) fixedMillisecond12);
//        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        int int17 = timeSeries2.getItemCount();
//        java.lang.Object obj18 = null;
//        boolean boolean19 = timeSeries2.equals(obj18);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440938440L + "'", long13 == 1560440938440L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (-457));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.String str4 = timeSeries2.getDescription();
        int int5 = timeSeries2.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.removeChangeListener(seriesChangeListener6);
        timeSeries2.setDomainDescription("May");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: Oct");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 43646L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        try {
            timeSeries2.add(timeSeriesDataItem23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.toSerial();
        int int5 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-459), 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.util.Date date7 = month6.getEnd();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        java.lang.Class<?> wildcardClass10 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "Oct", "2019", (java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.time.TimePeriodFormatException: Oct", (java.lang.Class) wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440938579L + "'", long2 == 1560440938579L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNull(inputStream13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1927, (int) '#', (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(12);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate3.getPreviousDayOfWeek(3);
        java.lang.String str13 = spreadsheetDate3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11-January-1900" + "'", str13.equals("11-January-1900"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -457");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.time.TimePeriodFormatException: ");
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        long long4 = fixedMillisecond1.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond1.getClass();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year11 = month10.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 43646L);
//        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440876531L, "ClassContext", "Value", (java.lang.Class) wildcardClass14);
//        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Time", (java.lang.Class) wildcardClass14);
//        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440938822L + "'", long2 == 1560440938822L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440938822L + "'", long4 == 1560440938822L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL16);
//        org.junit.Assert.assertNull(obj17);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year1 = month0.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 43646L);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.util.Date date6 = month5.getEnd();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(8, serialDate8);
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        boolean boolean12 = timeSeriesDataItem3.equals((java.lang.Object) day11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.next();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getEnd();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
//        java.lang.Class<?> wildcardClass22 = day20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13, "Oct", "2019", (java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560440891737L);
//        timeSeriesDataItem25.setValue((java.lang.Number) 1560440898864L);
//        boolean boolean28 = day11.equals((java.lang.Object) 1560440898864L);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2027" + "'", str10.equals("30-June-2027"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440939021L + "'", long14 == 1560440939021L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.lang.Object obj4 = timeSeriesDataItem3.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1);
//        boolean boolean9 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem8.getPeriod();
//        java.lang.Object obj11 = null;
//        int int12 = timeSeriesDataItem8.compareTo(obj11);
//        java.lang.Object obj13 = timeSeriesDataItem8.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440939208L + "'", long1 == 1560440939208L);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440939209L + "'", long6 == 1560440939209L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(obj13);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January");
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440939279L + "'", long1 == 1560440939279L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440939279L + "'", long2 == 1560440939279L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440939279L + "'", long3 == 1560440939279L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440939279L + "'", long5 == 1560440939279L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears(7, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        serialDate6.setDescription("January");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        java.util.Date date18 = month17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(8, serialDate20);
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries12.createCopy(regularTimePeriod15, (org.jfree.data.time.RegularTimePeriod) day23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2027" + "'", str22.equals("30-June-2027"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(12);
        int int8 = spreadsheetDate7.toSerial();
        boolean boolean9 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        boolean boolean10 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
        int int17 = spreadsheetDate16.toSerial();
        boolean boolean18 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate24.setDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(6, serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate20.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str31 = serialDate30.getDescription();
        boolean boolean33 = spreadsheetDate16.isInRange(serialDate28, serialDate30, 6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(12);
        int int36 = spreadsheetDate35.getDayOfWeek();
        int int37 = spreadsheetDate35.toSerial();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate40);
        serialDate41.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        boolean boolean44 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, serialDate41);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate48.setDescription("");
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(6, serialDate48);
        java.lang.String str52 = serialDate48.toString();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate48);
        boolean boolean55 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate48, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "17-May-1927" + "'", str52.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year4);
        long long6 = year4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year3 = month2.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 43646L);
//        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 1);
//        timeSeriesDataItem11.setValue((java.lang.Number) 1560440871544L);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.util.Date date15 = month14.getStart();
//        boolean boolean16 = timeSeriesDataItem11.equals((java.lang.Object) month14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int19 = spreadsheetDate18.getDayOfWeek();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.util.Date date21 = month20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
//        boolean boolean24 = spreadsheetDate18.isOnOrAfter(serialDate23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.util.Date date26 = month25.getEnd();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
//        java.lang.Class<?> wildcardClass29 = day27.getClass();
//        int int30 = day27.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day27.getSerialDate();
//        boolean boolean32 = spreadsheetDate18.isAfter(serialDate31);
//        int int33 = timeSeriesDataItem11.compareTo((java.lang.Object) serialDate31);
//        try {
//            timeSeries7.add(timeSeriesDataItem11, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440939831L + "'", long9 == 1560440939831L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        long long2 = month0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(100);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries2.removeChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.addChangeListener(seriesChangeListener9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        int int27 = spreadsheetDate26.toSerial();
        boolean boolean28 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean30 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate20.getPreviousDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        int int6 = year1.getYear();
        java.util.Calendar calendar7 = null;
        try {
            year1.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(6, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June" + "'", str2.equals("June"));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        boolean boolean7 = timeSeries2.getNotify();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        boolean boolean23 = month16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
//        timeSeries10.setKey((java.lang.Comparable) month16);
//        org.jfree.data.time.Year year26 = month16.getYear();
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        java.util.Date date28 = month27.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
//        long long31 = day29.getLastMillisecond();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
//        int int34 = day29.compareTo((java.lang.Object) day32);
//        int int35 = year26.compareTo((java.lang.Object) day29);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440940018L + "'", long21 == 1560440940018L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 17 + "'", int34 == 17);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.util.Date date5 = fixedMillisecond0.getStart();
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond0.peg(calendar6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, (java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440940316L + "'", long1 == 1560440940316L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.setMaximumItemCount(2147483647);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        boolean boolean15 = month8.equals((java.lang.Object) fixedMillisecond12);
//        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.String str17 = timeSeries2.getRangeDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries2.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440940410L + "'", long13 == 1560440940410L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 43646L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date6 = spreadsheetDate2.toDate();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getYear();
        int int4 = day2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-457));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.setMaximumItemCount(2147483647);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        boolean boolean15 = month8.equals((java.lang.Object) fixedMillisecond12);
//        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class18);
//        timeSeries19.fireSeriesChanged();
//        java.lang.String str21 = timeSeries19.getDescription();
//        int int22 = timeSeries19.getMaximumItemCount();
//        java.util.Collection collection23 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries19);
//        boolean boolean24 = timeSeries2.isEmpty();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440940484L + "'", long13 == 1560440940484L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-459));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        boolean boolean6 = fixedMillisecond0.equals((java.lang.Object) "Thu Jun 13 08:48:10 PDT 2019");
//        long long7 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440940581L + "'", long1 == 1560440940581L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440940581L + "'", long7 == 1560440940581L);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int6 = spreadsheetDate5.toSerial();
//        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int10 = spreadsheetDate9.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
//        serialDate13.setDescription("");
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
//        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9999);
//        java.lang.String str20 = serialDate19.getDescription();
//        boolean boolean22 = spreadsheetDate5.isInRange(serialDate17, serialDate19, 6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int25 = spreadsheetDate24.getDayOfWeek();
//        int int26 = spreadsheetDate24.toSerial();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(12);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate29);
//        serialDate30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean33 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, serialDate30);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate5);
//        int int35 = spreadsheetDate5.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        long long37 = fixedMillisecond36.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 1);
//        java.lang.Object obj40 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        long long42 = fixedMillisecond41.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 1);
//        boolean boolean45 = timeSeriesDataItem39.equals((java.lang.Object) timeSeriesDataItem44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeriesDataItem44.getPeriod();
//        try {
//            int int47 = spreadsheetDate5.compareTo((java.lang.Object) regularTimePeriod46);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440940600L + "'", long37 == 1560440940600L);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560440940601L + "'", long42 == 1560440940601L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        long long5 = day2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day14);
//        int int19 = timeSeries2.getMaximumItemCount();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440940648L + "'", long9 == 1560440940648L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440940648L + "'", long11 == 1560440940648L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.Class class4 = timeSeries2.getTimePeriodClass();
        org.junit.Assert.assertNull(class4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setDescription("June 2019");
        java.lang.Object obj18 = timeSeries13.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) month23);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year31 = month30.getYear();
        long long32 = year31.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) year31);
        boolean boolean34 = timeSeries33.getNotify();
        timeSeries33.clear();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries19.addAndOrUpdate(timeSeries33);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries36.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9, 2147483647, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        int int6 = month2.compareTo((java.lang.Object) class4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        java.lang.String str8 = seriesChangeEvent7.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.util.Date date10 = month9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "Oct", "2019", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=June 2019]", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440884171L, (java.lang.Class) wildcardClass13);
//        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("11-January-1900", (java.lang.Class) wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440941136L + "'", long5 == 1560440941136L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNull(uRL18);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=June 2019]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str20 = serialDate19.getDescription();
        boolean boolean22 = spreadsheetDate5.isInRange(serialDate17, serialDate19, 6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        int int25 = spreadsheetDate24.getDayOfWeek();
        int int26 = spreadsheetDate24.toSerial();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate29);
        serialDate30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        boolean boolean33 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(12);
        int int38 = spreadsheetDate37.getDayOfWeek();
        int int39 = spreadsheetDate37.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        int int42 = spreadsheetDate41.toSerial();
        boolean boolean43 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean44 = spreadsheetDate35.isOn((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate37.getPreviousDayOfWeek(3);
        boolean boolean47 = spreadsheetDate24.isOnOrAfter(serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(12);
        int int52 = spreadsheetDate51.getDayOfWeek();
        int int53 = spreadsheetDate51.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(12);
        int int56 = spreadsheetDate55.toSerial();
        boolean boolean57 = spreadsheetDate51.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean58 = spreadsheetDate49.isOn((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
        int int61 = spreadsheetDate60.getDayOfWeek();
        int int62 = spreadsheetDate60.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(12);
        int int65 = spreadsheetDate64.toSerial();
        boolean boolean66 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(12);
        int int69 = spreadsheetDate68.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate72.setDescription("");
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(6, serialDate72);
        org.jfree.data.time.SerialDate serialDate76 = spreadsheetDate68.getEndOfCurrentMonth(serialDate75);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str79 = serialDate78.getDescription();
        boolean boolean81 = spreadsheetDate64.isInRange(serialDate76, serialDate78, 6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(12);
        int int84 = spreadsheetDate83.getDayOfWeek();
        int int85 = spreadsheetDate83.toSerial();
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate88);
        serialDate89.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        boolean boolean92 = spreadsheetDate64.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate83, serialDate89);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate94 = new org.jfree.data.time.SpreadsheetDate(12);
        int int95 = spreadsheetDate94.toSerial();
        boolean boolean96 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate83, (org.jfree.data.time.SerialDate) spreadsheetDate94);
        boolean boolean97 = spreadsheetDate24.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 5 + "'", int84 == 5);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 12 + "'", int85 == 12);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 12 + "'", int95 == 12);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate5.setDescription("");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month14);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year22 = month21.getYear();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) year22);
        java.util.Date date25 = year22.getStart();
        long long26 = year22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year22);
        java.util.Calendar calendar28 = null;
        try {
            year22.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            day2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        java.util.Calendar calendar5 = null;
//        fixedMillisecond0.peg(calendar5);
//        long long7 = fixedMillisecond0.getMiddleMillisecond();
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440942696L + "'", long1 == 1560440942696L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560440942696L + "'", long7 == 1560440942696L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440942696L + "'", long8 == 1560440942696L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        long long8 = timeSeries2.getMaximumItemAge();
        boolean boolean9 = timeSeries2.getNotify();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries2.getDataItem(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate5.setDescription("");
        boolean boolean8 = spreadsheetDate1.isOn(serialDate5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.next();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
//        java.util.Date date8 = month7.getEnd();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.next();
//        java.lang.Class<?> wildcardClass11 = day9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, "Oct", "2019", (java.lang.Class) wildcardClass11);
//        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.util.Date date16 = month15.getEnd();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
//        java.lang.Class<?> wildcardClass19 = day17.getClass();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.util.Date date21 = month20.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date21, timeZone22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.util.Date date27 = month26.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class30);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month32.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) month32);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year40 = month39.getYear();
//        long long41 = year40.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) year40);
//        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
//        int int44 = timeSeries42.getItemCount();
//        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond28, (java.lang.Object) timeSeries42);
//        java.util.Date date46 = fixedMillisecond28.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        long long51 = fixedMillisecond50.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond50.next();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        java.util.Date date56 = month55.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.next();
//        java.lang.Class<?> wildcardClass59 = day57.getClass();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond50, "Oct", "2019", (java.lang.Class) wildcardClass59);
//        java.io.InputStream inputStream61 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass59);
//        java.io.InputStream inputStream62 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass59);
//        java.lang.ClassLoader classLoader63 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass59);
//        java.io.InputStream inputStream64 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass59);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month();
//        java.util.Date date66 = month65.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date66);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class69);
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month71.next();
//        timeSeries70.delete((org.jfree.data.time.RegularTimePeriod) month71);
//        java.beans.PropertyChangeListener propertyChangeListener75 = null;
//        timeSeries70.addPropertyChangeListener(propertyChangeListener75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year79 = month78.getYear();
//        long long80 = year79.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries70.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (org.jfree.data.time.RegularTimePeriod) year79);
//        java.lang.Class class82 = timeSeries81.getTimePeriodClass();
//        int int83 = timeSeries81.getItemCount();
//        boolean boolean84 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond67, (java.lang.Object) timeSeries81);
//        long long85 = fixedMillisecond67.getFirstMillisecond();
//        java.util.Date date86 = fixedMillisecond67.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date46, timeZone87);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440943731L + "'", long3 == 1560440943731L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(inputStream13);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560440943764L + "'", long51 == 1560440943764L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNull(inputStream61);
//        org.junit.Assert.assertNull(inputStream62);
//        org.junit.Assert.assertNotNull(classLoader63);
//        org.junit.Assert.assertNull(inputStream64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(year79);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577865599999L + "'", long80 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertNull(class82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1561964399999L + "'", long85 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "Oct", "2019", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader18 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440948212L + "'", long4 == 1560440948212L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNotNull(classLoader16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(classLoader18);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.String str4 = timeSeries2.getDescription();
        int int5 = timeSeries2.getMaximumItemCount();
        timeSeries2.setMaximumItemCount(12);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        boolean boolean14 = month8.equals((java.lang.Object) month11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month8.previous();
        int int16 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month8);
        int int17 = month8.getYearValue();
        int int18 = month8.getYearValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month6);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        int int18 = timeSeries16.getItemCount();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond2, (java.lang.Object) timeSeries16);
        timeSeries16.setDomainDescription("11-January-1900");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        long long5 = year1.getLastMillisecond();
        java.lang.String str6 = year1.toString();
        int int8 = year1.compareTo((java.lang.Object) 1560440892412L);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "Oct", "2019", (java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440885329L, "Mar", "org.jfree.data.time.TimePeriodFormatException: ", class14);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.next();
//        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month19);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year27 = month26.getYear();
//        long long28 = year27.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) year27);
//        java.lang.Class class30 = timeSeries29.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.addAndOrUpdate(timeSeries29);
//        timeSeries29.clear();
//        int int33 = timeSeries29.getItemCount();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440949024L + "'", long4 == 1560440949024L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(class30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        long long8 = timeSeries2.getMaximumItemAge();
        java.lang.String str9 = timeSeries2.getDomainDescription();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class11);
        timeSeries12.setMaximumItemCount(2147483647);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month18);
        boolean boolean22 = timeSeries17.getNotify();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class24);
        timeSeries25.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries17.addAndOrUpdate(timeSeries25);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.addAndOrUpdate(timeSeries27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        try {
            timeSeries31.update(12, (java.lang.Number) 1561964399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 1560440913252L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.toSerial();
        boolean boolean8 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate14.setDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(6, serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth(serialDate17);
        boolean boolean19 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        int int25 = spreadsheetDate23.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        int int28 = spreadsheetDate27.toSerial();
        boolean boolean29 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean31 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate33.toDate();
        boolean boolean36 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(8, serialDate8);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate9, serialDate12, (-1));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
        int int18 = spreadsheetDate17.getDayOfWeek();
        int int19 = spreadsheetDate17.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        int int22 = spreadsheetDate21.toSerial();
        boolean boolean23 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        int int26 = spreadsheetDate25.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate29.setDescription("");
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(6, serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate25.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str36 = serialDate35.getDescription();
        boolean boolean38 = spreadsheetDate21.isInRange(serialDate33, serialDate35, 6);
        java.lang.String str39 = spreadsheetDate21.getDescription();
        boolean boolean40 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries2.getDomainDescription();
        java.lang.String str10 = timeSeries2.getDescription();
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getEnd();
        long long15 = month13.getLastMillisecond();
        long long16 = month13.getFirstMillisecond();
        java.lang.Object obj17 = null;
        int int18 = month13.compareTo(obj17);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month13);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        int int4 = year1.getYear();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        int int28 = timeSeries26.getItemCount();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond12, (java.lang.Object) timeSeries26);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries2.setDomainDescription("ThreadContext");
        timeSeries2.setMaximumItemAge(1560440878570L);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.previous();
        long long37 = month35.getSerialIndex();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class39);
        timeSeries40.setMaximumItemCount(2147483647);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month46.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.next();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) month46);
        boolean boolean50 = timeSeries45.getNotify();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class52);
        timeSeries53.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries45.addAndOrUpdate(timeSeries53);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries40.addAndOrUpdate(timeSeries55);
        boolean boolean57 = month35.equals((java.lang.Object) timeSeries40);
        java.util.Date date58 = month35.getStart();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58, timeZone59);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 1560440889404L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 24234L + "'", long37 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        java.lang.Class class5 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.util.Date date7 = month6.getEnd();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date7);
        java.lang.Object obj12 = null;
        int int13 = fixedMillisecond11.compareTo(obj12);
        long long14 = fixedMillisecond11.getMiddleMillisecond();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond0.getTime();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) (short) -1);
//        long long10 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440950273L + "'", long1 == 1560440950273L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440950273L + "'", long2 == 1560440950273L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440950273L + "'", long4 == 1560440950273L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440950273L + "'", long5 == 1560440950273L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440950273L + "'", long6 == 1560440950273L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560440950273L + "'", long10 == 1560440950273L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Oct");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long20 = timeSeries15.getMaximumItemAge();
        int int21 = timeSeries15.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries12.getDataItem(regularTimePeriod27);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class30);
        timeSeries31.setMaximumItemCount(100);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
        timeSeries31.setKey((java.lang.Comparable) serialDate37);
        boolean boolean39 = timeSeries12.equals((java.lang.Object) timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        java.util.Date date2 = month1.getEnd();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.util.Date date10 = month9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "Oct", "2019", (java.lang.Class) wildcardClass13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        boolean boolean16 = month3.equals((java.lang.Object) wildcardClass13);
//        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440950870L + "'", long5 == 1560440950870L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(obj17);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440950959L + "'", long1 == 1560440950959L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440950959L + "'", long2 == 1560440950959L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440950959L + "'", long3 == 1560440950959L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3, (int) (byte) -1, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        try {
            timeSeries2.removeAgedItems(1560440898983L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("10-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.lang.Class<?> wildcardClass12 = day10.getClass();
        int int13 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
        boolean boolean15 = spreadsheetDate1.isAfter(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
        int int18 = spreadsheetDate17.getDayOfWeek();
        int int19 = spreadsheetDate17.getMonth();
        int int20 = spreadsheetDate17.getDayOfWeek();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month24);
        boolean boolean28 = timeSeries23.getNotify();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class30);
        timeSeries31.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries23.addAndOrUpdate(timeSeries31);
        boolean boolean34 = spreadsheetDate17.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        boolean boolean37 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, serialDate36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        int int5 = spreadsheetDate1.getDayOfMonth();
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int5);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        java.util.Date date6 = month5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        long long8 = day7.getSerialIndex();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560440938164L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43646L + "'", long8 == 43646L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str2 = serialDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate4 = serialDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getFirstMillisecond();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getYear();
        long long4 = day2.getLastMillisecond();
        java.lang.String str5 = day2.toString();
        java.util.Calendar calendar6 = null;
        try {
            day2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "30-June-2019" + "'", str5.equals("30-June-2019"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2958465, (-435), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: June 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: June 2019"));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year11 = month10.getYear();
//        long long12 = year11.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
//        int int15 = fixedMillisecond9.compareTo((java.lang.Object) 2147483647);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond9.getFirstMillisecond(calendar16);
//        int int19 = fixedMillisecond9.compareTo((java.lang.Object) 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440951916L + "'", long17 == 1560440951916L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440951968L + "'", long2 == 1560440951968L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
        java.lang.String str22 = timeSeries15.getDomainDescription();
        timeSeries15.setNotify(false);
        timeSeries15.setRangeDescription("30-June-2019");
        timeSeries15.setMaximumItemAge(1560440888005L);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        java.util.Date date31 = month30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.SerialDate serialDate33 = day32.getSerialDate();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(5, serialDate33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
        long long38 = fixedMillisecond37.getFirstMillisecond();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond37.getMiddleMillisecond(calendar39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.next();
        boolean boolean43 = timeSeries2.equals((java.lang.Object) day35);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        timeSeries4.setDescription("org.jfree.data.general.SeriesChangeEvent[source=June 2019]");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        int int16 = spreadsheetDate15.getDayOfWeek();
        int int17 = spreadsheetDate15.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        int int20 = spreadsheetDate19.toSerial();
        boolean boolean21 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate27.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(6, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate23.getEndOfCurrentMonth(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str34 = serialDate33.getDescription();
        boolean boolean36 = spreadsheetDate19.isInRange(serialDate31, serialDate33, 6);
        boolean boolean37 = timeSeries4.equals((java.lang.Object) boolean36);
        timeSeries4.setNotify(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        boolean boolean7 = timeSeries2.getNotify();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        boolean boolean23 = month16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
//        timeSeries10.setKey((java.lang.Comparable) month16);
//        timeSeries10.setNotify(false);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440952403L + "'", long21 == 1560440952403L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 100.0d);
        int int5 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date14 = year11.getStart();
        long long15 = year11.getFirstMillisecond();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        long long18 = year17.getLastMillisecond();
        boolean boolean20 = year17.equals((java.lang.Object) 100.0d);
        int int21 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        boolean boolean23 = year11.equals((java.lang.Object) regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 43646L);
        java.lang.Class<?> wildcardClass4 = timeSeriesDataItem3.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.getDayOfWeek();
        int int8 = spreadsheetDate6.toSerial();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(8, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate17);
        boolean boolean20 = spreadsheetDate6.isInRange(serialDate14, serialDate17, (-1));
        int int21 = timeSeriesDataItem3.compareTo((java.lang.Object) serialDate17);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.util.Date date10 = month9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "Oct", "2019", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=June 2019]", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440884171L, (java.lang.Class) wildcardClass13);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        java.lang.Object obj19 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class18);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440952778L + "'", long5 == 1560440952778L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNull(obj19);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        boolean boolean14 = timeSeries13.getNotify();
        timeSeries13.clear();
        timeSeries13.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        java.util.Date date11 = month10.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
//        java.lang.Class<?> wildcardClass14 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "Oct", "2019", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass14);
//        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("October", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        long long22 = fixedMillisecond21.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.next();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        java.util.Date date27 = month26.getEnd();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, "Oct", "2019", (java.lang.Class) wildcardClass30);
//        java.io.InputStream inputStream32 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass30);
//        java.io.InputStream inputStream33 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass30);
//        java.lang.ClassLoader classLoader34 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", class36);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440953054L + "'", long6 == 1560440953054L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNull(uRL18);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560440953082L + "'", long22 == 1560440953082L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(inputStream32);
//        org.junit.Assert.assertNull(inputStream33);
//        org.junit.Assert.assertNotNull(classLoader34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNull(inputStream37);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        java.lang.String str10 = timeSeries4.getDomainDescription();
        int int11 = timeSeries4.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries4.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October" + "'", str10.equals("October"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year4 = month0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.getDayOfWeek();
        int int8 = spreadsheetDate6.getMonth();
        int int9 = spreadsheetDate6.getDayOfWeek();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month13);
        boolean boolean17 = timeSeries12.getNotify();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class19);
        timeSeries20.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries12.addAndOrUpdate(timeSeries20);
        boolean boolean23 = spreadsheetDate6.equals((java.lang.Object) timeSeries20);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class25);
        timeSeries26.setMaximumItemCount(100);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.util.Date date30 = month29.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date30);
        timeSeries26.setKey((java.lang.Comparable) serialDate32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries20.addAndOrUpdate(timeSeries26);
        int int35 = year4.compareTo((java.lang.Object) timeSeries20);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        long long4 = fixedMillisecond3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.util.Date date9 = month8.getEnd();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3, "Oct", "2019", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass12);
//        java.lang.ClassLoader classLoader16 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        java.util.Date date19 = month18.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month24);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year32 = month31.getYear();
//        long long33 = year32.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) year32);
//        java.lang.Class class35 = timeSeries34.getTimePeriodClass();
//        int int36 = timeSeries34.getItemCount();
//        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond20, (java.lang.Object) timeSeries34);
//        long long38 = fixedMillisecond20.getFirstMillisecond();
//        java.util.Date date39 = fixedMillisecond20.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date39, timeZone40);
//        java.lang.ClassLoader classLoader42 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440953993L + "'", long4 == 1560440953993L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNotNull(classLoader16);
//        org.junit.Assert.assertNull(inputStream17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNull(class35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(classLoader42);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int3 = spreadsheetDate2.getDayOfWeek();
//        int int4 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int7 = spreadsheetDate6.toSerial();
//        boolean boolean8 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int11 = spreadsheetDate10.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9999);
//        serialDate14.setDescription("");
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(6, serialDate14);
//        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9999);
//        java.lang.String str21 = serialDate20.getDescription();
//        boolean boolean23 = spreadsheetDate6.isInRange(serialDate18, serialDate20, 6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
//        java.util.Date date33 = month32.getEnd();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        java.lang.Class<?> wildcardClass36 = day34.getClass();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27, "Oct", "2019", (java.lang.Class) wildcardClass36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440885329L, "Mar", "org.jfree.data.time.TimePeriodFormatException: ", class38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate20, class38);
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
//        java.net.URL uRL42 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("October", class41);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440954435L + "'", long28 == 1560440954435L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNull(uRL42);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate5.setDescription("");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month14);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year22 = month21.getYear();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) year22);
        java.util.Date date25 = year22.getStart();
        long long26 = year22.getFirstMillisecond();
        java.lang.Number number27 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year22);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.util.Date date30 = month29.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears(8, serialDate32);
        java.lang.String str34 = serialDate33.toString();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
        boolean boolean37 = year22.equals((java.lang.Object) day35);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.0d + "'", number27.equals(0.0d));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "30-June-2027" + "'", str34.equals("30-June-2027"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str14 = year11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        int int17 = year11.compareTo((java.lang.Object) "June 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        long long5 = day2.getSerialIndex();
        int int6 = day2.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43646L + "'", long5 == 43646L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        int int3 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int6 = spreadsheetDate5.toSerial();
//        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int10 = spreadsheetDate9.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
//        serialDate13.setDescription("");
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
//        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9999);
//        java.lang.String str20 = serialDate19.getDescription();
//        boolean boolean22 = spreadsheetDate5.isInRange(serialDate17, serialDate19, 6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        long long27 = fixedMillisecond26.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond26.next();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.util.Date date32 = month31.getEnd();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.next();
//        java.lang.Class<?> wildcardClass35 = day33.getClass();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond26, "Oct", "2019", (java.lang.Class) wildcardClass35);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440885329L, "Mar", "org.jfree.data.time.TimePeriodFormatException: ", class37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate19, class37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        java.util.Date date41 = month40.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        long long43 = month42.getLastMillisecond();
//        java.util.Date date44 = month42.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month42);
//        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) month42);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440955023L + "'", long27 == 1560440955023L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
//        org.junit.Assert.assertNotNull(date44);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str7 = timeSeries2.getRangeDescription();
        timeSeries2.setDescription("org.jfree.data.time.TimePeriodFormatException: Oct");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1561921199999L);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        java.lang.String str13 = seriesChangeEvent11.toString();
        boolean boolean14 = timeSeries2.equals((java.lang.Object) seriesChangeEvent11);
        java.lang.String str15 = seriesChangeEvent11.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + 1561921199999L + "'", obj12.equals(1561921199999L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1561921199999]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=1561921199999]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1561921199999]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=1561921199999]"));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        timeSeriesDataItem3.setValue((java.lang.Number) 1560440871544L);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.util.Date date7 = month6.getStart();
//        boolean boolean8 = timeSeriesDataItem3.equals((java.lang.Object) month6);
//        boolean boolean10 = month6.equals((java.lang.Object) 24234L);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class12);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month14);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries13.addPropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year22 = month21.getYear();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (org.jfree.data.time.RegularTimePeriod) year22);
//        java.lang.String str25 = year22.toString();
//        java.lang.Object obj26 = null;
//        int int27 = year22.compareTo(obj26);
//        long long28 = year22.getLastMillisecond();
//        boolean boolean29 = month6.equals((java.lang.Object) year22);
//        java.util.Calendar calendar30 = null;
//        try {
//            month6.peg(calendar30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440955524L + "'", long1 == 1560440955524L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(2147483647);
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year7 = month6.getYear();
        java.lang.String str8 = year7.toString();
        int int9 = year7.getYear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        boolean boolean14 = year11.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.previous();
        int int16 = year11.getYear();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year11);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.removeChangeListener(seriesChangeListener6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.addChangeListener(seriesChangeListener19);
//        timeSeries18.clear();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440955606L + "'", long9 == 1560440955606L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440955606L + "'", long11 == 1560440955606L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
        java.util.List list12 = timeSeries11.getItems();
        long long13 = timeSeries11.getMaximumItemAge();
        timeSeries11.clear();
        timeSeries11.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.next();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) month19);
        long long23 = timeSeries18.getMaximumItemAge();
        int int24 = timeSeries18.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        int int27 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        long long2 = fixedMillisecond1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        long long4 = fixedMillisecond1.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = fixedMillisecond1.getClass();
//        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("11-January-1900", (java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440955876L + "'", long2 == 1560440955876L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440955876L + "'", long4 == 1560440955876L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(uRL6);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = fixedMillisecond9.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1577865599999L);
        java.lang.Number number18 = null;
        timeSeriesDataItem17.setValue(number18);
        java.lang.Number number20 = timeSeriesDataItem17.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        java.lang.Object obj7 = seriesChangeEvent4.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + "June 2019" + "'", obj7.equals("June 2019"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        long long7 = month5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, (int) (short) 100);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "April 100" + "'", str3.equals("April 100"));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 11);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440956008L + "'", long1 == 1560440956008L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440956008L + "'", long4 == 1560440956008L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int10 = spreadsheetDate9.getDayOfWeek();
//        int int11 = spreadsheetDate9.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int14 = spreadsheetDate13.toSerial();
//        boolean boolean15 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9999);
//        serialDate21.setDescription("");
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(6, serialDate21);
//        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate17.getEndOfCurrentMonth(serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
//        java.lang.String str28 = serialDate27.getDescription();
//        boolean boolean30 = spreadsheetDate13.isInRange(serialDate25, serialDate27, 6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        long long35 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond34.next();
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        java.util.Date date40 = month39.getEnd();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.next();
//        java.lang.Class<?> wildcardClass43 = day41.getClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond34, "Oct", "2019", (java.lang.Class) wildcardClass43);
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560440885329L, "Mar", "org.jfree.data.time.TimePeriodFormatException: ", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27, class45);
//        java.util.List list48 = timeSeries47.getItems();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries2.addAndOrUpdate(timeSeries47);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440956158L + "'", long35 == 1560440956158L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(list48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        boolean boolean12 = spreadsheetDate6.isOnOrAfter(serialDate11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.next();
        java.lang.Class<?> wildcardClass17 = day15.getClass();
        int int18 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
        boolean boolean20 = spreadsheetDate6.isAfter(serialDate19);
        boolean boolean21 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int22 = spreadsheetDate1.getMonth();
        java.util.Date date23 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("April 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        java.util.Collection collection13 = timeSeries2.getTimePeriods();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        java.util.Date date15 = month14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Date date21 = regularTimePeriod20.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 1560440953488L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        java.lang.String str4 = timeSeries2.getDescription();
        int int5 = timeSeries2.getItemCount();
        java.lang.Object obj6 = timeSeries2.clone();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.util.Date date1 = month0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.util.Date date10 = month9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "Oct", "2019", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        java.lang.Class<?> wildcardClass21 = day19.getClass();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        java.util.Date date23 = month22.getEnd();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date23, timeZone24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone26);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date1, timeZone26);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440956949L + "'", long5 == 1560440956949L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.lang.Class<?> wildcardClass12 = day10.getClass();
        int int13 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
        boolean boolean15 = spreadsheetDate1.isAfter(serialDate14);
        java.lang.String str16 = spreadsheetDate1.getDescription();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str18 = day17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day17.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11-January-1900" + "'", str18.equals("11-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries2.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timeSeries2.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries2.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) -1 + "'", comparable6.equals((short) -1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.getDayOfWeek();
        int int7 = spreadsheetDate5.getMonth();
        int int8 = spreadsheetDate5.getDayOfWeek();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month12);
        boolean boolean16 = timeSeries11.getNotify();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class18);
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries11.addAndOrUpdate(timeSeries19);
        boolean boolean22 = spreadsheetDate5.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        java.lang.String str31 = serialDate30.toString();
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, serialDate30);
        try {
            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', serialDate30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "30-June-2019" + "'", str31.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440957538L + "'", long1 == 1560440957538L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440957538L + "'", long3 == 1560440957538L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440957538L + "'", long4 == 1560440957538L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries2.getDomainDescription();
//        timeSeries2.setNotify(false);
//        timeSeries2.setRangeDescription("30-June-2019");
//        timeSeries2.setMaximumItemAge(1560440888005L);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(5, serialDate20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
//        long long25 = fixedMillisecond24.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year30 = month29.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 43646L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
//        timeSeries28.delete(regularTimePeriod33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year36 = month35.getYear();
//        long long37 = year36.getLastMillisecond();
//        boolean boolean39 = year36.equals((java.lang.Object) 100.0d);
//        int int40 = year36.getYear();
//        int int41 = year36.getYear();
//        int int42 = year36.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 1L);
//        timeSeriesDataItem44.setValue((java.lang.Number) 1560440879017L);
//        boolean boolean47 = timeSeries28.equals((java.lang.Object) 1560440879017L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        long long49 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 1);
//        java.lang.Object obj52 = timeSeriesDataItem51.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        long long54 = fixedMillisecond53.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 1);
//        boolean boolean57 = timeSeriesDataItem51.equals((java.lang.Object) timeSeriesDataItem56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeriesDataItem56.getPeriod();
//        java.lang.Object obj59 = null;
//        int int60 = timeSeriesDataItem56.compareTo(obj59);
//        try {
//            timeSeries28.add(timeSeriesDataItem56);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560440957583L + "'", long49 == 1560440957583L);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560440957584L + "'", long54 == 1560440957584L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.util.Date date20 = month19.getEnd();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.next();
//        java.lang.Class<?> wildcardClass23 = day21.getClass();
//        int int24 = day21.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.previous();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440957608L + "'", long9 == 1560440957608L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440957608L + "'", long11 == 1560440957608L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.toSerial();
        boolean boolean8 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate14.setDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(6, serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth(serialDate17);
        boolean boolean19 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        int int25 = spreadsheetDate23.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        int int28 = spreadsheetDate27.toSerial();
        boolean boolean29 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean31 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.util.Date date35 = spreadsheetDate33.toDate();
        boolean boolean36 = spreadsheetDate21.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int37 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate39 = null;
        try {
            boolean boolean40 = spreadsheetDate21.isBefore(serialDate39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
        org.junit.Assert.assertNotNull(serialDate38);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str20 = serialDate19.getDescription();
        boolean boolean22 = spreadsheetDate5.isInRange(serialDate17, serialDate19, 6);
        java.lang.String str23 = spreadsheetDate5.getDescription();
        java.util.Date date24 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long20 = timeSeries15.getMaximumItemAge();
        int int21 = timeSeries15.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries12.getDataItem(regularTimePeriod27);
        timeSeries12.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date5 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond4);
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440958028L + "'", long1 == 1560440958028L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440958028L + "'", long6 == 1560440958028L);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("Thu Jun 13 08:48:10 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int2 = month0.getYearValue();
        java.lang.String str3 = month0.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) timePeriodFormatException7);
//        java.lang.Throwable[] throwableArray10 = timePeriodFormatException7.getSuppressed();
//        java.lang.String str11 = timePeriodFormatException7.toString();
//        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException7.getSuppressed();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440958192L + "'", long1 == 1560440958192L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440958192L + "'", long5 == 1560440958192L);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(throwableArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray12);
//        org.junit.Assert.assertNotNull(throwableArray13);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-457));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        int int3 = timeSeries2.getMaximumItemCount();
        java.util.List list4 = timeSeries2.getItems();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate21.setDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate27.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(6, serialDate27);
        java.lang.String str31 = serialDate27.toString();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate27);
        boolean boolean34 = spreadsheetDate9.isInRange(serialDate21, serialDate27, (int) (byte) 0);
        int int35 = spreadsheetDate9.getDayOfMonth();
        int int36 = spreadsheetDate9.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 30, (-447));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SerialDate serialDate16 = day15.getSerialDate();
        int int18 = day15.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 1560440885829L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.addChangeListener(seriesChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        long long17 = year16.getLastMillisecond();
        boolean boolean19 = year16.equals((java.lang.Object) 100.0d);
        int int20 = year16.getYear();
        int int21 = year16.getYear();
        int int22 = year16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1L);
        try {
            timeSeries12.add(timeSeriesDataItem24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        int int5 = day2.getYear();
        long long6 = day2.getSerialIndex();
        boolean boolean8 = day2.equals((java.lang.Object) 1560440880213L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43646L + "'", long6 == 43646L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getYear();
        long long4 = day2.getLastMillisecond();
        java.lang.String str5 = day2.toString();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class7);
        timeSeries8.setMaximumItemCount(2147483647);
        int int11 = day2.compareTo((java.lang.Object) 2147483647);
        long long12 = day2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "30-June-2019" + "'", str5.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561878000000L + "'", long12 == 1561878000000L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timeSeries2.getDomainDescription();
        timeSeries2.setNotify(false);
        timeSeries2.clear();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        long long20 = timeSeries15.getMaximumItemAge();
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.util.Date date23 = month22.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        int int25 = day24.getYear();
        long long26 = day24.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year29 = month28.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) 1560440891437L);
        java.lang.String str40 = day37.toString();
        int int41 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day37);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30-June-2019" + "'", str40.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        timeSeries4.setDescription("org.jfree.data.general.SeriesChangeEvent[source=June 2019]");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener12);
        timeSeries4.setMaximumItemAge(1560440883379L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str20 = serialDate19.getDescription();
        boolean boolean22 = spreadsheetDate5.isInRange(serialDate17, serialDate19, 6);
        try {
            org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate5.getFollowingDayOfWeek(17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(12);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(0, serialDate5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.next();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        java.lang.Class<?> wildcardClass21 = day19.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, "Oct", "2019", (java.lang.Class) wildcardClass21);
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass21);
//        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass21);
//        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResource("October", (java.lang.Class) wildcardClass21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond28.next();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        java.util.Date date34 = month33.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.next();
//        java.lang.Class<?> wildcardClass37 = day35.getClass();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond28, "Oct", "2019", (java.lang.Class) wildcardClass37);
//        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass37);
//        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass37);
//        java.lang.ClassLoader classLoader41 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass37);
//        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", (java.lang.Class) wildcardClass21, (java.lang.Class) wildcardClass37);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass21);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440959697L + "'", long13 == 1560440959697L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(inputStream23);
//        org.junit.Assert.assertNull(inputStream24);
//        org.junit.Assert.assertNull(uRL25);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440959700L + "'", long29 == 1560440959700L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNull(inputStream39);
//        org.junit.Assert.assertNull(inputStream40);
//        org.junit.Assert.assertNotNull(classLoader41);
//        org.junit.Assert.assertNull(obj42);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) timeSeries15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        int int25 = spreadsheetDate24.getDayOfWeek();
        int int26 = spreadsheetDate24.getMonth();
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.String str28 = spreadsheetDate24.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
        long long12 = month0.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Date date7 = regularTimePeriod6.getStart();
        java.lang.String str8 = regularTimePeriod6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Sun Jun 30 23:59:59 PDT 2019" + "'", str8.equals("Sun Jun 30 23:59:59 PDT 2019"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries2.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year6 = month5.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (java.lang.Number) 43646L);
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month3, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("Time", (java.lang.Class) wildcardClass9);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.previous();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year17 = month16.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 43646L);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, (java.lang.Class) wildcardClass20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("Time", (java.lang.Class) wildcardClass20);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.lang.String str4 = year3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month20);
        long long24 = month20.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560668399999L + "'", long24 == 1560668399999L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        boolean boolean6 = month0.equals((java.lang.Object) month3);
        java.lang.String str7 = month3.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        int int3 = day2.getYear();
        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        timeSeries2.delete(regularTimePeriod15);
        java.lang.String str17 = timeSeries2.getDescription();
        timeSeries2.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate6.setDescription("");
        org.jfree.data.time.SerialDate serialDate9 = null;
        try {
            boolean boolean11 = spreadsheetDate1.isInRange(serialDate6, serialDate9, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        int int28 = timeSeries26.getItemCount();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond12, (java.lang.Object) timeSeries26);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries2.setDomainDescription("ThreadContext");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(12);
        int int35 = spreadsheetDate34.getDayOfWeek();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        java.util.Date date37 = month36.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date37);
        boolean boolean40 = spreadsheetDate34.isOnOrAfter(serialDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
        int int43 = spreadsheetDate42.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate46.setDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(6, serialDate46);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate42.getEndOfCurrentMonth(serialDate49);
        boolean boolean51 = spreadsheetDate34.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean53 = spreadsheetDate34.equals((java.lang.Object) "Time");
        boolean boolean54 = timeSeries2.equals((java.lang.Object) spreadsheetDate34);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 5 + "'", int35 == 5);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5 + "'", int43 == 5);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
        java.lang.Class<?> wildcardClass6 = day4.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        java.util.Date date8 = month7.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone9);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass6);
        java.util.List list12 = timeSeries11.getItems();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "ERROR : Relative To String", "January", class16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class22);
        timeSeries23.fireSeriesChanged();
        java.lang.String str25 = timeSeries23.getDescription();
        int int26 = timeSeries23.getMaximumItemCount();
        java.util.Collection collection27 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.util.Date date29 = month28.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1560440919841L);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.util.Date date33 = month32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class36);
        int int38 = month34.compareTo((java.lang.Object) class36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month34);
        int int40 = month34.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month28, (org.jfree.data.time.RegularTimePeriod) month34);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(2147483647);
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries2.update(regularTimePeriod6, (java.lang.Number) 1560440956949L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        java.lang.String str10 = timeSeries4.getDomainDescription();
        int int11 = timeSeries4.getItemCount();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        long long15 = month14.getLastMillisecond();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month14);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(6);
        boolean boolean20 = month14.equals((java.lang.Object) 6);
        java.lang.String str21 = month14.toString();
        int int22 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        timeSeries4.setDomainDescription("Time");
        java.util.Collection collection25 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October" + "'", str10.equals("October"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate9.setDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        boolean boolean13 = spreadsheetDate1.isBefore(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        int int16 = spreadsheetDate15.getDayOfWeek();
        int int17 = spreadsheetDate15.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        int int20 = spreadsheetDate19.toSerial();
        boolean boolean21 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate27.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(6, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate23.getEndOfCurrentMonth(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str34 = serialDate33.getDescription();
        boolean boolean36 = spreadsheetDate19.isInRange(serialDate31, serialDate33, 6);
        boolean boolean37 = spreadsheetDate1.isOnOrAfter(serialDate33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.getDayOfWeek();
        int int7 = spreadsheetDate5.getMonth();
        int int8 = spreadsheetDate5.getDayOfWeek();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month12);
        boolean boolean16 = timeSeries11.getNotify();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class18);
        timeSeries19.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries11.addAndOrUpdate(timeSeries19);
        boolean boolean22 = spreadsheetDate5.equals((java.lang.Object) timeSeries19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        java.lang.String str31 = serialDate30.toString();
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, serialDate30);
        try {
            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), (org.jfree.data.time.SerialDate) spreadsheetDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "30-June-2019" + "'", str31.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440962207L + "'", long1 == 1560440962207L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440962207L + "'", long2 == 1560440962207L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440962207L + "'", long3 == 1560440962207L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.previous();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (java.lang.Number) 43646L);
        java.lang.Class<?> wildcardClass7 = timeSeriesDataItem6.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month1, (java.lang.Class) wildcardClass7);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("Time", (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        int int7 = spreadsheetDate6.toSerial();
        boolean boolean8 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate14.setDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(6, serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate10.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str21 = serialDate20.getDescription();
        boolean boolean23 = spreadsheetDate6.isInRange(serialDate18, serialDate20, 6);
        java.lang.String str24 = spreadsheetDate6.getDescription();
        int int25 = spreadsheetDate6.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(5, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
        org.junit.Assert.assertNotNull(serialDate26);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setDomainDescription("October");
//        timeSeries4.setDescription("org.jfree.data.general.SeriesChangeEvent[source=June 2019]");
//        java.lang.Object obj12 = timeSeries4.clone();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year24 = month23.getYear();
//        long long25 = year24.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getMiddleMillisecond();
//        long long29 = fixedMillisecond27.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) (-1.0f));
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond27.getFirstMillisecond(calendar32);
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440962338L + "'", long28 == 1560440962338L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560440962338L + "'", long29 == 1560440962338L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560440962338L + "'", long33 == 1560440962338L);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Last");
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.next();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        java.util.Date date10 = month9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        java.lang.Class<?> wildcardClass13 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4, "Oct", "2019", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass13);
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=June 2019]", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        java.util.Date date26 = month25.getEnd();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.next();
//        java.lang.Class<?> wildcardClass29 = day27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, "Oct", "2019", (java.lang.Class) wildcardClass29);
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass29);
//        java.io.InputStream inputStream32 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass29);
//        java.lang.ClassLoader classLoader33 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass29);
//        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass29);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October", (java.lang.Class) wildcardClass13, (java.lang.Class) wildcardClass29);
//        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:48:11 PDT 2019", (java.lang.Class) wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440962374L + "'", long5 == 1560440962374L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNull(inputStream15);
//        org.junit.Assert.assertNull(inputStream16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440962381L + "'", long21 == 1560440962381L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNull(inputStream31);
//        org.junit.Assert.assertNull(inputStream32);
//        org.junit.Assert.assertNotNull(classLoader33);
//        org.junit.Assert.assertNull(uRL34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertNull(uRL36);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        long long7 = month5.getFirstMillisecond();
        long long8 = month5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day14);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day14.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440962565L + "'", long9 == 1560440962565L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440962565L + "'", long11 == 1560440962565L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.lang.Class<?> wildcardClass5 = day3.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: June 2019", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(inputStream6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate5.setDescription("");
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(6, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
        int int12 = spreadsheetDate11.getDayOfWeek();
        int int13 = spreadsheetDate11.getMonth();
        int int14 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
        int int17 = spreadsheetDate16.getDayOfWeek();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.util.Date date19 = month18.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date19);
        boolean boolean22 = spreadsheetDate16.isOnOrAfter(serialDate21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.util.Date date24 = month23.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.next();
        java.lang.Class<?> wildcardClass27 = day25.getClass();
        int int28 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day25.getSerialDate();
        boolean boolean30 = spreadsheetDate16.isAfter(serialDate29);
        boolean boolean31 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(2);
        boolean boolean34 = spreadsheetDate11.isAfter(serialDate33);
        boolean boolean35 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.lang.String str3 = month0.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str3);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        java.lang.String str7 = seriesChangeEvent4.toString();
        java.lang.String str8 = seriesChangeEvent4.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        timeSeries2.setRangeDescription("Nearest");
        java.lang.String str12 = timeSeries2.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Nearest" + "'", str12.equals("Nearest"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate4.getMonth();
        int int7 = spreadsheetDate4.getDayOfWeek();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries18);
        boolean boolean21 = spreadsheetDate4.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate27.setDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(6, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate23.getEndOfCurrentMonth(serialDate30);
        int int32 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.createCopy(1, (int) 'a');
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(comparable12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
        int int5 = year4.getYear();
        long long6 = year4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class7);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
//        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) month9);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year17 = month16.getYear();
//        long long18 = year17.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) year17);
//        int int21 = fixedMillisecond15.compareTo((java.lang.Object) 2147483647);
//        java.util.Date date22 = fixedMillisecond15.getTime();
//        int int23 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440963100L + "'", long1 == 1560440963100L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440963100L + "'", long5 == 1560440963100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        timeSeries2.setMaximumItemCount(2147483647);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.addAndOrUpdate(timeSeries17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener19);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class22);
        int int24 = timeSeries23.getMaximumItemCount();
        java.lang.Class class25 = timeSeries23.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries23.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        java.util.Date date29 = month28.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
        timeSeries23.setKey((java.lang.Comparable) fixedMillisecond33);
        java.util.Collection collection36 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(collection36);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440963519L + "'", long1 == 1560440963519L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440963519L + "'", long3 == 1560440963519L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560440963519L + "'", long4 == 1560440963519L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440963519L + "'", long5 == 1560440963519L);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate4.getMonth();
        int int7 = spreadsheetDate4.getDayOfWeek();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries18);
        boolean boolean21 = spreadsheetDate4.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        java.lang.String str30 = serialDate29.toString();
        boolean boolean31 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate29);
        int int32 = spreadsheetDate1.getYYYY();
        int int33 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "30-June-2019" + "'", str30.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
        java.lang.String str6 = day2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "30-June-2019" + "'", str6.equals("30-June-2019"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        boolean boolean7 = timeSeries2.getNotify();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries2.addAndOrUpdate(timeSeries10);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        boolean boolean23 = month16.equals((java.lang.Object) fixedMillisecond20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
//        timeSeries10.setKey((java.lang.Comparable) month16);
//        long long26 = month16.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560440963806L + "'", long21 == 1560440963806L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560668399999L + "'", long26 == 1560668399999L);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year7 = month6.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 43646L);
//        java.lang.Class<?> wildcardClass10 = timeSeriesDataItem9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, (java.lang.Class) wildcardClass10);
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("Time", (java.lang.Class) wildcardClass10);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass10);
//        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October", (java.lang.Class) wildcardClass10);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        java.util.Date date25 = month24.getEnd();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
//        java.lang.Class<?> wildcardClass28 = day26.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19, "Oct", "2019", (java.lang.Class) wildcardClass28);
//        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass28);
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass28);
//        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResource("October", (java.lang.Class) wildcardClass28);
//        java.lang.ClassLoader classLoader33 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass28);
//        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass28);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNull(uRL13);
//        org.junit.Assert.assertNull(inputStream14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560440963900L + "'", long20 == 1560440963900L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNull(inputStream30);
//        org.junit.Assert.assertNull(inputStream31);
//        org.junit.Assert.assertNull(uRL32);
//        org.junit.Assert.assertNotNull(classLoader33);
//        org.junit.Assert.assertNull(obj34);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.Object obj7 = timeSeries4.clone();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.previous();
        java.lang.Number number11 = timeSeries4.getValue(regularTimePeriod10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class16);
        int int18 = month14.compareTo((java.lang.Object) class16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month14.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) month14);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.getDataItem(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) timeSeries15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate24.setDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(6, serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate20.getEndOfCurrentMonth(serialDate27);
        int int29 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int30 = spreadsheetDate20.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, "ERROR : Relative To String", "January", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setDomainDescription("October");
        java.lang.String str10 = timeSeries4.getDomainDescription();
        int int11 = timeSeries4.getItemCount();
        timeSeries4.setRangeDescription("Nearest");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October" + "'", str10.equals("October"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        int int3 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int6 = spreadsheetDate5.getDayOfWeek();
//        int int7 = spreadsheetDate5.getMonth();
//        int int8 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int11 = spreadsheetDate10.getDayOfWeek();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        boolean boolean16 = spreadsheetDate10.isOnOrAfter(serialDate15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.util.Date date18 = month17.getEnd();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
//        java.lang.Class<?> wildcardClass21 = day19.getClass();
//        int int22 = day19.getMonth();
//        org.jfree.data.time.SerialDate serialDate23 = day19.getSerialDate();
//        boolean boolean24 = spreadsheetDate10.isAfter(serialDate23);
//        boolean boolean25 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int26 = spreadsheetDate5.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int29 = spreadsheetDate28.getDayOfWeek();
//        int int30 = spreadsheetDate28.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int33 = spreadsheetDate32.toSerial();
//        boolean boolean34 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        long long36 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond35.next();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        java.util.Date date41 = month40.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
//        java.lang.Class<?> wildcardClass44 = day42.getClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, "Oct", "2019", (java.lang.Class) wildcardClass44);
//        boolean boolean46 = spreadsheetDate32.equals((java.lang.Object) timeSeries45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(12);
//        int int49 = spreadsheetDate48.getDayOfWeek();
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        java.util.Date date51 = month50.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date51);
//        boolean boolean54 = spreadsheetDate48.isOnOrAfter(serialDate53);
//        boolean boolean55 = spreadsheetDate32.isOnOrAfter(serialDate53);
//        boolean boolean56 = spreadsheetDate5.isBefore(serialDate53);
//        boolean boolean57 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440964242L + "'", long36 == 1560440964242L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 5 + "'", int49 == 5);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Sun Jun 30 23:59:59 PDT 2019");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
        java.lang.Class<?> wildcardClass12 = day10.getClass();
        int int13 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
        boolean boolean15 = spreadsheetDate1.isAfter(serialDate14);
        java.lang.String str16 = spreadsheetDate1.getDescription();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.util.Date date2 = month1.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(5, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        long long5 = day2.getMiddleMillisecond();
        java.lang.String str6 = day2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561921199999L + "'", long5 == 1561921199999L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "30-June-2019" + "'", str6.equals("30-June-2019"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) timeSeries15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        int int25 = spreadsheetDate24.getDayOfWeek();
        int int26 = spreadsheetDate24.getMonth();
        boolean boolean27 = spreadsheetDate20.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(12);
        int int30 = spreadsheetDate29.getDayOfWeek();
        int int31 = spreadsheetDate29.getMonth();
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate29.getFollowingDayOfWeek(1);
        boolean boolean34 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate37);
        boolean boolean39 = spreadsheetDate29.isOnOrBefore(serialDate38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
//        java.util.Date date6 = month5.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        java.lang.Class<?> wildcardClass9 = day7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "Oct", "2019", (java.lang.Class) wildcardClass9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond0.peg(calendar11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440965061L + "'", long1 == 1560440965061L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
//        boolean boolean10 = month3.equals((java.lang.Object) fixedMillisecond7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month3.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 10);
//        long long14 = month3.getLastMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            month3.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560440965100L + "'", long8 == 1560440965100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
//        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        long long17 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
//        boolean boolean19 = month12.equals((java.lang.Object) fixedMillisecond16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 10);
//        try {
//            timeSeries2.add(timeSeriesDataItem22, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560440965116L + "'", long17 == 1560440965116L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        long long7 = timeSeries2.getMaximumItemAge();
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.util.Date date10 = month9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        int int12 = day11.getYear();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year16 = month15.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 43646L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 1560440891437L);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        java.util.Date date28 = month27.getEnd();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date28);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class31);
        int int33 = month29.compareTo((java.lang.Object) class31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.previous();
        timeSeries19.update(regularTimePeriod35, (java.lang.Number) 1560440874628L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        int int4 = spreadsheetDate1.getDayOfWeek();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month8);
        boolean boolean12 = timeSeries7.getNotify();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.addAndOrUpdate(timeSeries15);
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) timeSeries15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int23 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440965571L + "'", long1 == 1560440965571L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440965571L + "'", long2 == 1560440965571L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440965571L + "'", long3 == 1560440965571L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440965571L + "'", long5 == 1560440965571L);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getSerialIndex();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        timeSeries5.setMaximumItemCount(2147483647);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries5.addAndOrUpdate(timeSeries20);
        boolean boolean22 = month0.equals((java.lang.Object) timeSeries5);
        java.util.Date date23 = month0.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        long long2 = year1.getLastMillisecond();
        boolean boolean4 = year1.equals((java.lang.Object) 100.0d);
        int int5 = year1.getYear();
        int int6 = year1.getYear();
        int int7 = year1.getYear();
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, number8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month13.next();
        int int18 = timeSeriesDataItem9.compareTo((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        timeSeries2.setKey((java.lang.Comparable) "SerialDate.weekInMonthToString(): invalid code.");
        long long9 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year24 = month23.getYear();
        long long25 = year24.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) year24);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        int int28 = timeSeries26.getItemCount();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) fixedMillisecond12, (java.lang.Object) timeSeries26);
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        timeSeries2.setDomainDescription("ThreadContext");
        timeSeries2.setMaximumItemAge(1560440878570L);
        timeSeries2.setMaximumItemCount(1927);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        java.util.Date date38 = month37.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.next();
        java.lang.Class<?> wildcardClass41 = day39.getClass();
        int int42 = day39.getMonth();
        org.jfree.data.time.SerialDate serialDate43 = day39.getSerialDate();
        int int44 = day39.getYear();
        java.lang.Number number45 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertNull(number45);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=June 2019]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=June 2019]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=June 2019]"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(2019, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
//        timeSeries2.fireSeriesChanged();
//        java.lang.String str4 = timeSeries2.getDescription();
//        int int5 = timeSeries2.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.util.Date date10 = fixedMillisecond8.getTime();
//        long long11 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        java.util.Date date13 = month12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getYear();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) day14);
//        java.util.List list19 = timeSeries2.getItems();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560440966042L + "'", long9 == 1560440966042L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440966042L + "'", long11 == 1560440966042L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(list19);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.SerialDate serialDate3 = day2.getSerialDate();
        long long4 = day2.getLastMillisecond();
        boolean boolean6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) day2, (java.lang.Object) false);
        int int7 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class2);
        timeSeries3.fireSeriesChanged();
        java.lang.String str5 = timeSeries3.getDescription();
        int int6 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemCount(12);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year13 = month12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        boolean boolean15 = month9.equals((java.lang.Object) month12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month9.previous();
        int int17 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year18 = month9.getYear();
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(2147483647, year18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = year2.getLastMillisecond();
        boolean boolean5 = year2.equals((java.lang.Object) 100.0d);
        int int6 = year2.getYear();
        int int7 = year2.getYear();
        int int8 = year2.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 1L);
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(100, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) month3);
        boolean boolean7 = timeSeries2.getNotify();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeries2.equals(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        long long6 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1);
//        java.lang.Object obj9 = timeSeriesDataItem8.clone();
//        boolean boolean10 = fixedMillisecond0.equals(obj9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440966231L + "'", long1 == 1560440966231L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560440966231L + "'", long2 == 1560440966231L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560440966231L + "'", long3 == 1560440966231L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440966232L + "'", long6 == 1560440966232L);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getSerialIndex();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class4);
        timeSeries5.setMaximumItemCount(2147483647);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean15 = timeSeries10.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) -1, class17);
        timeSeries18.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries10.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries5.addAndOrUpdate(timeSeries20);
        boolean boolean22 = month0.equals((java.lang.Object) timeSeries5);
        java.lang.String str23 = month0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-447));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560440966353L + "'", long1 == 1560440966353L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560440966353L + "'", long5 == 1560440966353L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560440966353L + "'", long6 == 1560440966353L);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.toSerial();
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate9.getEndOfCurrentMonth(serialDate16);
        boolean boolean18 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        int int23 = spreadsheetDate22.getDayOfWeek();
        int int24 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(12);
        int int27 = spreadsheetDate26.toSerial();
        boolean boolean28 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean30 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.util.Date date34 = spreadsheetDate32.toDate();
        boolean boolean35 = spreadsheetDate20.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int36 = spreadsheetDate20.getYYYY();
        java.lang.String str37 = spreadsheetDate20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        int int42 = spreadsheetDate41.getDayOfWeek();
        int int43 = spreadsheetDate41.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(12);
        int int46 = spreadsheetDate45.toSerial();
        boolean boolean47 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean48 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean49 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(12);
        int int52 = spreadsheetDate51.getDayOfWeek();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        java.util.Date date54 = month53.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date54);
        boolean boolean57 = spreadsheetDate51.isOnOrAfter(serialDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(12);
        int int60 = spreadsheetDate59.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate63.setDescription("");
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addDays(6, serialDate63);
        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate59.getEndOfCurrentMonth(serialDate66);
        boolean boolean68 = spreadsheetDate51.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(12);
        int int72 = spreadsheetDate71.getDayOfWeek();
        int int73 = spreadsheetDate71.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(12);
        int int76 = spreadsheetDate75.toSerial();
        boolean boolean77 = spreadsheetDate71.isOn((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(12);
        int int80 = spreadsheetDate79.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(9999);
        serialDate83.setDescription("");
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addDays(6, serialDate83);
        org.jfree.data.time.SerialDate serialDate87 = spreadsheetDate79.getEndOfCurrentMonth(serialDate86);
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.lang.String str90 = serialDate89.getDescription();
        boolean boolean92 = spreadsheetDate75.isInRange(serialDate87, serialDate89, 6);
        boolean boolean93 = spreadsheetDate59.isAfter(serialDate89);
        org.jfree.data.time.SerialDate serialDate94 = spreadsheetDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "11-January-1900" + "'", str37.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 5 + "'", int42 == 5);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 5 + "'", int72 == 5);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 12 + "'", int76 == 12);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 5 + "'", int80 == 5);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertNull(str90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(serialDate94);
    }
}

