import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.lang.String str9 = year6.toString();
        int int10 = year6.getYear();
        boolean boolean11 = month0.equals((java.lang.Object) year6);
        java.lang.String str12 = year6.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        int int3 = month0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
//        long long5 = month0.getLastMillisecond();
//        org.jfree.data.time.Year year6 = month0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
//        long long10 = fixedMillisecond8.getFirstMillisecond();
//        java.util.Date date11 = fixedMillisecond8.getTime();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getMonth();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        int int18 = day13.compareTo((java.lang.Object) day16);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass22 = day21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "", "", (java.lang.Class) wildcardClass22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getFirstMillisecond(calendar26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
//        java.util.Date date29 = fixedMillisecond25.getStart();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date29, timeZone31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date11, timeZone31);
//        int int34 = month0.compareTo((java.lang.Object) date11);
//        int int35 = month0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 520764324");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        timeSeries15.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        java.lang.String str18 = timeSeries6.getRangeDescription();
//        timeSeries6.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        serialDate7.setDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(2019, serialDate7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        long long14 = year12.getSerialIndex();
        java.util.Date date15 = year12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = serialDate7.getEndOfCurrentMonth(serialDate19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj14 = timeSeriesDataItem5.clone();
//        java.lang.Number number15 = timeSeriesDataItem5.getValue();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        java.lang.String str17 = month16.toString();
//        org.jfree.data.time.Year year18 = month16.getYear();
//        int int19 = month16.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.previous();
//        long long21 = month16.getLastMillisecond();
//        org.jfree.data.time.Year year22 = month16.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        long long26 = fixedMillisecond24.getFirstMillisecond();
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int31 = day29.getMonth();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        int int34 = day29.compareTo((java.lang.Object) day32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass38 = day37.getClass();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day29, "", "", (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getFirstMillisecond(calendar42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond41.next();
//        java.util.Date date45 = fixedMillisecond41.getStart();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date45, timeZone47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date27, timeZone47);
//        int int50 = month16.compareTo((java.lang.Object) date27);
//        int int51 = month16.getYearValue();
//        boolean boolean52 = timeSeriesDataItem5.equals((java.lang.Object) int51);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560236399999L + "'", long33 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj14 = timeSeriesDataItem5.clone();
//        timeSeriesDataItem5.setValue((java.lang.Number) 1560191986461L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(obj14);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
//        java.lang.String str2 = timeSeries1.getDescription();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getMonth();
//        int int6 = day3.getMonth();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) (-31507200000L));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.lang.String str14 = year13.toString();
//        long long15 = year13.getSerialIndex();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.lang.String str20 = serialDate19.toString();
//        java.lang.String str21 = serialDate19.toString();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass23 = day22.getClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.lang.String str25 = year24.toString();
//        long long26 = year24.getSerialIndex();
//        java.util.Date date27 = year24.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate19, (java.lang.Class) wildcardClass23);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(12, serialDate19);
//        boolean boolean32 = spreadsheetDate11.isOn(serialDate19);
//        int int33 = spreadsheetDate11.getDayOfMonth();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getSerialIndex();
//        java.util.Date date37 = year34.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) 1L);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getSerialIndex();
//        int int42 = day40.getMonth();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day40, "10-June-2019", "ERROR : Relative To String", class45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
//        java.lang.String str49 = timeSeries46.getDomainDescription();
//        boolean boolean50 = timeSeriesDataItem39.equals((java.lang.Object) timeSeries46);
//        java.lang.Object obj51 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        java.lang.String str53 = year52.toString();
//        int int54 = timeSeriesDataItem39.compareTo((java.lang.Object) str53);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        java.lang.String str56 = year55.toString();
//        long long57 = year55.getSerialIndex();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58, timeZone59);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date58);
//        java.lang.String str62 = serialDate61.toString();
//        java.lang.String str63 = serialDate61.toString();
//        boolean boolean64 = timeSeriesDataItem39.equals((java.lang.Object) serialDate61);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        java.lang.String str68 = year67.toString();
//        long long69 = year67.getSerialIndex();
//        java.util.Date date70 = year67.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70, timeZone71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date70);
//        java.lang.String str74 = serialDate73.toString();
//        java.lang.String str75 = serialDate73.toString();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass77 = day76.getClass();
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        java.lang.String str79 = year78.toString();
//        long long80 = year78.getSerialIndex();
//        java.util.Date date81 = year78.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone82);
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate73, (java.lang.Class) wildcardClass77);
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate61, "9-June-2019", "April", (java.lang.Class) wildcardClass77);
//        boolean boolean86 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate61);
//        int int87 = spreadsheetDate11.getMonth();
//        java.util.Date date88 = spreadsheetDate11.toDate();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31-December-2019" + "'", str62.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31-December-2019" + "'", str63.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019" + "'", str68.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "31-December-2019" + "'", str74.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "31-December-2019" + "'", str75.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2019" + "'", str79.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 2019L + "'", long80 == 2019L);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertNotNull(date88);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str10 = serialDate9.toString();
        java.lang.String str11 = serialDate9.toString();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
        int int23 = spreadsheetDate1.toSerial();
        java.util.Date date24 = spreadsheetDate1.toDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date24);
        java.lang.Class<?> wildcardClass26 = date24.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        java.lang.String str14 = timeSeries6.getDomainDescription();
//        timeSeries6.setDescription("ERROR : Relative To String");
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries6.createCopy((int) '4', (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        int int7 = day3.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        java.util.List list56 = timeSeries6.getItems();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(list56);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 4, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        java.util.List list24 = timeSeries12.getItems();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
//        java.lang.Number number26 = null;
//        try {
//            timeSeries12.add(regularTimePeriod25, number26, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(list24);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass9 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "", (java.lang.Class) wildcardClass9);
//        timeSeries10.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener12);
//        timeSeries10.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.lang.Class<?> wildcardClass8 = date4.getClass();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, serialDate9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        long long6 = day3.getLastMillisecond();
//        int int7 = day3.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        java.lang.Class class16 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        int int19 = day17.getMonth();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17, "10-June-2019", "ERROR : Relative To String", class22);
//        timeSeries23.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str26 = timeSeries23.getDomainDescription();
//        timeSeries23.setMaximumItemAge((long) 2);
//        timeSeries23.setDomainDescription("April");
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.addOrUpdate(regularTimePeriod35, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries6.addAndOrUpdate(timeSeries23);
//        timeSeries23.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192001136L + "'", long1 == 1560192001136L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192001136L + "'", long2 == 1560192001136L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond2.next();
//        java.util.Date date6 = fixedMillisecond2.getStart();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        int int12 = day7.compareTo((java.lang.Object) day10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass16 = day15.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "", "", (java.lang.Class) wildcardClass16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getFirstMillisecond(calendar20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
//        java.util.Date date23 = fixedMillisecond19.getStart();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date23, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date6, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.lang.String str29 = year28.toString();
//        long long30 = year28.getSerialIndex();
//        java.util.Date date31 = year28.getEnd();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date31, timeZone36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date6, timeZone36);
//        try {
//            org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(1900, year39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
//        java.util.Date date5 = fixedMillisecond1.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        int int11 = day6.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "", "", (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date5, timeZone24);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        long long29 = year27.getSerialIndex();
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date30, timeZone35);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date5, timeZone35);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date5);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '4', 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
//        java.lang.String str5 = fixedMillisecond1.toString();
//        long long6 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        java.lang.String str9 = day7.toString();
//        long long10 = day7.getSerialIndex();
//        long long11 = day7.getFirstMillisecond();
//        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) day7);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getMonth();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "10-June-2019", "ERROR : Relative To String", class18);
//        timeSeries19.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str22 = timeSeries19.getDomainDescription();
//        timeSeries19.setMaximumItemAge((long) 2);
//        timeSeries19.setDomainDescription("April");
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        long long29 = year27.getSerialIndex();
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year27.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries19.addOrUpdate(regularTimePeriod31, (java.lang.Number) 10.0f);
//        timeSeries19.clear();
//        boolean boolean35 = day7.equals((java.lang.Object) timeSeries19);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str5.equals("Wed Dec 31 16:00:00 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        int int3 = day0.getMonth();
//        long long4 = day0.getFirstMillisecond();
//        long long5 = day0.getSerialIndex();
//        boolean boolean7 = day0.equals((java.lang.Object) 1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.String str8 = year7.toString();
//        long long9 = year7.getSerialIndex();
//        java.util.Date date10 = year7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
//        boolean boolean14 = spreadsheetDate6.equals((java.lang.Object) regularTimePeriod13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        long long20 = year18.getSerialIndex();
//        java.util.Date date21 = year18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date21);
//        java.lang.String str25 = serialDate24.toString();
//        java.lang.String str26 = serialDate24.toString();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass28 = day27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getSerialIndex();
//        java.util.Date date32 = year29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate24, (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears(12, serialDate24);
//        boolean boolean37 = spreadsheetDate16.isOn(serialDate24);
//        int int38 = spreadsheetDate16.getDayOfMonth();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        java.lang.String str40 = year39.toString();
//        long long41 = year39.getSerialIndex();
//        java.util.Date date42 = year39.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) 1L);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getSerialIndex();
//        int int47 = day45.getMonth();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day45, "10-June-2019", "ERROR : Relative To String", class50);
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timeSeries51.addPropertyChangeListener(propertyChangeListener52);
//        java.lang.String str54 = timeSeries51.getDomainDescription();
//        boolean boolean55 = timeSeriesDataItem44.equals((java.lang.Object) timeSeries51);
//        java.lang.Object obj56 = timeSeriesDataItem44.clone();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        java.lang.String str58 = year57.toString();
//        int int59 = timeSeriesDataItem44.compareTo((java.lang.Object) str58);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        java.lang.String str61 = year60.toString();
//        long long62 = year60.getSerialIndex();
//        java.util.Date date63 = year60.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date63, timeZone64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date63);
//        java.lang.String str67 = serialDate66.toString();
//        java.lang.String str68 = serialDate66.toString();
//        boolean boolean69 = timeSeriesDataItem44.equals((java.lang.Object) serialDate66);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
//        java.lang.String str73 = year72.toString();
//        long long74 = year72.getSerialIndex();
//        java.util.Date date75 = year72.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date75);
//        java.lang.String str79 = serialDate78.toString();
//        java.lang.String str80 = serialDate78.toString();
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass82 = day81.getClass();
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
//        java.lang.String str84 = year83.toString();
//        long long85 = year83.getSerialIndex();
//        java.util.Date date86 = year83.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date86, timeZone87);
//        org.jfree.data.time.TimeSeries timeSeries89 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate78, (java.lang.Class) wildcardClass82);
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate66, "9-June-2019", "April", (java.lang.Class) wildcardClass82);
//        boolean boolean91 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate66);
//        boolean boolean92 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.SerialDate serialDate93 = null;
//        try {
//            boolean boolean94 = spreadsheetDate3.isOnOrBefore(serialDate93);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(obj56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "31-December-2019" + "'", str67.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31-December-2019" + "'", str68.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019" + "'", str73.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2019L + "'", long74 == 2019L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "31-December-2019" + "'", str79.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "31-December-2019" + "'", str80.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "2019" + "'", str84.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 2019L + "'", long85 == 2019L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int27 = day24.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getMonth();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day28.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int36 = day24.getMonth();
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day24.getFirstMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) 1546329600000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day21.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getLastMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getStart();
        boolean boolean11 = month0.equals((java.lang.Object) fixedMillisecond5);
        long long12 = month0.getSerialIndex();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getMonth();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, "10-June-2019", "ERROR : Relative To String", class10);
//        timeSeries11.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str14 = timeSeries11.getDomainDescription();
//        timeSeries11.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
//        timeSeries11.delete(regularTimePeriod21);
//        int int23 = year0.compareTo((java.lang.Object) timeSeries11);
//        try {
//            timeSeries11.delete(1900, 520764324);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond2.getLastMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (-1L));
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        long long11 = year9.getSerialIndex();
        java.util.Date date12 = year9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.lang.String str16 = serialDate15.toString();
        java.lang.String str17 = serialDate15.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass19 = day18.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        long long22 = year20.getSerialIndex();
        java.util.Date date23 = year20.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate15, (java.lang.Class) wildcardClass19);
        java.lang.String str27 = timeSeries26.getDomainDescription();
        boolean boolean28 = timeSeriesDataItem8.equals((java.lang.Object) str27);
        boolean boolean29 = year0.equals((java.lang.Object) timeSeriesDataItem8);
        long long30 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        timeSeries17.setRangeDescription("September 2958465");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year0.next();
        long long26 = year0.getLastMillisecond();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.String str30 = year29.toString();
        long long31 = year29.getSerialIndex();
        java.util.Date date32 = year29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.lang.String str36 = serialDate35.toString();
        java.lang.String str37 = serialDate35.toString();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass39 = day38.getClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        long long42 = year40.getSerialIndex();
        java.util.Date date43 = year40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate35, (java.lang.Class) wildcardClass39);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=0]", "2019", (java.lang.Class) wildcardClass39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31-December-2019" + "'", str36.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getSerialIndex();
//        int int34 = day32.getMonth();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day32, "10-June-2019", "ERROR : Relative To String", class37);
//        java.lang.Object obj39 = timeSeries38.clone();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
//        timeSeries38.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.String str46 = month45.toString();
//        boolean boolean47 = timeSeries38.equals((java.lang.Object) month45);
//        timeSeries38.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries31.addAndOrUpdate(timeSeries38);
//        boolean boolean50 = timeSeries49.isEmpty();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(obj39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        boolean boolean13 = day11.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        timeSeries17.removeAgedItems(true);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries17.removePropertyChangeListener(propertyChangeListener20);
        int int22 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = null;
        try {
            java.util.Collection collection24 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, 2147483647, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        int int18 = day15.compareTo((java.lang.Object) 'a');
//        long long19 = day15.getFirstMillisecond();
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date25);
//        serialDate28.setDescription("");
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(11, serialDate28);
//        int int32 = day15.compareTo((java.lang.Object) serialDate28);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560150000000L + "'", long19 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        boolean boolean11 = timeSeries6.isEmpty();
//        java.lang.Object obj12 = timeSeries6.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(obj12);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        int int13 = timeSeries6.getMaximumItemCount();
//        try {
//            timeSeries6.delete((-447), (int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -447");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date3);
        serialDate9.setDescription("June");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560192003713L + "'", long1 == 1560192003713L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560192003713L + "'", long2 == 1560192003713L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560150000000L + "'", long4 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str9 = serialDate8.toString();
        java.lang.String str10 = serialDate8.toString();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass12 = day11.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        long long15 = year13.getSerialIndex();
        java.util.Date date16 = year13.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate8, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate8);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(9, serialDate8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        java.lang.String str40 = spreadsheetDate1.getDescription();
//        java.util.Date date41 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        long long43 = fixedMillisecond42.getSerialIndex();
//        try {
//            int int44 = spreadsheetDate1.compareTo((java.lang.Object) long43);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560192004165L + "'", long43 == 1560192004165L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.util.Date date0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass2 = day1.getClass();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date0, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        boolean boolean7 = day3.equals((java.lang.Object) (byte) 0);
//        java.util.Calendar calendar8 = null;
//        try {
//            day3.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 2958465);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getSerialIndex();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93297991906800000L + "'", long3 == 93297991906800000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35501589L + "'", long4 == 35501589L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "September 2958465" + "'", str5.equals("September 2958465"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35501589L + "'", long6 == 35501589L);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemCount(8);
//        try {
//            java.lang.Number number17 = timeSeries12.getValue(12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(collection9);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        long long11 = year9.getSerialIndex();
        java.util.Date date12 = year9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.lang.String str16 = serialDate15.toString();
        java.lang.String str17 = serialDate15.toString();
        org.jfree.data.time.SerialDate serialDate18 = serialDate8.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate20 = serialDate8.getNearestDayOfWeek((int) (byte) 1);
        serialDate8.setDescription("7-January-1900");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getSerialIndex();
//        int int4 = day2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        int int7 = day2.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "", (java.lang.Class) wildcardClass11);
//        timeSeries12.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener14);
//        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0);
//        java.lang.Object obj19 = seriesChangeEvent18.getSource();
//        try {
//            int int20 = spreadsheetDate1.compareTo(obj19);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + obj19 + "' != '" + 0 + "'", obj19.equals(0));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        spreadsheetDate1.setDescription("Following");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
//        serialDate8.setDescription("");
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.lang.String str14 = year13.toString();
//        long long15 = year13.getSerialIndex();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(10, serialDate20);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass34 = day33.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "", "", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "June 2019", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getFirstMillisecond(calendar41);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getLastMillisecond(calendar43);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond40.getLastMillisecond(calendar45);
//        try {
//            timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 520764324, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        java.util.Date date8 = year5.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.lang.String str12 = serialDate11.toString();
//        java.lang.String str13 = serialDate11.toString();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.lang.String str17 = year16.toString();
//        long long18 = year16.getSerialIndex();
//        java.util.Date date19 = year16.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
//        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
//        int int25 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getMonth();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getLastMillisecond();
//        int int31 = day26.compareTo((java.lang.Object) day29);
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date36);
//        boolean boolean41 = spreadsheetDate3.isInRange(serialDate32, serialDate39, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        java.lang.String str46 = year45.toString();
//        long long47 = year45.getSerialIndex();
//        java.util.Date date48 = year45.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.lang.String str52 = serialDate51.toString();
//        java.lang.String str53 = serialDate51.toString();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass55 = day54.getClass();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate51, (java.lang.Class) wildcardClass55);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addYears(12, serialDate51);
//        boolean boolean64 = spreadsheetDate43.isOn(serialDate51);
//        boolean boolean65 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        java.util.Date date66 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
//        java.lang.String str69 = year68.toString();
//        long long70 = year68.getSerialIndex();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date71, timeZone72);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date71);
//        serialDate74.setDescription("");
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths(11, serialDate74);
//        boolean boolean78 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate74);
//        java.lang.Object obj79 = null;
//        try {
//            int int80 = spreadsheetDate1.compareTo(obj79);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560236399999L + "'", long30 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019" + "'", str46.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-2019" + "'", str52.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2019" + "'", str69.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        int int11 = month9.getMonth();
//        int int12 = month9.getYearValue();
//        int int13 = month9.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 93297991906800000L);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries6.createCopy(0, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        boolean boolean12 = timeSeries6.isEmpty();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        java.lang.String str40 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.lang.String str42 = year41.toString();
//        long long43 = year41.getSerialIndex();
//        java.util.Date date44 = year41.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44, timeZone45);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date44);
//        serialDate47.setDescription("");
//        boolean boolean50 = spreadsheetDate1.isOn(serialDate47);
//        org.jfree.data.time.SerialDate serialDate51 = null;
//        try {
//            boolean boolean52 = spreadsheetDate1.isAfter(serialDate51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.lang.String str6 = year3.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11, timeZone12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.lang.String str15 = serialDate14.toString();
        java.lang.String str16 = serialDate14.toString();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass18 = day17.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        long long21 = year19.getSerialIndex();
        java.util.Date date22 = year19.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate14, (java.lang.Class) wildcardClass18);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(6, serialDate14);
        int int27 = year3.compareTo((java.lang.Object) serialDate14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year3.next();
        long long29 = year3.getLastMillisecond();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.lang.String str33 = year32.toString();
        long long34 = year32.getSerialIndex();
        java.util.Date date35 = year32.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.lang.String str39 = serialDate38.toString();
        java.lang.String str40 = serialDate38.toString();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass42 = day41.getClass();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.lang.String str44 = year43.toString();
        long long45 = year43.getSerialIndex();
        java.util.Date date46 = year43.getEnd();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date46, timeZone47);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate38, (java.lang.Class) wildcardClass42);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3, "org.jfree.data.general.SeriesChangeEvent[source=0]", "2019", (java.lang.Class) wildcardClass42);
        try {
            org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries(comparable0, "Value", "org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "31-December-2019" + "'", str39.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-2019" + "'", str40.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate17);
//        java.lang.String str19 = serialDate18.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        long long25 = year23.getSerialIndex();
//        java.util.Date date26 = year23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date26);
//        java.lang.String str30 = serialDate29.toString();
//        java.lang.String str31 = serialDate29.toString();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass33 = day32.getClass();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getSerialIndex();
//        java.util.Date date37 = year34.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate29, (java.lang.Class) wildcardClass33);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears(12, serialDate29);
//        boolean boolean42 = spreadsheetDate21.isOn(serialDate29);
//        int int43 = spreadsheetDate21.toSerial();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getSerialIndex();
//        int int46 = day44.getMonth();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getLastMillisecond();
//        int int49 = day44.compareTo((java.lang.Object) day47);
//        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        java.lang.String str52 = year51.toString();
//        long long53 = year51.getSerialIndex();
//        java.util.Date date54 = year51.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54, timeZone55);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date54);
//        boolean boolean59 = spreadsheetDate21.isInRange(serialDate50, serialDate57, 10);
//        java.lang.String str60 = spreadsheetDate21.getDescription();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        java.lang.String str62 = year61.toString();
//        long long63 = year61.getSerialIndex();
//        java.util.Date date64 = year61.getEnd();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date64, timeZone65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date64);
//        serialDate67.setDescription("");
//        boolean boolean70 = spreadsheetDate21.isOn(serialDate67);
//        boolean boolean71 = spreadsheetDate1.isInRange(serialDate18, serialDate67);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond73.getFirstMillisecond(calendar74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond73.next();
//        java.util.Date date77 = fixedMillisecond73.getStart();
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date77);
//        org.jfree.data.time.SerialDate serialDate79 = day78.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate80 = serialDate67.getEndOfCurrentMonth(serialDate79);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560236399999L + "'", long48 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNull(str60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 100L + "'", long75 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate80);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
        int int2 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass4);
        java.lang.Object obj6 = timeSeries5.clone();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.lang.Number number11 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(number11);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj17 = timeSeriesDataItem5.clone();
//        int int19 = timeSeriesDataItem5.compareTo((java.lang.Object) 11);
//        timeSeriesDataItem5.setValue((java.lang.Number) 2019);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        java.util.Date date18 = fixedMillisecond14.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getSerialIndex();
//        int int21 = day19.getMonth();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getLastMillisecond();
//        int int24 = day19.compareTo((java.lang.Object) day22);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass28 = day27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, "", "", (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getFirstMillisecond(calendar32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
//        java.util.Date date35 = fixedMillisecond31.getStart();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date35, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date18, timeZone37);
//        boolean boolean40 = year8.equals((java.lang.Object) day39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) ' ');
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        java.lang.String str19 = timeSeries12.getDomainDescription();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1L));
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getSerialIndex();
//        java.util.Date date32 = year29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date32);
//        java.lang.String str36 = serialDate35.toString();
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass39 = day38.getClass();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.lang.String str41 = year40.toString();
//        long long42 = year40.getSerialIndex();
//        java.util.Date date43 = year40.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate35, (java.lang.Class) wildcardClass39);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        boolean boolean48 = timeSeriesDataItem28.equals((java.lang.Object) str47);
//        boolean boolean49 = year20.equals((java.lang.Object) timeSeriesDataItem28);
//        try {
//            timeSeries12.add(timeSeriesDataItem28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31-December-2019" + "'", str36.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Time" + "'", str47.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        java.lang.String str40 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.lang.String str42 = year41.toString();
//        long long43 = year41.getSerialIndex();
//        java.util.Date date44 = year41.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44, timeZone45);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date44);
//        serialDate47.setDescription("");
//        boolean boolean50 = spreadsheetDate1.isOn(serialDate47);
//        int int51 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        java.lang.Object obj13 = null;
        boolean boolean14 = fixedMillisecond12.equals(obj13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        java.lang.String str7 = month6.toString();
//        org.jfree.data.time.Year year8 = month6.getYear();
//        int int9 = month6.getYearValue();
//        int int10 = fixedMillisecond1.compareTo((java.lang.Object) month6);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) 1L);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        int int19 = day17.getMonth();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17, "10-June-2019", "ERROR : Relative To String", class22);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
//        java.lang.String str26 = timeSeries23.getDomainDescription();
//        boolean boolean27 = timeSeriesDataItem16.equals((java.lang.Object) timeSeries23);
//        timeSeries23.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries23.removeChangeListener(seriesChangeListener30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        java.lang.Number number34 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        long long36 = day35.getSerialIndex();
//        int int38 = day35.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getSerialIndex();
//        int int41 = day39.getMonth();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getLastMillisecond();
//        int int44 = day39.compareTo((java.lang.Object) day42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) day35, (org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day47, "10-June-2019", "ERROR : Relative To String", class52);
//        timeSeries53.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str56 = timeSeries53.getDomainDescription();
//        java.lang.Comparable comparable57 = timeSeries53.getKey();
//        int int58 = day35.compareTo((java.lang.Object) comparable57);
//        boolean boolean59 = fixedMillisecond1.equals((java.lang.Object) day35);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560236399999L + "'", long33 == 1560236399999L);
//        org.junit.Assert.assertNull(number34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43626L + "'", long36 == 43626L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560236399999L + "'", long43 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(10);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        java.util.Date date64 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        long long67 = day66.getSerialIndex();
//        int int68 = day66.getMonth();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        long long70 = day69.getLastMillisecond();
//        int int71 = day66.compareTo((java.lang.Object) day69);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass75 = day74.getClass();
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day66, "", "", (java.lang.Class) wildcardClass75);
//        timeSeries76.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener78 = null;
//        timeSeries76.removeChangeListener(seriesChangeListener78);
//        int int80 = fixedMillisecond65.compareTo((java.lang.Object) timeSeries76);
//        timeSeries76.setNotify(true);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 43626L + "'", long67 == 43626L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560236399999L + "'", long70 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        long long15 = fixedMillisecond13.getFirstMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        java.lang.Number number25 = timeSeriesDataItem24.getValue();
//        java.lang.Object obj26 = timeSeriesDataItem24.clone();
//        try {
//            timeSeries6.add(timeSeriesDataItem24, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192009225L + "'", long14 == 1560192009225L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192009225L + "'", long15 == 1560192009225L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
//        org.junit.Assert.assertNotNull(obj26);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener13);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1);
//        timeSeriesDataItem4.setValue((java.lang.Number) 1560191993289L);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries6.createCopy(0, 8);
//        try {
//            java.lang.Number number14 = timeSeries6.getValue((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries12);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries10 = null;
//        try {
//            java.util.Collection collection11 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(collection9);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) 2019L);
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        java.lang.String str67 = year66.toString();
//        long long68 = year66.getSerialIndex();
//        java.util.Date date69 = year66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date69);
//        serialDate72.setDescription("");
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(2019, serialDate72);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        java.lang.String str78 = year77.toString();
//        long long79 = year77.getSerialIndex();
//        java.util.Date date80 = year77.getEnd();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80, timeZone81);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date80);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate83);
//        org.jfree.data.time.SerialDate serialDate85 = serialDate72.getEndOfCurrentMonth(serialDate84);
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addMonths(10, serialDate84);
//        boolean boolean87 = spreadsheetDate1.isAfter(serialDate86);
//        java.lang.String str88 = serialDate86.toString();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "2019" + "'", str78.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 2019L + "'", long79 == 2019L);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "31-October-2117" + "'", str88.equals("31-October-2117"));
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        timeSeriesDataItem7.setValue((java.lang.Number) 0.0f);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0f);
//        java.lang.Object obj11 = seriesChangeEvent10.getSource();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 0.0f + "'", obj11.equals(0.0f));
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
//        java.util.Date date18 = fixedMillisecond14.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getSerialIndex();
//        int int21 = day19.getMonth();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getLastMillisecond();
//        int int24 = day19.compareTo((java.lang.Object) day22);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass28 = day27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, "", "", (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getFirstMillisecond(calendar32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
//        java.util.Date date35 = fixedMillisecond31.getStart();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date35, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date18, timeZone37);
//        boolean boolean40 = year8.equals((java.lang.Object) day39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getSerialIndex();
//        int int43 = day41.getMonth();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "10-June-2019", "ERROR : Relative To String", class46);
//        timeSeries47.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str50 = timeSeries47.getDescription();
//        timeSeries47.clear();
//        boolean boolean52 = timeSeries47.isEmpty();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getSerialIndex();
//        int int55 = day53.getMonth();
//        java.lang.Class class58 = null;
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day53, "10-June-2019", "ERROR : Relative To String", class58);
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timeSeries59.addPropertyChangeListener(propertyChangeListener60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass63 = day62.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) day62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day62, (double) 24234L);
//        boolean boolean67 = year8.equals((java.lang.Object) day62);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(str50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 43626L + "'", long54 == 43626L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond57.getFirstMillisecond(calendar58);
//        long long60 = fixedMillisecond57.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (java.lang.Number) 2019);
//        long long63 = fixedMillisecond57.getMiddleMillisecond();
//        int int64 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 100L + "'", long59 == 100L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        long long3 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        timeSeries12.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        timeSeries12.setMaximumItemAge((long) 2);
//        timeSeries12.setDomainDescription("April");
//        int int20 = day5.compareTo((java.lang.Object) timeSeries12);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries12.addChangeListener(seriesChangeListener21);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.Class<?> wildcardClass9 = date5.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date5);
        boolean boolean12 = spreadsheetDate1.isAfter(serialDate11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener8);
//        try {
//            java.lang.Number number11 = timeSeries6.getValue(9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException4.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        java.util.Date date11 = fixedMillisecond7.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone18);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond28.next();
        java.util.Date date32 = fixedMillisecond28.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass34 = day33.getClass();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        long long37 = year35.getSerialIndex();
        java.util.Date date38 = year35.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date32, timeZone39);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date11, timeZone39);
        java.util.Calendar calendar43 = null;
        try {
            long long44 = day42.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        long long8 = year6.getSerialIndex();
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getSerialIndex();
//        int int14 = day12.getMonth();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, "10-June-2019", "ERROR : Relative To String", class17);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        java.lang.String str21 = timeSeries18.getDomainDescription();
//        boolean boolean22 = timeSeriesDataItem11.equals((java.lang.Object) timeSeries18);
//        timeSeries18.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        java.lang.Number number29 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int33 = day30.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getSerialIndex();
//        int int36 = day34.getMonth();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        int int39 = day34.compareTo((java.lang.Object) day37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day34.previous();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getSerialIndex();
//        int int44 = day42.getMonth();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day42, "10-June-2019", "ERROR : Relative To String", class47);
//        timeSeries48.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str51 = timeSeries48.getDomainDescription();
//        java.lang.Comparable comparable52 = timeSeries48.getKey();
//        int int53 = day30.compareTo((java.lang.Object) comparable52);
//        boolean boolean54 = fixedMillisecond1.equals((java.lang.Object) comparable52);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond1.getLastMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond1.previous();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        int int11 = month9.getMonth();
//        int int12 = month9.getYearValue();
//        int int13 = month9.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 93297991906800000L);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = month9.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        java.lang.String str16 = timeSeries6.getRangeDescription();
//        timeSeries6.setMaximumItemCount(4);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.createCopy(10, 12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ERROR : Relative To String" + "'", str16.equals("ERROR : Relative To String"));
//        org.junit.Assert.assertNotNull(timeSeries21);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 1560236399999L);
//        boolean boolean21 = timeSeries12.isEmpty();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.setMaximumItemAge((long) 2019);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass9 = day8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass9);
        java.lang.Object obj11 = timeSeries10.clone();
        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries10.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(collection12);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries6.addChangeListener(seriesChangeListener14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getMonth();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "10-June-2019", "ERROR : Relative To String", class8);
//        timeSeries9.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str12 = timeSeries9.getDomainDescription();
//        timeSeries9.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
//        timeSeries9.delete(regularTimePeriod19);
//        boolean boolean21 = day0.equals((java.lang.Object) timeSeries9);
//        int int22 = timeSeries9.getItemCount();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.lang.String str9 = year8.toString();
//        long long10 = year8.getSerialIndex();
//        java.util.Date date11 = year8.getEnd();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11, timeZone12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date11);
//        java.lang.String str15 = serialDate14.toString();
//        java.lang.String str16 = serialDate14.toString();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass18 = day17.getClass();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate14, (java.lang.Class) wildcardClass18);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(12, serialDate14);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getSerialIndex();
//        int int29 = day27.getMonth();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getLastMillisecond();
//        int int32 = day27.compareTo((java.lang.Object) day30);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass36 = day35.getClass();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, "", "", (java.lang.Class) wildcardClass36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate14, (java.lang.Class) wildcardClass36);
//        java.lang.String str39 = timeSeries38.getDomainDescription();
//        int int40 = year0.compareTo((java.lang.Object) timeSeries38);
//        try {
//            timeSeries38.update(4, (java.lang.Number) (-31507200000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.lang.String str5 = fixedMillisecond1.toString();
        long long6 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str5.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        java.lang.Class class16 = timeSeries6.getTimePeriodClass();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        int int19 = day17.getMonth();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day17, "10-June-2019", "ERROR : Relative To String", class22);
//        timeSeries23.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str26 = timeSeries23.getDomainDescription();
//        timeSeries23.setMaximumItemAge((long) 2);
//        timeSeries23.setDomainDescription("April");
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries23.addOrUpdate(regularTimePeriod35, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries6.addAndOrUpdate(timeSeries23);
//        try {
//            timeSeries6.delete(520764324, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10);
        timeSeries11.setDomainDescription("7-January-1900");
        java.lang.Comparable comparable14 = timeSeries11.getKey();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(comparable14);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getSerialIndex();
//        int int4 = day2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        int int7 = day2.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "", (java.lang.Class) wildcardClass11);
//        timeSeries12.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener14);
//        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) timeSeries12);
//        java.util.Date date17 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        long long19 = year18.getFirstMillisecond();
//        long long20 = year18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
//        try {
//            int int23 = spreadsheetDate1.compareTo((java.lang.Object) year18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
//        timeSeries2.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass9 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass9);
//        java.lang.Object obj11 = timeSeries10.clone();
//        java.util.Collection collection12 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getLastMillisecond(calendar17);
//        long long19 = fixedMillisecond14.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getFirstMillisecond();
//        long long22 = fixedMillisecond20.getFirstMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond20.getMiddleMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond20.peg(calendar25);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener28);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(collection12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560192014109L + "'", long21 == 1560192014109L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560192014109L + "'", long22 == 1560192014109L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560192014109L + "'", long24 == 1560192014109L);
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        long long5 = year0.getSerialIndex();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        timeSeries6.setMaximumItemAge(1560191941655L);
//        java.lang.Class class18 = timeSeries6.getTimePeriodClass();
//        long long19 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191941655L + "'", long19 == 1560191941655L);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.String str8 = year7.toString();
//        long long9 = year7.getSerialIndex();
//        java.util.Date date10 = year7.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
//        boolean boolean14 = spreadsheetDate6.equals((java.lang.Object) regularTimePeriod13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        long long20 = year18.getSerialIndex();
//        java.util.Date date21 = year18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date21);
//        java.lang.String str25 = serialDate24.toString();
//        java.lang.String str26 = serialDate24.toString();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass28 = day27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getSerialIndex();
//        java.util.Date date32 = year29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate24, (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears(12, serialDate24);
//        boolean boolean37 = spreadsheetDate16.isOn(serialDate24);
//        int int38 = spreadsheetDate16.getDayOfMonth();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        java.lang.String str40 = year39.toString();
//        long long41 = year39.getSerialIndex();
//        java.util.Date date42 = year39.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) 1L);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getSerialIndex();
//        int int47 = day45.getMonth();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day45, "10-June-2019", "ERROR : Relative To String", class50);
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timeSeries51.addPropertyChangeListener(propertyChangeListener52);
//        java.lang.String str54 = timeSeries51.getDomainDescription();
//        boolean boolean55 = timeSeriesDataItem44.equals((java.lang.Object) timeSeries51);
//        java.lang.Object obj56 = timeSeriesDataItem44.clone();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        java.lang.String str58 = year57.toString();
//        int int59 = timeSeriesDataItem44.compareTo((java.lang.Object) str58);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
//        java.lang.String str61 = year60.toString();
//        long long62 = year60.getSerialIndex();
//        java.util.Date date63 = year60.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date63, timeZone64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date63);
//        java.lang.String str67 = serialDate66.toString();
//        java.lang.String str68 = serialDate66.toString();
//        boolean boolean69 = timeSeriesDataItem44.equals((java.lang.Object) serialDate66);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
//        java.lang.String str73 = year72.toString();
//        long long74 = year72.getSerialIndex();
//        java.util.Date date75 = year72.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date75);
//        java.lang.String str79 = serialDate78.toString();
//        java.lang.String str80 = serialDate78.toString();
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass82 = day81.getClass();
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year();
//        java.lang.String str84 = year83.toString();
//        long long85 = year83.getSerialIndex();
//        java.util.Date date86 = year83.getEnd();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date86, timeZone87);
//        org.jfree.data.time.TimeSeries timeSeries89 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate78, (java.lang.Class) wildcardClass82);
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate66, "9-June-2019", "April", (java.lang.Class) wildcardClass82);
//        boolean boolean91 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, serialDate66);
//        boolean boolean92 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int93 = spreadsheetDate3.getYYYY();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(obj56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "31-December-2019" + "'", str67.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "31-December-2019" + "'", str68.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "2019" + "'", str73.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 2019L + "'", long74 == 2019L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "31-December-2019" + "'", str79.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "31-December-2019" + "'", str80.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "2019" + "'", str84.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 2019L + "'", long85 == 2019L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1900 + "'", int93 == 1900);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        java.util.Collection collection10 = timeSeries6.getTimePeriods();
//        try {
//            timeSeries6.update(2, (java.lang.Number) 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(collection10);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
        long long2 = timeSeries1.getMaximumItemAge();
        int int3 = timeSeries1.getItemCount();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) 1546329600000L);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        int int28 = day26.getYear();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int31 = day29.getMonth();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        int int34 = day29.compareTo((java.lang.Object) day32);
//        boolean boolean36 = day32.equals((java.lang.Object) (byte) 0);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getSerialIndex();
//        int int39 = day37.getMonth();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, "10-June-2019", "ERROR : Relative To String", class42);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener44);
//        java.lang.String str46 = timeSeries43.getDomainDescription();
//        boolean boolean47 = timeSeries43.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener48);
//        long long50 = timeSeries43.getMaximumItemAge();
//        int int51 = timeSeries43.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener52);
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timeSeries43.addPropertyChangeListener(propertyChangeListener54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (double) 1L);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        long long63 = day62.getSerialIndex();
//        int int64 = day62.getMonth();
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day62, "10-June-2019", "ERROR : Relative To String", class67);
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timeSeries68.addPropertyChangeListener(propertyChangeListener69);
//        java.lang.String str71 = timeSeries68.getDomainDescription();
//        boolean boolean72 = timeSeriesDataItem61.equals((java.lang.Object) timeSeries68);
//        timeSeries68.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener75 = null;
//        timeSeries68.removeChangeListener(seriesChangeListener75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        long long78 = day77.getLastMillisecond();
//        java.lang.Number number79 = timeSeries68.getValue((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        long long81 = day80.getSerialIndex();
//        int int83 = day80.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        long long85 = day84.getSerialIndex();
//        int int86 = day84.getMonth();
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day();
//        long long88 = day87.getLastMillisecond();
//        int int89 = day84.compareTo((java.lang.Object) day87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = day84.previous();
//        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries68.createCopy((org.jfree.data.time.RegularTimePeriod) day80, (org.jfree.data.time.RegularTimePeriod) day84);
//        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries43.addAndOrUpdate(timeSeries91);
//        int int93 = day32.compareTo((java.lang.Object) timeSeries91);
//        int int94 = day26.compareTo((java.lang.Object) int93);
//        int int95 = day21.compareTo((java.lang.Object) int94);
//        java.util.Calendar calendar96 = null;
//        try {
//            long long97 = day21.getFirstMillisecond(calendar96);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560236399999L + "'", long33 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 9223372036854775807L + "'", long50 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2147483647 + "'", int51 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 43626L + "'", long63 == 43626L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10-June-2019" + "'", str71.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560236399999L + "'", long78 == 1560236399999L);
//        org.junit.Assert.assertNull(number79);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 43626L + "'", long81 == 43626L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 43626L + "'", long85 == 43626L);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 6 + "'", int86 == 6);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560236399999L + "'", long88 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(timeSeries91);
//        org.junit.Assert.assertNotNull(timeSeries92);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        boolean boolean20 = fixedMillisecond17.equals((java.lang.Object) regularTimePeriod19);
//        java.lang.String str21 = regularTimePeriod19.toString();
//        try {
//            timeSeries6.add(regularTimePeriod19, (double) (-2208398400001L), true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9-June-2019" + "'", str21.equals("9-June-2019"));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.next();
//        java.util.Date date7 = fixedMillisecond3.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        java.lang.String str9 = year8.toString();
//        long long10 = year8.getSerialIndex();
//        java.util.Date date11 = year8.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        long long20 = year18.getSerialIndex();
//        java.util.Date date21 = year18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date17, timeZone22);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date17, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date7, timeZone25);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(1, year28);
//        long long30 = year28.getFirstMillisecond();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, year28);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getSerialIndex();
//        int int34 = day32.getMonth();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day32, "10-June-2019", "ERROR : Relative To String", class37);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
//        java.lang.String str41 = timeSeries38.getDomainDescription();
//        boolean boolean42 = timeSeries38.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener43);
//        long long45 = timeSeries38.getMaximumItemAge();
//        int int46 = timeSeries38.getMaximumItemCount();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int50 = day47.compareTo((java.lang.Object) 'a');
//        long long51 = day47.getFirstMillisecond();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day47);
//        boolean boolean53 = month31.equals((java.lang.Object) day47);
//        long long54 = month31.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2147483647 + "'", int46 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560150000000L + "'", long51 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 23635L + "'", long54 == 23635L);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries6.getTimePeriod((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        long long6 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
//        int int18 = fixedMillisecond12.compareTo((java.lang.Object) timePeriodFormatException17);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str7 = serialDate6.toString();
//        java.lang.String str8 = serialDate6.toString();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
//        timeSeries17.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond21.next();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.String str29 = month28.toString();
//        long long30 = month28.getFirstMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        boolean boolean33 = month28.equals((java.lang.Object) day31);
//        int int34 = day31.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        long long37 = day36.getSerialIndex();
//        int int38 = day36.getMonth();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        long long40 = day39.getLastMillisecond();
//        int int41 = day36.compareTo((java.lang.Object) day39);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass45 = day44.getClass();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day36, "", "", (java.lang.Class) wildcardClass45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getFirstMillisecond(calendar49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.next();
//        java.util.Date date52 = fixedMillisecond48.getStart();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date52, timeZone54);
//        timeSeries17.add(regularTimePeriod55, (double) 0L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str10 = serialDate9.toString();
        java.lang.String str11 = serialDate9.toString();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
        int int23 = spreadsheetDate1.toSerial();
        java.util.Date date24 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass29 = day28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getFirstMillisecond(calendar33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        java.util.Date date36 = fixedMillisecond32.getStart();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass38 = day37.getClass();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.lang.String str40 = year39.toString();
        long long41 = year39.getSerialIndex();
        java.util.Date date42 = year39.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date36, timeZone43);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass50 = day49.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getFirstMillisecond(calendar54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.next();
        java.util.Date date57 = fixedMillisecond53.getStart();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass59 = day58.getClass();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        java.lang.String str61 = year60.toString();
        long long62 = year60.getSerialIndex();
        java.util.Date date63 = year60.getEnd();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date57, timeZone64);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date36, timeZone64);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date24, timeZone64);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 100L + "'", long34 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "2019" + "'", str61.equals("2019"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 2019L + "'", long62 == 2019L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        timeSeries31.removeAgedItems(1577779200000L, true);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        java.lang.String str36 = month35.toString();
//        org.jfree.data.time.Year year37 = month35.getYear();
//        int int38 = month35.getYearValue();
//        long long39 = month35.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month35, (double) 3);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        long long43 = month42.getLastMillisecond();
//        long long44 = month42.getSerialIndex();
//        int int45 = month42.getMonth();
//        boolean boolean47 = month42.equals((java.lang.Object) "Wed Dec 31 16:00:00 PST 1969");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) month42);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "June 2019" + "'", str36.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 24234L + "'", long44 == 24234L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        long long6 = year5.getLastMillisecond();
        java.lang.Object obj7 = null;
        int int8 = year5.compareTo(obj7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.util.Date date20 = fixedMillisecond1.getTime();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        long long22 = year20.getSerialIndex();
//        java.util.Date date23 = year20.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) 1L);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getMonth();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day26, "10-June-2019", "ERROR : Relative To String", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getDomainDescription();
//        boolean boolean36 = timeSeriesDataItem25.equals((java.lang.Object) timeSeries32);
//        timeSeries32.setMaximumItemAge((long) 9);
//        java.lang.String str39 = timeSeries32.getDomainDescription();
//        timeSeries32.setDescription("");
//        timeSeries32.setRangeDescription("31-December-2019");
//        boolean boolean44 = timeSeriesDataItem9.equals((java.lang.Object) "31-December-2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getFirstMillisecond(calendar47);
//        long long49 = fixedMillisecond46.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 2019);
//        boolean boolean52 = timeSeriesDataItem9.equals((java.lang.Object) fixedMillisecond46);
//        java.lang.Number number53 = timeSeriesDataItem9.getValue();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 100L + "'", long49 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 1.0d + "'", number53.equals(1.0d));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
//        java.lang.String str18 = serialDate17.toString();
//        java.lang.String str19 = serialDate17.toString();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass21 = day20.getClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate17, (java.lang.Class) wildcardClass21);
//        java.lang.String str29 = timeSeries28.getDomainDescription();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int32 = day30.getMonth();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day30, "10-June-2019", "ERROR : Relative To String", class35);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries36.addPropertyChangeListener(propertyChangeListener37);
//        java.lang.String str39 = timeSeries36.getDomainDescription();
//        boolean boolean40 = timeSeries36.isEmpty();
//        boolean boolean41 = timeSeries28.equals((java.lang.Object) timeSeries36);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getSerialIndex();
//        int int44 = day42.getMonth();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getLastMillisecond();
//        int int47 = day42.compareTo((java.lang.Object) day45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getSerialIndex();
//        int int50 = day48.getMonth();
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, "10-June-2019", "ERROR : Relative To String", class53);
//        timeSeries54.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str57 = timeSeries54.getDomainDescription();
//        java.lang.Comparable comparable58 = timeSeries54.getKey();
//        int int59 = day42.compareTo((java.lang.Object) comparable58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getSerialIndex();
//        int int62 = day60.getMonth();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        long long64 = day63.getLastMillisecond();
//        int int65 = day60.compareTo((java.lang.Object) day63);
//        java.lang.String str66 = day60.toString();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        long long69 = day68.getSerialIndex();
//        java.lang.String str70 = day68.toString();
//        long long71 = day68.getSerialIndex();
//        long long72 = day68.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day60, (org.jfree.data.time.RegularTimePeriod) day68);
//        java.util.Date date74 = day60.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 43626L + "'", long61 == 43626L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 43626L + "'", long69 == 43626L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 43626L + "'", long71 == 43626L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560150000000L + "'", long72 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(date74);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        int int40 = spreadsheetDate1.getYYYY();
//        try {
//            org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate1.getPreviousDayOfWeek(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1900 + "'", int40 == 1900);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
        java.lang.String str18 = serialDate17.toString();
        java.lang.String str19 = serialDate17.toString();
        org.jfree.data.time.SerialDate serialDate20 = serialDate10.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, serialDate17);
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', serialDate17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        long long12 = year10.getSerialIndex();
        java.util.Date date13 = year10.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date9, timeZone14);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date9, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date3, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) 43626L);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getMiddleMillisecond();
        int int4 = year2.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-452));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str7 = serialDate6.toString();
//        java.lang.String str8 = serialDate6.toString();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
//        timeSeries17.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getLastMillisecond(calendar24);
//        long long26 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond21.next();
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        java.lang.String str29 = month28.toString();
//        long long30 = month28.getFirstMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        boolean boolean33 = month28.equals((java.lang.Object) day31);
//        int int34 = day31.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getFirstMillisecond(calendar38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.next();
//        java.util.Date date41 = fixedMillisecond37.getStart();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getSerialIndex();
//        int int44 = day42.getMonth();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getLastMillisecond();
//        int int47 = day42.compareTo((java.lang.Object) day45);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass51 = day50.getClass();
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day42, "", "", (java.lang.Class) wildcardClass51);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getFirstMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
//        java.util.Date date58 = fixedMillisecond54.getStart();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date58, timeZone60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date41, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        java.lang.String str64 = year63.toString();
//        long long65 = year63.getSerialIndex();
//        java.util.Date date66 = year63.getEnd();
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        java.lang.String str68 = year67.toString();
//        long long69 = year67.getSerialIndex();
//        java.util.Date date70 = year67.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70, timeZone71);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date66, timeZone71);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date41, timeZone71);
//        int int76 = year74.compareTo((java.lang.Object) 8);
//        long long77 = year74.getFirstMillisecond();
//        try {
//            timeSeries35.update((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 8);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "June 2019" + "'", str29.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "2019" + "'", str64.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019" + "'", str68.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-31507200000L) + "'", long77 == (-31507200000L));
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str7 = serialDate6.toString();
//        java.lang.String str8 = serialDate6.toString();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.lang.String str22 = year21.toString();
//        long long23 = year21.getSerialIndex();
//        java.util.Date date24 = year21.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date24);
//        java.lang.String str28 = serialDate27.toString();
//        java.lang.String str29 = serialDate27.toString();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass31 = day30.getClass();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27, (java.lang.Class) wildcardClass31);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(12, serialDate27);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getSerialIndex();
//        int int42 = day40.getMonth();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        int int45 = day40.compareTo((java.lang.Object) day43);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass49 = day48.getClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day40, "", "", (java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27, (java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, "Wed Dec 31 16:00:00 PST 1969", "org.jfree.data.general.SeriesChangeEvent[source=0]", (java.lang.Class) wildcardClass49);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeries52.getTimePeriod((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-2019" + "'", str28.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        java.util.Date date8 = year5.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.lang.String str12 = serialDate11.toString();
//        java.lang.String str13 = serialDate11.toString();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.lang.String str17 = year16.toString();
//        long long18 = year16.getSerialIndex();
//        java.util.Date date19 = year16.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
//        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
//        int int25 = spreadsheetDate3.getDayOfMonth();
//        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        long long28 = day27.getMiddleMillisecond();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int32 = day29.compareTo((java.lang.Object) 'a');
//        java.util.Date date33 = day29.getStart();
//        boolean boolean34 = day27.equals((java.lang.Object) date33);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208398400001L) + "'", long28 == (-2208398400001L));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        int int2 = month0.getMonth();
//        int int3 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        long long7 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date8 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        timeSeries16.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str19 = timeSeries16.getDomainDescription();
//        timeSeries16.setMaximumItemAge((long) 2);
//        timeSeries16.setDomainDescription("April");
//        int int24 = day9.compareTo((java.lang.Object) timeSeries16);
//        int int25 = month0.compareTo((java.lang.Object) int24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        java.lang.String str27 = year26.toString();
//        long long28 = year26.getSerialIndex();
//        java.util.Date date29 = year26.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem31.getPeriod();
//        boolean boolean33 = month0.equals((java.lang.Object) regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        timeSeries6.setDomainDescription("April");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate(regularTimePeriod18, (java.lang.Number) 10.0f);
//        timeSeries6.setMaximumItemCount(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
//        long long26 = fixedMillisecond24.getFirstMillisecond();
//        java.util.Date date27 = fixedMillisecond24.getTime();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int31 = day29.getMonth();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day29, "10-June-2019", "ERROR : Relative To String", class34);
//        timeSeries35.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        timeSeries35.setMaximumItemAge((long) 2);
//        timeSeries35.setDomainDescription("April");
//        int int43 = day28.compareTo((java.lang.Object) timeSeries35);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries6.addAndOrUpdate(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(timeSeries44);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        java.lang.String str25 = year0.toString();
        int int26 = year0.getYear();
        int int27 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int27 = day24.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getMonth();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day28.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day28);
//        long long36 = timeSeries35.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9L + "'", long36 == 9L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.lang.Object obj19 = timeSeries17.clone();
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(collection20);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getSerialIndex();
//        int int4 = day2.getMonth();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "10-June-2019", "ERROR : Relative To String", class7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        long long11 = year9.getSerialIndex();
//        java.util.Date date12 = year9.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.Class<?> wildcardClass16 = date12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date12);
//        timeSeries8.setKey((java.lang.Comparable) date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
//        java.util.Date date25 = fixedMillisecond21.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getMonth();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getLastMillisecond();
//        int int31 = day26.compareTo((java.lang.Object) day29);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass35 = day34.getClass();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day26, "", "", (java.lang.Class) wildcardClass35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getFirstMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond38.next();
//        java.util.Date date42 = fixedMillisecond38.getStart();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date42, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date25, timeZone44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        java.lang.String str48 = year47.toString();
//        long long49 = year47.getSerialIndex();
//        java.util.Date date50 = year47.getEnd();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        java.lang.String str52 = year51.toString();
//        long long53 = year51.getSerialIndex();
//        java.util.Date date54 = year51.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date50, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date25, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date12, timeZone55);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560236399999L + "'", long30 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
//        java.util.Date date5 = fixedMillisecond1.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        int int11 = day6.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "", "", (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date5, timeZone24);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        long long29 = year27.getSerialIndex();
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date30, timeZone35);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date5, timeZone35);
//        java.util.Date date39 = year38.getEnd();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(date39);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        java.util.Date date8 = year5.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date4, timeZone9);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date4, timeZone12);
//        long long14 = day13.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        long long20 = year18.getSerialIndex();
//        java.util.Date date21 = year18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date21);
//        java.lang.String str25 = serialDate24.toString();
//        java.lang.String str26 = serialDate24.toString();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass28 = day27.getClass();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        java.lang.String str30 = year29.toString();
//        long long31 = year29.getSerialIndex();
//        java.util.Date date32 = year29.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate24, (java.lang.Class) wildcardClass28);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears(12, serialDate24);
//        boolean boolean37 = spreadsheetDate16.isOn(serialDate24);
//        int int38 = spreadsheetDate16.toSerial();
//        boolean boolean39 = day13.equals((java.lang.Object) int38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        java.lang.String str41 = year40.toString();
//        long long42 = year40.getSerialIndex();
//        java.util.Date date43 = year40.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year40.previous();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getSerialIndex();
//        int int47 = day45.getMonth();
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day45, "10-June-2019", "ERROR : Relative To String", class50);
//        timeSeries51.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str54 = timeSeries51.getDomainDescription();
//        timeSeries51.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
//        java.lang.String str58 = year57.toString();
//        long long59 = year57.getSerialIndex();
//        java.util.Date date60 = year57.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year57.previous();
//        timeSeries51.delete(regularTimePeriod61);
//        int int63 = year40.compareTo((java.lang.Object) timeSeries51);
//        boolean boolean64 = day13.equals((java.lang.Object) year40);
//        org.jfree.data.time.SerialDate serialDate65 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(1900, serialDate65);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577779200000L + "'", long14 == 1577779200000L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "31-December-2019" + "'", str26.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43626L + "'", long46 == 43626L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        int int7 = day0.getMonth();
//        int int8 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        int int11 = month9.getMonth();
//        int int12 = month9.getYearValue();
//        int int13 = month9.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 93297991906800000L);
//        int int16 = month9.getMonth();
//        long long17 = month9.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
//        boolean boolean11 = fixedMillisecond8.equals((java.lang.Object) regularTimePeriod10);
//        long long12 = fixedMillisecond8.getSerialIndex();
//        timeSeries6.setKey((java.lang.Comparable) fixedMillisecond8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        int int16 = day14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod17, (java.lang.Number) 6);
//        try {
//            timeSeries6.add(timeSeriesDataItem19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        serialDate8.setDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        long long15 = year13.getSerialIndex();
        java.util.Date date16 = year13.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate21);
        try {
            org.jfree.data.time.SerialDate serialDate24 = serialDate22.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long58 = fixedMillisecond57.getMiddleMillisecond();
//        int int59 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        long long60 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 9223372036854775807L + "'", long60 == 9223372036854775807L);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        boolean boolean24 = timeSeries12.getNotify();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener25);
//        java.lang.String str27 = timeSeries12.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "ERROR : Relative To String" + "'", str27.equals("ERROR : Relative To String"));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.removeAgedItems(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        int int12 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        java.lang.Number number8 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Date date14 = fixedMillisecond10.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.String str24 = year23.toString();
        long long25 = year23.getSerialIndex();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.String str28 = year27.toString();
        long long29 = year27.getSerialIndex();
        java.util.Date date30 = year27.getEnd();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date26, timeZone31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date26, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date20, timeZone34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date14, timeZone34);
        boolean boolean38 = timeSeriesDataItem5.equals((java.lang.Object) date14);
        java.lang.Number number39 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 1.0d + "'", number39.equals(1.0d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        java.lang.String str14 = serialDate10.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str22 = serialDate21.toString();
        java.lang.String str23 = serialDate21.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        long long28 = year26.getSerialIndex();
        java.util.Date date29 = year26.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21, (java.lang.Class) wildcardClass25);
        boolean boolean33 = spreadsheetDate1.isInRange(serialDate10, serialDate21);
        java.lang.String str34 = serialDate10.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "31-December-2019" + "'", str34.equals("31-December-2019"));
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day3.equals(obj7);
//        int int9 = day3.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year32);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries31.getDataItem((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.next();
        java.util.Date date7 = fixedMillisecond3.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        long long20 = year18.getSerialIndex();
        java.util.Date date21 = year18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date17, timeZone22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date17, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date7, timeZone25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(1, year28);
        long long30 = year28.getFirstMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(7, year28);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = month31.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 2958465);
        int int3 = month2.getYearValue();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2958465 + "'", int3 == 2958465);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35501589L + "'", long4 == 35501589L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = month6.getYear();
        int int9 = month6.getYearValue();
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) month6);
        long long11 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
//        java.lang.String str18 = serialDate17.toString();
//        java.lang.String str19 = serialDate17.toString();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass21 = day20.getClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone26);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate17, (java.lang.Class) wildcardClass21);
//        java.lang.String str29 = timeSeries28.getDomainDescription();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int32 = day30.getMonth();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day30, "10-June-2019", "ERROR : Relative To String", class35);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries36.addPropertyChangeListener(propertyChangeListener37);
//        java.lang.String str39 = timeSeries36.getDomainDescription();
//        boolean boolean40 = timeSeries36.isEmpty();
//        boolean boolean41 = timeSeries28.equals((java.lang.Object) timeSeries36);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getSerialIndex();
//        int int44 = day42.getMonth();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        long long46 = day45.getLastMillisecond();
//        int int47 = day42.compareTo((java.lang.Object) day45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        long long49 = day48.getSerialIndex();
//        int int50 = day48.getMonth();
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, "10-June-2019", "ERROR : Relative To String", class53);
//        timeSeries54.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str57 = timeSeries54.getDomainDescription();
//        java.lang.Comparable comparable58 = timeSeries54.getKey();
//        int int59 = day42.compareTo((java.lang.Object) comparable58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getSerialIndex();
//        int int62 = day60.getMonth();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        long long64 = day63.getLastMillisecond();
//        int int65 = day60.compareTo((java.lang.Object) day63);
//        java.lang.String str66 = day60.toString();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day60);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        long long69 = day68.getSerialIndex();
//        java.lang.String str70 = day68.toString();
//        long long71 = day68.getSerialIndex();
//        long long72 = day68.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day60, (org.jfree.data.time.RegularTimePeriod) day68);
//        java.lang.Class class74 = timeSeries73.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-2019" + "'", str19.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 43626L + "'", long61 == 43626L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 43626L + "'", long69 == 43626L);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 43626L + "'", long71 == 43626L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560150000000L + "'", long72 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNull(class74);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
//        long long11 = fixedMillisecond9.getFirstMillisecond();
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        int int19 = day14.compareTo((java.lang.Object) day17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass23 = day22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, "", "", (java.lang.Class) wildcardClass23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
//        java.util.Date date30 = fixedMillisecond26.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date12, timeZone32);
//        boolean boolean35 = timeSeriesDataItem7.equals((java.lang.Object) date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date12);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        java.lang.Class class16 = timeSeries6.getTimePeriodClass();
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        try {
//            java.lang.Number number20 = timeSeries6.getValue((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class16);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        long long1 = month0.getLastMillisecond();
//        int int2 = month0.getMonth();
//        int int3 = month0.getYearValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
//        long long7 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date8 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        timeSeries16.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str19 = timeSeries16.getDomainDescription();
//        timeSeries16.setMaximumItemAge((long) 2);
//        timeSeries16.setDomainDescription("April");
//        int int24 = day9.compareTo((java.lang.Object) timeSeries16);
//        int int25 = month0.compareTo((java.lang.Object) int24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        org.jfree.data.time.Year year2 = month0.getYear();
//        int int3 = month0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
//        long long5 = month0.getLastMillisecond();
//        org.jfree.data.time.Year year6 = month0.getYear();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        int int12 = day7.compareTo((java.lang.Object) day10);
//        org.jfree.data.time.SerialDate serialDate13 = day10.getSerialDate();
//        long long14 = day10.getFirstMillisecond();
//        boolean boolean15 = month0.equals((java.lang.Object) day10);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str10 = serialDate9.toString();
        java.lang.String str11 = serialDate9.toString();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
        int int23 = spreadsheetDate1.toSerial();
        java.util.Date date24 = spreadsheetDate1.toDate();
        int int25 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.lang.String str28 = year27.toString();
        long long29 = year27.getSerialIndex();
        java.util.Date date30 = year27.getEnd();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date30);
        serialDate33.setDescription("");
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(2019, serialDate33);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.String str39 = year38.toString();
        long long40 = year38.getSerialIndex();
        java.util.Date date41 = year38.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = serialDate33.getEndOfCurrentMonth(serialDate45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        long long48 = month47.getLastMillisecond();
        int int49 = month47.getMonth();
        int int50 = month47.getYearValue();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        java.lang.String str54 = year53.toString();
        long long55 = year53.getSerialIndex();
        java.util.Date date56 = year53.getEnd();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date56);
        java.lang.String str60 = serialDate59.toString();
        java.lang.String str61 = serialDate59.toString();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass63 = day62.getClass();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.lang.String str65 = year64.toString();
        long long66 = year64.getSerialIndex();
        java.util.Date date67 = year64.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date67, timeZone68);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate59, (java.lang.Class) wildcardClass63);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addMonths(6, serialDate59);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate59);
        int int73 = month47.compareTo((java.lang.Object) serialDate72);
        boolean boolean75 = spreadsheetDate1.isInRange(serialDate33, serialDate72, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1561964399999L + "'", long48 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "31-December-2019" + "'", str60.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "31-December-2019" + "'", str61.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2019" + "'", str65.equals("2019"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 2019L + "'", long66 == 2019L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, (int) (short) 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        int int4 = year0.getYear();
        long long5 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = null;
//        try {
//            timeSeries6.add(timeSeriesDataItem12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass11 = day10.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        java.util.Date date18 = fixedMillisecond14.getStart();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass20 = day19.getClass();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.lang.String str22 = year21.toString();
        long long23 = year21.getSerialIndex();
        java.util.Date date24 = year21.getEnd();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date18, timeZone25);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, class28);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(class28);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        java.lang.String str3 = month0.toString();
        long long4 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        long long6 = fixedMillisecond4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4);
        long long9 = month8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2649600000L) + "'", long9 == (-2649600000L));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        timeSeriesDataItem7.setValue((java.lang.Number) 0.0f);
//        java.lang.Number number10 = timeSeriesDataItem7.getValue();
//        timeSeriesDataItem7.setValue((java.lang.Number) (short) 1);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getMonth();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "10-June-2019", "ERROR : Relative To String", class18);
//        boolean boolean20 = timeSeriesDataItem7.equals((java.lang.Object) day13);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0f + "'", number10.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        long long17 = month16.getLastMillisecond();
//        int int18 = month16.getMonth();
//        java.lang.String str19 = month16.toString();
//        long long20 = month16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month16.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 11);
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeSeries24);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(520764324);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 7, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date6, timeZone11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date6);
        boolean boolean17 = spreadsheetDate1.equals((java.lang.Object) date6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getLastMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getStart();
        boolean boolean11 = month0.equals((java.lang.Object) fixedMillisecond5);
        long long12 = month0.getSerialIndex();
        java.util.Date date13 = month0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) 1546329600000L);
//        java.lang.Number number26 = timeSeriesDataItem25.getValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        long long15 = fixedMillisecond13.getFirstMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
//        java.util.Date date19 = fixedMillisecond13.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192025075L + "'", long14 == 1560192025075L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192025075L + "'", long15 == 1560192025075L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        long long5 = month0.getLastMillisecond();
        org.jfree.data.time.Year year6 = month0.getYear();
        java.util.Date date7 = month0.getStart();
        java.lang.String str8 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getLastMillisecond();
//        int int11 = month9.getMonth();
//        int int12 = month9.getYearValue();
//        int int13 = month9.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 93297991906800000L);
//        int int16 = month9.getMonth();
//        long long17 = month9.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getMonth();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day13, "10-June-2019", "ERROR : Relative To String", class18);
//        timeSeries19.setDomainDescription("2019");
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.addAndOrUpdate(timeSeries19);
//        boolean boolean24 = timeSeries19.equals((java.lang.Object) (-2208441600000L));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries6.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
//        serialDate8.setDescription("");
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.lang.String str14 = year13.toString();
//        long long15 = year13.getSerialIndex();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(10, serialDate20);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass34 = day33.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "", "", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "June 2019", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate22);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        serialDate7.setDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(2019, serialDate7);
        serialDate10.setDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        boolean boolean11 = timeSeries6.isEmpty();
//        timeSeries6.setMaximumItemAge((long) 5);
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        long long15 = fixedMillisecond13.getFirstMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
//        java.lang.Class class19 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, class19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560192025520L + "'", long14 == 1560192025520L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560192025520L + "'", long15 == 1560192025520L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.lang.String str11 = serialDate10.toString();
        java.lang.String str12 = serialDate10.toString();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass14 = day13.getClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond2.getLastMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (-1L));
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        long long11 = year9.getSerialIndex();
        java.util.Date date12 = year9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.lang.String str16 = serialDate15.toString();
        java.lang.String str17 = serialDate15.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass19 = day18.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        long long22 = year20.getSerialIndex();
        java.util.Date date23 = year20.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate15, (java.lang.Class) wildcardClass19);
        java.lang.String str27 = timeSeries26.getDomainDescription();
        boolean boolean28 = timeSeriesDataItem8.equals((java.lang.Object) str27);
        boolean boolean29 = year0.equals((java.lang.Object) timeSeriesDataItem8);
        int int30 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "31-December-2019" + "'", str16.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getEnd();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        java.lang.String str24 = timeSeries12.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.lang.String str11 = serialDate10.toString();
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
//        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
//        int int24 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean40 = spreadsheetDate2.isInRange(serialDate31, serialDate38, 10);
//        int int41 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(6);
//        boolean boolean45 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        java.lang.String str46 = spreadsheetDate44.getDescription();
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNull(str46);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date25);
//        java.lang.String str29 = serialDate28.toString();
//        java.lang.String str30 = serialDate28.toString();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass32 = day31.getClass();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone37);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate28, (java.lang.Class) wildcardClass32);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears(12, serialDate28);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getSerialIndex();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getLastMillisecond();
//        int int46 = day41.compareTo((java.lang.Object) day44);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass50 = day49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "", "", (java.lang.Class) wildcardClass50);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate28, (java.lang.Class) wildcardClass50);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, "Wed Dec 31 16:00:00 PST 1969", "org.jfree.data.general.SeriesChangeEvent[source=0]", (java.lang.Class) wildcardClass50);
//        java.lang.String str54 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate56 = serialDate7.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate7);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        java.lang.Comparable comparable18 = timeSeries6.getKey();
//        try {
//            timeSeries6.removeAgedItems(10L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(comparable18);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.String str10 = timeSeries6.getDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNull(str10);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass4 = day3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
//        java.util.Date date11 = fixedMillisecond7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone18);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getSerialIndex();
//        java.util.Date date28 = year25.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date28);
//        java.lang.String str32 = serialDate31.toString();
//        java.lang.String str33 = serialDate31.toString();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass35 = day34.getClass();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        java.lang.String str37 = year36.toString();
//        long long38 = year36.getSerialIndex();
//        java.util.Date date39 = year36.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31, (java.lang.Class) wildcardClass35);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(12, serialDate31);
//        boolean boolean44 = spreadsheetDate23.isOn(serialDate31);
//        int int45 = spreadsheetDate23.toSerial();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        long long47 = day46.getSerialIndex();
//        int int48 = day46.getMonth();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getLastMillisecond();
//        int int51 = day46.compareTo((java.lang.Object) day49);
//        org.jfree.data.time.SerialDate serialDate52 = day49.getSerialDate();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        java.lang.String str54 = year53.toString();
//        long long55 = year53.getSerialIndex();
//        java.util.Date date56 = year53.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date56);
//        boolean boolean61 = spreadsheetDate23.isInRange(serialDate52, serialDate59, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
//        java.lang.String str66 = year65.toString();
//        long long67 = year65.getSerialIndex();
//        java.util.Date date68 = year65.getEnd();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date68, timeZone69);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(date68);
//        java.lang.String str72 = serialDate71.toString();
//        java.lang.String str73 = serialDate71.toString();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass75 = day74.getClass();
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
//        java.lang.String str77 = year76.toString();
//        long long78 = year76.getSerialIndex();
//        java.util.Date date79 = year76.getEnd();
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date79, timeZone80);
//        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate71, (java.lang.Class) wildcardClass75);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addYears(12, serialDate71);
//        boolean boolean84 = spreadsheetDate63.isOn(serialDate71);
//        boolean boolean85 = spreadsheetDate23.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        java.util.Date date86 = spreadsheetDate23.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond(date86);
//        java.util.TimeZone timeZone88 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date86, timeZone88);
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date86);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 8 + "'", int45 == 8);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 43626L + "'", long47 == 43626L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2019" + "'", str66.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "31-December-2019" + "'", str72.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "31-December-2019" + "'", str73.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "2019" + "'", str77.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 2019L + "'", long78 == 2019L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        java.util.Date date64 = spreadsheetDate1.toDate();
//        int int65 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond67.next();
//        long long69 = fixedMillisecond67.getFirstMillisecond();
//        java.util.Date date70 = fixedMillisecond67.getTime();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        long long73 = day72.getSerialIndex();
//        int int74 = day72.getMonth();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        long long76 = day75.getLastMillisecond();
//        int int77 = day72.compareTo((java.lang.Object) day75);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass81 = day80.getClass();
//        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day72, "", "", (java.lang.Class) wildcardClass81);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar85 = null;
//        long long86 = fixedMillisecond84.getFirstMillisecond(calendar85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond84.next();
//        java.util.Date date88 = fixedMillisecond84.getStart();
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date88);
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date88, timeZone90);
//        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month(date70, timeZone90);
//        boolean boolean93 = spreadsheetDate1.equals((java.lang.Object) month92);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 100L + "'", long69 == 100L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43626L + "'", long73 == 43626L);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560236399999L + "'", long76 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 100L + "'", long86 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        long long3 = day2.getSerialIndex();
//        int int4 = day2.getMonth();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        int int7 = day2.compareTo((java.lang.Object) day5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, "", "", (java.lang.Class) wildcardClass11);
//        timeSeries12.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener14);
//        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) timeSeries12);
//        java.util.Date date17 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(8);
//        int int20 = spreadsheetDate19.getDayOfMonth();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date25);
//        serialDate28.setDescription("");
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(2019, serialDate28);
//        java.lang.String str32 = serialDate28.getDescription();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date36);
//        java.lang.String str40 = serialDate39.toString();
//        java.lang.String str41 = serialDate39.toString();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass43 = day42.getClass();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        java.lang.String str45 = year44.toString();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate39, (java.lang.Class) wildcardClass43);
//        boolean boolean51 = spreadsheetDate19.isInRange(serialDate28, serialDate39);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        java.lang.String str54 = year53.toString();
//        long long55 = year53.getSerialIndex();
//        java.util.Date date56 = year53.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date56);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate59);
//        java.lang.String str61 = serialDate60.getDescription();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(serialDate60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond64.next();
//        long long66 = fixedMillisecond64.getFirstMillisecond();
//        java.util.Date date67 = fixedMillisecond64.getTime();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(date67);
//        boolean boolean71 = spreadsheetDate19.isInRange(serialDate60, serialDate69, 5);
//        boolean boolean72 = spreadsheetDate1.isOnOrBefore(serialDate69);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-2019" + "'", str40.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-December-2019" + "'", str41.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNull(str61);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 100L + "'", long66 == 100L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
//        timeSeries2.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        long long11 = year9.getSerialIndex();
//        java.util.Date date12 = year9.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        int int17 = day15.getMonth();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, "10-June-2019", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries2.addAndOrUpdate(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeries23);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int27 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        try {
//            timeSeries15.delete((int) (byte) 0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        timeSeries6.setDomainDescription("April");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate(regularTimePeriod18, (java.lang.Number) 10.0f);
//        timeSeries6.clear();
//        timeSeries6.removeAgedItems(true);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getSerialIndex();
//        java.util.Date date28 = year25.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date28);
//        java.lang.String str32 = serialDate31.toString();
//        java.lang.String str33 = serialDate31.toString();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass35 = day34.getClass();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        java.lang.String str37 = year36.toString();
//        long long38 = year36.getSerialIndex();
//        java.util.Date date39 = year36.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone40);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31, (java.lang.Class) wildcardClass35);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(12, serialDate31);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getSerialIndex();
//        int int46 = day44.getMonth();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getLastMillisecond();
//        int int49 = day44.compareTo((java.lang.Object) day47);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day44, "", "", (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.previous();
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) year56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        java.lang.String str60 = year59.toString();
//        long long61 = year59.getSerialIndex();
//        java.util.Date date62 = year59.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year59, (double) 1L);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
//        long long66 = day65.getSerialIndex();
//        int int67 = day65.getMonth();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day65, "10-June-2019", "ERROR : Relative To String", class70);
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timeSeries71.addPropertyChangeListener(propertyChangeListener72);
//        java.lang.String str74 = timeSeries71.getDomainDescription();
//        boolean boolean75 = timeSeriesDataItem64.equals((java.lang.Object) timeSeries71);
//        timeSeries71.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener78 = null;
//        timeSeries71.removeChangeListener(seriesChangeListener78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        long long81 = day80.getLastMillisecond();
//        java.lang.Number number82 = timeSeries71.getValue((org.jfree.data.time.RegularTimePeriod) day80);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day80, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year56, (org.jfree.data.time.RegularTimePeriod) day80);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-December-2019" + "'", str32.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-2019" + "'", str33.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560236399999L + "'", long48 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019" + "'", str60.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 43626L + "'", long66 == 43626L);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "10-June-2019" + "'", str74.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560236399999L + "'", long81 == 1560236399999L);
//        org.junit.Assert.assertNull(number82);
//        org.junit.Assert.assertNotNull(timeSeries85);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str10 = serialDate9.toString();
        java.lang.String str11 = serialDate9.toString();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
        java.util.Date date23 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries2.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        long long3 = fixedMillisecond1.getFirstMillisecond();
//        long long4 = fixedMillisecond1.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "10-June-2019", "ERROR : Relative To String", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        boolean boolean15 = timeSeries13.isEmpty();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass20 = day19.getClass();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass20);
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries13.addAndOrUpdate(timeSeries21);
//        boolean boolean23 = fixedMillisecond1.equals((java.lang.Object) timeSeries22);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        java.util.List list3 = timeSeries2.getItems();
        timeSeries2.removeAgedItems(true);
        org.junit.Assert.assertNotNull(list3);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        long long11 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        try {
//            org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate41.getPreviousDayOfWeek((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.lang.String str11 = serialDate10.toString();
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
//        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
//        int int24 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean40 = spreadsheetDate2.isInRange(serialDate31, serialDate38, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        java.lang.String str45 = year44.toString();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.lang.String str51 = serialDate50.toString();
//        java.lang.String str52 = serialDate50.toString();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass54 = day53.getClass();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        java.lang.String str56 = year55.toString();
//        long long57 = year55.getSerialIndex();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date58, timeZone59);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate50, (java.lang.Class) wildcardClass54);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears(12, serialDate50);
//        boolean boolean63 = spreadsheetDate42.isOn(serialDate50);
//        boolean boolean64 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        java.lang.String str68 = year67.toString();
//        long long69 = year67.getSerialIndex();
//        java.util.Date date70 = year67.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70, timeZone71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date70);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate73);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        java.lang.String str76 = year75.toString();
//        long long77 = year75.getSerialIndex();
//        java.util.Date date78 = year75.getEnd();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date78, timeZone79);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date78);
//        java.lang.String str82 = serialDate81.toString();
//        java.lang.String str83 = serialDate81.toString();
//        org.jfree.data.time.SerialDate serialDate84 = serialDate74.getEndOfCurrentMonth(serialDate81);
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays(0, serialDate81);
//        boolean boolean86 = spreadsheetDate2.isOn(serialDate81);
//        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate81);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-2019" + "'", str52.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019" + "'", str68.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "2019" + "'", str76.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 2019L + "'", long77 == 2019L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "31-December-2019" + "'", str82.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "31-December-2019" + "'", str83.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(serialDate87);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException13);
        java.lang.Throwable[] throwableArray16 = seriesException13.getSuppressed();
        java.lang.Throwable[] throwableArray17 = seriesException13.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        boolean boolean2 = month0.equals((java.lang.Object) 2019L);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass7 = day6.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Date date14 = fixedMillisecond10.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone21);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass28 = day27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getFirstMillisecond(calendar32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
        java.util.Date date35 = fixedMillisecond31.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass37 = day36.getClass();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.String str39 = year38.toString();
        long long40 = year38.getSerialIndex();
        java.util.Date date41 = year38.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date35, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date14, timeZone42);
        int int46 = month0.compareTo((java.lang.Object) day45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        int int18 = day16.getMonth();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getLastMillisecond();
//        int int21 = day16.compareTo((java.lang.Object) day19);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getSerialIndex();
//        int int24 = day22.getMonth();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day22, "10-June-2019", "ERROR : Relative To String", class27);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries28.addPropertyChangeListener(propertyChangeListener29);
//        boolean boolean31 = day16.equals((java.lang.Object) propertyChangeListener29);
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.clear();
//        timeSeries12.setRangeDescription("Nearest");
//        java.lang.Class class20 = timeSeries12.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(class20);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        timeSeries6.setNotify(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        serialDate7.setDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(2019, serialDate7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        int int12 = day11.getDayOfMonth();
        java.lang.String str13 = day11.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "11-July-2025" + "'", str13.equals("11-July-2025"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        int int4 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate12.setDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(2019, serialDate12);
        java.lang.String str16 = serialDate12.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.lang.String str24 = serialDate23.toString();
        java.lang.String str25 = serialDate23.toString();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass27 = day26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        long long30 = year28.getSerialIndex();
        java.util.Date date31 = year28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone32);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate23, (java.lang.Class) wildcardClass27);
        boolean boolean35 = spreadsheetDate3.isInRange(serialDate12, serialDate23);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.lang.String str38 = year37.toString();
        long long39 = year37.getSerialIndex();
        java.util.Date date40 = year37.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40, timeZone41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date40);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate43);
        java.lang.String str45 = serialDate44.getDescription();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.next();
        long long50 = fixedMillisecond48.getFirstMillisecond();
        java.util.Date date51 = fixedMillisecond48.getTime();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date51);
        boolean boolean55 = spreadsheetDate3.isInRange(serialDate44, serialDate53, 5);
        boolean boolean56 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        java.util.Date date11 = fixedMillisecond7.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone18);
        java.util.Date date21 = regularTimePeriod20.getStart();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        java.lang.String str19 = timeSeries12.getDomainDescription();
//        timeSeries12.setDescription("");
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
//        try {
//            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year22, (double) 1561964399999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        long long14 = year12.getSerialIndex();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date15, timeZone20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date15, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date9, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date5, timeZone23);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(serialDate27);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        timeSeriesDataItem7.setValue((java.lang.Number) 0.0f);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0f);
//        java.lang.String str11 = seriesChangeEvent10.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0.0]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=0.0]"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class9);
//        timeSeries10.setMaximumItemAge((long) 2019);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass17 = day16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass17);
//        java.lang.Object obj19 = timeSeries18.clone();
//        java.util.Collection collection20 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond22.getLastMillisecond(calendar25);
//        long long27 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        long long29 = fixedMillisecond28.getFirstMillisecond();
//        long long30 = fixedMillisecond28.getFirstMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond28.peg(calendar33);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        boolean boolean36 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond28);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560192033722L + "'", long29 == 1560192033722L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560192033722L + "'", long30 == 1560192033722L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560192033722L + "'", long32 == 1560192033722L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date14);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate17);
//        java.lang.String str19 = serialDate18.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        long long25 = year23.getSerialIndex();
//        java.util.Date date26 = year23.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date26);
//        java.lang.String str30 = serialDate29.toString();
//        java.lang.String str31 = serialDate29.toString();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass33 = day32.getClass();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getSerialIndex();
//        java.util.Date date37 = year34.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate29, (java.lang.Class) wildcardClass33);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears(12, serialDate29);
//        boolean boolean42 = spreadsheetDate21.isOn(serialDate29);
//        int int43 = spreadsheetDate21.toSerial();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getSerialIndex();
//        int int46 = day44.getMonth();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getLastMillisecond();
//        int int49 = day44.compareTo((java.lang.Object) day47);
//        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        java.lang.String str52 = year51.toString();
//        long long53 = year51.getSerialIndex();
//        java.util.Date date54 = year51.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54, timeZone55);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date54);
//        boolean boolean59 = spreadsheetDate21.isInRange(serialDate50, serialDate57, 10);
//        java.lang.String str60 = spreadsheetDate21.getDescription();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        java.lang.String str62 = year61.toString();
//        long long63 = year61.getSerialIndex();
//        java.util.Date date64 = year61.getEnd();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date64, timeZone65);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date64);
//        serialDate67.setDescription("");
//        boolean boolean70 = spreadsheetDate21.isOn(serialDate67);
//        boolean boolean71 = spreadsheetDate1.isInRange(serialDate18, serialDate67);
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
//        java.lang.String str74 = year73.toString();
//        long long75 = year73.getSerialIndex();
//        java.util.Date date76 = year73.getEnd();
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date76, timeZone77);
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(date76);
//        java.lang.String str80 = serialDate79.toString();
//        java.lang.String str81 = serialDate79.toString();
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass83 = day82.getClass();
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
//        java.lang.String str85 = year84.toString();
//        long long86 = year84.getSerialIndex();
//        java.util.Date date87 = year84.getEnd();
//        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass83, date87, timeZone88);
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate79, (java.lang.Class) wildcardClass83);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addMonths(6, serialDate79);
//        java.lang.String str92 = serialDate91.getDescription();
//        boolean boolean93 = spreadsheetDate1.isOnOrAfter(serialDate91);
//        int int94 = spreadsheetDate1.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-2019" + "'", str30.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-2019" + "'", str31.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560236399999L + "'", long48 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "2019" + "'", str52.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 2019L + "'", long53 == 2019L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNull(str60);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "2019" + "'", str74.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2019L + "'", long75 == 2019L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "31-December-2019" + "'", str80.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "31-December-2019" + "'", str81.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "2019" + "'", str85.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 2019L + "'", long86 == 2019L);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone88);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertNull(str92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 7 + "'", int94 == 7);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long58 = fixedMillisecond57.getMiddleMillisecond();
//        int int59 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
//        timeSeries6.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 100L + "'", long58 == 100L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        java.lang.String str67 = year66.toString();
//        long long68 = year66.getSerialIndex();
//        java.util.Date date69 = year66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date69);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate72);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
//        java.lang.String str75 = year74.toString();
//        long long76 = year74.getSerialIndex();
//        java.util.Date date77 = year74.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date77, timeZone78);
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(date77);
//        java.lang.String str81 = serialDate80.toString();
//        java.lang.String str82 = serialDate80.toString();
//        org.jfree.data.time.SerialDate serialDate83 = serialDate73.getEndOfCurrentMonth(serialDate80);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(0, serialDate80);
//        boolean boolean85 = spreadsheetDate1.isOn(serialDate80);
//        try {
//            org.jfree.data.time.SerialDate serialDate87 = serialDate80.getFollowingDayOfWeek((-447));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "2019" + "'", str75.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2019L + "'", long76 == 2019L);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "31-December-2019" + "'", str81.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "31-December-2019" + "'", str82.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = month0.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        int int10 = day8.getMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getLastMillisecond();
//        int int13 = day8.compareTo((java.lang.Object) day11);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass17 = day16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, "", "", (java.lang.Class) wildcardClass17);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 10, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.removeAgedItems(true);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        timeSeries2.setNotify(false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass9 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "", (java.lang.Class) wildcardClass9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
//        java.util.Date date16 = fixedMillisecond12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date16, timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int23 = day20.compareTo((java.lang.Object) 'a');
//        java.util.Date date24 = day20.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond28.previous();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond28);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        timeSeries6.clear();
//        boolean boolean11 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getSerialIndex();
//        int int14 = day12.getMonth();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, "10-June-2019", "ERROR : Relative To String", class17);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass22 = day21.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (double) 24234L);
//        long long26 = day21.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        java.lang.String str6 = year5.toString();
//        long long7 = year5.getSerialIndex();
//        java.util.Date date8 = year5.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
//        java.lang.String str12 = serialDate11.toString();
//        java.lang.String str13 = serialDate11.toString();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.lang.String str17 = year16.toString();
//        long long18 = year16.getSerialIndex();
//        java.util.Date date19 = year16.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
//        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
//        int int25 = spreadsheetDate3.toSerial();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        long long27 = day26.getSerialIndex();
//        int int28 = day26.getMonth();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getLastMillisecond();
//        int int31 = day26.compareTo((java.lang.Object) day29);
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date36);
//        boolean boolean41 = spreadsheetDate3.isInRange(serialDate32, serialDate39, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        java.lang.String str46 = year45.toString();
//        long long47 = year45.getSerialIndex();
//        java.util.Date date48 = year45.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.lang.String str52 = serialDate51.toString();
//        java.lang.String str53 = serialDate51.toString();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass55 = day54.getClass();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate51, (java.lang.Class) wildcardClass55);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addYears(12, serialDate51);
//        boolean boolean64 = spreadsheetDate43.isOn(serialDate51);
//        boolean boolean65 = spreadsheetDate3.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        java.util.Date date66 = spreadsheetDate3.toDate();
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
//        java.lang.String str69 = year68.toString();
//        long long70 = year68.getSerialIndex();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date71, timeZone72);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date71);
//        serialDate74.setDescription("");
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addMonths(11, serialDate74);
//        boolean boolean78 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate3, serialDate74);
//        int int79 = spreadsheetDate1.toSerial();
//        int int80 = spreadsheetDate1.toSerial();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560236399999L + "'", long30 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2019" + "'", str46.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-2019" + "'", str52.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2019" + "'", str69.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 10 + "'", int79 == 10);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 10 + "'", int80 == 10);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.clear();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        int int5 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 1560191965221L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.removeAgedItems(true);
        boolean boolean5 = timeSeries2.getNotify();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str7 = serialDate6.toString();
//        java.lang.String str8 = serialDate6.toString();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
//        java.lang.String str18 = timeSeries17.getDomainDescription();
//        java.lang.Object obj19 = timeSeries17.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.lang.String str25 = year24.toString();
//        long long26 = year24.getSerialIndex();
//        java.util.Date date27 = year24.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) 1L);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int32 = day30.getMonth();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day30, "10-June-2019", "ERROR : Relative To String", class35);
//        boolean boolean37 = timeSeriesDataItem29.equals((java.lang.Object) timeSeries36);
//        java.lang.Object obj38 = timeSeriesDataItem29.clone();
//        int int39 = fixedMillisecond21.compareTo((java.lang.Object) timeSeriesDataItem29);
//        try {
//            timeSeries17.add(timeSeriesDataItem29, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray11 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray12 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray13 = seriesException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        java.lang.String str37 = year36.toString();
//        long long38 = year36.getSerialIndex();
//        java.util.Date date39 = year36.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date39);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate42);
//        java.lang.String str44 = serialDate43.getDescription();
//        int int45 = year32.compareTo((java.lang.Object) str44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
//        java.lang.String str48 = year47.toString();
//        long long49 = year47.getSerialIndex();
//        java.util.Date date50 = year47.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50, timeZone51);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date50);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate53);
//        int int55 = year32.compareTo((java.lang.Object) serialDate53);
//        try {
//            org.jfree.data.time.SerialDate serialDate57 = serialDate53.getFollowingDayOfWeek((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNull(str44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 2019L + "'", long49 == 2019L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.lang.String str13 = serialDate12.toString();
        java.lang.String str14 = serialDate12.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(12, serialDate12);
        boolean boolean25 = spreadsheetDate4.isOn(serialDate12);
        int int26 = spreadsheetDate4.getDayOfMonth();
        boolean boolean27 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(8);
        int int30 = spreadsheetDate29.getDayOfMonth();
        boolean boolean31 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int32 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 7 + "'", int26 == 7);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("9-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-460), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 1);
//        java.lang.String str5 = day0.toString();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        timeSeries6.setDomainDescription("April");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate(regularTimePeriod18, (java.lang.Number) 10.0f);
//        timeSeries6.clear();
//        timeSeries6.removeAgedItems(true);
//        java.lang.Object obj24 = timeSeries6.clone();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(obj24);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getSerialIndex();
//        int int34 = day32.getMonth();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day32, "10-June-2019", "ERROR : Relative To String", class37);
//        java.lang.Object obj39 = timeSeries38.clone();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
//        timeSeries38.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        java.lang.String str46 = month45.toString();
//        boolean boolean47 = timeSeries38.equals((java.lang.Object) month45);
//        timeSeries38.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries31.addAndOrUpdate(timeSeries38);
//        java.lang.Object obj50 = timeSeries38.clone();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(obj39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNotNull(obj50);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        timeSeries17.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries17.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long28 = day27.getMiddleMillisecond();
        long long29 = day27.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208398400001L) + "'", long28 == (-2208398400001L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 8L + "'", long29 == 8L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1559372400000L);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.lang.String str11 = serialDate10.toString();
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
//        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
//        int int24 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean40 = spreadsheetDate2.isInRange(serialDate31, serialDate38, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        java.lang.String str45 = year44.toString();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.lang.String str51 = serialDate50.toString();
//        java.lang.String str52 = serialDate50.toString();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass54 = day53.getClass();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        java.lang.String str56 = year55.toString();
//        long long57 = year55.getSerialIndex();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date58, timeZone59);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate50, (java.lang.Class) wildcardClass54);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears(12, serialDate50);
//        boolean boolean63 = spreadsheetDate42.isOn(serialDate50);
//        boolean boolean64 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        java.util.Date date65 = spreadsheetDate2.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond68.next();
//        long long70 = fixedMillisecond68.getFirstMillisecond();
//        java.util.Date date71 = fixedMillisecond68.getTime();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date71);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate73);
//        boolean boolean75 = spreadsheetDate2.isOnOrBefore(serialDate73);
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addDays((-1), serialDate73);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-2019" + "'", str52.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 100L + "'", long70 == 100L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNotNull(serialDate76);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        java.lang.String str14 = timeSeries6.getDomainDescription();
//        timeSeries6.setDescription("ERROR : Relative To String");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries6.addChangeListener(seriesChangeListener17);
//        java.util.Collection collection19 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        int int22 = day20.getYear();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        int int25 = day23.getMonth();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day23, "10-June-2019", "ERROR : Relative To String", class28);
//        timeSeries29.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str32 = timeSeries29.getDomainDescription();
//        timeSeries29.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        java.lang.String str36 = year35.toString();
//        long long37 = year35.getSerialIndex();
//        java.util.Date date38 = year35.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year35.previous();
//        timeSeries29.delete(regularTimePeriod39);
//        boolean boolean41 = day20.equals((java.lang.Object) timeSeries29);
//        int int42 = day20.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 1560236399999L);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries6.addChangeListener(seriesChangeListener45);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43626L + "'", long24 == 43626L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        java.lang.String str17 = year16.toString();
//        long long18 = year16.getSerialIndex();
//        java.util.Date date19 = year16.getEnd();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        long long22 = year20.getSerialIndex();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19, timeZone24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date19);
//        int int28 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) day27);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        timeSeries31.removeAgedItems(1577779200000L, true);
//        java.util.List list35 = timeSeries31.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 1560191963645L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(list35);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//    }
//}

