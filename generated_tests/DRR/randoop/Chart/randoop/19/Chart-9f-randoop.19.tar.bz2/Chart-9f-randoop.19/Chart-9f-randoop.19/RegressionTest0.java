import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(8, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries6.getTimePeriod(6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getYear();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day8, (double) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(2019, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(collection9);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, 9, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        try {
            timeSeries2.delete(1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        try {
//            timeSeries12.update(4, (java.lang.Number) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        try {
            timeSeries2.update((int) 'a', (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
//        try {
//            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year22, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("31-December-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.createCopy(2, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        serialDate6.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate6.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.clear();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year8, (double) 1.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        long long11 = year9.getSerialIndex();
//        java.util.Date date12 = year9.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        int int17 = day15.getMonth();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, "10-June-2019", "ERROR : Relative To String", class20);
//        boolean boolean22 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries21);
//        try {
//            timeSeries6.add(timeSeriesDataItem14, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "April" + "'", str2.equals("April"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate6.getNearestDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        timeSeriesDataItem5.setValue((java.lang.Number) 2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getFirstMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 10, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191942399L + "'", long15 == 1560191942399L);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        java.lang.String str19 = timeSeries12.getDescription();
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        long long22 = year20.getSerialIndex();
//        java.util.Date date23 = year20.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year20.previous();
//        try {
//            timeSeries12.add(regularTimePeriod24, (java.lang.Number) 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        boolean boolean13 = timeSeries6.isEmpty();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        int int15 = day13.getDayOfMonth();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day13, 1.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) (short) 1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) ' ', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.String str10 = timeSeries6.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str10.equals("SerialDate.weekInMonthToString(): invalid code."));
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass2 = day1.getClass();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date6, timeZone7);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        java.lang.String str19 = timeSeries12.getDescription();
//        try {
//            java.lang.Number number21 = timeSeries12.getValue((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(str19);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem(regularTimePeriod9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        java.lang.String str18 = timeSeries6.getRangeDescription();
//        try {
//            timeSeries6.removeAgedItems((long) '4', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR : Relative To String" + "'", str18.equals("ERROR : Relative To String"));
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        long long11 = fixedMillisecond10.getFirstMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) '4', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560191945177L + "'", long11 == 1560191945177L);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener8);
//        try {
//            timeSeries6.setMaximumItemAge((-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date0, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2019, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        int int7 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        serialDate7.setDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(2019, serialDate7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate10.getNearestDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.next();
//        long long17 = fixedMillisecond15.getFirstMillisecond();
//        java.util.Date date18 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 'a', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        long long12 = year10.getSerialIndex();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1L);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        int int18 = day16.getMonth();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, "10-June-2019", "ERROR : Relative To String", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getDomainDescription();
//        boolean boolean26 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries22);
//        timeSeries22.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries22.removeChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        java.lang.Number number33 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getSerialIndex();
//        int int37 = day34.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        long long39 = day38.getSerialIndex();
//        int int40 = day38.getMonth();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getLastMillisecond();
//        int int43 = day38.compareTo((java.lang.Object) day41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day38.previous();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day34, (org.jfree.data.time.RegularTimePeriod) day38);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day38, (double) 1L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNull(number33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43626L + "'", long39 == 43626L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560236399999L + "'", long42 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj14 = timeSeriesDataItem5.clone();
//        java.lang.Number number15 = timeSeriesDataItem5.getValue();
//        java.lang.Number number16 = timeSeriesDataItem5.getValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0d + "'", number16.equals(1.0d));
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        long long12 = year10.getSerialIndex();
        java.util.Date date13 = year10.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.lang.String str17 = serialDate16.toString();
        java.lang.String str18 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate19 = serialDate9.getEndOfCurrentMonth(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        try {
//            timeSeries12.removeAgedItems((long) (byte) 0, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
//        try {
//            java.lang.Number number11 = timeSeries6.getValue(regularTimePeriod10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        long long12 = year10.getSerialIndex();
        java.util.Date date13 = year10.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.lang.String str17 = serialDate16.toString();
        java.lang.String str18 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate19 = serialDate9.getEndOfCurrentMonth(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-2019" + "'", str17.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-2019" + "'", str18.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries6.getTimePeriod((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.lang.String str8 = serialDate7.toString();
        java.lang.String str9 = serialDate7.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass11 = day10.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        long long14 = year12.getSerialIndex();
        java.util.Date date15 = year12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
        java.lang.String str20 = serialDate19.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2019);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        int int12 = day11.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate6.getNearestDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries6.getTimePeriod(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        boolean boolean7 = day3.equals((java.lang.Object) (byte) 0);
//        long long8 = day3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries6.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        int int10 = timeSeries6.getItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        int int16 = day14.getMonth();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, "10-June-2019", "ERROR : Relative To String", class19);
//        java.lang.Object obj21 = timeSeries20.clone();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) day22);
//        try {
//            timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 10L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43626L + "'", long23 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException7.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries6.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10, 12, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) 1L);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "10-June-2019", "ERROR : Relative To String", class12);
//        boolean boolean14 = timeSeriesDataItem6.equals((java.lang.Object) timeSeries13);
//        java.lang.Object obj15 = timeSeriesDataItem6.clone();
//        boolean boolean16 = year0.equals((java.lang.Object) timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass7 = day6.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Date date14 = fixedMillisecond10.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone21);
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries(comparable0, "June 2019", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        java.util.Date date4 = day0.getStart();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        timeSeries6.removeAgedItems(true);
//        timeSeries6.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        try {
//            timeSeries6.removeAgedItems((long) 12, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        try {
//            timeSeries6.update((int) '4', (java.lang.Number) 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass9 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "", (java.lang.Class) wildcardClass9);
//        java.lang.Comparable comparable11 = timeSeries10.getKey();
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries10.removePropertyChangeListener(propertyChangeListener12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(comparable11);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate8.getPreviousDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year56, (double) 1L);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        long long63 = day62.getSerialIndex();
//        int int64 = day62.getMonth();
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day62, "10-June-2019", "ERROR : Relative To String", class67);
//        boolean boolean69 = timeSeriesDataItem61.equals((java.lang.Object) timeSeries68);
//        java.lang.Object obj70 = timeSeriesDataItem61.clone();
//        java.lang.Number number71 = timeSeriesDataItem61.getValue();
//        try {
//            timeSeries6.add(timeSeriesDataItem61);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 43626L + "'", long63 == 43626L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(obj70);
//        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 1.0d + "'", number71.equals(1.0d));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        long long11 = year9.getSerialIndex();
//        java.util.Date date12 = year9.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        int int17 = day15.getMonth();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, "10-June-2019", "ERROR : Relative To String", class20);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
//        java.lang.String str24 = timeSeries21.getDomainDescription();
//        boolean boolean25 = timeSeriesDataItem14.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getLastMillisecond();
//        java.lang.Number number32 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        long long34 = day33.getSerialIndex();
//        int int36 = day33.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getSerialIndex();
//        int int39 = day37.getMonth();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        int int42 = day37.compareTo((java.lang.Object) day40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day37.previous();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day33, (org.jfree.data.time.RegularTimePeriod) day37);
//        java.util.Collection collection45 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries21);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43626L + "'", long34 == 43626L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(collection45);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond12.peg(calendar16);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertNull(number15);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        long long3 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getSerialIndex();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str9 = serialDate8.toString();
        java.lang.String str10 = serialDate8.toString();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass12 = day11.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        long long15 = year13.getSerialIndex();
        java.util.Date date16 = year13.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate8, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(12, serialDate8);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(8, serialDate20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        int int10 = timeSeries6.getItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getFirstMillisecond();
//        long long15 = fixedMillisecond13.getFirstMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
//        try {
//            timeSeries6.delete(8, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560191955186L + "'", long14 == 1560191955186L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191955186L + "'", long15 == 1560191955186L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Object obj20 = null;
//        int int21 = timeSeriesDataItem9.compareTo(obj20);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        serialDate6.setDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SerialDate serialDate40 = null;
//        try {
//            boolean boolean41 = spreadsheetDate1.isOnOrBefore(serialDate40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(11, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "November" + "'", str2.equals("November"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10);
        serialDate2.setDescription("hi!");
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2019, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem22.getPeriod();
//        int int24 = timeSeriesDataItem5.compareTo((java.lang.Object) regularTimePeriod23);
//        java.lang.Number number25 = timeSeriesDataItem5.getValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0d + "'", number25.equals(1.0d));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.getDataItem((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(11);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date7 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date10, timeZone15);
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) date10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Thursday" + "'", str1.equals("Thursday"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
        timeSeries1.clear();
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries6.equals((java.lang.Object) month13);
//        timeSeries6.fireSeriesChanged();
//        try {
//            java.lang.Number number18 = timeSeries6.getValue(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        long long4 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries6.equals((java.lang.Object) month13);
//        timeSeries6.fireSeriesChanged();
//        timeSeries6.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        try {
//            timeSeries6.setMaximumItemCount((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        long long25 = year23.getSerialIndex();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) 1L);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        long long30 = day29.getSerialIndex();
//        int int31 = day29.getMonth();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day29, "10-June-2019", "ERROR : Relative To String", class34);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
//        java.lang.String str38 = timeSeries35.getDomainDescription();
//        boolean boolean39 = timeSeriesDataItem28.equals((java.lang.Object) timeSeries35);
//        java.lang.Comparable comparable40 = timeSeries35.getKey();
//        try {
//            int int41 = spreadsheetDate1.compareTo((java.lang.Object) comparable40);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(comparable40);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.addChangeListener(seriesChangeListener8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getMonth();
//        int int4 = day0.getDayOfMonth();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        long long12 = year10.getSerialIndex();
//        java.lang.Object obj13 = null;
//        int int14 = year10.compareTo(obj13);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year10, (double) 1577779200000L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getSerialIndex();
//        java.lang.String str14 = day12.toString();
//        long long15 = day12.getSerialIndex();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 100L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getYear();
//        java.lang.Number number16 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        try {
//            timeSeries6.delete((int) (byte) 100, 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNull(number16);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.clear();
//        java.util.Collection collection18 = timeSeries12.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(collection18);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        serialDate7.setDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(2019, serialDate7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.String str13 = year12.toString();
        long long14 = year12.getSerialIndex();
        java.util.Date date15 = year12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = serialDate7.getEndOfCurrentMonth(serialDate19);
        java.lang.String str21 = serialDate19.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNull(str21);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        int int15 = day10.compareTo((java.lang.Object) day13);
//        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
//        boolean boolean17 = spreadsheetDate1.isBefore(serialDate16);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setMaximumItemAge((long) 10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        timeSeries12.removeAgedItems(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries12.addChangeListener(seriesChangeListener21);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', (int) '4', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        int int15 = day13.getYear();
//        java.lang.Number number16 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries6.createCopy(2019, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNull(number16);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        long long20 = fixedMillisecond1.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getTimePeriod((-459));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        int int10 = timeSeries6.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.next();
        java.util.Date date7 = fixedMillisecond3.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.String str9 = year8.toString();
        long long10 = year8.getSerialIndex();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        long long20 = year18.getSerialIndex();
        java.util.Date date21 = year18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date17, timeZone22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date17, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date11, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date7, timeZone25);
        try {
            int int29 = spreadsheetDate1.compareTo((java.lang.Object) year28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.String str4 = year3.toString();
        long long5 = year3.getSerialIndex();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str10 = serialDate9.toString();
        java.lang.String str11 = serialDate9.toString();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
        int int23 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        timeSeries6.setDomainDescription("");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        java.lang.String str11 = month10.toString();
        org.jfree.data.time.Year year12 = month10.getYear();
        int int13 = month10.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month10.previous();
        long long15 = month10.getLastMillisecond();
        try {
            int int16 = spreadsheetDate1.compareTo((java.lang.Object) long15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June 2019" + "'", str11.equals("June 2019"));
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = year2.getMiddleMillisecond();
        java.lang.String str4 = year2.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
//        serialDate8.setDescription("");
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.lang.String str14 = year13.toString();
//        long long15 = year13.getSerialIndex();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate19);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth(serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(10, serialDate20);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass34 = day33.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "", "", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "June 2019", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass34);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(class37);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getYear();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.addAndOrUpdate(timeSeries14);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries15.getTimePeriod(12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(11, 11, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.String str34 = timeSeries31.getDomainDescription();
//        boolean boolean35 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        timeSeries31.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.Number number42 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) day40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getSerialIndex();
//        int int46 = day43.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        int int49 = day47.getMonth();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getLastMillisecond();
//        int int52 = day47.compareTo((java.lang.Object) day50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day47.previous();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries6.addAndOrUpdate(timeSeries54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
//        java.lang.String str57 = month56.toString();
//        org.jfree.data.time.Year year58 = month56.getYear();
//        int int59 = month56.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month56.previous();
//        try {
//            timeSeries6.update((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) 0L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43626L + "'", long44 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43626L + "'", long48 == 43626L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560236399999L + "'", long51 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June 2019" + "'", str57.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        timeSeries12.removeAgedItems(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener21);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 1560236399999L);
//        long long21 = day17.getSerialIndex();
//        int int22 = day17.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Class class10 = timeSeries6.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNull(class10);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        timeSeries12.removeAgedItems(true);
//        try {
//            java.lang.Number number22 = timeSeries12.getValue(2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass9 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "", "", (java.lang.Class) wildcardClass9);
//        java.lang.String str11 = timeSeries10.getDescription();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        long long13 = month12.getLastMillisecond();
//        long long14 = month12.getSerialIndex();
//        int int15 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("9-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        boolean boolean8 = timeSeries6.isEmpty();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        java.util.Calendar calendar25 = null;
        try {
            year0.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.removeAgedItems(true);
        java.lang.String str5 = timeSeries2.getRangeDescription();
        try {
            timeSeries2.update(7, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        serialDate8.setDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries11.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Date date3 = year0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener20);
//        timeSeries6.setRangeDescription("Value");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.lang.String str11 = serialDate10.toString();
        java.lang.String str12 = serialDate10.toString();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass14 = day13.getClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
        int int24 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate26 = null;
        org.jfree.data.time.SerialDate serialDate27 = null;
        try {
            boolean boolean29 = spreadsheetDate2.isInRange(serialDate26, serialDate27, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(serialDate25);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        long long3 = year1.getSerialIndex();
//        java.util.Date date4 = year1.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str8 = serialDate7.toString();
//        java.lang.String str9 = serialDate7.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass11 = day10.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        int int22 = day20.getMonth();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        int int25 = day20.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass29 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, "", "", (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, (java.lang.Class) wildcardClass29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
//        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) year32);
//        java.util.Date date35 = year32.getStart();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date35);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.lang.String str4 = year1.toString();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date9);
        java.lang.String str13 = serialDate12.toString();
        java.lang.String str14 = serialDate12.toString();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(6, serialDate12);
        int int25 = year1.compareTo((java.lang.Object) serialDate12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year1.next();
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        int int6 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        java.lang.String str3 = year2.toString();
//        long long4 = year2.getSerialIndex();
//        java.util.Date date5 = year2.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
//        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        java.lang.String str14 = year13.toString();
//        long long15 = year13.getSerialIndex();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.lang.String str20 = serialDate19.toString();
//        java.lang.String str21 = serialDate19.toString();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass23 = day22.getClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.lang.String str25 = year24.toString();
//        long long26 = year24.getSerialIndex();
//        java.util.Date date27 = year24.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate19, (java.lang.Class) wildcardClass23);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(12, serialDate19);
//        boolean boolean32 = spreadsheetDate11.isOn(serialDate19);
//        int int33 = spreadsheetDate11.getDayOfMonth();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getSerialIndex();
//        java.util.Date date37 = year34.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) 1L);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getSerialIndex();
//        int int42 = day40.getMonth();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day40, "10-June-2019", "ERROR : Relative To String", class45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries46.addPropertyChangeListener(propertyChangeListener47);
//        java.lang.String str49 = timeSeries46.getDomainDescription();
//        boolean boolean50 = timeSeriesDataItem39.equals((java.lang.Object) timeSeries46);
//        java.lang.Object obj51 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        java.lang.String str53 = year52.toString();
//        int int54 = timeSeriesDataItem39.compareTo((java.lang.Object) str53);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        java.lang.String str56 = year55.toString();
//        long long57 = year55.getSerialIndex();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58, timeZone59);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date58);
//        java.lang.String str62 = serialDate61.toString();
//        java.lang.String str63 = serialDate61.toString();
//        boolean boolean64 = timeSeriesDataItem39.equals((java.lang.Object) serialDate61);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        java.lang.String str68 = year67.toString();
//        long long69 = year67.getSerialIndex();
//        java.util.Date date70 = year67.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70, timeZone71);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date70);
//        java.lang.String str74 = serialDate73.toString();
//        java.lang.String str75 = serialDate73.toString();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass77 = day76.getClass();
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
//        java.lang.String str79 = year78.toString();
//        long long80 = year78.getSerialIndex();
//        java.util.Date date81 = year78.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date81, timeZone82);
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate73, (java.lang.Class) wildcardClass77);
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate61, "9-June-2019", "April", (java.lang.Class) wildcardClass77);
//        boolean boolean86 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, serialDate61);
//        int int87 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "31-December-2019" + "'", str20.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "10-June-2019" + "'", str49.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "31-December-2019" + "'", str62.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31-December-2019" + "'", str63.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "2019" + "'", str68.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "31-December-2019" + "'", str74.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "31-December-2019" + "'", str75.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2019" + "'", str79.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 2019L + "'", long80 == 2019L);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1900 + "'", int87 == 1900);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries6.equals((java.lang.Object) month13);
//        timeSeries6.fireSeriesChanged();
//        long long17 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12);
        java.lang.String str2 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.next();
        long long6 = fixedMillisecond4.getFirstMillisecond();
        long long7 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond4.previous();
        timeSeries1.delete(regularTimePeriod8);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(6, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June" + "'", str2.equals("June"));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass1 = day0.getClass();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1);
//        boolean boolean6 = timeSeriesDataItem4.equals((java.lang.Object) 1560236399999L);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        int int11 = day10.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod3, (java.lang.Number) (byte) 1);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(4, 8, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 2958465);
        long long3 = month2.getLastMillisecond();
        long long4 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93297994498799999L + "'", long3 == 93297994498799999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 93297994498799999L + "'", long4 == 93297994498799999L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        long long14 = timeSeries12.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        long long2 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191974289L + "'", long1 == 1560191974289L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191974289L + "'", long2 == 1560191974289L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191974289L + "'", long4 == 1560191974289L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191974289L + "'", long5 == 1560191974289L);
//    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertNull(number15);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass18 = day17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getFirstMillisecond(calendar22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond21.next();
        java.util.Date date25 = fixedMillisecond21.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass27 = day26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.lang.String str29 = year28.toString();
        long long30 = year28.getSerialIndex();
        java.util.Date date31 = year28.getEnd();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date25, timeZone32);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass39 = day38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond42.next();
        java.util.Date date46 = fixedMillisecond42.getStart();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass48 = day47.getClass();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        java.lang.String str50 = year49.toString();
        long long51 = year49.getSerialIndex();
        java.util.Date date52 = year49.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date46, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date25, timeZone53);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date3, timeZone53);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2019" + "'", str50.equals("2019"));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate7);
        java.lang.String str9 = serialDate8.getDescription();
        java.lang.String str10 = serialDate8.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        java.lang.String str14 = serialDate10.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str22 = serialDate21.toString();
        java.lang.String str23 = serialDate21.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        long long28 = year26.getSerialIndex();
        java.util.Date date29 = year26.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21, (java.lang.Class) wildcardClass25);
        boolean boolean33 = spreadsheetDate1.isInRange(serialDate10, serialDate21);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        long long37 = year35.getSerialIndex();
        java.util.Date date38 = year35.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date38);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate41);
        java.lang.String str43 = serialDate42.getDescription();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond46.next();
        long long48 = fixedMillisecond46.getFirstMillisecond();
        java.util.Date date49 = fixedMillisecond46.getTime();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date49);
        boolean boolean53 = spreadsheetDate1.isInRange(serialDate42, serialDate51, 5);
        boolean boolean55 = spreadsheetDate1.equals((java.lang.Object) 1577779200000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries6.addChangeListener(seriesChangeListener10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int27 = day24.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getMonth();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day28.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day28);
//        java.util.Calendar calendar36 = null;
//        try {
//            long long37 = day28.getLastMillisecond(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        java.lang.String str14 = serialDate10.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str22 = serialDate21.toString();
        java.lang.String str23 = serialDate21.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        long long28 = year26.getSerialIndex();
        java.util.Date date29 = year26.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21, (java.lang.Class) wildcardClass25);
        boolean boolean33 = spreadsheetDate1.isInRange(serialDate10, serialDate21);
        java.lang.String str34 = serialDate10.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        java.lang.String str13 = year8.toString();
//        java.util.Calendar calendar14 = null;
//        try {
//            year8.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 3, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        timeSeries6.clear();
//        java.lang.Comparable comparable10 = null;
//        try {
//            timeSeries6.setKey(comparable10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str14 = serialDate13.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class5);
        java.util.List list7 = timeSeries6.getItems();
        java.util.Collection collection8 = timeSeries6.getTimePeriods();
        int int9 = month0.compareTo((java.lang.Object) collection8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 0 + "'", obj3.equals(0));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=0]"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        org.jfree.data.time.Year year3 = month1.getYear();
        org.jfree.data.time.Year year4 = month1.getYear();
        long long5 = year4.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 100, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520764324 + "'", int1 == 520764324);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        java.lang.Class class21 = timeSeries12.getTimePeriodClass();
//        timeSeries12.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(class21);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        java.lang.String str14 = serialDate10.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str22 = serialDate21.toString();
        java.lang.String str23 = serialDate21.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        long long28 = year26.getSerialIndex();
        java.util.Date date29 = year26.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21, (java.lang.Class) wildcardClass25);
        boolean boolean33 = spreadsheetDate1.isInRange(serialDate10, serialDate21);
        java.lang.String str34 = serialDate21.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(8);
        int int29 = spreadsheetDate28.getDayOfMonth();
        boolean boolean30 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(8);
        int int33 = spreadsheetDate32.getDayOfMonth();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        long long37 = year35.getSerialIndex();
        java.util.Date date38 = year35.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date38);
        serialDate41.setDescription("");
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays(2019, serialDate41);
        java.lang.String str45 = serialDate41.getDescription();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.lang.String str47 = year46.toString();
        long long48 = year46.getSerialIndex();
        java.util.Date date49 = year46.getEnd();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date49, timeZone50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date49);
        java.lang.String str53 = serialDate52.toString();
        java.lang.String str54 = serialDate52.toString();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass56 = day55.getClass();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.lang.String str58 = year57.toString();
        long long59 = year57.getSerialIndex();
        java.util.Date date60 = year57.getEnd();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate52, (java.lang.Class) wildcardClass56);
        boolean boolean64 = spreadsheetDate32.isInRange(serialDate41, serialDate52);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        java.lang.String str67 = year66.toString();
        long long68 = year66.getSerialIndex();
        java.util.Date date69 = year66.getEnd();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date69);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate72);
        java.lang.String str74 = serialDate73.getDescription();
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(serialDate73);
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond77.next();
        long long79 = fixedMillisecond77.getFirstMillisecond();
        java.util.Date date80 = fixedMillisecond77.getTime();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(date80);
        boolean boolean84 = spreadsheetDate32.isInRange(serialDate73, serialDate82, 5);
        boolean boolean85 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int86 = spreadsheetDate32.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 7 + "'", int33 == 7);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019" + "'", str47.equals("2019"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "31-December-2019" + "'", str53.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "31-December-2019" + "'", str54.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 7 + "'", int86 == 7);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        serialDate6.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate6.getPreviousDayOfWeek((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
//        boolean boolean10 = spreadsheetDate2.equals((java.lang.Object) regularTimePeriod9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date17);
//        java.lang.String str21 = serialDate20.toString();
//        java.lang.String str22 = serialDate20.toString();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass24 = day23.getClass();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        java.lang.String str26 = year25.toString();
//        long long27 = year25.getSerialIndex();
//        java.util.Date date28 = year25.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate20, (java.lang.Class) wildcardClass24);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears(12, serialDate20);
//        boolean boolean33 = spreadsheetDate12.isOn(serialDate20);
//        int int34 = spreadsheetDate12.getDayOfMonth();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
//        java.lang.String str36 = year35.toString();
//        long long37 = year35.getSerialIndex();
//        java.util.Date date38 = year35.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year35, (double) 1L);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getSerialIndex();
//        int int43 = day41.getMonth();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "10-June-2019", "ERROR : Relative To String", class46);
//        java.beans.PropertyChangeListener propertyChangeListener48 = null;
//        timeSeries47.addPropertyChangeListener(propertyChangeListener48);
//        java.lang.String str50 = timeSeries47.getDomainDescription();
//        boolean boolean51 = timeSeriesDataItem40.equals((java.lang.Object) timeSeries47);
//        java.lang.Object obj52 = timeSeriesDataItem40.clone();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        java.lang.String str54 = year53.toString();
//        int int55 = timeSeriesDataItem40.compareTo((java.lang.Object) str54);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59, timeZone60);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date59);
//        java.lang.String str63 = serialDate62.toString();
//        java.lang.String str64 = serialDate62.toString();
//        boolean boolean65 = timeSeriesDataItem40.equals((java.lang.Object) serialDate62);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
//        java.lang.String str69 = year68.toString();
//        long long70 = year68.getSerialIndex();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date71, timeZone72);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date71);
//        java.lang.String str75 = serialDate74.toString();
//        java.lang.String str76 = serialDate74.toString();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass78 = day77.getClass();
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year();
//        java.lang.String str80 = year79.toString();
//        long long81 = year79.getSerialIndex();
//        java.util.Date date82 = year79.getEnd();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date82, timeZone83);
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate74, (java.lang.Class) wildcardClass78);
//        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate62, "9-June-2019", "April", (java.lang.Class) wildcardClass78);
//        boolean boolean87 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, serialDate62);
//        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.lang.String str89 = spreadsheetDate2.toString();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 7 + "'", int34 == 7);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43626L + "'", long42 == 43626L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10-June-2019" + "'", str50.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(obj52);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "2019" + "'", str54.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31-December-2019" + "'", str63.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "31-December-2019" + "'", str64.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2019" + "'", str69.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "31-December-2019" + "'", str75.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "31-December-2019" + "'", str76.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2019" + "'", str80.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 2019L + "'", long81 == 2019L);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "7-January-1900" + "'", str89.equals("7-January-1900"));
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str9 = serialDate8.toString();
        java.lang.String str10 = serialDate8.toString();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass12 = day11.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        long long15 = year13.getSerialIndex();
        java.util.Date date16 = year13.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone17);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate8, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(6, serialDate8);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate8);
        try {
            org.jfree.data.time.SerialDate serialDate23 = serialDate21.getPreviousDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Date date13 = fixedMillisecond12.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getFirstMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond2.next();
        java.util.Date date6 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.lang.String str14 = year13.toString();
        long long15 = year13.getSerialIndex();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date10, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(1, year27);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = month28.getFirstMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone24);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond1.getMiddleMillisecond(calendar20);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate12);
        java.lang.String str14 = serialDate12.toString();
        org.jfree.data.time.SerialDate serialDate15 = null;
        try {
            boolean boolean17 = spreadsheetDate3.isInRange(serialDate12, serialDate15, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getYear();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getMonth();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "10-June-2019", "ERROR : Relative To String", class8);
//        timeSeries9.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str12 = timeSeries9.getDomainDescription();
//        timeSeries9.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
//        timeSeries9.delete(regularTimePeriod19);
//        boolean boolean21 = day0.equals((java.lang.Object) timeSeries9);
//        int int22 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getFirstMillisecond(calendar13);
//        java.lang.Number number15 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date20);
//        serialDate23.setDescription("");
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(2019, serialDate23);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        boolean boolean28 = fixedMillisecond12.equals((java.lang.Object) day27);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-452));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 4, 520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:00 PST 1969");
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj17 = timeSeriesDataItem5.clone();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
//        java.lang.String str19 = year18.toString();
//        int int20 = timeSeriesDataItem5.compareTo((java.lang.Object) str19);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.lang.String str22 = year21.toString();
//        long long23 = year21.getSerialIndex();
//        java.util.Date date24 = year21.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date24);
//        java.lang.String str28 = serialDate27.toString();
//        java.lang.String str29 = serialDate27.toString();
//        boolean boolean30 = timeSeriesDataItem5.equals((java.lang.Object) serialDate27);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        java.lang.String str34 = year33.toString();
//        long long35 = year33.getSerialIndex();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date36);
//        java.lang.String str40 = serialDate39.toString();
//        java.lang.String str41 = serialDate39.toString();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass43 = day42.getClass();
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        java.lang.String str45 = year44.toString();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate39, (java.lang.Class) wildcardClass43);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27, "9-June-2019", "April", (java.lang.Class) wildcardClass43);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        java.lang.String str53 = year52.toString();
//        long long54 = year52.getSerialIndex();
//        java.util.Date date55 = year52.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date55);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        java.lang.String str59 = year58.toString();
//        long long60 = year58.getSerialIndex();
//        java.util.Date date61 = year58.getEnd();
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        java.lang.String str63 = year62.toString();
//        long long64 = year62.getSerialIndex();
//        java.util.Date date65 = year62.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date65, timeZone66);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date61, timeZone66);
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date61, timeZone69);
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date55, timeZone69);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass76 = day75.getClass();
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass76);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond79.getFirstMillisecond(calendar80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = fixedMillisecond79.next();
//        java.util.Date date83 = fixedMillisecond79.getStart();
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass85 = day84.getClass();
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year();
//        java.lang.String str87 = year86.toString();
//        long long88 = year86.getSerialIndex();
//        java.util.Date date89 = year86.getEnd();
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass85, date89, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date83, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date55, timeZone90);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-2019" + "'", str28.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "31-December-2019" + "'", str29.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "31-December-2019" + "'", str40.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "31-December-2019" + "'", str41.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2019" + "'", str53.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 2019L + "'", long54 == 2019L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 2019L + "'", long60 == 2019L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "2019" + "'", str63.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2019L + "'", long64 == 2019L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(wildcardClass85);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "2019" + "'", str87.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 2019L + "'", long88 == 2019L);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        timeSeries6.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        java.lang.String str14 = timeSeries6.getDomainDescription();
//        java.util.Collection collection15 = timeSeries6.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(collection15);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        long long6 = fixedMillisecond5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12, (int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        timeSeries17.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        try {
            timeSeries17.delete((int) (byte) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries6.createCopy(11, 1900);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries12);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener8);
//        java.lang.String str10 = timeSeries6.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ERROR : Relative To String" + "'", str10.equals("ERROR : Relative To String"));
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getLastMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getStart();
        boolean boolean11 = month0.equals((java.lang.Object) fixedMillisecond5);
        long long12 = month0.getSerialIndex();
        java.util.Calendar calendar13 = null;
        try {
            month0.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24234L + "'", long12 == 24234L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.lang.String str11 = serialDate10.toString();
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
//        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
//        int int24 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getLastMillisecond();
//        int int30 = day25.compareTo((java.lang.Object) day28);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        java.lang.String str33 = year32.toString();
//        long long34 = year32.getSerialIndex();
//        java.util.Date date35 = year32.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean40 = spreadsheetDate2.isInRange(serialDate31, serialDate38, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        java.lang.String str45 = year44.toString();
//        long long46 = year44.getSerialIndex();
//        java.util.Date date47 = year44.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date47);
//        java.lang.String str51 = serialDate50.toString();
//        java.lang.String str52 = serialDate50.toString();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass54 = day53.getClass();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        java.lang.String str56 = year55.toString();
//        long long57 = year55.getSerialIndex();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date58, timeZone59);
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate50, (java.lang.Class) wildcardClass54);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears(12, serialDate50);
//        boolean boolean63 = spreadsheetDate42.isOn(serialDate50);
//        boolean boolean64 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        java.util.Date date65 = spreadsheetDate2.toDate();
//        int int66 = spreadsheetDate2.getMonth();
//        try {
//            org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "31-December-2019" + "'", str52.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        int int7 = day5.getMonth();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, "10-June-2019", "ERROR : Relative To String", class10);
//        timeSeries11.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str14 = timeSeries11.getDomainDescription();
//        timeSeries11.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.previous();
//        timeSeries11.delete(regularTimePeriod21);
//        int int23 = year0.compareTo((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        java.lang.String str25 = year24.toString();
//        long long26 = year24.getSerialIndex();
//        java.util.Date date27 = year24.getEnd();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.lang.String str29 = year28.toString();
//        long long30 = year28.getSerialIndex();
//        java.util.Date date31 = year28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27, timeZone32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date27);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
//        try {
//            timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, 0.0d, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43626L + "'", long6 == 43626L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.lang.String str3 = year2.toString();
        long long4 = year2.getSerialIndex();
        java.util.Date date5 = year2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date5);
        serialDate8.setDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(2019, serialDate8);
        java.lang.String str12 = serialDate8.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9999, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = day0.equals(obj3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December" + "'", str2.equals("December"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 12, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 2019);
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        long long9 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June" + "'", str1.equals("June"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) -1, 10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        long long3 = month0.getSerialIndex();
        long long4 = month0.getSerialIndex();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean9 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = month0.equals((java.lang.Object) spreadsheetDate8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.lang.String str11 = serialDate10.toString();
        java.lang.String str12 = serialDate10.toString();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass14 = day13.getClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
        int int24 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate26 = null;
        try {
            boolean boolean27 = spreadsheetDate2.isOnOrAfter(serialDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(serialDate25);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "10-June-2019", "ERROR : Relative To String", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getFirstMillisecond();
//        long long17 = year15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) (byte) -1);
//        java.lang.String str20 = year15.toString();
//        int int21 = year15.getYear();
//        int int22 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries6.createCopy(11, 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        long long7 = day3.getFirstMillisecond();
//        long long8 = day3.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        int int8 = day3.compareTo((java.lang.Object) day6);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass12 = day11.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "", "", (java.lang.Class) wildcardClass12);
//        timeSeries13.clear();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries13.removeChangeListener(seriesChangeListener15);
//        boolean boolean17 = spreadsheetDate2.equals((java.lang.Object) timeSeries13);
//        try {
//            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass5 = day4.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        java.util.Date date12 = fixedMillisecond8.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass14 = day13.getClass();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date12, timeZone19);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "December", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) regularTimePeriod3);
        long long5 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        java.lang.String str40 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        java.lang.String str42 = year41.toString();
//        long long43 = year41.getSerialIndex();
//        java.util.Date date44 = year41.getEnd();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44, timeZone45);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date44);
//        serialDate47.setDescription("");
//        boolean boolean50 = spreadsheetDate1.isOn(serialDate47);
//        try {
//            org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "2019" + "'", str42.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        long long7 = day3.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        java.lang.String str3 = day1.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) -1, serialDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        long long10 = timeSeries6.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDescription();
//        timeSeries6.clear();
//        boolean boolean11 = timeSeries6.isEmpty();
//        java.util.Collection collection12 = timeSeries6.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(collection12);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.clear();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries12.getTimePeriod((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191987594L + "'", long1 == 1560191987594L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        boolean boolean4 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = null;
        try {
            boolean boolean6 = spreadsheetDate1.isOnOrBefore(serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass1 = day0.getClass();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.String str7 = year6.toString();
        long long8 = year6.getSerialIndex();
        java.util.Date date9 = year6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date9);
        serialDate12.setDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(2019, serialDate12);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        boolean boolean17 = year0.equals((java.lang.Object) serialDate15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener20);
//        try {
//            timeSeries6.removeAgedItems((long) 5, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        long long28 = day27.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208441600000L) + "'", long28 == (-2208441600000L));
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries6.isEmpty();
//        try {
//            timeSeries6.removeAgedItems(0L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.String str7 = year6.toString();
//        long long8 = year6.getSerialIndex();
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getSerialIndex();
//        int int14 = day12.getMonth();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, "10-June-2019", "ERROR : Relative To String", class17);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
//        java.lang.String str21 = timeSeries18.getDomainDescription();
//        boolean boolean22 = timeSeriesDataItem11.equals((java.lang.Object) timeSeries18);
//        timeSeries18.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        java.lang.Number number29 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        int int33 = day30.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getSerialIndex();
//        int int36 = day34.getMonth();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        int int39 = day34.compareTo((java.lang.Object) day37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day34.previous();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        long long43 = day42.getSerialIndex();
//        int int44 = day42.getMonth();
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day42, "10-June-2019", "ERROR : Relative To String", class47);
//        timeSeries48.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str51 = timeSeries48.getDomainDescription();
//        java.lang.Comparable comparable52 = timeSeries48.getKey();
//        int int53 = day30.compareTo((java.lang.Object) comparable52);
//        boolean boolean54 = fixedMillisecond1.equals((java.lang.Object) comparable52);
//        java.util.Calendar calendar55 = null;
//        fixedMillisecond1.peg(calendar55);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43626L + "'", long13 == 43626L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43626L + "'", long31 == 43626L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43626L + "'", long35 == 43626L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 43626L + "'", long43 == 43626L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        timeSeries6.setDomainDescription("April");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate(regularTimePeriod18, (java.lang.Number) 10.0f);
//        timeSeries6.setMaximumItemCount(8);
//        try {
//            timeSeries6.update(6, (java.lang.Number) 1560191965221L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Following");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Following");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray20 = seriesException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) seriesException19);
        java.lang.Throwable[] throwableArray22 = seriesException19.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException19);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date10, timeZone15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date10, timeZone18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date4, timeZone18);
        try {
            org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date0, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeZone18);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        int int5 = day3.getMonth();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, "10-June-2019", "ERROR : Relative To String", class8);
//        java.lang.Object obj10 = timeSeries9.clone();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener11);
//        int int13 = year0.compareTo((java.lang.Object) seriesChangeListener11);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = year0.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        long long3 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        timeSeries12.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        timeSeries12.setMaximumItemAge((long) 2);
//        timeSeries12.setDomainDescription("April");
//        int int20 = day5.compareTo((java.lang.Object) timeSeries12);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        java.lang.String str22 = year21.toString();
//        long long23 = year21.getSerialIndex();
//        java.util.Date date24 = year21.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) 1L);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getSerialIndex();
//        int int29 = day27.getMonth();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, "10-June-2019", "ERROR : Relative To String", class32);
//        boolean boolean34 = timeSeriesDataItem26.equals((java.lang.Object) timeSeries33);
//        java.lang.Object obj35 = timeSeriesDataItem26.clone();
//        try {
//            timeSeries12.add(timeSeriesDataItem26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(obj35);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        int int11 = day10.getDayOfMonth();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day10.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        long long20 = day18.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.String str7 = serialDate6.toString();
        java.lang.String str8 = serialDate6.toString();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass10 = day9.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.lang.String str12 = year11.toString();
        long long13 = year11.getSerialIndex();
        java.util.Date date14 = year11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        try {
            java.lang.Number number20 = timeSeries17.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int27 = day24.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getMonth();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day28.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day28);
//        timeSeries12.clear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = day3.equals(obj7);
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day3.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        long long3 = month0.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        timeSeries6.setDomainDescription("April");
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.addOrUpdate(regularTimePeriod18, (java.lang.Number) 10.0f);
//        timeSeries6.setMaximumItemCount(8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries6.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(12, serialDate11);
        boolean boolean24 = spreadsheetDate3.isOn(serialDate11);
        int int25 = spreadsheetDate3.getDayOfMonth();
        boolean boolean26 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(8);
        int int29 = spreadsheetDate28.getDayOfMonth();
        boolean boolean30 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int31 = spreadsheetDate28.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        int int4 = month0.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int3 = day0.compareTo((java.lang.Object) 'a');
//        long long4 = day0.getSerialIndex();
//        int int5 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1546329600000L, class1);
        timeSeries2.setRangeDescription("");
        boolean boolean5 = timeSeries2.getNotify();
        try {
            timeSeries2.removeAgedItems(1577865599999L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1577779200000L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 1560191986461L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setDomainDescription("2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries6.removeChangeListener(seriesChangeListener9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        java.lang.String str19 = timeSeries12.getDomainDescription();
//        timeSeries12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=SerialDate.weekInMonthToString(): invalid code.]");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        timeSeries6.setDomainDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((int) '4', (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(timeSeries15);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone11);
//        long long13 = day12.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        java.lang.String str18 = year17.toString();
//        long long19 = year17.getSerialIndex();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date20);
//        java.lang.String str24 = serialDate23.toString();
//        java.lang.String str25 = serialDate23.toString();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass27 = day26.getClass();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.lang.String str29 = year28.toString();
//        long long30 = year28.getSerialIndex();
//        java.util.Date date31 = year28.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone32);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate23, (java.lang.Class) wildcardClass27);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(12, serialDate23);
//        boolean boolean36 = spreadsheetDate15.isOn(serialDate23);
//        int int37 = spreadsheetDate15.toSerial();
//        boolean boolean38 = day12.equals((java.lang.Object) int37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        java.lang.String str40 = year39.toString();
//        long long41 = year39.getSerialIndex();
//        java.util.Date date42 = year39.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year39.previous();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getSerialIndex();
//        int int46 = day44.getMonth();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day44, "10-June-2019", "ERROR : Relative To String", class49);
//        timeSeries50.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str53 = timeSeries50.getDomainDescription();
//        timeSeries50.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
//        java.lang.String str57 = year56.toString();
//        long long58 = year56.getSerialIndex();
//        java.util.Date date59 = year56.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year56.previous();
//        timeSeries50.delete(regularTimePeriod60);
//        int int62 = year39.compareTo((java.lang.Object) timeSeries50);
//        boolean boolean63 = day12.equals((java.lang.Object) year39);
//        java.util.Calendar calendar64 = null;
//        try {
//            long long65 = day12.getLastMillisecond(calendar64);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577779200000L + "'", long13 == 1577779200000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-2019" + "'", str24.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "31-December-2019" + "'", str25.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43626L + "'", long45 == 43626L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10-June-2019" + "'", str53.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "2019" + "'", str57.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        java.lang.Object obj13 = null;
        boolean boolean14 = fixedMillisecond12.equals(obj13);
        long long15 = fixedMillisecond12.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999, (int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        java.lang.Number number8 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0d + "'", number8.equals(1.0d));
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.clear();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.getDataItem((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        java.lang.Class class8 = timeSeries6.getTimePeriodClass();
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(class8);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
//        long long3 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getLastMillisecond();
//        int int11 = day6.compareTo((java.lang.Object) day9);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass15 = day14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "", "", (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date22, timeZone24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date4, timeZone24);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = month26.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        long long3 = year1.getSerialIndex();
        java.lang.String str4 = year1.toString();
        int int5 = year1.getYear();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass7 = day6.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Date date14 = fixedMillisecond10.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass16 = day15.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.lang.String str18 = year17.toString();
        long long19 = year17.getSerialIndex();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date14, timeZone21);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass28 = day27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Wed Dec 31 16:00:00 PST 1969", "31-December-2019", (java.lang.Class) wildcardClass28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getFirstMillisecond(calendar32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
        java.util.Date date35 = fixedMillisecond31.getStart();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass37 = day36.getClass();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.String str39 = year38.toString();
        long long40 = year38.getSerialIndex();
        java.util.Date date41 = year38.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date35, timeZone42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date14, timeZone42);
        java.lang.Class<?> wildcardClass46 = day45.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ', "Last", "2019", (java.lang.Class) wildcardClass46);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191991553L + "'", long1 == 1560191991553L);
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        java.util.List list24 = timeSeries12.getItems();
//        boolean boolean25 = timeSeries12.isEmpty();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
//        java.lang.String str11 = serialDate10.toString();
//        java.lang.String str12 = serialDate10.toString();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass14 = day13.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        java.lang.String str16 = year15.toString();
//        long long17 = year15.getSerialIndex();
//        java.util.Date date18 = year15.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone19);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate10, (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears(12, serialDate10);
//        boolean boolean23 = spreadsheetDate2.isOn(serialDate10);
//        int int24 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
//        long long29 = fixedMillisecond27.getFirstMillisecond();
//        java.util.Date date30 = fixedMillisecond27.getTime();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date30);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date30);
//        boolean boolean34 = spreadsheetDate2.equals((java.lang.Object) date30);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        java.lang.String str38 = year37.toString();
//        long long39 = year37.getSerialIndex();
//        java.util.Date date40 = year37.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40, timeZone41);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date40);
//        serialDate43.setDescription("");
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(2019, serialDate43);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        java.lang.String str49 = year48.toString();
//        long long50 = year48.getSerialIndex();
//        java.util.Date date51 = year48.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51, timeZone52);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date51);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate54);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate43.getEndOfCurrentMonth(serialDate55);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(10, serialDate55);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getSerialIndex();
//        int int62 = day60.getMonth();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        long long64 = day63.getLastMillisecond();
//        int int65 = day60.compareTo((java.lang.Object) day63);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass69 = day68.getClass();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day60, "", "", (java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate57, "June 2019", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass69);
//        boolean boolean72 = spreadsheetDate2.isBefore(serialDate57);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 43626L + "'", long61 == 43626L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getLastMillisecond();
        int int3 = month1.getMonth();
        int int4 = month1.getYearValue();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.String str8 = year7.toString();
        long long9 = year7.getSerialIndex();
        java.util.Date date10 = year7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.lang.String str14 = serialDate13.toString();
        java.lang.String str15 = serialDate13.toString();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass17 = day16.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        long long20 = year18.getSerialIndex();
        java.util.Date date21 = year18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate13, (java.lang.Class) wildcardClass17);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(6, serialDate13);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(6, serialDate13);
        int int27 = month1.compareTo((java.lang.Object) serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate26);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-2019" + "'", str14.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31-December-2019" + "'", str15.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        long long12 = year10.getSerialIndex();
//        java.util.Date date13 = year10.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) 1L);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getSerialIndex();
//        int int18 = day16.getMonth();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, "10-June-2019", "ERROR : Relative To String", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getDomainDescription();
//        boolean boolean26 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries22);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        long long29 = year27.getSerialIndex();
//        java.util.Date date30 = year27.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) 1L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
//        int int34 = timeSeriesDataItem15.compareTo((java.lang.Object) regularTimePeriod33);
//        try {
//            timeSeries6.add(timeSeriesDataItem15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43626L + "'", long17 == 43626L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        timeSeries6.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191993289L + "'", long1 == 1560191993289L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.util.Collection collection9 = timeSeries6.getTimePeriods();
//        try {
//            java.lang.Number number11 = timeSeries6.getValue(520764324);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 520764324, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(collection9);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Object obj7 = timeSeries6.clone();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        long long9 = day8.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day8);
//        timeSeries6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        boolean boolean15 = timeSeries6.equals((java.lang.Object) month13);
//        int int16 = timeSeries6.getItemCount();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.String str18 = month17.toString();
//        org.jfree.data.time.Year year19 = month17.getYear();
//        int int20 = month17.getYearValue();
//        long long21 = month17.getLastMillisecond();
//        org.jfree.data.time.Year year22 = month17.getYear();
//        int int23 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43626L + "'", long9 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        java.lang.String str14 = serialDate10.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str22 = serialDate21.toString();
        java.lang.String str23 = serialDate21.toString();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass25 = day24.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.lang.String str27 = year26.toString();
        long long28 = year26.getSerialIndex();
        java.util.Date date29 = year26.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21, (java.lang.Class) wildcardClass25);
        boolean boolean33 = spreadsheetDate1.isInRange(serialDate10, serialDate21);
        int int34 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1969, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Last");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        timeSeriesDataItem7.setValue((java.lang.Number) 0.0f);
//        timeSeriesDataItem7.setValue((java.lang.Number) 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.lang.Comparable comparable7 = timeSeries6.getKey();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        long long9 = year8.getFirstMillisecond();
//        long long10 = year8.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year8, (double) (byte) -1);
//        java.lang.String str13 = year8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertNotNull(comparable7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1);
        boolean boolean3 = timeSeries2.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeries12.setMaximumItemAge((long) 9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        java.lang.Number number23 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int27 = day24.compareTo((java.lang.Object) 'a');
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        long long29 = day28.getSerialIndex();
//        int int30 = day28.getMonth();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getLastMillisecond();
//        int int33 = day28.compareTo((java.lang.Object) day31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.previous();
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) day24, (org.jfree.data.time.RegularTimePeriod) day28);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries12.getDataItem(1969);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeSeries35);
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        int int9 = day7.getMonth();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, "10-June-2019", "ERROR : Relative To String", class12);
//        java.lang.Comparable comparable14 = timeSeries13.getKey();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getFirstMillisecond();
//        long long17 = year15.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) (byte) -1);
//        java.lang.String str20 = year15.toString();
//        int int21 = year15.getYear();
//        int int22 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year15.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(comparable14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str7 = serialDate6.toString();
//        java.lang.String str8 = serialDate6.toString();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass10 = day9.getClass();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        java.lang.String str12 = year11.toString();
//        long long13 = year11.getSerialIndex();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, (java.lang.Class) wildcardClass10);
//        java.lang.String str18 = timeSeries17.getDomainDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getSerialIndex();
//        int int21 = day19.getMonth();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, "10-June-2019", "ERROR : Relative To String", class24);
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timeSeries25.getDomainDescription();
//        boolean boolean29 = timeSeries25.isEmpty();
//        boolean boolean30 = timeSeries17.equals((java.lang.Object) timeSeries25);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getSerialIndex();
//        int int33 = day31.getMonth();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        long long35 = day34.getLastMillisecond();
//        int int36 = day31.compareTo((java.lang.Object) day34);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getSerialIndex();
//        int int39 = day37.getMonth();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, "10-June-2019", "ERROR : Relative To String", class42);
//        timeSeries43.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str46 = timeSeries43.getDomainDescription();
//        java.lang.Comparable comparable47 = timeSeries43.getKey();
//        int int48 = day31.compareTo((java.lang.Object) comparable47);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        long long50 = day49.getSerialIndex();
//        int int51 = day49.getMonth();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        long long53 = day52.getLastMillisecond();
//        int int54 = day49.compareTo((java.lang.Object) day52);
//        java.lang.String str55 = day49.toString();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) day49);
//        int int57 = day31.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-2019" + "'", str7.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-2019" + "'", str8.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43626L + "'", long20 == 43626L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43626L + "'", long32 == 43626L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43626L + "'", long50 == 43626L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        int int5 = day0.compareTo((java.lang.Object) day3);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date7);
        serialDate10.setDescription("");
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(2019, serialDate10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        long long17 = year15.getSerialIndex();
        java.util.Date date18 = year15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = serialDate10.getEndOfCurrentMonth(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, serialDate23);
        int int25 = fixedMillisecond1.compareTo((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        int int2 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod3, (java.lang.Number) 6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1L));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        long long16 = year14.getSerialIndex();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.lang.String str21 = serialDate20.toString();
        java.lang.String str22 = serialDate20.toString();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass24 = day23.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.String str26 = year25.toString();
        long long27 = year25.getSerialIndex();
        java.util.Date date28 = year25.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate20, (java.lang.Class) wildcardClass24);
        java.lang.String str32 = timeSeries31.getDomainDescription();
        boolean boolean33 = timeSeriesDataItem13.equals((java.lang.Object) str32);
        boolean boolean34 = timeSeriesDataItem5.equals((java.lang.Object) boolean33);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-2019" + "'", str22.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        boolean boolean13 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj14 = timeSeriesDataItem5.clone();
//        java.lang.Number number15 = timeSeriesDataItem5.getValue();
//        timeSeriesDataItem5.setValue((java.lang.Number) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem5.getPeriod();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 2958465);
        long long3 = month2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year4 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93297994498799999L + "'", long3 == 93297994498799999L);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        long long2 = year0.getSerialIndex();
//        java.util.Date date3 = year0.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1L);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getSerialIndex();
//        int int8 = day6.getMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, "10-June-2019", "ERROR : Relative To String", class11);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
//        java.lang.String str15 = timeSeries12.getDomainDescription();
//        boolean boolean16 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        java.lang.Object obj17 = timeSeriesDataItem5.clone();
//        java.lang.Object obj18 = timeSeriesDataItem5.clone();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertNotNull(obj18);
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getSerialIndex();
//        int int21 = day18.compareTo((java.lang.Object) 'a');
//        java.util.Date date22 = day18.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1560191974289L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.lang.String str5 = year4.toString();
        long long6 = year4.getSerialIndex();
        java.util.Date date7 = year4.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date3, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("Last");
        int int15 = fixedMillisecond12.compareTo((java.lang.Object) timePeriodFormatException14);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        java.lang.String str1 = month0.toString();
//        long long2 = month0.getFirstMillisecond();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        boolean boolean5 = month0.equals((java.lang.Object) day3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.next();
//        long long11 = fixedMillisecond9.getFirstMillisecond();
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        int int16 = day14.getMonth();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        int int19 = day14.compareTo((java.lang.Object) day17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass23 = day22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, "", "", (java.lang.Class) wildcardClass23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
//        java.util.Date date30 = fixedMillisecond26.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date30, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date12, timeZone32);
//        boolean boolean35 = timeSeriesDataItem7.equals((java.lang.Object) date12);
//        timeSeriesDataItem7.setValue((java.lang.Number) 1560191965221L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        java.lang.String str23 = year22.toString();
//        long long24 = year22.getSerialIndex();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        java.lang.String str27 = year26.toString();
//        long long28 = year26.getSerialIndex();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date25, timeZone30);
//        int int33 = day32.getDayOfMonth();
//        java.lang.Number number34 = null;
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day32, number34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 31 + "'", int33 == 31);
//    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        java.lang.Comparable comparable18 = timeSeries6.getKey();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        long long21 = year19.getSerialIndex();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) 1L);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getSerialIndex();
//        int int27 = day25.getMonth();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, "10-June-2019", "ERROR : Relative To String", class30);
//        boolean boolean32 = timeSeriesDataItem24.equals((java.lang.Object) timeSeries31);
//        java.lang.Object obj33 = timeSeriesDataItem24.clone();
//        try {
//            timeSeries6.add(timeSeriesDataItem24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(comparable18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43626L + "'", long26 == 43626L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(obj33);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 31);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getSerialIndex();
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        java.util.Date date8 = year5.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date8);
        java.lang.String str12 = serialDate11.toString();
        java.lang.String str13 = serialDate11.toString();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.String str17 = year16.toString();
        long long18 = year16.getSerialIndex();
        java.util.Date date19 = year16.getEnd();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(6, serialDate11);
        int int24 = year0.compareTo((java.lang.Object) serialDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year0.next();
        long long26 = year0.getLastMillisecond();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.String str30 = year29.toString();
        long long31 = year29.getSerialIndex();
        java.util.Date date32 = year29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.lang.String str36 = serialDate35.toString();
        java.lang.String str37 = serialDate35.toString();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        java.lang.Class<?> wildcardClass39 = day38.getClass();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        long long42 = year40.getSerialIndex();
        java.util.Date date43 = year40.getEnd();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate35, (java.lang.Class) wildcardClass39);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, "org.jfree.data.general.SeriesChangeEvent[source=0]", "2019", (java.lang.Class) wildcardClass39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getFirstMillisecond(calendar51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond50.next();
        java.util.Date date54 = fixedMillisecond50.getStart();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.lang.String str56 = year55.toString();
        long long57 = year55.getSerialIndex();
        java.util.Date date58 = year55.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond(date58);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date58);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.lang.String str62 = year61.toString();
        long long63 = year61.getSerialIndex();
        java.util.Date date64 = year61.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        java.lang.String str66 = year65.toString();
        long long67 = year65.getSerialIndex();
        java.util.Date date68 = year65.getEnd();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date68, timeZone69);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date64, timeZone69);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date64, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date58, timeZone72);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date54, timeZone72);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(1, year75);
        boolean boolean77 = year0.equals((java.lang.Object) year75);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-2019" + "'", str12.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-2019" + "'", str13.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "31-December-2019" + "'", str36.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-2019" + "'", str37.equals("31-December-2019"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2019" + "'", str56.equals("2019"));
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "2019" + "'", str66.equals("2019"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        java.lang.Comparable comparable10 = timeSeries6.getKey();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.getDataItem((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(comparable10);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        int int4 = month0.getMonth();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        boolean boolean63 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        java.lang.String str67 = year66.toString();
//        long long68 = year66.getSerialIndex();
//        java.util.Date date69 = year66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date69);
//        serialDate72.setDescription("");
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays(2019, serialDate72);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        java.lang.String str78 = year77.toString();
//        long long79 = year77.getSerialIndex();
//        java.util.Date date80 = year77.getEnd();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80, timeZone81);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance(date80);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addYears((int) 'a', serialDate83);
//        org.jfree.data.time.SerialDate serialDate85 = serialDate72.getEndOfCurrentMonth(serialDate84);
//        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.addMonths(10, serialDate84);
//        boolean boolean87 = spreadsheetDate1.isAfter(serialDate86);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond89 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar90 = null;
//        long long91 = fixedMillisecond89.getFirstMillisecond(calendar90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = fixedMillisecond89.previous();
//        try {
//            int int93 = spreadsheetDate1.compareTo((java.lang.Object) regularTimePeriod92);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 2019L + "'", long68 == 2019L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "2019" + "'", str78.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 2019L + "'", long79 == 2019L);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 100L + "'", long91 == 100L);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        timeSeries6.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        timeSeries6.setMaximumItemAge((long) 2);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        java.lang.String str13 = year12.toString();
//        long long14 = year12.getSerialIndex();
//        java.util.Date date15 = year12.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
//        timeSeries6.delete(regularTimePeriod16);
//        timeSeries6.setDomainDescription("Time");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        java.lang.String str4 = year3.toString();
//        long long5 = year3.getSerialIndex();
//        java.util.Date date6 = year3.getEnd();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.String str11 = serialDate9.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass13 = day12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        long long16 = year14.getSerialIndex();
//        java.util.Date date17 = year14.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass13);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears(12, serialDate9);
//        boolean boolean22 = spreadsheetDate1.isOn(serialDate9);
//        int int23 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        int int26 = day24.getMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getLastMillisecond();
//        int int29 = day24.compareTo((java.lang.Object) day27);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        long long33 = year31.getSerialIndex();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        boolean boolean39 = spreadsheetDate1.isInRange(serialDate30, serialDate37, 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        java.lang.String str44 = year43.toString();
//        long long45 = year43.getSerialIndex();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date46);
//        java.lang.String str50 = serialDate49.toString();
//        java.lang.String str51 = serialDate49.toString();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.Class<?> wildcardClass53 = day52.getClass();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        java.lang.String str55 = year54.toString();
//        long long56 = year54.getSerialIndex();
//        java.util.Date date57 = year54.getEnd();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate49, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears(12, serialDate49);
//        boolean boolean62 = spreadsheetDate41.isOn(serialDate49);
//        int int63 = spreadsheetDate41.toSerial();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        long long65 = day64.getSerialIndex();
//        int int66 = day64.getMonth();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        long long68 = day67.getLastMillisecond();
//        int int69 = day64.compareTo((java.lang.Object) day67);
//        org.jfree.data.time.SerialDate serialDate70 = day67.getSerialDate();
//        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
//        java.lang.String str72 = year71.toString();
//        long long73 = year71.getSerialIndex();
//        java.util.Date date74 = year71.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date74, timeZone75);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date74);
//        boolean boolean79 = spreadsheetDate41.isInRange(serialDate70, serialDate77, 10);
//        boolean boolean80 = spreadsheetDate1.isOnOrBefore(serialDate70);
//        try {
//            org.jfree.data.time.SerialDate serialDate82 = serialDate70.getFollowingDayOfWeek(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-2019" + "'", str11.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 8 + "'", int23 == 8);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43626L + "'", long25 == 43626L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31-December-2019" + "'", str50.equals("31-December-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "31-December-2019" + "'", str51.equals("31-December-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 8 + "'", int63 == 8);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 43626L + "'", long65 == 43626L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560236399999L + "'", long68 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "2019" + "'", str72.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2019L + "'", long73 == 2019L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        int int2 = month0.getMonth();
        int int3 = month0.getYearValue();
        long long4 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        java.lang.String str5 = year4.toString();
//        long long6 = year4.getSerialIndex();
//        java.util.Date date7 = year4.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year4, (double) 1L);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        int int12 = day10.getMonth();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, "10-June-2019", "ERROR : Relative To String", class15);
//        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries16);
//        java.lang.Object obj18 = timeSeriesDataItem9.clone();
//        int int19 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Number number20 = timeSeriesDataItem9.getValue();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0d + "'", number20.equals(1.0d));
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        long long4 = month0.getLastMillisecond();
        long long5 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getMonth();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "10-June-2019", "ERROR : Relative To String", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getDomainDescription();
//        boolean boolean10 = timeSeries6.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener11);
//        long long13 = timeSeries6.getMaximumItemAge();
//        int int14 = timeSeries6.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener15);
//        java.util.Collection collection17 = timeSeries6.getTimePeriods();
//        try {
//            timeSeries6.update(520764324, (java.lang.Number) 1562097599999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 520764324, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray21 = seriesException20.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException20);
        java.lang.Throwable[] throwableArray23 = seriesException20.getSuppressed();
        java.lang.Throwable[] throwableArray24 = seriesException20.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
    }
}

