import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test01");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(1, (int) (short) 1);
//        long long4 = week3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(1, (int) (short) 1);
//        long long9 = week8.getLastMillisecond();
//        long long10 = week8.getSerialIndex();
//        java.util.Date date11 = week8.getEnd();
//        int int12 = week8.getYearValue();
//        int int13 = week8.getYearValue();
//        boolean boolean14 = week3.equals((java.lang.Object) int13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.util.Date date16 = week15.getEnd();
//        java.lang.Object obj17 = null;
//        boolean boolean18 = week15.equals(obj17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week15.next();
//        boolean boolean20 = week3.equals((java.lang.Object) week15);
//        long long21 = week15.getSerialIndex();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        java.util.Date date24 = week23.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str27 = timePeriodFormatException26.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        boolean boolean31 = week23.equals((java.lang.Object) timePeriodFormatException26);
//        org.jfree.data.time.Year year32 = week23.getYear();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(0, year32);
//        java.util.Date date34 = year32.getStart();
//        boolean boolean35 = week15.equals((java.lang.Object) year32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) -1, year32);
//        java.lang.Class<?> wildcardClass37 = week36.getClass();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62135654400001L) + "'", long4 == (-62135654400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62135654400001L) + "'", long9 == (-62135654400001L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 54L + "'", long10 == 54L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long4 = week3.getLastMillisecond();
        long long5 = week3.getSerialIndex();
        java.util.Date date6 = week3.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = regularTimePeriod12.getStart();
        java.lang.Class<?> wildcardClass14 = date13.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long19 = week18.getLastMillisecond();
        long long20 = week18.getSerialIndex();
        java.util.Date date21 = week18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date13, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date6, timeZone22);
        try {
            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date0, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62135654400001L) + "'", long4 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 54L + "'", long5 == 54L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135654400001L) + "'", long19 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 54L + "'", long20 == 54L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str6 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        boolean boolean10 = week2.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.Year year11 = week2.getYear();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(0, year11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year11);
        long long14 = week13.getLastMillisecond();
        java.lang.String str15 = week13.toString();
        java.util.Date date16 = week13.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546156799999L + "'", long14 == 1546156799999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 0, 2019" + "'", str15.equals("Week 0, 2019"));
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        java.lang.Class<?> wildcardClass7 = date6.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long12 = week11.getLastMillisecond();
        long long13 = week11.getSerialIndex();
        java.util.Date date14 = week11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date6, timeZone15);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.Year year19 = week18.getYear();
        java.util.Date date20 = year19.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = week21.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62135654400001L) + "'", long12 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 54L + "'", long13 == 54L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        long long8 = week7.getLastMillisecond();
        java.util.Date date9 = week7.getStart();
        int int10 = week7.getWeek();
        long long11 = week7.getMiddleMillisecond();
        int int12 = week7.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week7.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62135654400001L) + "'", long3 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 54L + "'", long4 == 54L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62135654400001L) + "'", long8 == (-62135654400001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62135956800001L) + "'", long11 == (-62135956800001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test06");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (-2018));
//        long long3 = week2.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.util.Date date5 = week4.getEnd();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week4.equals(obj6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        long long9 = week4.getMiddleMillisecond();
//        boolean boolean10 = week2.equals((java.lang.Object) week4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-125819280000001L) + "'", long3 == (-125819280000001L));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 0);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str4 = timePeriodFormatException3.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        boolean boolean8 = week0.equals((java.lang.Object) timePeriodFormatException3);
//        long long9 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        long long11 = week0.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        try {
//            week0.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = regularTimePeriod1.getStart();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.util.Date date4 = week3.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        java.util.Date date11 = week10.getEnd();
//        java.util.Date date12 = week10.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date7, timeZone13);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(1, (int) (short) 1);
//        long long19 = week18.getLastMillisecond();
//        long long20 = week18.getSerialIndex();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date21, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date7, timeZone22);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date4, timeZone22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date2, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
//        long long28 = regularTimePeriod27.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62135654400001L) + "'", long19 == (-62135654400001L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 54L + "'", long20 == 54L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560365999999L + "'", long28 == 1560365999999L);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 100);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        java.util.Date date4 = week3.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str7 = timePeriodFormatException6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        boolean boolean11 = week3.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.Year year12 = week3.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(0, year12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(0, year12);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(6, year12);
        java.util.Date date16 = week15.getStart();
        java.util.Calendar calendar17 = null;
        try {
            week15.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = regularTimePeriod11.getStart();
        java.lang.Class<?> wildcardClass13 = date12.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long18 = week17.getLastMillisecond();
        long long19 = week17.getSerialIndex();
        java.util.Date date20 = week17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone21);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date5, timeZone21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date5);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date5, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62135654400001L) + "'", long3 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 54L + "'", long4 == 54L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62135654400001L) + "'", long18 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 54L + "'", long19 == 54L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        java.util.Date date5 = week2.getEnd();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62135654400001L) + "'", long3 == (-62135654400001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 1, 1" + "'", str6.equals("Week 1, 1"));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (short) 10);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long6 = week5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        boolean boolean9 = week2.equals((java.lang.Object) regularTimePeriod7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62135654400001L) + "'", long6 == (-62135654400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 100);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59005814400001L) + "'", long3 == (-59005814400001L));
    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getEnd();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str6 = timePeriodFormatException5.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.util.Date date18 = week17.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.String str21 = timePeriodFormatException20.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
//        boolean boolean25 = week17.equals((java.lang.Object) timePeriodFormatException20);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        int int28 = week0.compareTo((java.lang.Object) timePeriodFormatException20);
//        java.lang.String str29 = timePeriodFormatException20.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
//        java.lang.Throwable[] throwableArray32 = timePeriodFormatException31.getSuppressed();
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
//        java.lang.Throwable[] throwableArray34 = timePeriodFormatException31.getSuppressed();
//        java.lang.Throwable[] throwableArray35 = timePeriodFormatException31.getSuppressed();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray32);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNotNull(throwableArray35);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }
//}

