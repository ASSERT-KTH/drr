import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        double double4 = textTitle1.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        textTitle1.setURLText("");
        textTitle1.setPadding((double) (short) 10, 1.0E-8d, (double) (byte) 1, (double) 3);
        textTitle1.setHeight(2.0d);
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickMarkOutsideLength((float) '4');
        double double4 = numberAxis3D1.getFixedDimension();
        numberAxis3D1.setTickMarkOutsideLength((float) 1L);
        double double7 = numberAxis3D1.getUpperMargin();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset((-1.0d));
        double double13 = rectangleInsets10.getBottom();
        textTitle9.setMargin(rectangleInsets10);
        java.lang.Object obj15 = textTitle9.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle9.getPadding();
        numberAxis3D1.setTickLabelInsets(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color1, color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color8, color9 };
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color11 };
        java.awt.Stroke[] strokeArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray15 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray10, paintArray12, strokeArray13, strokeArray14, shapeArray15);
        java.awt.Paint paint17 = defaultDrawingSupplier16.getNextFillPaint();
        java.awt.Paint paint18 = defaultDrawingSupplier16.getNextPaint();
        java.lang.Object obj19 = defaultDrawingSupplier16.clone();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setUpperBound((double) 0L);
        boolean boolean23 = numberAxis20.isAutoRange();
        boolean boolean24 = numberAxis20.isAutoRange();
        boolean boolean25 = defaultDrawingSupplier16.equals((java.lang.Object) boolean24);
        piePlot3D0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint13 = categoryAxis12.getTickLabelPaint();
        categoryAxis12.setAxisLineVisible(false);
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis12.setTickMarkStroke(stroke18);
        xYPlot4.setDomainZeroBaselineStroke(stroke18);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot4.getRangeAxisEdge((-1656));
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot18.render(graphics2D19, rectangle2D20, 8, plotRenderingInfo22, crosshairState23);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers(2);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke30);
        java.awt.Paint paint32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30, paint32, stroke33, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker35.setLabelTextAnchor(textAnchor36);
        xYPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35, layer39);
        org.jfree.chart.plot.Plot plot41 = null;
        categoryPlot0.setParent(plot41);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        java.awt.geom.Point2D point2D15 = xYPlot14.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        xYPlot14.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot14.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot14.getRangeAxisLocation(3);
        xYPlot4.setRangeAxisLocation(axisLocation21);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection4 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
        org.junit.Assert.assertNull(entityCollection4);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape5 = numberAxis4.getLeftArrow();
        org.jfree.data.Range range6 = numberAxis4.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 15);
        boolean boolean9 = legendTitle2.equals((java.lang.Object) range6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo1.setCopyright("");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str5 = projectInfo1.toString();
        java.util.List list6 = projectInfo1.getContributors();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot9.getDataset();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot9, (org.jfree.chart.block.Arrangement) flowArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement16);
        flowArrangement15.clear();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        java.awt.Color color6 = java.awt.Color.GRAY;
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = ringPlot0.getSectionPaint((java.lang.Comparable) 3.0d);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot10.setShadowPaint((java.awt.Paint) color12);
        double double14 = ringPlot10.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str19 = textAnchor18.toString();
        boolean boolean20 = rectangleInsets15.equals((java.lang.Object) str19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, (java.awt.Paint) color21);
        ringPlot10.setShadowPaint((java.awt.Paint) color21);
        java.awt.Color color24 = color21.brighter();
        ringPlot0.setLabelShadowPaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = ringPlot0.getSimpleLabelOffset();
        double double28 = rectangleInsets26.extendWidth((double) (short) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str19.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 15.625d + "'", double28 == 15.625d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (byte) 100);
        categoryPlot16.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot16.setDomainAxis((int) (byte) 0, categoryAxis23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot16.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot16.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers(2);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot31.setRangeCrosshairStroke(stroke34);
        categoryPlot0.setDomainGridlineStroke(stroke34);
        float float37 = categoryPlot0.getBackgroundImageAlpha();
        int int38 = categoryPlot0.getWeight();
        categoryPlot0.clearAnnotations();
        int int40 = categoryPlot0.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot0.getRendererForDataset(categoryDataset41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot0.getDomainAxis((-16777024));
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNull(categoryAxis44);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot4.setOrientation(plotOrientation12);
        double double14 = xYPlot4.getDomainCrosshairValue();
        xYPlot4.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot4.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = ringPlot4.getBaseSectionPaint();
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot4.setNoDataMessageFont(font10);
        dateAxis1.setLabelFont(font10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape14 = numberAxis13.getRightArrow();
        float float15 = numberAxis13.getTickMarkInsideLength();
        org.jfree.chart.PaintMap paintMap16 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D18.setTickMarkOutsideLength((float) '4');
        boolean boolean21 = paintMap16.equals((java.lang.Object) numberAxis3D18);
        java.awt.Shape shape22 = numberAxis3D18.getUpArrow();
        org.jfree.data.Range range23 = numberAxis3D18.getDefaultAutoRange();
        org.jfree.data.Range range26 = org.jfree.data.Range.expand(range23, (double) 1L, 0.0d);
        numberAxis13.setRangeWithMargins(range23);
        dateAxis1.setRange(range23, true, false);
        dateAxis1.setLabelAngle((double) (byte) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        java.awt.Paint paint3 = legendTitle2.getBackgroundPaint();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle2.getItemContainer();
        double double5 = blockContainer4.getContentYOffset();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        double double8 = textTitle7.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        textTitle7.setURLText("");
        org.jfree.chart.block.BlockFrame blockFrame12 = textTitle7.getFrame();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle7.setFont(font13);
        blockContainer4.add((org.jfree.chart.block.Block) textTitle7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers(2);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke7);
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7, paint9, stroke10, 0.0f);
        categoryAxis3D1.setTickMarkStroke(stroke10);
        categoryAxis3D1.setLabelAngle(0.025d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("Category Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Category Plot");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color0, color1, color2, color3, color4 };
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, color7, color8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray14 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray9, paintArray11, strokeArray12, strokeArray13, shapeArray14);
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextFillPaint();
        java.awt.Paint paint17 = defaultDrawingSupplier15.getNextPaint();
        java.awt.Paint paint18 = defaultDrawingSupplier15.getNextOutlinePaint();
        java.awt.Paint paint19 = defaultDrawingSupplier15.getNextOutlinePaint();
        java.lang.Object obj20 = defaultDrawingSupplier15.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset((-1.0d));
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateLeftInset((double) (-1L));
        double double7 = rectangleInsets0.calculateRightInset((double) (byte) 0);
        double double8 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        boolean boolean7 = dateAxis1.equals((java.lang.Object) rectangleConstraint6);
        boolean boolean8 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        multiplePiePlot1.handleClick(0, 10, plotRenderingInfo4);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str3 = ringPlot2.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot2);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = ringPlot2.getLegendItems();
        java.awt.Stroke stroke6 = ringPlot2.getSeparatorStroke();
        categoryAxis1.setAxisLineStroke(stroke6);
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color11 = java.awt.Color.GRAY;
        java.awt.Color color12 = color11.brighter();
        ringPlot10.setLabelBackgroundPaint((java.awt.Paint) color12);
        float float14 = ringPlot10.getForegroundAlpha();
        int int15 = ringPlot10.getPieIndex();
        double double17 = ringPlot10.getExplodePercent((java.lang.Comparable) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.clearDomainMarkers(2);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot18.setRangeCrosshairStroke(stroke21);
        categoryPlot18.setDomainGridlinesVisible(false);
        boolean boolean25 = ringPlot10.equals((java.lang.Object) categoryPlot18);
        boolean boolean26 = categoryPlot18.isDomainGridlinesVisible();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        java.lang.Object obj4 = blockContainer3.clone();
        java.util.List list5 = blockContainer3.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame6 = blockContainer3.getFrame();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(blockFrame6);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        xYPlot4.mapDatasetToDomainAxis(0, 0);
        java.awt.Stroke stroke12 = xYPlot4.getOutlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot4.getRangeAxisLocation(1);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        java.awt.Paint paint21 = jFreeChart15.getBackgroundPaint();
        jFreeChart15.setBorderVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getPadding();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 2, (double) 8, (double) (short) -1, (double) 0.5f);
        java.awt.Color color16 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.clearDomainMarkers(2);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot17.setRangeCrosshairStroke(stroke20);
        java.awt.Paint paint22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20, paint22, stroke23, 0.0f);
        valueMarker25.setValue((double) (-1));
        valueMarker25.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke30 = valueMarker25.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = valueMarker25.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot32 = new org.jfree.chart.plot.RingPlot();
        double double33 = ringPlot32.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = legendTitle34.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle34.getBounds();
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets31.createInsetRectangle(rectangle2D36, false, true);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets14.createInsetRectangle(rectangle2D36);
        double double42 = rectangleInsets14.extendHeight((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.5d + "'", double42 == 1.5d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        java.awt.Stroke stroke10 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.geom.Point2D point2D18 = xYPlot17.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot17.getRenderer(1);
        java.util.List list21 = xYPlot17.getAnnotations();
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot17.setRangeTickBandPaint(paint22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.geom.Point2D point2D31 = xYPlot30.getQuadrantOrigin();
        xYPlot17.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D31, true);
        xYPlot4.zoomDomainAxes((double) (short) 100, plotRenderingInfo12, point2D31, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot4.getDomainAxisForDataset((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.Color color9 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.clearDomainMarkers(2);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot10.setRangeCrosshairStroke(stroke13);
        java.awt.Paint paint15 = null;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke13, paint15, stroke16, 0.0f);
        valueMarker18.setValue((double) (-1));
        valueMarker18.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke23 = valueMarker18.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = valueMarker18.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        double double26 = ringPlot25.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle27.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D29 = legendTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets24.createInsetRectangle(rectangle2D29, false, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        boolean boolean35 = categoryPlot0.render(graphics2D7, rectangle2D32, (int) (byte) -1, plotRenderingInfo34);
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(categoryDataset36);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        boolean boolean14 = textTitle1.getExpandToFitSpace();
        double double15 = textTitle1.getWidth();
        textTitle1.setURLText("TextAnchor.BASELINE_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setWeight((int) (byte) 100);
        categoryPlot18.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint25 = categoryAxis24.getTickLabelPaint();
        categoryAxis24.setAxisLineVisible(false);
        categoryAxis24.setTickLabelsVisible(false);
        categoryAxis24.setCategoryMargin((double) (-1L));
        int int32 = categoryPlot18.getDomainAxisIndex(categoryAxis24);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis34.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis34.getLabelInsets();
        double double39 = rectangleInsets37.calculateBottomInset((double) 0L);
        categoryAxis24.setLabelInsets(rectangleInsets37);
        textTitle1.setMargin(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.0d + "'", double39 == 3.0d);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        java.awt.Shape shape6 = numberAxis3D2.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        chartEntity7.setURLText("ClassContext");
        chartEntity7.setURLText("hi!");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        org.jfree.data.Range range6 = numberAxis3D2.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setUpperBound((double) 0L);
        numberAxis7.setLowerBound((double) (short) -1);
        java.awt.Shape shape12 = numberAxis7.getUpArrow();
        numberAxis3D2.setLeftArrow(shape12);
        org.jfree.chart.entity.ChartEntity chartEntity15 = new org.jfree.chart.entity.ChartEntity(shape12, "java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot4.setOrientation(plotOrientation12);
        java.lang.String str14 = xYPlot4.getPlotType();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle17.getBounds();
        java.util.List list19 = null;
        xYPlot4.drawDomainTickBands(graphics2D15, rectangle2D18, list19);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "XY Plot" + "'", str14.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        int int7 = ringPlot0.getPieIndex();
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 0);
        ringPlot0.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        xYPlot4.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (byte) 100);
        categoryPlot13.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot13.setDomainAxis((int) (byte) 0, categoryAxis20);
        boolean boolean22 = categoryPlot13.isRangeZoomable();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        double double24 = ringPlot23.getStartAngle();
        boolean boolean25 = ringPlot23.getIgnoreNullValues();
        ringPlot23.setSeparatorsVisible(false);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot23.setBaseSectionOutlinePaint((java.awt.Paint) color28);
        ringPlot23.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint32 = ringPlot23.getBaseSectionOutlinePaint();
        categoryPlot13.setDomainGridlinePaint(paint32);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setNegativeArrowVisible(false);
        java.lang.String str38 = numberAxis35.getLabel();
        categoryPlot13.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, valueAxis45, xYItemRenderer46);
        java.awt.geom.Point2D point2D48 = xYPlot47.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot47.getRenderer(1);
        java.util.List list51 = xYPlot47.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = xYPlot47.getRenderer();
        java.awt.geom.Point2D point2D53 = xYPlot47.getQuadrantOrigin();
        categoryPlot13.zoomDomainAxes((double) 10.0f, 0.0d, plotRenderingInfo42, point2D53);
        xYPlot4.setQuadrantOrigin(point2D53);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNull(xYItemRenderer52);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis0.getLabelInsets();
        double double2 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot5.getRangeMarkers((int) (short) 0, layer17);
        float float19 = categoryPlot5.getBackgroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot5.setDataset(categoryDataset20);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        boolean boolean2 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        ringPlot0.setDataset(pieDataset5);
        ringPlot0.setStartAngle((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getDomainAxis((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace13 = xYPlot4.getFixedRangeAxisSpace();
        xYPlot4.mapDatasetToDomainAxis((int) (byte) 10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Color color7 = java.awt.Color.RED;
        ringPlot0.setOutlinePaint((java.awt.Paint) color7);
        double double9 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle1.getPosition();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.geom.Point2D point2D13 = xYPlot12.getQuadrantOrigin();
        boolean boolean14 = rectangleEdge7.equals((java.lang.Object) xYPlot12);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot12.getDomainMarkers(layer15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap19 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D21.setTickMarkOutsideLength((float) '4');
        boolean boolean24 = paintMap19.equals((java.lang.Object) numberAxis3D21);
        java.awt.Shape shape25 = numberAxis3D21.getUpArrow();
        org.jfree.data.Range range26 = numberAxis3D21.getDefaultAutoRange();
        org.jfree.data.Range range29 = org.jfree.data.Range.expand(range26, (double) 1L, 0.0d);
        dateAxis18.setRange(range29, false, false);
        boolean boolean33 = dateAxis18.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double35 = dateRange34.getCentralValue();
        dateAxis18.setRange((org.jfree.data.Range) dateRange34);
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date38 = dateAxis18.calculateLowestVisibleTickValue(dateTickUnit37);
        xYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateRange34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.5d + "'", double35 == 0.5d);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int4 = color3.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot5.setDomainAxis((int) (byte) 0, categoryAxis12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateLeftInset((-1.0d));
        double double20 = rectangleInsets17.getLeft();
        double double22 = rectangleInsets17.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("ClassContext", font2, (java.awt.Paint) color3, rectangleEdge14, horizontalAlignment15, verticalAlignment16, rectangleInsets17);
        java.awt.Color color24 = java.awt.Color.white;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        double double28 = textTitle27.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle27);
        double double30 = textTitle27.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle27.getPosition();
        boolean boolean32 = textBlock25.equals((java.lang.Object) rectangleEdge31);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot36 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = multiplePiePlot36.getDataset();
        java.awt.Font font38 = multiplePiePlot36.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("{0}", font38);
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("java.awt.Color[r=182,g=182,b=182]", font38);
        textBlock25.addLine(textLine40);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setPieIndex(0);
        ringPlot0.setExplodePercent((java.lang.Comparable) 0.0d, (double) (-1.0f));
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        double double14 = ringPlot13.getStartAngle();
        boolean boolean15 = ringPlot13.getIgnoreNullValues();
        ringPlot13.setSeparatorsVisible(false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot13.setBaseSectionOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str21 = ringPlot20.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot20);
        java.lang.Object obj23 = plotChangeEvent22.getSource();
        ringPlot13.notifyListeners(plotChangeEvent22);
        ringPlot0.notifyListeners(plotChangeEvent22);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setWeight((int) (byte) 100);
        categoryPlot26.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot26.setDomainAxis((int) (byte) 0, categoryAxis33);
        boolean boolean35 = categoryPlot26.isRangeZoomable();
        org.jfree.chart.plot.RingPlot ringPlot36 = new org.jfree.chart.plot.RingPlot();
        double double37 = ringPlot36.getStartAngle();
        boolean boolean38 = ringPlot36.getIgnoreNullValues();
        ringPlot36.setSeparatorsVisible(false);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot36.setBaseSectionOutlinePaint((java.awt.Paint) color41);
        ringPlot36.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint45 = ringPlot36.getBaseSectionOutlinePaint();
        categoryPlot26.setDomainGridlinePaint(paint45);
        ringPlot0.setLabelOutlinePaint(paint45);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator48 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.0d + "'", double14 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 90.0d + "'", double37 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(pieURLGenerator48);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getDomainAxis((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace13 = xYPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.geom.Point2D point2D22 = xYPlot21.getQuadrantOrigin();
        xYPlot4.zoomDomainAxes((double) 1, 0.0d, plotRenderingInfo16, point2D22);
        org.jfree.chart.plot.Plot plot24 = xYPlot4.getRootPlot();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(plot24);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        java.awt.Paint paint9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot4.setRangeTickBandPaint(paint9);
        java.awt.Paint paint11 = xYPlot4.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.Color color14 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers(2);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot15.setRangeCrosshairStroke(stroke18);
        java.awt.Paint paint20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18, paint20, stroke21, 0.0f);
        valueMarker23.setValue((double) (-1));
        valueMarker23.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke28 = valueMarker23.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = valueMarker23.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        double double31 = ringPlot30.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = legendTitle32.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D34 = legendTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets29.createInsetRectangle(rectangle2D34, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D37, rectangleAnchor38);
        java.awt.Font font42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int44 = color43.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot45.setWeight((int) (byte) 100);
        categoryPlot45.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot45.setDomainAxis((int) (byte) 0, categoryAxis52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot45.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double59 = rectangleInsets57.calculateLeftInset((-1.0d));
        double double60 = rectangleInsets57.getLeft();
        double double62 = rectangleInsets57.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle("ClassContext", font42, (java.awt.Paint) color43, rectangleEdge54, horizontalAlignment55, verticalAlignment56, rectangleInsets57);
        java.awt.Color color64 = java.awt.Color.white;
        org.jfree.chart.text.TextBlock textBlock65 = org.jfree.chart.text.TextUtilities.createTextBlock("", font42, (java.awt.Paint) color64);
        org.jfree.chart.text.TextLine textLine67 = new org.jfree.chart.text.TextLine("");
        textBlock65.addLine(textLine67);
        java.util.List list69 = textBlock65.getLines();
        try {
            xYPlot4.drawRangeTickBands(graphics2D12, rectangle2D37, list69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 90.0d + "'", double31 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 4.0d + "'", double59 == 4.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 4.0d + "'", double60 == 4.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(textBlock65);
        org.junit.Assert.assertNotNull(list69);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        java.lang.String str4 = numberAxis0.getLabelToolTip();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj6 = categoryAxis3D5.clone();
        boolean boolean7 = legendTitle2.equals((java.lang.Object) categoryAxis3D5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setNegativeArrowVisible(false);
        boolean boolean11 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis8.getTickLabelInsets();
        legendTitle2.setLegendItemGraphicPadding(rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.geom.Point2D point2D19 = xYPlot18.getQuadrantOrigin();
        boolean boolean20 = xYPlot18.isDomainZeroBaselineVisible();
        boolean boolean21 = legendTitle2.equals((java.lang.Object) xYPlot18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle2.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(false);
        piePlot3D0.setIgnoreNullValues(false);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        double double8 = textTitle7.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        textTitle7.setFrame((org.jfree.chart.block.BlockFrame) lineBorder10);
        java.awt.Stroke stroke12 = lineBorder10.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color5, stroke12);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        valueMarker13.setLabelFont(font14);
        java.awt.Paint paint16 = valueMarker13.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        double double20 = textTitle19.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent21 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle19);
        textTitle19.setURLText("");
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle19.getFrame();
        boolean boolean25 = textAnchor17.equals((java.lang.Object) blockFrame24);
        valueMarker13.setLabelTextAnchor(textAnchor17);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("VerticalAlignment.CENTER", graphics2D1, (float) 100, (float) 255, textAnchor17, (double) 0.0f, (float) 10, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        java.awt.Color color12 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers(2);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeCrosshairStroke(stroke16);
        java.awt.Paint paint18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16, paint18, stroke19, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor22);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray25 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray25);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(xYItemRendererArray25);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(8, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot4.setDomainZeroBaselinePaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot4.zoomDomainAxes((double) (-65536), plotRenderingInfo11, point2D12, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("PlotOrientation.VERTICAL");
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("TextBlockAnchor.TOP_CENTER");
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot5.axisChanged(axisChangeEvent18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint22 = categoryAxis21.getTickLabelPaint();
        categoryAxis21.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint26 = null;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) (short) 10, paint26);
        boolean boolean28 = categoryPlot5.equals((java.lang.Object) categoryAxis21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            categoryPlot5.handleClick(500, 3, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isBorderVisible();
        boolean boolean22 = jFreeChart15.getAntiAlias();
        java.awt.Paint paint23 = jFreeChart15.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle24 = jFreeChart15.getTitle();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(textTitle24);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getDomainAxis((int) (short) 1);
        org.jfree.chart.PaintMap paintMap14 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D16.setTickMarkOutsideLength((float) '4');
        boolean boolean19 = paintMap14.equals((java.lang.Object) numberAxis3D16);
        java.awt.Shape shape20 = numberAxis3D16.getUpArrow();
        org.jfree.data.Range range21 = numberAxis3D16.getDefaultAutoRange();
        try {
            xYPlot4.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) numberAxis3D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        java.awt.geom.Point2D point2D15 = xYPlot14.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) 0L, (double) 0.5f, plotRenderingInfo9, point2D15);
        java.awt.Paint paint17 = xYPlot4.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = columnArrangement0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint7 = categoryAxis6.getTickLabelPaint();
        categoryAxis6.setAxisLineVisible(false);
        categoryAxis6.setTickLabelsVisible(false);
        categoryAxis6.setCategoryMargin((double) (-1L));
        int int14 = categoryPlot0.getDomainAxisIndex(categoryAxis6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge(4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (byte) 100);
        categoryPlot16.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot16.setDomainAxis((int) (byte) 0, categoryAxis23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot16.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot16.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers(2);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot31.setRangeCrosshairStroke(stroke34);
        categoryPlot0.setDomainGridlineStroke(stroke34);
        float float37 = categoryPlot0.getBackgroundImageAlpha();
        int int38 = categoryPlot0.getWeight();
        categoryPlot0.clearAnnotations();
        int int40 = categoryPlot0.getWeight();
        java.awt.Color color42 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.clearDomainMarkers(2);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot43.setRangeCrosshairStroke(stroke46);
        java.awt.Paint paint48 = null;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color42, stroke46, paint48, stroke49, 0.0f);
        valueMarker51.setValue((double) (-1));
        valueMarker51.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke56 = valueMarker51.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = valueMarker51.getLabelAnchor();
        org.jfree.chart.util.Layer layer58 = null;
        try {
            boolean boolean59 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker51, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
    }
}

