import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        xYPlot4.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot4.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D();
        double double3 = size2D2.getHeight();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint10.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D13 = legendTitle8.arrange(graphics2D9, rectangleConstraint12);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle8.setItemFont(font14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle8.getLegendItemGraphicLocation();
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 82.0d, (double) (-1), rectangleAnchor16);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickMarkOutsideLength((float) '4');
        double double4 = numberAxis3D1.getFixedDimension();
        numberAxis3D1.setTickMarkOutsideLength((float) 1L);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot3D7.setLabelGenerator(pieSectionLabelGenerator10);
        java.awt.Shape shape12 = piePlot3D7.getLegendItemShape();
        numberAxis3D1.setUpArrow(shape12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        categoryPlot0.axisChanged(axisChangeEvent13);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range4, 0.0d, false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        java.awt.Stroke stroke10 = xYPlot4.getDomainZeroBaselineStroke();
        int int11 = xYPlot4.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            xYPlot4.handleClick(0, (-16777024), plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot5.getDomainAxisLocation();
        boolean boolean17 = categoryPlot5.isRangeCrosshairLockedOnData();
        float float18 = categoryPlot5.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        double double19 = textTitle18.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent20 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle18);
        double double21 = textTitle18.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = textTitle18.getPosition();
        textTitle18.setURLText("");
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D25.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean28 = textTitle18.equals((java.lang.Object) piePlot3D25);
        try {
            jFreeChart15.addSubtitle((int) ' ', (org.jfree.chart.title.Title) textTitle18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            textFragment2.draw(graphics2D3, 0.0f, (float) 0L, textAnchor6, (float) (byte) 10, 0.0f, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        java.lang.Object obj2 = waferMapPlot0.clone();
        org.junit.Assert.assertNull(waferMapDataset1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        ringPlot0.setExplodePercent((java.lang.Comparable) 0, 2.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(1.05d, (double) 100.0f, (double) (-1), (double) 100.0f);
        ringPlot0.setLabelPadding(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        boolean boolean9 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        double double11 = ringPlot10.getStartAngle();
        boolean boolean12 = ringPlot10.getIgnoreNullValues();
        ringPlot10.setSeparatorsVisible(false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot10.setBaseSectionOutlinePaint((java.awt.Paint) color15);
        ringPlot10.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint19 = ringPlot10.getBaseSectionOutlinePaint();
        categoryPlot0.setDomainGridlinePaint(paint19);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = null;
        try {
            categoryPlot0.setRenderers(categoryItemRendererArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        int int18 = jFreeChart15.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) -1, (double) 1.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        boolean boolean3 = numberAxis0.isAutoRange();
        numberAxis0.setLabelURL("Pie 3D Plot");
        java.awt.Shape shape6 = numberAxis0.getRightArrow();
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        java.lang.Object obj4 = blockContainer3.clone();
        blockContainer3.clear();
        org.jfree.chart.block.Arrangement arrangement6 = blockContainer3.getArrangement();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        double double9 = textTitle8.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle8);
        textTitle8.setURLText("");
        org.jfree.chart.block.BlockFrame blockFrame13 = textTitle8.getFrame();
        blockContainer3.setFrame(blockFrame13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        double double17 = size2D16.getHeight();
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        double double21 = ringPlot20.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint24.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D27 = legendTitle22.arrange(graphics2D23, rectangleConstraint26);
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle22.setItemFont(font28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = legendTitle22.getLegendItemGraphicLocation();
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 82.0d, (double) (-1), rectangleAnchor30);
        try {
            blockContainer3.draw(graphics2D15, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(arrangement6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (byte) 100);
        categoryPlot13.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot13.setDomainAxis((int) (byte) 0, categoryAxis20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot13.setRenderer(categoryItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot13.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(2, axisLocation25, true);
        boolean boolean28 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint11 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.PaintMap paintMap4 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D6.setTickMarkOutsideLength((float) '4');
        boolean boolean9 = paintMap4.equals((java.lang.Object) numberAxis3D6);
        java.awt.Shape shape10 = numberAxis3D6.getUpArrow();
        boolean boolean11 = multiplePiePlot1.equals((java.lang.Object) numberAxis3D6);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str4 = titleChangeEvent3.toString();
        java.lang.String str5 = titleChangeEvent3.toString();
        org.jfree.chart.title.Title title6 = titleChangeEvent3.getTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = title6.getPosition();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(title6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("poly", font1);
        boolean boolean3 = textTitle2.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot4.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = ringPlot4.getBaseSectionPaint();
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot4.setNoDataMessageFont(font10);
        dateAxis1.setLabelFont(font10);
        java.util.Date date13 = dateAxis1.getMaximumDate();
        java.text.DateFormat dateFormat14 = null;
        dateAxis1.setDateFormatOverride(dateFormat14);
        boolean boolean16 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        int int11 = xYPlot4.getWeight();
        java.awt.Color color14 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers(2);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot15.setRangeCrosshairStroke(stroke18);
        java.awt.Paint paint20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18, paint20, stroke21, 0.0f);
        java.awt.Paint paint24 = valueMarker23.getLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.geom.Point2D point2D30 = xYPlot29.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot29.getRenderer(1);
        xYPlot29.configureDomainAxes();
        xYPlot29.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot29.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.setWeight((int) (byte) 100);
        categoryPlot38.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot38.setDomainAxis((int) (byte) 0, categoryAxis45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot38.setRenderer(categoryItemRenderer47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot38.getRangeAxisLocation(10);
        xYPlot29.setDomainAxisLocation(axisLocation50);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("");
        double double54 = textTitle53.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent55 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder();
        textTitle53.setFrame((org.jfree.chart.block.BlockFrame) lineBorder56);
        java.awt.Stroke stroke58 = lineBorder56.getStroke();
        xYPlot29.setRangeGridlineStroke(stroke58);
        valueMarker23.setStroke(stroke58);
        org.jfree.chart.util.Layer layer61 = null;
        try {
            boolean boolean62 = xYPlot4.removeRangeMarker(1, (org.jfree.chart.plot.Marker) valueMarker23, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateLeftOutset((double) 8);
        java.lang.String str8 = rectangleInsets4.toString();
        legendTitle2.setItemLabelPadding(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str5.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str8.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickMarkInsideLength(10.0f);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D();
        size2D6.height = 1.0f;
        java.lang.Object obj9 = size2D6.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.0d, 0.0d, rectangleAnchor12);
        org.jfree.chart.util.Size2D size2D14 = new org.jfree.chart.util.Size2D();
        double double15 = size2D14.getHeight();
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        double double19 = ringPlot18.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot18);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint22.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D25 = legendTitle20.arrange(graphics2D21, rectangleConstraint24);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle20.setItemFont(font26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle20.getLegendItemGraphicLocation();
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D14, 82.0d, (double) (-1), rectangleAnchor28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot34.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.axis.AxisState axisState37 = numberAxis3D1.draw(graphics2D4, (-1.0d), rectangle2D13, rectangle2D29, rectangleEdge35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        xYPlot4.mapDatasetToDomainAxis(0, 0);
        xYPlot4.clearRangeMarkers((int) (byte) 0);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str15 = plotOrientation14.toString();
        xYPlot4.setOrientation(plotOrientation14);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.VERTICAL" + "'", str15.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Range[-1.0,1.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", graphics2D1, (float) 10, (float) 500, (double) 3, (float) 1, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 45.0d, (double) ' ', 15, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        xYPlot4.datasetChanged(datasetChangeEvent10);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getRightArrow();
        float float2 = numberAxis0.getTickMarkInsideLength();
        numberAxis0.setLabelAngle((double) 2.0f);
        boolean boolean5 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setLabel("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = categoryAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot3.getLegendItems();
        categoryPlot3.clearRangeMarkers();
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Range[-1.0,1.0]", graphics2D1, 0.0f, (float) 10, 45.0d, (float) 2, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str9 = textAnchor8.toString();
        boolean boolean10 = rectangleInsets5.equals((java.lang.Object) str9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color11);
        ringPlot0.setShadowPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        ringPlot0.handleClick((int) (byte) 10, 2, plotRenderingInfo16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot0.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D();
        size2D20.height = 1.0f;
        java.lang.Object obj23 = size2D20.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.0d, 0.0d, rectangleAnchor26);
        org.jfree.chart.plot.RingPlot ringPlot30 = new org.jfree.chart.plot.RingPlot();
        double double31 = ringPlot30.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = legendTitle32.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D34 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) (-65536), 0.12d, rectangleAnchor33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState44 = null;
        boolean boolean45 = xYPlot39.render(graphics2D40, rectangle2D41, 8, plotRenderingInfo43, crosshairState44);
        int int46 = xYPlot39.getWeight();
        java.awt.geom.Point2D point2D47 = xYPlot39.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            ringPlot0.draw(graphics2D19, rectangle2D34, point2D47, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str9.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 90.0d + "'", double31 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        double double2 = piePlot3D0.getLabelLinkMargin();
        piePlot3D0.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("poly", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot9.getPieChart();
        try {
            org.jfree.chart.title.Title title15 = jFreeChart13.getSubtitle((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jFreeChart13);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int5 = color4.getRed();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 10.0f, 90.0d, 1.0d, (java.awt.Paint) color4);
        java.awt.Color color7 = color4.darker();
        float[] floatArray8 = new float[] {};
        try {
            float[] floatArray9 = color7.getComponents(floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setCircular(true);
        java.awt.Shape shape6 = ringPlot0.getLegendItemShape();
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        ringPlot0.setLabelFont(font8);
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int14 = color13.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setWeight((int) (byte) 100);
        categoryPlot15.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot15.setDomainAxis((int) (byte) 0, categoryAxis22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double29 = rectangleInsets27.calculateLeftInset((-1.0d));
        double double30 = rectangleInsets27.getLeft();
        double double32 = rectangleInsets27.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("ClassContext", font12, (java.awt.Paint) color13, rectangleEdge24, horizontalAlignment25, verticalAlignment26, rectangleInsets27);
        java.awt.Color color34 = java.awt.Color.white;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font12, (java.awt.Paint) color34);
        ringPlot0.setLabelLinkPaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(textBlock35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 1.0f;
        java.lang.String str3 = size2D0.toString();
        double double4 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=1.0]" + "'", str3.equals("Size2D[width=0.0, height=1.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor5 = new org.jfree.chart.plot.PieLabelDistributor(0);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor5);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setNegativeArrowVisible(false);
        java.lang.String str10 = numberAxis7.getLabel();
        java.awt.Paint paint11 = numberAxis7.getTickLabelPaint();
        ringPlot0.setLabelOutlinePaint(paint11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (byte) 100);
        categoryPlot2.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot2.setDomainAxis((int) (byte) 0, categoryAxis9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot2.getRangeAxisEdge();
        categoryPlot2.setBackgroundAlpha((float) 2);
        boolean boolean14 = objectList0.equals((java.lang.Object) categoryPlot2);
        java.awt.Stroke stroke15 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot2.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot2.setRenderer(255, categoryItemRenderer18, false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.RIGHT", graphics2D1, (float) (-1L), (float) '4', (double) (short) 100, (float) (byte) 0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = ringPlot0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem5 = legendItemCollection3.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart15.getLegend((int) (short) 1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener22 = null;
        try {
            jFreeChart15.removeChangeListener(chartChangeListener22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(legendTitle21);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = ringPlot0.getDatasetGroup();
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        ringPlot0.setBaseSectionOutlineStroke(stroke5);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperBound((double) 0L);
        numberAxis1.setLowerBound((double) (short) -1);
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) numberAxis1);
        java.lang.Object obj7 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ThreadContext");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis6.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis6.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (byte) 100);
        categoryPlot10.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot10.zoomDomainAxes(10.0d, plotRenderingInfo16, point2D17, false);
        boolean boolean20 = categoryAxis6.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot10.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(0, axisLocation21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        java.awt.geom.Point2D point2D28 = xYPlot27.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        xYPlot27.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot27.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot27.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot27.getRangeAxisLocation(2);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str38 = plotOrientation37.toString();
        java.lang.String str39 = plotOrientation37.toString();
        java.lang.String str40 = plotOrientation37.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation37);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation37);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.VERTICAL" + "'", str38.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PlotOrientation.VERTICAL" + "'", str39.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "PlotOrientation.VERTICAL" + "'", str40.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setPieIndex(0);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color12 = java.awt.Color.GRAY;
        java.awt.Color color13 = color12.brighter();
        ringPlot11.setLabelBackgroundPaint((java.awt.Paint) color13);
        ringPlot11.setCircular(true);
        java.awt.Shape shape17 = ringPlot11.getLegendItemShape();
        java.awt.Paint paint18 = ringPlot11.getLabelPaint();
        ringPlot0.setSectionPaint((java.lang.Comparable) 10.0d, paint18);
        ringPlot0.setSectionDepth(82.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation(8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        double double7 = ringPlot0.getExplodePercent((java.lang.Comparable) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(2);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke11);
        categoryPlot8.setDomainGridlinesVisible(false);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) categoryPlot8);
        boolean boolean16 = categoryPlot8.isDomainGridlinesVisible();
        int int17 = categoryPlot8.getDatasetCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Color color7 = java.awt.Color.RED;
        ringPlot0.setOutlinePaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        ringPlot0.setSeparatorPaint(paint9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        java.awt.RenderingHints renderingHints21 = jFreeChart15.getRenderingHints();
        java.awt.Paint paint22 = jFreeChart15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.geom.Point2D point2D8 = xYPlot7.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot7.getRenderer(1);
        xYPlot7.configureDomainAxes();
        xYPlot7.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot7.getDomainAxis((int) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CrosshairState crosshairState25 = null;
        boolean boolean26 = xYPlot20.render(graphics2D21, rectangle2D22, 8, plotRenderingInfo24, crosshairState25);
        boolean boolean27 = xYPlot20.isDomainCrosshairVisible();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setUpperBound((double) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape32 = numberAxis31.getRightArrow();
        float float33 = numberAxis31.getTickMarkInsideLength();
        double double34 = numberAxis31.getLabelAngle();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D36.configure();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setUpperBound((double) 0L);
        boolean boolean41 = numberAxis38.getAutoRangeIncludesZero();
        float float42 = numberAxis38.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        numberAxis43.setUpperBound((double) 0L);
        boolean boolean46 = numberAxis43.isAutoRange();
        numberAxis43.setLowerBound((double) 1);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { numberAxis28, numberAxis31, numberAxis3D36, numberAxis38, numberAxis43 };
        xYPlot20.setDomainAxes(valueAxisArray49);
        xYPlot7.setRangeAxes(valueAxisArray49);
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint55 = categoryAxis54.getTickLabelPaint();
        xYPlot7.setRangeCrosshairPaint(paint55);
        ringPlot0.setShadowPaint(paint55);
        org.junit.Assert.assertNotNull(point2D8);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        double double4 = textTitle3.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) lineBorder6);
        java.awt.Stroke stroke8 = lineBorder6.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke8);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = null;
        piePlot3D10.setLabelGenerator(pieSectionLabelGenerator13);
        valueMarker9.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot3D10);
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        double double17 = ringPlot16.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot16);
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color20 = java.awt.Color.GRAY;
        java.awt.Color color21 = color20.brighter();
        ringPlot19.setLabelBackgroundPaint((java.awt.Paint) color21);
        float float23 = ringPlot19.getForegroundAlpha();
        int int24 = ringPlot19.getPieIndex();
        double double26 = ringPlot19.getExplodePercent((java.lang.Comparable) true);
        java.awt.Font font27 = ringPlot19.getLabelFont();
        legendTitle18.setItemFont(font27);
        valueMarker9.setLabelFont(font27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        xYPlot0.rendererChanged(rendererChangeEvent1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor5 = new org.jfree.chart.plot.PieLabelDistributor(0);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor5);
        java.lang.String str7 = pieLabelDistributor5.toString();
        int int8 = pieLabelDistributor5.getItemCount();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord10 = pieLabelDistributor5.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        java.awt.Shape shape6 = numberAxis3D2.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.awt.Shape shape8 = chartEntity7.getArea();
        java.lang.String str9 = chartEntity7.getShapeType();
        java.lang.String str10 = chartEntity7.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "poly" + "'", str9.equals("poly"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartEntity: tooltip = null" + "'", str10.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = numberAxis0.getStandardTickUnits();
        double double2 = numberAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot4.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = ringPlot4.getBaseSectionPaint();
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot4.setNoDataMessageFont(font10);
        dateAxis1.setLabelFont(font10);
        java.util.Date date13 = dateAxis1.getMaximumDate();
        try {
            boolean boolean15 = dateAxis1.isHiddenValue((long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getDomainAxisEdge();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D();
        double double8 = size2D7.getHeight();
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        double double12 = ringPlot11.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot11);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint15.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D18 = legendTitle13.arrange(graphics2D14, rectangleConstraint17);
        java.awt.Font font19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle13.setItemFont(font19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle13.getLegendItemGraphicLocation();
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, 82.0d, (double) (-1), rectangleAnchor21);
        try {
            categoryPlot0.drawBackground(graphics2D6, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot13.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setNegativeArrowVisible(false);
        boolean boolean19 = numberAxis16.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        numberAxis16.setDefaultAutoRange(range27);
        numberAxis16.resizeRange((double) 100);
        numberAxis16.setLowerBound((double) 0L);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        java.text.DateFormat dateFormat35 = dateAxis34.getDateFormatOverride();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16, dateAxis34 };
        categoryPlot0.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(dateFormat35);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(sortOrder38);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot9.getPieChart();
        jFreeChart13.setTitle("Category Plot");
        try {
            org.jfree.chart.title.Title title17 = jFreeChart13.getSubtitle(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jFreeChart13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot3.removeChangeListener(plotChangeListener18);
        categoryPlot3.clearDomainMarkers();
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        jFreeChart15.setBorderPaint(paint16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        xYPlot4.setRangeAxis(valueAxis11);
        xYPlot4.mapDatasetToDomainAxis((int) ' ', (int) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.geom.Point2D point2D22 = xYPlot21.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        xYPlot21.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot21.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot21.getRangeAxisLocation(3);
        xYPlot4.setRangeAxisLocation(8, axisLocation28, false);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot4.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(valueAxis32);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight(10.0d);
        double double7 = rectangleConstraint4.getWidth();
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D();
        size2D8.height = 1.0f;
        java.lang.Object obj11 = size2D8.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, 0.0d, 0.0d, rectangleAnchor14);
        size2D8.setHeight((double) 100);
        org.jfree.chart.util.Size2D size2D18 = rectangleConstraint4.calculateConstrainedSize(size2D8);
        boolean boolean19 = categoryPlot0.equals((java.lang.Object) size2D8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setPieIndex(0);
        ringPlot0.setExplodePercent((java.lang.Comparable) 0.0d, (double) (-1.0f));
        ringPlot0.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 2.0f);
        columnArrangement4.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setWeight((int) (byte) 100);
        categoryPlot6.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot6.setDomainAxis((int) (byte) 0, categoryAxis13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot6.setRenderer(categoryItemRenderer15);
        boolean boolean17 = columnArrangement4.equals((java.lang.Object) categoryPlot6);
        boolean boolean18 = categoryPlot6.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        boolean boolean3 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setInverted(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Range[-1.0,1.0]");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle1.getPosition();
        java.lang.String str8 = textTitle1.getID();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        java.awt.geom.Point2D point2D12 = xYPlot11.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot11.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot11.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot11.getRangeAxisLocation(3);
        try {
            xYPlot4.setRangeAxisLocation((int) (short) -1, axisLocation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot4.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setWeight((int) (byte) 100);
        categoryPlot6.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot6.setDomainAxis((int) (byte) 0, categoryAxis13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot6.getRangeAxisEdge();
        categoryPlot6.setBackgroundAlpha((float) 2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot6.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot24.render(graphics2D25, rectangle2D26, 8, plotRenderingInfo28, crosshairState29);
        java.awt.Color color32 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.clearDomainMarkers(2);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot33.setRangeCrosshairStroke(stroke36);
        java.awt.Paint paint38 = null;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36, paint38, stroke39, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker41.setLabelTextAnchor(textAnchor42);
        xYPlot24.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean46 = categoryPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker41, layer45);
        try {
            boolean boolean47 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        double double4 = textTitle1.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        textTitle1.setURLText("");
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean11 = textTitle1.equals((java.lang.Object) piePlot3D8);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot3D8.setLabelLinkPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint2 = piePlot3D0.getLabelShadowPaint();
        java.lang.String str3 = piePlot3D0.getPlotType();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        double double6 = size2D5.getHeight();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        double double10 = ringPlot9.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D16 = legendTitle11.arrange(graphics2D12, rectangleConstraint15);
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle11.setItemFont(font17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle11.getLegendItemGraphicLocation();
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, 82.0d, (double) (-1), rectangleAnchor19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setWeight((int) (byte) 100);
        categoryPlot21.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot21.setDomainAxis((int) (byte) 0, categoryAxis28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot21.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.CrosshairState crosshairState42 = null;
        boolean boolean43 = xYPlot37.render(graphics2D38, rectangle2D39, 8, plotRenderingInfo41, crosshairState42);
        int int44 = xYPlot37.getWeight();
        java.awt.geom.Point2D point2D45 = xYPlot37.getQuadrantOrigin();
        categoryPlot21.zoomRangeAxes((double) 0, plotRenderingInfo32, point2D45, false);
        org.jfree.chart.plot.PlotState plotState48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        try {
            piePlot3D0.draw(graphics2D4, rectangle2D20, point2D45, plotState48, plotRenderingInfo49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(point2D45);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        java.awt.Color color6 = java.awt.Color.GRAY;
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color8, color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, color16 };
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray17, paintArray19, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextFillPaint();
        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextPaint();
        java.awt.Stroke stroke26 = defaultDrawingSupplier23.getNextStroke();
        java.lang.Object obj27 = defaultDrawingSupplier23.clone();
        ringPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean30 = defaultDrawingSupplier23.equals((java.lang.Object) dateTickUnit29);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot9.getDataset();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color16 = java.awt.Color.GRAY;
        java.awt.Color color17 = color16.brighter();
        ringPlot15.setLabelBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = ringPlot15.getLegendLabelURLGenerator();
        ringPlot15.setLabelGap(4.0d);
        boolean boolean22 = multiplePiePlot9.equals((java.lang.Object) ringPlot15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        java.awt.geom.Point2D point2D10 = xYPlot9.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot9.getRenderer(1);
        java.util.List list13 = xYPlot9.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot9.getRenderer();
        java.awt.Stroke stroke15 = xYPlot9.getDomainZeroBaselineStroke();
        int int16 = xYPlot9.getDatasetCount();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot9.setRangeTickBandPaint(paint17);
        categoryAxis1.setTickMarkPaint(paint17);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = ringPlot0.getDatasetGroup();
        java.awt.Stroke stroke5 = null;
        try {
            ringPlot0.setSeparatorStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(datasetGroup4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot5.axisChanged(axisChangeEvent18);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot5.getRangeMarkers((int) (short) 1, layer21);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setVerticalTickLabels(true);
        numberAxis0.setUpperBound(2.0d);
        java.lang.String str9 = numberAxis0.getLabel();
        java.awt.Shape shape10 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle11.setVerticalAlignment(verticalAlignment12);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(verticalAlignment12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace16);
        float float18 = categoryPlot5.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setCircular(true);
        java.awt.Shape shape6 = ringPlot0.getLegendItemShape();
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        ringPlot0.setLabelFont(font8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = ringPlot0.getSimpleLabelOffset();
        double double11 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = ringPlot0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord9 = abstractPieLabelDistributor7.getPieLabelRecord((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot4.getOrientation();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        org.jfree.data.Range range30 = org.jfree.data.Range.expand(range27, (double) 1L, 0.0d);
        dateAxis19.setRange(range30, false, false);
        boolean boolean34 = categoryPlot3.equals((java.lang.Object) false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str38 = categoryAxis37.getLabelToolTip();
        java.lang.Object obj39 = categoryAxis37.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setLabelToolTip("ThreadContext");
        categoryAxis41.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        double double48 = categoryAxis47.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint51 = categoryAxis50.getTickLabelPaint();
        categoryAxis50.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35, categoryAxis37, categoryAxis40, categoryAxis41, categoryAxis47, categoryAxis50 };
        categoryPlot3.setDomainAxes(categoryAxisArray54);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint59 = categoryAxis58.getTickLabelPaint();
        categoryAxis58.setAxisLineVisible(false);
        java.lang.Object obj62 = null;
        boolean boolean63 = categoryAxis58.equals(obj62);
        try {
            categoryPlot3.setDomainAxis((-16777024), categoryAxis58, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.clearDomainMarkers(2);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke7);
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7, paint9, stroke10, 0.0f);
        categoryAxis3D1.setTickMarkStroke(stroke10);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D16 = new org.jfree.chart.util.Size2D();
        size2D16.height = 1.0f;
        java.lang.Object obj19 = size2D16.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 0.0d, 0.0d, rectangleAnchor22);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        double double27 = ringPlot26.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = legendTitle28.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, (double) (-65536), 0.12d, rectangleAnchor29);
        org.jfree.chart.util.Size2D size2D31 = new org.jfree.chart.util.Size2D();
        size2D31.height = 1.0f;
        java.lang.Object obj34 = size2D31.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, 0.0d, 0.0d, rectangleAnchor37);
        org.jfree.chart.plot.RingPlot ringPlot41 = new org.jfree.chart.plot.RingPlot();
        double double42 = ringPlot41.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendTitle43.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D45 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D31, (double) (-65536), 0.12d, rectangleAnchor44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        try {
            org.jfree.chart.axis.AxisState axisState48 = categoryAxis3D1.draw(graphics2D14, 0.0d, rectangle2D30, rectangle2D45, rectangleEdge46, plotRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 90.0d + "'", double27 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 90.0d + "'", double42 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        boolean boolean4 = numberAxis0.isVisible();
        numberAxis0.setUpperBound(1.0E-8d);
        java.awt.Shape shape7 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        java.awt.Paint paint3 = waferMapPlot1.getBackgroundPaint();
        boolean boolean4 = projectInfo0.equals((java.lang.Object) paint3);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        projectInfo6.setCopyright("");
        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(projectInfo6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        java.awt.Paint paint9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        xYPlot4.setRangeTickBandPaint(paint9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.geom.Point2D point2D18 = xYPlot17.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) (short) 100, plotRenderingInfo12, point2D18, true);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        try {
            xYPlot4.setDataset((-1), xYDataset22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers(2);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot16.setRangeCrosshairStroke(stroke19);
        java.awt.Paint paint21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19, paint21, stroke22, 0.0f);
        valueMarker24.setValue((double) (-1));
        valueMarker24.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer29);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setNegativeArrowVisible(false);
        boolean boolean34 = numberAxis31.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap35 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D37.setTickMarkOutsideLength((float) '4');
        boolean boolean40 = paintMap35.equals((java.lang.Object) numberAxis3D37);
        java.awt.Shape shape41 = numberAxis3D37.getUpArrow();
        org.jfree.data.Range range42 = numberAxis3D37.getDefaultAutoRange();
        numberAxis31.setDefaultAutoRange(range42);
        numberAxis31.resizeRange((double) 100);
        numberAxis31.setInverted(false);
        numberAxis31.centerRange(0.05d);
        org.jfree.data.Range range50 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNull(range50);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot4.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = ringPlot4.getBaseSectionPaint();
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot4.setNoDataMessageFont(font10);
        dateAxis1.setLabelFont(font10);
        java.util.Date date13 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        java.util.Date date17 = dateAxis16.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline20 = null;
        dateAxis19.setTimeline(timeline20);
        java.util.TimeZone timeZone22 = dateAxis19.getTimeZone();
        java.util.Date date23 = dateAxis19.getMinimumDate();
        try {
            dateAxis1.setRange(date17, date23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        boolean boolean6 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        java.awt.geom.Point2D point2D12 = xYPlot11.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot11.rendererChanged(rendererChangeEvent13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot11.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot11.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot11.getRangeAxisLocation(2);
        java.awt.Color color22 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.clearDomainMarkers(2);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot23.setRangeCrosshairStroke(stroke26);
        java.awt.Paint paint28 = null;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26, paint28, stroke29, 0.0f);
        valueMarker31.setValue((double) (-1));
        valueMarker31.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer36 = null;
        xYPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker31, layer36);
        try {
            boolean boolean38 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = numberAxis0.getLabelInsets();
        double double3 = rectangleInsets1.calculateRightInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        xYPlot4.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            xYPlot4.handleClick(2, (int) 'a', plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) 1L, 0.0d);
        dateAxis1.setRange(range12, false, false);
        boolean boolean16 = dateAxis1.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double18 = dateRange17.getCentralValue();
        dateAxis1.setRange((org.jfree.data.Range) dateRange17);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color2, color3, color4, color5, color6 };
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color9, color10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray11, paintArray13, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.BOTTOM_LEFT", font1, paint19, 0.0f, textMeasurer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) 1L, 0.0d);
        dateAxis1.setRange(range12, false, false);
        double double16 = range12.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setVerticalTickLabels(true);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis0.setAxisLineStroke(stroke7);
        java.awt.Stroke stroke9 = numberAxis0.getAxisLineStroke();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle1.getPosition();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.geom.Point2D point2D13 = xYPlot12.getQuadrantOrigin();
        boolean boolean14 = rectangleEdge7.equals((java.lang.Object) xYPlot12);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color4 = java.awt.Color.GRAY;
        java.awt.Color color5 = color4.brighter();
        ringPlot3.setLabelBackgroundPaint((java.awt.Paint) color5);
        ringPlot3.setCircular(true);
        boolean boolean9 = piePlot3D0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(false);
        numberAxis0.setLowerBound((double) (byte) 100);
        numberAxis0.setTickMarkOutsideLength((float) 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getInsets();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot0.setRangeAxis((int) (byte) 1, valueAxis12);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        java.awt.Stroke stroke10 = xYPlot4.getDomainZeroBaselineStroke();
        int int11 = xYPlot4.getDatasetCount();
        boolean boolean12 = xYPlot4.isDomainCrosshairVisible();
        java.awt.Paint paint14 = xYPlot4.getQuadrantPaint(0);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(0);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        boolean boolean2 = ringPlot0.getIgnoreNullValues();
        java.awt.Paint paint3 = ringPlot0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers(2);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot16.setRangeCrosshairStroke(stroke19);
        java.awt.Paint paint21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19, paint21, stroke22, 0.0f);
        valueMarker24.setValue((double) (-1));
        valueMarker24.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer29);
        valueMarker24.setLabel("{0}");
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color34 = java.awt.Color.GRAY;
        java.awt.Color color35 = color34.brighter();
        ringPlot33.setLabelBackgroundPaint((java.awt.Paint) color35);
        float float37 = ringPlot33.getForegroundAlpha();
        int int38 = ringPlot33.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup39 = ringPlot33.getDatasetGroup();
        java.awt.Paint paint40 = ringPlot33.getLabelShadowPaint();
        valueMarker24.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) ringPlot33);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 1.0f + "'", float37 == 1.0f);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(datasetGroup39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int11 = color10.getRed();
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 10.0f, 90.0d, 1.0d, (java.awt.Paint) color10);
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        java.util.List list8 = categoryPlot4.getAnnotations();
        projectInfo0.setContributors(list8);
        java.lang.String str10 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JFreeChart" + "'", str10.equals("JFreeChart"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(10.0d);
        double double3 = rectangleConstraint0.getWidth();
        double double4 = rectangleConstraint0.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = xYPlot4.getDatasetRenderingOrder();
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setPieIndex(0);
        ringPlot0.setExplodePercent((java.lang.Comparable) 0.0d, (double) (-1.0f));
        ringPlot0.setSeparatorsVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        double double7 = ringPlot0.getExplodePercent((java.lang.Comparable) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(2);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke11);
        categoryPlot8.setDomainGridlinesVisible(false);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) categoryPlot8);
        boolean boolean16 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot8.removeChangeListener(plotChangeListener17);
        boolean boolean19 = categoryPlot8.isRangeZoomable();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot18 = jFreeChart15.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot13.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setNegativeArrowVisible(false);
        boolean boolean19 = numberAxis16.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        numberAxis16.setDefaultAutoRange(range27);
        numberAxis16.resizeRange((double) 100);
        numberAxis16.setLowerBound((double) 0L);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        java.text.DateFormat dateFormat35 = dateAxis34.getDateFormatOverride();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { numberAxis16, dateAxis34 };
        categoryPlot0.setRangeAxes(valueAxisArray36);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = categoryPlot0.getRangeMarkers(layer38);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(dateFormat35);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNull(collection39);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        boolean boolean14 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color16 = java.awt.Color.GRAY;
        java.awt.Color color17 = color16.brighter();
        ringPlot15.setLabelBackgroundPaint((java.awt.Paint) color17);
        float float19 = ringPlot15.getForegroundAlpha();
        ringPlot15.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation22 = ringPlot15.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = multiplePiePlot24.getDataset();
        java.awt.Font font26 = multiplePiePlot24.getNoDataMessageFont();
        boolean boolean27 = rotation22.equals((java.lang.Object) multiplePiePlot24);
        org.jfree.chart.util.TableOrder tableOrder28 = multiplePiePlot24.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder29 = multiplePiePlot24.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot24.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str32 = ringPlot31.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot31);
        java.lang.Object obj34 = plotChangeEvent33.getSource();
        jFreeChart30.plotChanged(plotChangeEvent33);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart30);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rotation22);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(tableOrder28);
        org.junit.Assert.assertNotNull(tableOrder29);
        org.junit.Assert.assertNotNull(jFreeChart30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("java.awt.Color[r=182,g=182,b=182]");
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.0d + "'", double2 == 15.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16744448) + "'", int1 == (-16744448));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = ringPlot0.getDatasetGroup();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.brighter();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color7);
        float float9 = ringPlot5.getForegroundAlpha();
        ringPlot5.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation12 = ringPlot5.getDirection();
        ringPlot0.setDirection(rotation12);
        boolean boolean14 = ringPlot0.getSimpleLabels();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(categoryAnchor3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color2 = java.awt.Color.GRAY;
        java.awt.Color color3 = color2.brighter();
        ringPlot1.setLabelBackgroundPaint((java.awt.Paint) color3);
        float float5 = ringPlot1.getForegroundAlpha();
        int int6 = ringPlot1.getPieIndex();
        java.awt.Color color7 = java.awt.Color.GRAY;
        ringPlot1.setShadowPaint((java.awt.Paint) color7);
        java.awt.Paint paint10 = ringPlot1.getSectionPaint((java.lang.Comparable) 3.0d);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot();
        boolean boolean12 = ringPlot11.isCircular();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot11.setShadowPaint((java.awt.Paint) color13);
        double double15 = ringPlot11.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str20 = textAnchor19.toString();
        boolean boolean21 = rectangleInsets16.equals((java.lang.Object) str20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets16, (java.awt.Paint) color22);
        ringPlot11.setShadowPaint((java.awt.Paint) color22);
        java.awt.Color color25 = color22.brighter();
        ringPlot1.setLabelShadowPaint((java.awt.Paint) color25);
        org.jfree.chart.plot.RingPlot ringPlot27 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color28 = java.awt.Color.GRAY;
        java.awt.Color color29 = color28.brighter();
        ringPlot27.setLabelBackgroundPaint((java.awt.Paint) color29);
        ringPlot27.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        ringPlot27.handleClick((int) (short) 100, (int) (byte) 1, plotRenderingInfo35);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor37 = ringPlot27.getLabelDistributor();
        java.awt.Stroke stroke38 = ringPlot27.getSeparatorStroke();
        org.jfree.chart.plot.RingPlot ringPlot39 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color40 = java.awt.Color.GRAY;
        java.awt.Color color41 = color40.brighter();
        ringPlot39.setLabelBackgroundPaint((java.awt.Paint) color41);
        float float43 = ringPlot39.getForegroundAlpha();
        ringPlot39.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation46 = ringPlot39.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot48 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset47);
        org.jfree.data.category.CategoryDataset categoryDataset49 = multiplePiePlot48.getDataset();
        java.awt.Font font50 = multiplePiePlot48.getNoDataMessageFont();
        boolean boolean51 = rotation46.equals((java.lang.Object) multiplePiePlot48);
        org.jfree.chart.util.TableOrder tableOrder52 = multiplePiePlot48.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder53 = multiplePiePlot48.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart54 = multiplePiePlot48.getPieChart();
        jFreeChart54.setNotify(false);
        jFreeChart54.setBackgroundImageAlpha((float) (byte) 100);
        boolean boolean59 = jFreeChart54.isBorderVisible();
        jFreeChart54.clearSubtitles();
        java.awt.Font font62 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int64 = color63.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot65.setWeight((int) (byte) 100);
        categoryPlot65.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot65.setDomainAxis((int) (byte) 0, categoryAxis72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot65.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment75 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment76 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double79 = rectangleInsets77.calculateLeftInset((-1.0d));
        double double80 = rectangleInsets77.getLeft();
        double double82 = rectangleInsets77.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("ClassContext", font62, (java.awt.Paint) color63, rectangleEdge74, horizontalAlignment75, verticalAlignment76, rectangleInsets77);
        int int84 = color63.getAlpha();
        int int85 = color63.getRGB();
        boolean boolean86 = jFreeChart54.equals((java.lang.Object) color63);
        org.jfree.chart.plot.PiePlot piePlot87 = new org.jfree.chart.plot.PiePlot();
        java.awt.Stroke stroke88 = piePlot87.getLabelLinkStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker90 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color25, stroke38, (java.awt.Paint) color63, stroke88, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str20.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(rotation46);
        org.junit.Assert.assertNull(categoryDataset49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(tableOrder52);
        org.junit.Assert.assertNotNull(tableOrder53);
        org.junit.Assert.assertNotNull(jFreeChart54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(horizontalAlignment75);
        org.junit.Assert.assertNotNull(verticalAlignment76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 4.0d + "'", double79 == 4.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 4.0d + "'", double80 == 4.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 255 + "'", int84 == 255);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-16777024) + "'", int85 == (-16777024));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        xYPlot4.mapDatasetToDomainAxis(0, 0);
        xYPlot4.clearRangeMarkers((int) (byte) 0);
        xYPlot4.setRangeCrosshairValue((double) 10.0f);
        boolean boolean16 = xYPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Other", graphics2D1, (double) (byte) -1, 0.5f, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.lang.Object obj3 = jFreeChartResources0.handleGetObject("");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        double double16 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        java.awt.Shape shape6 = numberAxis3D2.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        chartEntity7.setURLText("ClassContext");
        java.lang.String str10 = chartEntity7.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot5.getDomainAxisLocation();
        categoryPlot5.clearDomainMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot5.getRendererForDataset(categoryDataset19);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("JFreeChart", graphics2D1, 0.0f, (float) (short) 0, 90.0d, (float) 10L, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        boolean boolean11 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setUpperBound((double) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape16 = numberAxis15.getRightArrow();
        float float17 = numberAxis15.getTickMarkInsideLength();
        double double18 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D20.configure();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setUpperBound((double) 0L);
        boolean boolean25 = numberAxis22.getAutoRangeIncludesZero();
        float float26 = numberAxis22.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperBound((double) 0L);
        boolean boolean30 = numberAxis27.isAutoRange();
        numberAxis27.setLowerBound((double) 1);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis3D20, numberAxis22, numberAxis27 };
        xYPlot4.setDomainAxes(valueAxisArray33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        xYPlot4.setDomainAxis(8, valueAxis36, true);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace39, true);
        boolean boolean42 = xYPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot9.getDataset();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot9, (org.jfree.chart.block.Arrangement) flowArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement16);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot();
        double double19 = ringPlot18.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot18);
        org.jfree.chart.block.BlockContainer blockContainer21 = legendTitle20.getItemContainer();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range24 = rectangleConstraint23.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint23.toUnconstrainedHeight();
        org.jfree.chart.util.Size2D size2D26 = flowArrangement16.arrange(blockContainer21, graphics2D22, rectangleConstraint23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(size2D26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint5 = categoryAxis4.getTickLabelPaint();
        categoryAxis4.setAxisLineVisible(false);
        boolean boolean8 = numberAxis0.equals((java.lang.Object) false);
        org.jfree.chart.plot.Plot plot9 = numberAxis0.getPlot();
        boolean boolean10 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit11, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setInverted(false);
        numberAxis0.setLowerBound((double) (byte) 100);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis0.getStandardTickUnits();
        numberAxis0.setLowerMargin((double) (short) 1);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        org.jfree.data.Range range30 = org.jfree.data.Range.expand(range27, (double) 1L, 0.0d);
        dateAxis19.setRange(range30, false, false);
        boolean boolean34 = categoryPlot3.equals((java.lang.Object) false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str38 = categoryAxis37.getLabelToolTip();
        java.lang.Object obj39 = categoryAxis37.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setLabelToolTip("ThreadContext");
        categoryAxis41.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        double double48 = categoryAxis47.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint51 = categoryAxis50.getTickLabelPaint();
        categoryAxis50.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35, categoryAxis37, categoryAxis40, categoryAxis41, categoryAxis47, categoryAxis50 };
        categoryPlot3.setDomainAxes(categoryAxisArray54);
        categoryPlot3.clearDomainMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot3.getDomainAxis((-16777024));
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
        org.junit.Assert.assertNull(categoryAxis58);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color0, color1, color2, color3, color4 };
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, color7, color8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray14 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray9, paintArray11, strokeArray12, strokeArray13, shapeArray14);
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextFillPaint();
        java.awt.Paint paint17 = defaultDrawingSupplier15.getNextPaint();
        java.awt.Stroke stroke18 = defaultDrawingSupplier15.getNextStroke();
        java.lang.Object obj19 = defaultDrawingSupplier15.clone();
        java.awt.Paint paint20 = defaultDrawingSupplier15.getNextFillPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator3);
        java.awt.Shape shape5 = piePlot3D0.getLegendItemShape();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap8 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D10.setTickMarkOutsideLength((float) '4');
        boolean boolean13 = paintMap8.equals((java.lang.Object) numberAxis3D10);
        java.awt.Shape shape14 = numberAxis3D10.getUpArrow();
        org.jfree.data.Range range15 = numberAxis3D10.getDefaultAutoRange();
        org.jfree.data.Range range18 = org.jfree.data.Range.expand(range15, (double) 1L, 0.0d);
        dateAxis7.setRange(range18, false, false);
        boolean boolean22 = dateAxis7.isPositiveArrowVisible();
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis7.setTickMarkPaint(paint23);
        piePlot3D0.setLabelBackgroundPaint(paint23);
        org.jfree.chart.plot.RingPlot ringPlot26 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color27 = java.awt.Color.GRAY;
        java.awt.Color color28 = color27.brighter();
        ringPlot26.setLabelBackgroundPaint((java.awt.Paint) color28);
        float float30 = ringPlot26.getForegroundAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        ringPlot26.addChangeListener(plotChangeListener31);
        org.jfree.chart.plot.RingPlot ringPlot33 = new org.jfree.chart.plot.RingPlot();
        boolean boolean34 = ringPlot33.isCircular();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot33.setShadowPaint((java.awt.Paint) color35);
        double double37 = ringPlot33.getShadowYOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = ringPlot33.getLegendLabelGenerator();
        ringPlot26.setLegendLabelGenerator(pieSectionLabelGenerator38);
        piePlot3D0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator38);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator38);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        java.util.List list8 = categoryPlot4.getAnnotations();
        projectInfo0.setContributors(list8);
        projectInfo0.addOptionalLibrary("Size2D[width=0.0, height=1.0]");
        projectInfo0.setLicenceName("TextAnchor.HALF_ASCENT_LEFT");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        boolean boolean14 = textTitle1.getExpandToFitSpace();
        double double15 = textTitle1.getWidth();
        textTitle1.setURLText("TextAnchor.BASELINE_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = textTitle1.getPosition();
        java.awt.Paint paint19 = textTitle1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedHeight(10.0d);
        double double24 = rectangleConstraint21.getWidth();
        org.jfree.chart.util.Size2D size2D25 = new org.jfree.chart.util.Size2D();
        size2D25.height = 1.0f;
        java.lang.Object obj28 = size2D25.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D32 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, 0.0d, 0.0d, rectangleAnchor31);
        size2D25.setHeight((double) 100);
        org.jfree.chart.util.Size2D size2D35 = rectangleConstraint21.calculateConstrainedSize(size2D25);
        try {
            org.jfree.chart.util.Size2D size2D36 = textTitle1.arrange(graphics2D20, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(rectangleConstraint21);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(size2D35);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color0 = java.awt.Color.WHITE;
        float[] floatArray9 = new float[] { ' ', 0, (short) 100, 3, 500 };
        float[] floatArray10 = java.awt.Color.RGBtoHSB((int) (byte) 0, 8, 100, floatArray9);
        float[] floatArray11 = color0.getRGBComponents(floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateBottomInset((double) 0L);
        double double8 = rectangleInsets4.calculateLeftInset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setCircular(true);
        java.awt.Shape shape6 = ringPlot0.getLegendItemShape();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        ringPlot0.setLegendLabelURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color5);
        java.lang.String str7 = color5.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str7.equals("java.awt.Color[r=0,g=128,b=0]"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setUpperBound((double) 0L);
        numberAxis1.setLowerBound((double) (short) -1);
        boolean boolean6 = standardPieSectionLabelGenerator0.equals((java.lang.Object) numberAxis1);
        java.lang.Object obj7 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (byte) 100);
        categoryPlot13.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot13.setDomainAxis((int) (byte) 0, categoryAxis20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot13.setRenderer(categoryItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot13.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(2, axisLocation25, true);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = new org.jfree.chart.util.Size2D();
        size2D29.height = 1.0f;
        java.lang.Object obj32 = size2D29.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D29, 0.0d, 0.0d, rectangleAnchor35);
        try {
            categoryPlot0.drawBackground(graphics2D28, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        boolean boolean11 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setUpperBound((double) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape16 = numberAxis15.getRightArrow();
        float float17 = numberAxis15.getTickMarkInsideLength();
        double double18 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D20.configure();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setUpperBound((double) 0L);
        boolean boolean25 = numberAxis22.getAutoRangeIncludesZero();
        float float26 = numberAxis22.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setUpperBound((double) 0L);
        boolean boolean30 = numberAxis27.isAutoRange();
        numberAxis27.setLowerBound((double) 1);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { numberAxis12, numberAxis15, numberAxis3D20, numberAxis22, numberAxis27 };
        xYPlot4.setDomainAxes(valueAxisArray33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        xYPlot4.setDomainAxis(8, valueAxis36, true);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace39, true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = xYPlot4.getDomainAxis((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNull(valueAxis43);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        boolean boolean20 = jFreeChart15.isBorderVisible();
        java.lang.Object obj21 = jFreeChart15.clone();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart15.getLegend((int) (byte) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(legendTitle23);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot9.getDataset();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot9, (org.jfree.chart.block.Arrangement) flowArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement16);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        boolean boolean9 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        double double11 = ringPlot10.getStartAngle();
        boolean boolean12 = ringPlot10.getIgnoreNullValues();
        ringPlot10.setSeparatorsVisible(false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot10.setBaseSectionOutlinePaint((java.awt.Paint) color15);
        ringPlot10.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint19 = ringPlot10.getBaseSectionOutlinePaint();
        categoryPlot0.setDomainGridlinePaint(paint19);
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot5.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Color color20 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.clearDomainMarkers(2);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke24);
        java.awt.Paint paint26 = null;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24, paint26, stroke27, 0.0f);
        categoryAxis3D18.setTickMarkStroke(stroke27);
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D18);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setNegativeArrowVisible(false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        double double2 = piePlot3D0.getLabelLinkMargin();
        double double3 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-5d + "'", double3 == 1.0E-5d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", graphics2D1, 1.0f, (float) '4', (double) 100, (float) 100L, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        java.awt.Paint paint2 = waferMapPlot0.getBackgroundPaint();
        java.lang.String str3 = waferMapPlot0.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNull(waferMapDataset1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset((-1.0d));
        double double13 = rectangleInsets10.getLeft();
        double double15 = rectangleInsets10.calculateTopInset((-3.0d));
        categoryPlot0.setInsets(rectangleInsets10, false);
        int int18 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        double double6 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle1.getPosition();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.geom.Point2D point2D13 = xYPlot12.getQuadrantOrigin();
        boolean boolean14 = rectangleEdge7.equals((java.lang.Object) xYPlot12);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = null;
        try {
            xYPlot12.setDatasetRenderingOrder(datasetRenderingOrder15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Range[-1.0,1.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setPieIndex(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset((-1.0d));
        double double13 = rectangleInsets10.getBottom();
        ringPlot0.setSimpleLabelOffset(rectangleInsets10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        categoryAxis1.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        categoryAxis1.clearCategoryLabelToolTips();
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        java.lang.String str16 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        org.jfree.data.Range range30 = org.jfree.data.Range.expand(range27, (double) 1L, 0.0d);
        dateAxis19.setRange(range30, false, false);
        boolean boolean34 = dateAxis19.isPositiveArrowVisible();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis19, true);
        java.awt.Stroke stroke37 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 0.05d, false);
        org.jfree.chart.PaintMap paintMap4 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D6.setTickMarkOutsideLength((float) '4');
        boolean boolean9 = paintMap4.equals((java.lang.Object) numberAxis3D6);
        java.awt.Shape shape10 = numberAxis3D6.getUpArrow();
        org.jfree.data.Range range11 = numberAxis3D6.getDefaultAutoRange();
        org.jfree.data.Range range14 = org.jfree.data.Range.expand(range11, (double) 1L, 0.0d);
        java.lang.String str15 = range14.toString();
        double double16 = range14.getUpperBound();
        boolean boolean19 = range14.intersects((double) (-1L), (double) (-1L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range3, range14);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Range[-1.0,1.0]" + "'", str15.equals("Range[-1.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setWeight((int) (byte) 100);
        categoryPlot20.setAnchorValue((double) (short) 0);
        categoryPlot20.setAnchorValue((double) 10.0f);
        boolean boolean27 = categoryPlot20.getDrawSharedDomainAxis();
        double double28 = categoryPlot20.getAnchorValue();
        java.util.List list29 = categoryPlot20.getAnnotations();
        jFreeChart15.setSubtitles(list29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double35 = rectangleInsets33.calculateLeftInset((-1.0d));
        double double36 = rectangleInsets33.getBottom();
        textTitle32.setMargin(rectangleInsets33);
        textTitle32.setExpandToFitSpace(false);
        jFreeChart15.addSubtitle((org.jfree.chart.title.Title) textTitle32);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.0d + "'", double36 == 2.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        double double4 = textTitle1.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (byte) 100);
        categoryPlot10.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot10.setDomainAxis((int) (byte) 0, categoryAxis17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double24 = rectangleInsets22.calculateLeftInset((-1.0d));
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("ClassContext", font7, (java.awt.Paint) color8, rectangleEdge19, horizontalAlignment20, verticalAlignment21, rectangleInsets22);
        textTitle1.setVerticalAlignment(verticalAlignment21);
        java.awt.Paint paint30 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(paint30);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        boolean boolean4 = numberAxis0.isVisible();
        double double5 = numberAxis0.getFixedAutoRange();
        numberAxis0.setInverted(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot16.render(graphics2D17, rectangle2D18, 8, plotRenderingInfo20, crosshairState21);
        int int23 = xYPlot16.getWeight();
        java.awt.geom.Point2D point2D24 = xYPlot16.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 0, plotRenderingInfo11, point2D24, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot0.setRenderer((int) ' ', categoryItemRenderer28, false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(8, xYItemRenderer6);
        java.awt.Stroke stroke8 = xYPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setWeight((int) (byte) 100);
        categoryPlot13.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot13.setDomainAxis((int) (byte) 0, categoryAxis20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot13.setRenderer(categoryItemRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot13.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(2, axisLocation25, true);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateLeftInset((-1.0d));
        double double32 = rectangleInsets29.getLeft();
        double double34 = rectangleInsets29.calculateTopInset((-3.0d));
        numberAxis28.setTickLabelInsets(rectangleInsets29);
        int int36 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis28);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setWeight((int) (byte) 100);
        categoryPlot2.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot2.setDomainAxis((int) (byte) 0, categoryAxis9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot2.getRangeAxisEdge();
        categoryPlot2.setBackgroundAlpha((float) 2);
        boolean boolean14 = objectList0.equals((java.lang.Object) categoryPlot2);
        java.awt.Stroke stroke15 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot2.getFixedDomainAxisSpace();
        java.awt.Stroke stroke17 = categoryPlot2.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        boolean boolean14 = textTitle1.getExpandToFitSpace();
        double double15 = textTitle1.getWidth();
        textTitle1.setURLText("TextAnchor.BASELINE_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = textTitle1.getPosition();
        java.awt.Paint paint19 = textTitle1.getBackgroundPaint();
        java.awt.Paint paint20 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge();
        boolean boolean14 = xYPlot4.equals((java.lang.Object) 0.5d);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int2 = objectList0.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setWeight((int) (byte) 100);
        categoryPlot4.setAnchorValue((double) (short) 0);
        boolean boolean9 = categoryPlot4.isSubplot();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot4.setRangeGridlineStroke(stroke10);
        objectList0.set((int) (byte) 100, (java.lang.Object) categoryPlot4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        categoryAxis1.setLabelToolTip("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = ringPlot6.getLabelDistributor();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot3.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem19 = legendItemCollection17.get((-667));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -667");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = ringPlot0.getDatasetGroup();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.brighter();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color7);
        float float9 = ringPlot5.getForegroundAlpha();
        ringPlot5.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation12 = ringPlot5.getDirection();
        ringPlot0.setDirection(rotation12);
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        boolean boolean16 = ringPlot15.isCircular();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot15.setShadowPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = ringPlot15.getSeparatorStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str21 = rectangleInsets20.toString();
        double double23 = rectangleInsets20.calculateLeftOutset((double) 8);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder(paint14, stroke19, rectangleInsets20);
        ringPlot0.setInsets(rectangleInsets20, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str21.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        textTitle1.setURLText("");
        java.lang.String str6 = textTitle1.getText();
        java.lang.String str7 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        double double7 = ringPlot0.getExplodePercent((java.lang.Comparable) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(2);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke11);
        categoryPlot8.setDomainGridlinesVisible(false);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) categoryPlot8);
        boolean boolean16 = categoryPlot8.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot8.removeChangeListener(plotChangeListener17);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        try {
            categoryPlot8.setDomainAxis((-16744448), categoryAxis21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.GRAY;
        java.awt.Color color3 = color2.brighter();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setWeight((int) (byte) 100);
        categoryPlot4.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        double double16 = textTitle15.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle15);
        double double18 = textTitle15.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle15.getPosition();
        textTitle15.setURLText("");
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D22.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean25 = textTitle15.equals((java.lang.Object) piePlot3D22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D27.setDarkerSides(true);
        boolean boolean30 = horizontalAlignment26.equals((java.lang.Object) true);
        textTitle15.setHorizontalAlignment(horizontalAlignment26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement35 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment26, verticalAlignment32, (double) (byte) 0, (double) (-1));
        java.awt.Font font37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int39 = color38.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setWeight((int) (byte) 100);
        categoryPlot40.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot40.setDomainAxis((int) (byte) 0, categoryAxis47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot40.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment50 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double54 = rectangleInsets52.calculateLeftInset((-1.0d));
        double double55 = rectangleInsets52.getLeft();
        double double57 = rectangleInsets52.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("ClassContext", font37, (java.awt.Paint) color38, rectangleEdge49, horizontalAlignment50, verticalAlignment51, rectangleInsets52);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double61 = rectangleInsets59.calculateRightOutset(100.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER_RIGHT", font1, (java.awt.Paint) color3, rectangleEdge13, horizontalAlignment26, verticalAlignment51, rectangleInsets59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(horizontalAlignment50);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 4.0d + "'", double54 == 4.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 4.0d + "'", double55 == 4.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 4.0d + "'", double61 == 4.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) 1L, 0.0d);
        dateAxis1.setRange(range12, false, false);
        boolean boolean16 = dateAxis1.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double18 = dateRange17.getCentralValue();
        dateAxis1.setRange((org.jfree.data.Range) dateRange17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date21 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit20);
        org.jfree.data.KeyedValues keyedValues22 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) date21, keyedValues22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setBackgroundImageAlignment((int) (byte) 1);
        java.awt.Paint paint3 = piePlot3D0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot0.setDataset((int) (short) 100, categoryDataset13);
        categoryPlot0.setWeight((int) 'a');
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelLinksVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot0.getLegendItems();
        java.util.Iterator iterator4 = legendItemCollection3.iterator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        boolean boolean3 = numberAxis0.isAutoRange();
        boolean boolean4 = numberAxis0.isAutoRange();
        java.awt.Paint paint5 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str11 = textAnchor10.toString();
        java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D5, 0.0f, (float) '4', textAnchor8, (double) 0L, textAnchor10);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.Shape shape15 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=200,b=0]", graphics2D1, (float) (byte) -1, (float) (-16777024), textAnchor8, 0.0d, textAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str11.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateLeftOutset((double) 8);
        legendTitle2.setItemLabelPadding(rectangleInsets4);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle2.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str5.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        java.lang.Object obj4 = blockContainer3.clone();
        blockContainer3.clear();
        java.util.List list6 = blockContainer3.getBlocks();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot4.getLegendItems();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(2);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke3);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str10 = categoryAxis9.getLabelToolTip();
        java.lang.Object obj11 = categoryAxis9.clone();
        categoryPlot0.setDomainAxis(1, categoryAxis9, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot0.setDataset((int) (short) 100, categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot0.setDataset((int) (byte) 100, categoryDataset16);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("java.awt.Color[r=255,g=200,b=0]", "TextAnchor.TOP_CENTER");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str3.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue((double) 4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot4.getLegendLabelURLGenerator();
        java.awt.Paint paint9 = ringPlot4.getBaseSectionPaint();
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot4.setNoDataMessageFont(font10);
        dateAxis1.setLabelFont(font10);
        java.util.Date date13 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis1.getTickUnit();
        java.text.DateFormat dateFormat15 = null;
        dateAxis1.setDateFormatOverride(dateFormat15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTickUnit14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint13 = categoryAxis12.getTickLabelPaint();
        categoryAxis12.setAxisLineVisible(false);
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis12.setTickMarkStroke(stroke18);
        xYPlot4.setDomainZeroBaselineStroke(stroke18);
        boolean boolean21 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation22 = null;
        try {
            boolean boolean23 = xYPlot4.removeAnnotation(xYAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        textTitle1.setExpandToFitSpace(false);
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color10 = java.awt.Color.GRAY;
        java.awt.Color color11 = color10.brighter();
        ringPlot9.setLabelBackgroundPaint((java.awt.Paint) color11);
        ringPlot9.setCircular(true);
        java.awt.Shape shape15 = ringPlot9.getLegendItemShape();
        java.awt.Paint paint16 = ringPlot9.getLabelPaint();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        ringPlot9.setLabelFont(font17);
        textTitle1.setFont(font17);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint2 = piePlot3D0.getLabelShadowPaint();
        java.lang.String str3 = piePlot3D0.getPlotType();
        java.awt.Stroke stroke4 = piePlot3D0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setWeight((int) (byte) 100);
        categoryPlot1.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint8 = categoryAxis7.getTickLabelPaint();
        categoryAxis7.setAxisLineVisible(false);
        categoryAxis7.setTickLabelsVisible(false);
        categoryAxis7.setCategoryMargin((double) (-1L));
        int int15 = categoryPlot1.getDomainAxisIndex(categoryAxis7);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis17.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryAxis17.getLabelInsets();
        double double22 = rectangleInsets20.calculateBottomInset((double) 0L);
        categoryAxis7.setLabelInsets(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D25.setTickMarkOutsideLength((float) '4');
        double double28 = numberAxis3D25.getFixedDimension();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setUpperBound((double) 0L);
        numberAxis29.setLowerBound((double) (short) -1);
        numberAxis29.setInverted(false);
        numberAxis29.setLowerBound((double) (byte) 100);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis29.getStandardTickUnits();
        numberAxis3D25.setStandardTickUnits(tickUnitSource38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis3D25, categoryItemRenderer40);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setWeight((int) (byte) 100);
        categoryPlot20.setAnchorValue((double) (short) 0);
        categoryPlot20.setAnchorValue((double) 10.0f);
        boolean boolean27 = categoryPlot20.getDrawSharedDomainAxis();
        double double28 = categoryPlot20.getAnchorValue();
        java.util.List list29 = categoryPlot20.getAnnotations();
        jFreeChart15.setSubtitles(list29);
        boolean boolean31 = jFreeChart15.isBorderVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        java.awt.Paint paint6 = lineBorder4.getPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getDomainAxis((int) (short) 1);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot4.getRangeMarkers((int) '4', layer14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot4.getRangeMarkers(layer16);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        java.text.DateFormat dateFormat3 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, (double) 1, (float) '4', 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("WMAP_Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name WMAP_Plot, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        org.jfree.data.Range range6 = numberAxis3D2.getRange();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        numberAxis3D2.setLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        java.awt.Color color6 = java.awt.Color.GRAY;
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = ringPlot0.getLegendLabelToolTipGenerator();
        ringPlot0.setOuterSeparatorExtension((double) (-1.0f));
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot4.getFixedLegendItems();
        boolean boolean13 = xYPlot4.isRangeCrosshairVisible();
        int int14 = xYPlot4.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot4.getRenderer();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor5 = new org.jfree.chart.plot.PieLabelDistributor(0);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor5);
        java.lang.String str7 = pieLabelDistributor5.toString();
        int int8 = pieLabelDistributor5.getItemCount();
        pieLabelDistributor5.distributeLabels((double) 2.0f, (double) ' ');
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord12 = null;
        try {
            pieLabelDistributor5.addPieLabelRecord(pieLabelRecord12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Color color2 = java.awt.Color.getColor("Pie Plot", (-65536));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) 1L, 0.0d);
        dateAxis1.setRange(range12, false, false);
        boolean boolean18 = range12.intersects((double) (-16744448), (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str15 = ringPlot14.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot14);
        jFreeChart13.plotChanged(plotChangeEvent16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (byte) 100);
        categoryPlot16.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot16.setDomainAxis((int) (byte) 0, categoryAxis23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot16.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot16.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str32 = ringPlot31.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot31);
        java.lang.Object obj34 = plotChangeEvent33.getSource();
        categoryPlot0.notifyListeners(plotChangeEvent33);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setUpperBound((double) 0L);
        numberAxis12.setLowerBound((double) (short) -1);
        java.awt.Shape shape17 = numberAxis12.getUpArrow();
        int int18 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.text.NumberFormat numberFormat19 = numberAxis12.getNumberFormatOverride();
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(numberFormat19);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.brighter();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color7);
        int int9 = color7.getTransparency();
        ringPlot0.setBaseSectionPaint((java.awt.Paint) color7);
        java.awt.Shape shape11 = null;
        try {
            ringPlot0.setLegendItemShape(shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setPieIndex((int) (short) 0);
        double double6 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        java.awt.Color color12 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers(2);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeCrosshairStroke(stroke16);
        java.awt.Paint paint18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16, paint18, stroke19, 0.0f);
        valueMarker21.setValue((double) (-1));
        valueMarker21.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke26 = valueMarker21.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = valueMarker21.getLabelAnchor();
        try {
            boolean boolean28 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint13 = categoryAxis12.getTickLabelPaint();
        categoryAxis12.setAxisLineVisible(false);
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis12.setTickMarkStroke(stroke18);
        xYPlot4.setDomainZeroBaselineStroke(stroke18);
        boolean boolean21 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setUpperBound((double) 0L);
        boolean boolean26 = numberAxis23.isAutoRange();
        boolean boolean27 = numberAxis23.isAutoRange();
        numberAxis23.setInverted(false);
        xYPlot4.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) numberAxis23, true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        java.awt.RenderingHints renderingHints21 = jFreeChart15.getRenderingHints();
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot();
        boolean boolean23 = ringPlot22.isCircular();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        ringPlot22.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        ringPlot22.axisChanged(axisChangeEvent27);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = null;
        ringPlot22.setLegendLabelToolTipGenerator(pieSectionLabelGenerator29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline33 = null;
        dateAxis32.setTimeline(timeline33);
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color36 = java.awt.Color.GRAY;
        java.awt.Color color37 = color36.brighter();
        ringPlot35.setLabelBackgroundPaint((java.awt.Paint) color37);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator39 = ringPlot35.getLegendLabelURLGenerator();
        java.awt.Paint paint40 = ringPlot35.getBaseSectionPaint();
        java.awt.Font font41 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot35.setNoDataMessageFont(font41);
        dateAxis32.setLabelFont(font41);
        java.util.Date date44 = dateAxis32.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis32.getTickUnit();
        java.awt.Stroke stroke46 = ringPlot22.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit45);
        org.jfree.chart.ui.ProjectInfo projectInfo47 = org.jfree.chart.JFreeChart.INFO;
        projectInfo47.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Image image50 = projectInfo47.getLogo();
        ringPlot22.setBackgroundImage(image50);
        jFreeChart15.setBackgroundImage(image50);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(renderingHints21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNull(pieURLGenerator39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertNull(stroke46);
        org.junit.Assert.assertNotNull(projectInfo47);
        org.junit.Assert.assertNotNull(image50);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setAxisLineVisible(false);
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean7 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers(2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot2.setRangeCrosshairStroke(stroke5);
        java.awt.Paint paint7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5, paint7, stroke8, 0.0f);
        valueMarker10.setValue((double) (-1));
        valueMarker10.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke15 = valueMarker10.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = valueMarker10.getLabelAnchor();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int22 = color21.getRed();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 1.0f, (double) 10.0f, 90.0d, 1.0d, (java.awt.Paint) color21);
        java.awt.Color color24 = color21.darker();
        valueMarker10.setOutlinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        org.jfree.chart.util.SortOrder sortOrder13 = categoryPlot0.getColumnRenderingOrder();
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        ringPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        ringPlot0.setExplodePercent((java.lang.Comparable) 8, (double) 1.0f);
        java.awt.Paint paint12 = ringPlot0.getLabelLinkPaint();
        boolean boolean13 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        java.awt.Color color2 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.clearDomainMarkers(2);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot3.setRangeCrosshairStroke(stroke6);
        java.awt.Paint paint8 = null;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color2, stroke6, paint8, stroke9, 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightOutset(100.0d);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint0, stroke6, rectangleInsets12);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) '#');
        boolean boolean5 = categoryPlot0.isSubplot();
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(2);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke11);
        java.awt.Paint paint13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11, paint13, stroke14, 0.0f);
        valueMarker16.setValue((double) (-1));
        valueMarker16.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker16, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot4.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot4.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        xYPlot4.zoomDomainAxes((double) 0L, 0.0d, plotRenderingInfo17, point2D18);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = xYPlot4.removeRangeMarker(3, marker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setWeight(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(500, xYItemRenderer11);
        xYPlot4.clearRangeAxes();
        java.awt.Paint paint15 = null;
        try {
            xYPlot4.setQuadrantPaint((-1), paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.5f, (float) (-16744448), (double) (-667), (float) (-1L), (float) (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(10.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart3);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        java.lang.Object obj6 = chartChangeEvent4.getSource();
        java.lang.String str7 = chartChangeEvent4.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0d + "'", obj5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 10.0d + "'", obj6.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str7.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        boolean boolean20 = jFreeChart15.isBorderVisible();
        jFreeChart15.clearSubtitles();
        boolean boolean22 = jFreeChart15.isNotify();
        java.awt.Paint paint23 = jFreeChart15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(10.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart3);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent4.getChart();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0d + "'", obj5.equals(10.0d));
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str14 = categoryAxis13.getLabelToolTip();
        categoryPlot0.setDomainAxis((int) (byte) 10, categoryAxis13, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot0.getIndexOf(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        ringPlot7.drawBackgroundImage(graphics2D9, rectangle2D10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        ringPlot7.axisChanged(axisChangeEvent12);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = null;
        ringPlot7.setLegendLabelToolTipGenerator(pieSectionLabelGenerator14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis17.setTimeline(timeline18);
        org.jfree.chart.plot.RingPlot ringPlot20 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color21 = java.awt.Color.GRAY;
        java.awt.Color color22 = color21.brighter();
        ringPlot20.setLabelBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = ringPlot20.getLegendLabelURLGenerator();
        java.awt.Paint paint25 = ringPlot20.getBaseSectionPaint();
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot20.setNoDataMessageFont(font26);
        dateAxis17.setLabelFont(font26);
        java.util.Date date29 = dateAxis17.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis17.getTickUnit();
        java.awt.Stroke stroke31 = ringPlot7.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit30);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.plot.RingPlot ringPlot35 = new org.jfree.chart.plot.RingPlot();
        double double36 = ringPlot35.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendTitle37.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D39 = legendTitle37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        try {
            double double41 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) dateTickUnit30, (java.lang.Comparable) 3, categoryDataset33, 0.0d, rectangle2D39, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(pieURLGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(dateTickUnit30);
        org.junit.Assert.assertNull(stroke31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 90.0d + "'", double36 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) '#');
        categoryPlot0.mapDatasetToRangeAxis((int) '4', (int) (byte) 10);
        int int8 = categoryPlot0.getWeight();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle2.getSources();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(8, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot4.setDomainZeroBaselinePaint(paint8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setNegativeArrowVisible(false);
        java.lang.String str13 = numberAxis10.getLabel();
        boolean boolean14 = numberAxis10.isVisible();
        int int15 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Color color18 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.clearDomainMarkers(2);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot19.setRangeCrosshairStroke(stroke22);
        java.awt.Paint paint24 = null;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke22, paint24, stroke25, 0.0f);
        valueMarker27.setValue((double) (-1));
        valueMarker27.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke32 = valueMarker27.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = valueMarker27.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot34 = new org.jfree.chart.plot.RingPlot();
        double double35 = ringPlot34.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = legendTitle36.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets33.createInsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.ui.ProjectInfo projectInfo42 = org.jfree.chart.JFreeChart.INFO;
        projectInfo42.setCopyright("");
        java.util.List list45 = projectInfo42.getContributors();
        xYPlot4.drawDomainTickBands(graphics2D16, rectangle2D38, list45);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(projectInfo42);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color11 = java.awt.Color.GRAY;
        java.awt.Color color12 = color11.brighter();
        ringPlot10.setLabelBackgroundPaint((java.awt.Paint) color12);
        float float14 = ringPlot10.getForegroundAlpha();
        ringPlot10.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation17 = ringPlot10.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = multiplePiePlot19.getDataset();
        java.awt.Font font21 = multiplePiePlot19.getNoDataMessageFont();
        boolean boolean22 = rotation17.equals((java.lang.Object) multiplePiePlot19);
        org.jfree.chart.util.TableOrder tableOrder23 = multiplePiePlot19.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder24 = multiplePiePlot19.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart25 = multiplePiePlot19.getPieChart();
        jFreeChart25.setNotify(false);
        jFreeChart25.setBackgroundImageAlpha((float) (byte) 100);
        boolean boolean30 = jFreeChart25.isBorderVisible();
        jFreeChart25.clearSubtitles();
        java.awt.Font font33 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int35 = color34.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setWeight((int) (byte) 100);
        categoryPlot36.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot36.setDomainAxis((int) (byte) 0, categoryAxis43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot36.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double50 = rectangleInsets48.calculateLeftInset((-1.0d));
        double double51 = rectangleInsets48.getLeft();
        double double53 = rectangleInsets48.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle("ClassContext", font33, (java.awt.Paint) color34, rectangleEdge45, horizontalAlignment46, verticalAlignment47, rectangleInsets48);
        int int55 = color34.getAlpha();
        int int56 = color34.getRGB();
        boolean boolean57 = jFreeChart25.equals((java.lang.Object) color34);
        xYPlot4.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot59.setWeight((int) (byte) 100);
        categoryPlot59.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        categoryPlot59.zoomDomainAxes(10.0d, plotRenderingInfo65, point2D66, false);
        org.jfree.data.general.DatasetGroup datasetGroup69 = categoryPlot59.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot59);
        boolean boolean71 = categoryPlot59.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder73 = categoryPlot72.getDatasetRenderingOrder();
        categoryPlot59.setDatasetRenderingOrder(datasetRenderingOrder73);
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis();
        numberAxis75.setNegativeArrowVisible(false);
        boolean boolean78 = numberAxis75.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap79 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D81 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D81.setTickMarkOutsideLength((float) '4');
        boolean boolean84 = paintMap79.equals((java.lang.Object) numberAxis3D81);
        java.awt.Shape shape85 = numberAxis3D81.getUpArrow();
        org.jfree.data.Range range86 = numberAxis3D81.getDefaultAutoRange();
        numberAxis75.setDefaultAutoRange(range86);
        numberAxis75.resizeRange((double) 100);
        numberAxis75.setLowerBound((double) 0L);
        org.jfree.chart.axis.DateAxis dateAxis93 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        java.text.DateFormat dateFormat94 = dateAxis93.getDateFormatOverride();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray95 = new org.jfree.chart.axis.ValueAxis[] { numberAxis75, dateAxis93 };
        categoryPlot59.setRangeAxes(valueAxisArray95);
        xYPlot4.setRangeAxes(valueAxisArray95);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(rotation17);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(tableOrder23);
        org.junit.Assert.assertNotNull(tableOrder24);
        org.junit.Assert.assertNotNull(jFreeChart25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
        org.junit.Assert.assertNotNull(verticalAlignment47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 255 + "'", int55 == 255);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-16777024) + "'", int56 == (-16777024));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(datasetGroup69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(range86);
        org.junit.Assert.assertNull(dateFormat94);
        org.junit.Assert.assertNotNull(valueAxisArray95);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = rectangleInsets12.equals((java.lang.Object) str16);
        legendTitle11.setItemLabelPadding(rectangleInsets12);
        java.lang.Object obj19 = null;
        boolean boolean20 = legendTitle11.equals(obj19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle11.arrange(graphics2D21, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle11.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        double double4 = textTitle1.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle1.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot();
        double double3 = ringPlot2.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle4.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D6 = legendTitle4.getBounds();
        numberAxis3D1.setLeftArrow((java.awt.Shape) rectangle2D6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), 86.0d, 1.05d, 1.05d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.geom.Point2D point2D19 = xYPlot18.getQuadrantOrigin();
        xYPlot8.zoomRangeAxes((double) 0L, (double) 0.5f, plotRenderingInfo13, point2D19);
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = xYPlot8.getDatasetRenderingOrder();
        java.awt.Paint paint23 = xYPlot8.getRangeGridlinePaint();
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        boolean boolean10 = rotation7.equals((java.lang.Object) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.PaintMap paintMap11 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D13.setTickMarkOutsideLength((float) '4');
        boolean boolean16 = paintMap11.equals((java.lang.Object) numberAxis3D13);
        java.awt.Shape shape17 = numberAxis3D13.getUpArrow();
        org.jfree.data.Range range18 = numberAxis3D13.getDefaultAutoRange();
        double double19 = range18.getLowerBound();
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range18, (double) (byte) 1, 0.0d);
        boolean boolean23 = rotation7.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isNotify();
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart15.addChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        java.awt.Stroke stroke10 = xYPlot4.getDomainZeroBaselineStroke();
        int int11 = xYPlot4.getDatasetCount();
        boolean boolean12 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot4.getRenderer();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(xYItemRenderer13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        boolean boolean6 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot7.setShadowPaint((java.awt.Paint) color9);
        org.jfree.data.general.PieDataset pieDataset11 = ringPlot7.getDataset();
        java.awt.Stroke stroke12 = ringPlot7.getLabelOutlineStroke();
        xYPlot4.setDomainCrosshairStroke(stroke12);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        int int11 = xYPlot4.getWeight();
        java.awt.geom.Point2D point2D12 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        java.awt.geom.Point2D point2D20 = xYPlot19.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) (-1L), plotRenderingInfo14, point2D20);
        xYPlot4.clearDomainMarkers((-1));
        org.jfree.chart.plot.RingPlot ringPlot24 = new org.jfree.chart.plot.RingPlot();
        double double25 = ringPlot24.getStartAngle();
        boolean boolean26 = ringPlot24.getIgnoreNullValues();
        ringPlot24.setSeparatorsVisible(false);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot24.setBaseSectionOutlinePaint((java.awt.Paint) color29);
        xYPlot4.setDomainTickBandPaint((java.awt.Paint) color29);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        double double2 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f);
        int int7 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setWeight((int) (byte) 100);
        categoryPlot20.setAnchorValue((double) (short) 0);
        categoryPlot20.setAnchorValue((double) 10.0f);
        boolean boolean27 = categoryPlot20.getDrawSharedDomainAxis();
        double double28 = categoryPlot20.getAnchorValue();
        java.util.List list29 = categoryPlot20.getAnnotations();
        jFreeChart15.setSubtitles(list29);
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart15.getLegend((int) (byte) 100);
        jFreeChart15.removeLegend();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(legendTitle32);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis3D1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        numberAxis0.setLowerBound((double) (short) -1);
        numberAxis0.setVerticalTickLabels(true);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis0.setAxisLineStroke(stroke7);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat10 = standardPieSectionLabelGenerator9.getNumberFormat();
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator9.getNumberFormat();
        numberAxis0.setNumberFormatOverride(numberFormat11);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getPadding();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        java.lang.String str10 = unitType9.toString();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot18.render(graphics2D19, rectangle2D20, 8, plotRenderingInfo22, crosshairState23);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers(2);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke30);
        java.awt.Paint paint32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30, paint32, stroke33, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker35.setLabelTextAnchor(textAnchor36);
        xYPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35, layer39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets();
        valueMarker35.setLabelOffset(rectangleInsets41);
        java.lang.String str43 = rectangleInsets41.toString();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str43.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot4.getRangeAxis(1);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot4.getFixedLegendItems();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNull(legendItemCollection13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        org.jfree.data.Range range12 = org.jfree.data.Range.expand(range9, (double) 1L, 0.0d);
        dateAxis1.setRange(range12, false, false);
        boolean boolean16 = dateAxis1.isPositiveArrowVisible();
        dateAxis1.zoomRange((double) (-1L), (double) '4');
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        try {
            java.util.List list25 = dateAxis1.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        boolean boolean3 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot0);
        org.jfree.chart.JFreeChart jFreeChart3 = plotChangeEvent2.getChart();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setWeight(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(500, xYItemRenderer11);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot4.getRenderer();
        org.jfree.data.general.DatasetGroup datasetGroup14 = xYPlot4.getDatasetGroup();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.geom.Point2D point2D19 = xYPlot18.getQuadrantOrigin();
        xYPlot8.zoomRangeAxes((double) 0L, (double) 0.5f, plotRenderingInfo13, point2D19);
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        xYPlot8.setRenderer(1, xYItemRenderer23);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        boolean boolean6 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        double double6 = textTitle1.getContentYOffset();
        textTitle1.setMargin((double) 1.0f, 0.025d, 0.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        boolean boolean5 = categoryPlot0.isSubplot();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit4, true, false);
        boolean boolean8 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = multiplePiePlot3.getDataset();
        java.awt.Font font5 = multiplePiePlot3.getNoDataMessageFont();
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", font5);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER_RIGHT", font5);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        java.awt.Color color12 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers(2);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeCrosshairStroke(stroke16);
        java.awt.Paint paint18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16, paint18, stroke19, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor22);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace25);
        try {
            java.awt.Paint paint28 = xYPlot4.getQuadrantPaint(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (8) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(axisSpace2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = ringPlot0.getLabelDistributor();
        int int4 = abstractPieLabelDistributor3.getItemCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint14 = categoryAxis13.getTickLabelPaint();
        categoryAxis13.setAxisLineVisible(false);
        java.lang.Object obj17 = null;
        boolean boolean18 = categoryAxis13.equals(obj17);
        java.awt.Paint paint19 = categoryAxis13.getTickLabelPaint();
        categoryAxis13.setCategoryLabelPositionOffset(1);
        java.util.List list22 = categoryPlot0.getCategoriesForAxis(categoryAxis13);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(list22);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        java.awt.Paint paint2 = waferMapPlot0.getBackgroundPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer5 = null;
        waferMapPlot0.setRenderer(waferMapRenderer5);
        org.junit.Assert.assertNull(waferMapDataset1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        boolean boolean3 = numberAxis0.isAutoRange();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainMarkers(2);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot8.setRangeCrosshairStroke(stroke11);
        java.awt.Paint paint13 = null;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11, paint13, stroke14, 0.0f);
        valueMarker16.setValue((double) (-1));
        valueMarker16.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke21 = valueMarker16.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = valueMarker16.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        double double24 = ringPlot23.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendTitle25.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets22.createInsetRectangle(rectangle2D27, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean33 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace34 = categoryPlot32.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot32.getDomainAxisEdge();
        try {
            java.util.List list36 = numberAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D27, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 90.0d + "'", double24 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, valueAxis9, xYItemRenderer10);
        java.awt.geom.Point2D point2D12 = xYPlot11.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot11.getRenderer(1);
        java.util.List list15 = xYPlot11.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot11.getRenderer();
        java.awt.Stroke stroke17 = xYPlot11.getDomainZeroBaselineStroke();
        int int18 = xYPlot11.getDatasetCount();
        java.awt.Paint paint19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot11.setRangeGridlinePaint(paint19);
        paintMap0.put((java.lang.Comparable) "XY Plot", paint19);
        java.lang.Comparable comparable22 = null;
        org.jfree.chart.plot.RingPlot ringPlot23 = new org.jfree.chart.plot.RingPlot();
        boolean boolean24 = ringPlot23.isCircular();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot23.setShadowPaint((java.awt.Paint) color25);
        double double27 = ringPlot23.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str32 = textAnchor31.toString();
        boolean boolean33 = rectangleInsets28.equals((java.lang.Object) str32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder(rectangleInsets28, (java.awt.Paint) color34);
        ringPlot23.setShadowPaint((java.awt.Paint) color34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        ringPlot23.handleClick((int) (byte) 10, 2, plotRenderingInfo39);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator41 = ringPlot23.getLegendLabelGenerator();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        ringPlot23.setBaseSectionOutlinePaint((java.awt.Paint) color42);
        try {
            paintMap0.put(comparable22, (java.awt.Paint) color42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str32.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getRightArrow();
        float float2 = numberAxis0.getTickMarkInsideLength();
        org.jfree.chart.PaintMap paintMap3 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.setTickMarkOutsideLength((float) '4');
        boolean boolean8 = paintMap3.equals((java.lang.Object) numberAxis3D5);
        java.awt.Shape shape9 = numberAxis3D5.getUpArrow();
        org.jfree.data.Range range10 = numberAxis3D5.getDefaultAutoRange();
        org.jfree.data.Range range13 = org.jfree.data.Range.expand(range10, (double) 1L, 0.0d);
        numberAxis0.setRangeWithMargins(range10);
        java.awt.Paint paint15 = numberAxis0.getTickMarkPaint();
        numberAxis0.setRange((double) (-1), (double) '#');
        numberAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint13 = categoryAxis12.getTickLabelPaint();
        categoryAxis12.setAxisLineVisible(false);
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis12.setTickMarkStroke(stroke18);
        xYPlot4.setDomainZeroBaselineStroke(stroke18);
        boolean boolean21 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setUpperBound((double) 0L);
        numberAxis23.setLowerBound((double) (short) -1);
        numberAxis23.setVerticalTickLabels(true);
        try {
            xYPlot4.setRangeAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) numberAxis23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str2 = rectangleInsets1.toString();
        double double3 = rectangleInsets1.getBottom();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 10L, (java.lang.Object) rectangleInsets1);
        double double6 = rectangleInsets1.calculateLeftOutset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str2.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset((-1.0d));
        double double13 = rectangleInsets10.getLeft();
        double double15 = rectangleInsets10.calculateTopInset((-3.0d));
        categoryPlot0.setInsets(rectangleInsets10, false);
        java.lang.Object obj18 = categoryPlot0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis(255);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(categoryAxis20);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRendererForDataset(categoryDataset13);
        org.jfree.chart.plot.RingPlot ringPlot15 = new org.jfree.chart.plot.RingPlot();
        double double16 = ringPlot15.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot15);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle17.getItemContainer();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj21 = categoryAxis3D20.clone();
        boolean boolean22 = legendTitle17.equals((java.lang.Object) categoryAxis3D20);
        java.util.List list23 = categoryPlot0.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D20);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        java.awt.Shape shape26 = numberAxis3D22.getUpArrow();
        org.jfree.data.Range range27 = numberAxis3D22.getDefaultAutoRange();
        org.jfree.data.Range range30 = org.jfree.data.Range.expand(range27, (double) 1L, 0.0d);
        dateAxis19.setRange(range30, false, false);
        boolean boolean34 = categoryPlot3.equals((java.lang.Object) false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str38 = categoryAxis37.getLabelToolTip();
        java.lang.Object obj39 = categoryAxis37.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setLabelToolTip("ThreadContext");
        categoryAxis41.setTickMarkOutsideLength((float) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        double double48 = categoryAxis47.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint51 = categoryAxis50.getTickLabelPaint();
        categoryAxis50.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35, categoryAxis37, categoryAxis40, categoryAxis41, categoryAxis47, categoryAxis50 };
        categoryPlot3.setDomainAxes(categoryAxisArray54);
        categoryPlot3.clearDomainMarkers();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot3);
        categoryPlot3.setAnchorValue((double) 0, true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str1 = ringPlot0.getNoDataMessage();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color2, color3, color4, color5, color6 };
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color9, color10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color12 };
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray11, paintArray13, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextFillPaint();
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextPaint();
        ringPlot0.setSeparatorPaint(paint19);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Range[-1.0,1.0]", "RectangleAnchor.RIGHT");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[-1.0,1.0]" + "'", str3.equals("Range[-1.0,1.0]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        textTitle1.setURLText("");
        java.lang.String str6 = textTitle1.getText();
        org.jfree.chart.event.TitleChangeListener titleChangeListener7 = null;
        textTitle1.addChangeListener(titleChangeListener7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        java.lang.String str16 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot18 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo1.setCopyright("");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo0.getLibraries();
        java.lang.String str6 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        java.lang.String str4 = titleChangeEvent3.toString();
        java.lang.String str5 = titleChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        titleChangeEvent3.setType(chartChangeEventType6);
        org.jfree.chart.title.Title title8 = titleChangeEvent3.getTitle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertNotNull(title8);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setPieIndex((int) (short) 0);
        java.lang.Object obj6 = ringPlot0.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isBorderVisible();
        boolean boolean22 = jFreeChart15.isNotify();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDarkerSides(false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setLabelLinksVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = piePlot0.getLegendItems();
        org.jfree.chart.LegendItem legendItem5 = null;
        legendItemCollection4.add(legendItem5);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setCircular(true);
        java.awt.Shape shape6 = ringPlot0.getLegendItemShape();
        java.awt.Paint paint7 = ringPlot0.getLabelPaint();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        ringPlot0.setLabelFont(font8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = ringPlot0.getSimpleLabelOffset();
        boolean boolean11 = ringPlot0.isCircular();
        java.awt.Paint paint12 = ringPlot0.getLabelShadowPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(pieURLGenerator13);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.05d, (double) '4');
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D1.setDarkerSides(true);
        boolean boolean4 = horizontalAlignment0.equals((java.lang.Object) true);
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.brighter();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color7);
        int int9 = color7.getTransparency();
        boolean boolean10 = horizontalAlignment0.equals((java.lang.Object) color7);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Image image12 = null;
        waferMapPlot11.setBackgroundImage(image12);
        boolean boolean14 = horizontalAlignment0.equals((java.lang.Object) waferMapPlot11);
        org.jfree.data.general.WaferMapDataset waferMapDataset15 = null;
        waferMapPlot11.setDataset(waferMapDataset15);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=128,b=0]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        java.awt.Font font3 = multiplePiePlot1.getNoDataMessageFont();
        java.awt.Paint paint4 = multiplePiePlot1.getBackgroundPaint();
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint2 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setAxisLineVisible(false);
        categoryAxis1.setVisible(true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        boolean boolean14 = textTitle1.getExpandToFitSpace();
        double double15 = textTitle1.getWidth();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        textTitle1.setFont(font16);
        double double18 = textTitle1.getHeight();
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle1.setFont(font19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.Color color23 = color22.brighter();
        ringPlot21.setLabelBackgroundPaint((java.awt.Paint) color23);
        float float25 = ringPlot21.getForegroundAlpha();
        ringPlot21.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation28 = ringPlot21.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = multiplePiePlot30.getDataset();
        java.awt.Font font32 = multiplePiePlot30.getNoDataMessageFont();
        boolean boolean33 = rotation28.equals((java.lang.Object) multiplePiePlot30);
        org.jfree.chart.util.TableOrder tableOrder34 = multiplePiePlot30.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder35 = multiplePiePlot30.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart36 = multiplePiePlot30.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot37 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str38 = ringPlot37.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent39 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot37);
        java.lang.Object obj40 = plotChangeEvent39.getSource();
        jFreeChart36.plotChanged(plotChangeEvent39);
        boolean boolean42 = jFreeChart36.isNotify();
        jFreeChart36.setNotify(false);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart36);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(tableOrder34);
        org.junit.Assert.assertNotNull(tableOrder35);
        org.junit.Assert.assertNotNull(jFreeChart36);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setPieIndex((int) (short) 0);
        double double6 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setCircular(true, false);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot0.setSeparatorStroke(stroke10);
        java.awt.Paint paint12 = ringPlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setCircular(true);
        java.awt.Shape shape6 = ringPlot0.getLegendItemShape();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        chartEntity8.setURLText("ThreadContext");
        java.awt.Shape shape11 = chartEntity8.getArea();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        java.awt.Color color6 = java.awt.Color.GRAY;
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color8, color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color14, color15, color16 };
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color18 };
        java.awt.Stroke[] strokeArray20 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray17, paintArray19, strokeArray20, strokeArray21, shapeArray22);
        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextFillPaint();
        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextPaint();
        java.awt.Stroke stroke26 = defaultDrawingSupplier23.getNextStroke();
        java.lang.Object obj27 = defaultDrawingSupplier23.clone();
        ringPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        try {
            java.awt.Shape shape29 = defaultDrawingSupplier23.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setWeight((int) (byte) 100);
        categoryPlot17.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot17.setDomainAxis((int) (byte) 0, categoryAxis24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot17.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.CrosshairState crosshairState38 = null;
        boolean boolean39 = xYPlot33.render(graphics2D34, rectangle2D35, 8, plotRenderingInfo37, crosshairState38);
        int int40 = xYPlot33.getWeight();
        java.awt.geom.Point2D point2D41 = xYPlot33.getQuadrantOrigin();
        categoryPlot17.zoomRangeAxes((double) 0, plotRenderingInfo28, point2D41, false);
        xYPlot4.zoomDomainAxes(0.12d, (double) 1L, plotRenderingInfo16, point2D41);
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color46 = java.awt.Color.GRAY;
        java.awt.Color color47 = color46.brighter();
        ringPlot45.setLabelBackgroundPaint((java.awt.Paint) color47);
        ringPlot45.setCircular(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        ringPlot45.handleClick((int) (short) 100, (int) (byte) 1, plotRenderingInfo53);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor55 = ringPlot45.getLabelDistributor();
        java.awt.Stroke stroke56 = ringPlot45.getSeparatorStroke();
        xYPlot4.setDomainZeroBaselineStroke(stroke56);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor55);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.geom.Point2D point2D18 = xYPlot17.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot17.getRenderer(1);
        xYPlot17.configureDomainAxes();
        xYPlot17.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot17.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setWeight((int) (byte) 100);
        categoryPlot26.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot26.setDomainAxis((int) (byte) 0, categoryAxis33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot26.setRenderer(categoryItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot26.getRangeAxisLocation(10);
        xYPlot17.setDomainAxisLocation(axisLocation38);
        categoryPlot0.setDomainAxisLocation((int) (byte) 10, axisLocation38, false);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAxis11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(axisLocation38);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getRightArrow();
        float float2 = numberAxis0.getTickMarkInsideLength();
        org.jfree.chart.PaintMap paintMap3 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D5.setTickMarkOutsideLength((float) '4');
        boolean boolean8 = paintMap3.equals((java.lang.Object) numberAxis3D5);
        java.awt.Shape shape9 = numberAxis3D5.getUpArrow();
        org.jfree.data.Range range10 = numberAxis3D5.getDefaultAutoRange();
        org.jfree.data.Range range13 = org.jfree.data.Range.expand(range10, (double) 1L, 0.0d);
        numberAxis0.setRangeWithMargins(range10);
        java.awt.Paint paint15 = numberAxis0.getTickMarkPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.geom.Point2D point2D23 = xYPlot22.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        xYPlot22.rendererChanged(rendererChangeEvent24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot22.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot22.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot22.getRangeAxisLocation(2);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str33 = plotOrientation32.toString();
        java.lang.String str34 = plotOrientation32.toString();
        java.lang.String str35 = plotOrientation32.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation32);
        try {
            double double37 = numberAxis0.lengthToJava2D((double) (byte) 10, rectangle2D17, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PlotOrientation.VERTICAL" + "'", str33.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotOrientation.VERTICAL" + "'", str34.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PlotOrientation.VERTICAL" + "'", str35.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot4.setRenderer((int) (short) 10, xYItemRenderer9);
        xYPlot4.clearDomainAxes();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot4.getDomainAxisForDataset((-667));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -667 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.jfree.chart.util.TableOrder tableOrder3 = multiplePiePlot1.getDataExtractOrder();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot8.setFixedRangeAxisSpace(axisSpace9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.geom.Point2D point2D19 = xYPlot18.getQuadrantOrigin();
        xYPlot8.zoomRangeAxes((double) 0L, (double) 0.5f, plotRenderingInfo13, point2D19);
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) xYPlot8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        try {
            xYPlot8.setDomainAxis((-667), (org.jfree.chart.axis.ValueAxis) numberAxis3D24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNotNull(tableOrder3);
        org.junit.Assert.assertNotNull(point2D19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        java.awt.Paint paint5 = null;
        ringPlot0.setOutlinePaint(paint5);
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        boolean boolean8 = ringPlot7.isCircular();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot7.setShadowPaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = ringPlot7.getSeparatorStroke();
        float float12 = ringPlot7.getForegroundAlpha();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        boolean boolean14 = ringPlot13.isCircular();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot13.setShadowPaint((java.awt.Paint) color15);
        double double17 = ringPlot13.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str22 = textAnchor21.toString();
        boolean boolean23 = rectangleInsets18.equals((java.lang.Object) str22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, (java.awt.Paint) color24);
        ringPlot13.setShadowPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        ringPlot13.handleClick((int) (byte) 10, 2, plotRenderingInfo29);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator31 = ringPlot13.getLegendLabelGenerator();
        ringPlot7.setLabelGenerator(pieSectionLabelGenerator31);
        ringPlot0.setLabelGenerator(pieSectionLabelGenerator31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setNegativeArrowVisible(false);
        boolean boolean37 = numberAxis34.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap38 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D40.setTickMarkOutsideLength((float) '4');
        boolean boolean43 = paintMap38.equals((java.lang.Object) numberAxis3D40);
        java.awt.Shape shape44 = numberAxis3D40.getUpArrow();
        org.jfree.data.Range range45 = numberAxis3D40.getDefaultAutoRange();
        numberAxis34.setDefaultAutoRange(range45);
        numberAxis34.resizeRange((double) 100);
        numberAxis34.setInverted(false);
        numberAxis34.centerRange(0.05d);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = null;
        numberAxis34.setMarkerBand(markerAxisBand53);
        java.awt.Paint paint55 = numberAxis34.getTickMarkPaint();
        ringPlot0.setLabelBackgroundPaint(paint55);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str22.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(paint55);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers(2);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot16.setRangeCrosshairStroke(stroke19);
        java.awt.Paint paint21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19, paint21, stroke22, 0.0f);
        valueMarker24.setValue((double) (-1));
        valueMarker24.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer29);
        java.awt.Paint paint31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker24.setLabelPaint(paint31);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRenderer();
        java.awt.Color color10 = java.awt.Color.GRAY;
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.DARK_GRAY;
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = new org.jfree.chart.util.Size2D();
        size2D15.height = 1.0f;
        java.lang.Object obj18 = size2D15.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 0.0d, 0.0d, rectangleAnchor21);
        org.jfree.chart.plot.RingPlot ringPlot25 = new org.jfree.chart.plot.RingPlot();
        double double26 = ringPlot25.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle27.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) (-65536), 0.12d, rectangleAnchor28);
        try {
            xYPlot4.drawBackground(graphics2D14, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = numberAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) (short) 100);
        boolean boolean5 = color0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        java.awt.Color color12 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainMarkers(2);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeCrosshairStroke(stroke16);
        java.awt.Paint paint18 = null;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16, paint18, stroke19, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor22);
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker21);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setWeight((int) (byte) 100);
        categoryPlot25.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot25.setDomainAxis((int) (byte) 0, categoryAxis32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot25.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot25.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot25.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo38, point2D39);
        java.lang.String str41 = categoryPlot25.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap45 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D47.setTickMarkOutsideLength((float) '4');
        boolean boolean50 = paintMap45.equals((java.lang.Object) numberAxis3D47);
        java.awt.Shape shape51 = numberAxis3D47.getUpArrow();
        org.jfree.data.Range range52 = numberAxis3D47.getDefaultAutoRange();
        org.jfree.data.Range range55 = org.jfree.data.Range.expand(range52, (double) 1L, 0.0d);
        dateAxis44.setRange(range55, false, false);
        boolean boolean59 = dateAxis44.isPositiveArrowVisible();
        categoryPlot25.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis44, true);
        boolean boolean62 = valueMarker21.equals((java.lang.Object) dateAxis44);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Category Plot" + "'", str41.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSeparatorsVisible(true);
        ringPlot0.setOuterSeparatorExtension((double) 3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight(10.0d);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d, jFreeChart3);
        java.lang.Object obj5 = chartChangeEvent4.getSource();
        java.lang.String str6 = chartChangeEvent4.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 10.0d + "'", obj5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=10.0]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=10.0]"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        boolean boolean5 = categoryPlot0.isSubplot();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke6);
        java.awt.Color color10 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.clearDomainMarkers(2);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeCrosshairStroke(stroke14);
        java.awt.Paint paint16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14, paint16, stroke17, 0.0f);
        valueMarker19.setValue((double) (-1));
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = categoryPlot0.removeRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker19, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        boolean boolean4 = numberAxis0.isVisible();
        org.jfree.chart.plot.RingPlot ringPlot5 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color6 = java.awt.Color.GRAY;
        java.awt.Color color7 = color6.brighter();
        ringPlot5.setLabelBackgroundPaint((java.awt.Paint) color7);
        ringPlot5.setPieIndex((int) (short) 0);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot5);
        numberAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getInsets();
        java.lang.String str11 = rectangleInsets10.toString();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str11.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot3.getDomainMarkers(layer19);
        categoryPlot3.mapDatasetToDomainAxis((int) (byte) 10, (-667));
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(collection20);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isCircular();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot1.setShadowPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke5 = ringPlot1.getSeparatorStroke();
        ringPlot0.setLabelOutlineStroke(stroke5);
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Paint paint9 = ringPlot0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        categoryPlot0.clearRangeMarkers((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent21);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis25.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis25.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setWeight((int) (byte) 100);
        categoryPlot29.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot29.zoomDomainAxes(10.0d, plotRenderingInfo35, point2D36, false);
        boolean boolean39 = categoryAxis25.hasListener((java.util.EventListener) categoryPlot29);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot29.getDomainAxisLocation();
        categoryPlot19.setRangeAxisLocation(0, axisLocation40);
        try {
            categoryPlot0.setRangeAxisLocation((-16777024), axisLocation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        java.awt.Shape shape6 = numberAxis3D2.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.awt.Shape shape8 = chartEntity7.getArea();
        java.lang.Object obj9 = chartEntity7.clone();
        java.lang.Object obj10 = chartEntity7.clone();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot15.getRangeAxisEdge();
        boolean boolean17 = chartEntity7.equals((java.lang.Object) xYPlot15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = ringPlot0.getLegendLabelURLGenerator();
        java.awt.Paint paint5 = ringPlot0.getBaseSectionPaint();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        ringPlot0.setToolTipGenerator(pieToolTipGenerator6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        ringPlot0.datasetChanged(datasetChangeEvent8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        boolean boolean5 = categoryPlot0.isSubplot();
        categoryPlot0.setWeight((-667));
        boolean boolean8 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap2 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D4.setTickMarkOutsideLength((float) '4');
        boolean boolean7 = paintMap2.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape8 = numberAxis3D4.getUpArrow();
        org.jfree.data.Range range9 = numberAxis3D4.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range9, false, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers(2);
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset();
        categoryPlot0.setRangeCrosshairValue((double) 3, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer(15, categoryItemRenderer8, false);
        java.awt.Image image11 = categoryPlot0.getBackgroundImage();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Image image3 = projectInfo0.getLogo();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean5 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        java.util.List list8 = categoryPlot4.getAnnotations();
        projectInfo0.setContributors(list8);
        java.util.List list10 = null;
        projectInfo0.setContributors(list10);
        java.lang.String str12 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TextAnchor.HALF_ASCENT_LEFT" + "'", str12.equals("TextAnchor.HALF_ASCENT_LEFT"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        ringPlot0.addChangeListener(plotChangeListener5);
        double double7 = ringPlot0.getShadowXOffset();
        ringPlot0.setShadowYOffset((double) (byte) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint10 = xYPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        xYPlot0.rendererChanged(rendererChangeEvent1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.configureDomainAxes();
        int int5 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setSeparatorPaint(paint5);
        java.awt.Paint paint7 = ringPlot0.getLabelOutlinePaint();
        java.awt.Paint paint8 = ringPlot0.getBackgroundPaint();
        ringPlot0.setSimpleLabels(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        boolean boolean6 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot();
        double double8 = ringPlot7.getStartAngle();
        boolean boolean9 = ringPlot7.getIgnoreNullValues();
        ringPlot7.setSeparatorsVisible(false);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot7.setBaseSectionOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str15 = ringPlot14.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot14);
        java.lang.Object obj17 = plotChangeEvent16.getSource();
        ringPlot7.notifyListeners(plotChangeEvent16);
        xYPlot4.notifyListeners(plotChangeEvent16);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(10);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        java.lang.Object obj14 = xYPlot4.clone();
        xYPlot4.clearAnnotations();
        xYPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isNotify();
        jFreeChart15.setNotify(false);
        jFreeChart15.removeLegend();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot4.setOrientation(plotOrientation12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace14, false);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-65536));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        categoryPlot3.configureRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot3.removeChangeListener(plotChangeListener18);
        org.jfree.chart.PaintMap paintMap20 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D22.setTickMarkOutsideLength((float) '4');
        boolean boolean25 = paintMap20.equals((java.lang.Object) numberAxis3D22);
        categoryPlot3.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D22);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str1.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxisForDataset((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis((int) ' ');
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        boolean boolean5 = ringPlot4.isCircular();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        ringPlot4.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        ringPlot4.axisChanged(axisChangeEvent9);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = null;
        ringPlot4.setLegendLabelToolTipGenerator(pieSectionLabelGenerator11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline15 = null;
        dateAxis14.setTimeline(timeline15);
        org.jfree.chart.plot.RingPlot ringPlot17 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color18 = java.awt.Color.GRAY;
        java.awt.Color color19 = color18.brighter();
        ringPlot17.setLabelBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = ringPlot17.getLegendLabelURLGenerator();
        java.awt.Paint paint22 = ringPlot17.getBaseSectionPaint();
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot17.setNoDataMessageFont(font23);
        dateAxis14.setLabelFont(font23);
        java.util.Date date26 = dateAxis14.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis14.getTickUnit();
        java.awt.Stroke stroke28 = ringPlot4.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit27);
        java.util.Date date29 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit27);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = rendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers(2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot2.setRangeCrosshairStroke(stroke5);
        java.awt.Paint paint7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5, paint7, stroke8, 0.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        try {
            valueMarker10.setLabelOffsetType(lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        ringPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis10.setTimeline(timeline11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color14 = java.awt.Color.GRAY;
        java.awt.Color color15 = color14.brighter();
        ringPlot13.setLabelBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = ringPlot13.getLegendLabelURLGenerator();
        java.awt.Paint paint18 = ringPlot13.getBaseSectionPaint();
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot13.setNoDataMessageFont(font19);
        dateAxis10.setLabelFont(font19);
        java.util.Date date22 = dateAxis10.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis10.getTickUnit();
        java.awt.Stroke stroke24 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit23);
        ringPlot0.setInnerSeparatorExtension((double) (-1));
        java.awt.Paint paint27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.RingPlot ringPlot28 = new org.jfree.chart.plot.RingPlot();
        boolean boolean29 = ringPlot28.isCircular();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot28.setShadowPaint((java.awt.Paint) color30);
        java.awt.Stroke stroke32 = ringPlot28.getSeparatorStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str34 = rectangleInsets33.toString();
        double double36 = rectangleInsets33.calculateLeftOutset((double) 8);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder(paint27, stroke32, rectangleInsets33);
        ringPlot0.setSeparatorStroke(stroke32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str34.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        java.awt.Shape shape6 = numberAxis3D2.getUpArrow();
        org.jfree.data.Range range7 = numberAxis3D2.getDefaultAutoRange();
        org.jfree.data.Range range10 = org.jfree.data.Range.expand(range7, (double) 1L, 0.0d);
        boolean boolean12 = range7.contains((double) (byte) 0);
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.combine(range7, range13);
        double double15 = range7.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 15, (double) (-1.0f), (double) (-1L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getRangeMarkers(layer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (byte) 100);
        categoryPlot12.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot12.setDomainAxis((int) (byte) 0, categoryAxis19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot12.getRangeAxisEdge();
        categoryPlot12.setBackgroundAlpha((float) 2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot12.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot30.render(graphics2D31, rectangle2D32, 8, plotRenderingInfo34, crosshairState35);
        java.awt.Color color38 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot39.clearDomainMarkers(2);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot39.setRangeCrosshairStroke(stroke42);
        java.awt.Paint paint44 = null;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color38, stroke42, paint44, stroke45, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor48 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker47.setLabelTextAnchor(textAnchor48);
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean52 = categoryPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker47, layer51);
        org.jfree.chart.util.Layer layer53 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47, layer53);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        blockResult0.setEntityCollection(entityCollection4);
        org.junit.Assert.assertNull(entityCollection3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setWeight(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        xYPlot4.setRenderer(500, xYItemRenderer11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setNegativeArrowVisible(false);
        java.lang.String str16 = numberAxis13.getLabel();
        boolean boolean17 = numberAxis13.isVisible();
        org.jfree.data.Range range18 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        xYPlot4.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        xYPlot4.configureDomainAxes();
        java.awt.Color color14 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.clearDomainMarkers(2);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot15.setRangeCrosshairStroke(stroke18);
        java.awt.Paint paint20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18, paint20, stroke21, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker23.setLabelTextAnchor(textAnchor24);
        try {
            boolean boolean26 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLegendLabelGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = ringPlot0.getDrawingSupplier();
        ringPlot0.setShadowYOffset(86.0d);
        java.awt.Stroke stroke9 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateLeftInset((-1.0d));
        double double13 = rectangleInsets10.getLeft();
        double double15 = rectangleInsets10.calculateTopInset((-3.0d));
        categoryPlot0.setInsets(rectangleInsets10, false);
        java.lang.Object obj18 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot0.getDomainMarkers((int) (short) 10, layer20);
        java.awt.Color color23 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearDomainMarkers(2);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot24.setRangeCrosshairStroke(stroke27);
        java.awt.Paint paint29 = null;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27, paint29, stroke30, 0.0f);
        java.awt.Stroke stroke33 = valueMarker32.getOutlineStroke();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32, layer34);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        xYPlot4.setRenderer(8, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        xYPlot4.setDomainZeroBaselinePaint(paint8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setNegativeArrowVisible(false);
        java.lang.String str13 = numberAxis10.getLabel();
        boolean boolean14 = numberAxis10.isVisible();
        int int15 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setUpperBound((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint22 = categoryAxis21.getTickLabelPaint();
        categoryAxis21.setAxisLineVisible(false);
        boolean boolean25 = numberAxis17.equals((java.lang.Object) false);
        org.jfree.chart.plot.Plot plot26 = numberAxis17.getPlot();
        numberAxis17.setLabelURL("java.awt.Color[r=128,g=255,b=255]");
        numberAxis17.setAutoTickUnitSelection(true);
        xYPlot4.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis17, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(plot26);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.CrosshairState crosshairState9 = null;
        boolean boolean10 = xYPlot4.render(graphics2D5, rectangle2D6, 8, plotRenderingInfo8, crosshairState9);
        int int11 = xYPlot4.getWeight();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double17 = rectangleInsets15.calculateLeftInset((-1.0d));
        double double18 = rectangleInsets15.getBottom();
        textTitle14.setMargin(rectangleInsets15);
        java.lang.Object obj20 = textTitle14.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle14.getPadding();
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(unitType22, (double) 2, (double) 8, (double) (short) -1, (double) 0.5f);
        java.awt.Color color29 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot30.clearDomainMarkers(2);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot30.setRangeCrosshairStroke(stroke33);
        java.awt.Paint paint35 = null;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke33, paint35, stroke36, 0.0f);
        valueMarker38.setValue((double) (-1));
        valueMarker38.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke43 = valueMarker38.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = valueMarker38.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot45 = new org.jfree.chart.plot.RingPlot();
        double double46 = ringPlot45.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = legendTitle47.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D49 = legendTitle47.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets44.createInsetRectangle(rectangle2D49, false, true);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets27.createInsetRectangle(rectangle2D49);
        org.jfree.chart.ui.ProjectInfo projectInfo54 = org.jfree.chart.JFreeChart.INFO;
        projectInfo54.setCopyright("");
        java.util.List list57 = projectInfo54.getContributors();
        xYPlot4.drawDomainTickBands(graphics2D12, rectangle2D49, list57);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 90.0d + "'", double46 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(projectInfo54);
        org.junit.Assert.assertNull(list57);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = rectangleInsets12.equals((java.lang.Object) str16);
        legendTitle11.setItemLabelPadding(rectangleInsets12);
        java.lang.Object obj19 = null;
        boolean boolean20 = legendTitle11.equals(obj19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double23 = rectangleInsets21.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str25 = textAnchor24.toString();
        boolean boolean26 = rectangleInsets21.equals((java.lang.Object) str25);
        legendTitle11.setItemLabelPadding(rectangleInsets21);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setNegativeArrowVisible(false);
        java.lang.String str31 = numberAxis28.getLabel();
        java.awt.Paint paint32 = numberAxis28.getTickLabelPaint();
        legendTitle11.setBackgroundPaint(paint32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle11.setLegendItemGraphicLocation(rectangleAnchor34);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str25.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str1.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (byte) 100);
        categoryPlot10.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot10.setDomainAxis((int) (byte) 0, categoryAxis17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double24 = rectangleInsets22.calculateLeftInset((-1.0d));
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("ClassContext", font7, (java.awt.Paint) color8, rectangleEdge19, horizontalAlignment20, verticalAlignment21, rectangleInsets22);
        boolean boolean29 = textTitle1.equals((java.lang.Object) verticalAlignment21);
        textTitle1.setURLText("");
        java.lang.Object obj32 = textTitle1.clone();
        boolean boolean33 = textTitle1.getNotify();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        java.awt.Paint paint5 = null;
        ringPlot0.setOutlinePaint(paint5);
        ringPlot0.setForegroundAlpha((float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (-667));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset10);
        multiplePiePlot11.setLimit(0.0d);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        double double16 = textTitle15.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle15);
        java.lang.String str18 = titleChangeEvent17.toString();
        java.lang.String str19 = titleChangeEvent17.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = titleChangeEvent17.getType();
        java.lang.Object obj21 = titleChangeEvent17.getSource();
        boolean boolean22 = multiplePiePlot11.equals(obj21);
        java.awt.Color color23 = java.awt.Color.cyan;
        boolean boolean25 = color23.equals((java.lang.Object) 1);
        multiplePiePlot11.setAggregatedItemsPaint((java.awt.Paint) color23);
        xYPlot4.setDomainGridlinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = multiplePiePlot2.getDataset();
        java.awt.Font font4 = multiplePiePlot2.getNoDataMessageFont();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", font4);
        java.awt.Paint paint6 = textFragment5.getPaint();
        java.awt.Paint paint7 = textFragment5.getPaint();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getFirstTextFragment();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot5 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = multiplePiePlot5.getDataset();
        java.awt.Font font7 = multiplePiePlot5.getNoDataMessageFont();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("Multiple Pie Plot", font7);
        textLine1.addFragment(textFragment8);
        float float10 = textFragment8.getBaselineOffset();
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot4.getDomainAxis();
        java.awt.Font font9 = xYPlot4.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        ringPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline11 = null;
        dateAxis10.setTimeline(timeline11);
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color14 = java.awt.Color.GRAY;
        java.awt.Color color15 = color14.brighter();
        ringPlot13.setLabelBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = ringPlot13.getLegendLabelURLGenerator();
        java.awt.Paint paint18 = ringPlot13.getBaseSectionPaint();
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot13.setNoDataMessageFont(font19);
        dateAxis10.setLabelFont(font19);
        java.util.Date date22 = dateAxis10.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis10.getTickUnit();
        java.awt.Stroke stroke24 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) dateTickUnit23);
        ringPlot0.setInnerSeparatorExtension((double) (-1));
        double double27 = ringPlot0.getInnerSeparatorExtension();
        double double28 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(pieURLGenerator17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot0.drawBackgroundImage(graphics2D12, rectangle2D13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle1);
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder4);
        java.lang.String str6 = textTitle1.getID();
        double double7 = textTitle1.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 1.0f;
        java.lang.Object obj3 = size2D0.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 0.0d, rectangleAnchor6);
        size2D0.setHeight((double) 100);
        double double10 = size2D0.height;
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartEntity: tooltip = null");
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isNotify();
        jFreeChart15.setNotify(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart15.removeProgressListener(chartProgressListener24);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        java.util.TimeZone timeZone4 = dateAxis1.getTimeZone();
        try {
            boolean boolean6 = dateAxis1.isHiddenValue((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = rectangleInsets12.equals((java.lang.Object) str16);
        legendTitle11.setItemLabelPadding(rectangleInsets12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendTitle11.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle11.getLegendItemGraphicLocation();
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        int int7 = ringPlot0.getPieIndex();
        ringPlot0.setMinimumArcAngleToDraw((double) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        ringPlot0.setDataset(pieDataset10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.plot.Plot plot12 = xYPlot4.getRootPlot();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        double double3 = multiplePiePlot1.getLimit();
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color5 = java.awt.Color.GRAY;
        java.awt.Color color6 = color5.brighter();
        ringPlot4.setLabelBackgroundPaint((java.awt.Paint) color6);
        float float8 = ringPlot4.getForegroundAlpha();
        ringPlot4.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation11 = ringPlot4.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot13.getDataset();
        java.awt.Font font15 = multiplePiePlot13.getNoDataMessageFont();
        boolean boolean16 = rotation11.equals((java.lang.Object) multiplePiePlot13);
        org.jfree.chart.util.TableOrder tableOrder17 = multiplePiePlot13.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder18 = multiplePiePlot13.getDataExtractOrder();
        multiplePiePlot1.setDataExtractOrder(tableOrder18);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rotation11);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(tableOrder17);
        org.junit.Assert.assertNotNull(tableOrder18);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint2 = piePlot3D0.getLabelShadowPaint();
        java.lang.String str3 = piePlot3D0.getPlotType();
        java.awt.Paint paint5 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "java.awt.Color[r=182,g=182,b=182]");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12d + "'", double1 == 0.12d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie 3D Plot" + "'", str3.equals("Pie 3D Plot"));
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        boolean boolean5 = numberAxis0.isInverted();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setUpperBound((double) 0L);
        numberAxis6.setLowerBound((double) (short) -1);
        numberAxis6.setInverted(false);
        numberAxis6.setLowerBound((double) (byte) 100);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis6.getStandardTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource15);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelToolTip("ThreadContext");
        boolean boolean3 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        double double4 = textTitle3.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) lineBorder6);
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int11 = color10.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setWeight((int) (byte) 100);
        categoryPlot12.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot12.setDomainAxis((int) (byte) 0, categoryAxis19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot12.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double26 = rectangleInsets24.calculateLeftInset((-1.0d));
        double double27 = rectangleInsets24.getLeft();
        double double29 = rectangleInsets24.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("ClassContext", font9, (java.awt.Paint) color10, rectangleEdge21, horizontalAlignment22, verticalAlignment23, rectangleInsets24);
        boolean boolean31 = textTitle3.equals((java.lang.Object) verticalAlignment23);
        textTitle3.setURLText("");
        textTitle3.setMargin((double) '4', 3.0d, (double) (short) 0, 0.0d);
        boolean boolean39 = textAnchor0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 4.0d + "'", double27 == 4.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setLowerMargin((double) (byte) 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        ringPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        ringPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator7);
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) pieSectionLabelGenerator7, (java.lang.Object) 0.08d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        org.jfree.chart.title.LegendTitle legendTitle21 = jFreeChart15.getLegend((int) (short) 1);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis23.getLabelInsets();
        double double26 = rectangleInsets24.calculateBottomInset((double) (short) 100);
        java.awt.Color color28 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearDomainMarkers(2);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot29.setRangeCrosshairStroke(stroke32);
        java.awt.Paint paint34 = null;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32, paint34, stroke35, 0.0f);
        valueMarker37.setValue((double) (-1));
        valueMarker37.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke42 = valueMarker37.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = valueMarker37.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        double double45 = ringPlot44.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendTitle46.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle46.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets43.createInsetRectangle(rectangle2D48, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D48);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets24.createAdjustedRectangle(rectangle2D48, lengthAdjustmentType53, lengthAdjustmentType54);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        try {
            jFreeChart15.draw(graphics2D22, rectangle2D55, chartRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(legendTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 90.0d + "'", double45 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        boolean boolean9 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        double double11 = ringPlot10.getStartAngle();
        boolean boolean12 = ringPlot10.getIgnoreNullValues();
        ringPlot10.setSeparatorsVisible(false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot10.setBaseSectionOutlinePaint((java.awt.Paint) color15);
        ringPlot10.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint19 = ringPlot10.getBaseSectionOutlinePaint();
        categoryPlot0.setDomainGridlinePaint(paint19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setNegativeArrowVisible(false);
        java.lang.String str25 = numberAxis22.getLabel();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, valueAxis32, xYItemRenderer33);
        java.awt.geom.Point2D point2D35 = xYPlot34.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot34.getRenderer(1);
        java.util.List list38 = xYPlot34.getAnnotations();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = xYPlot34.getRenderer();
        java.awt.geom.Point2D point2D40 = xYPlot34.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 10.0f, 0.0d, plotRenderingInfo29, point2D40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNotNull(point2D40);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = ringPlot0.getLegendLabelGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = ringPlot0.getDrawingSupplier();
        ringPlot0.setShadowYOffset(86.0d);
        ringPlot0.setMinimumArcAngleToDraw((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(false);
        double double3 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.12d + "'", double3 == 0.12d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        boolean boolean4 = numberAxis0.isVisible();
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        numberAxis0.setPositiveArrowVisible(false);
        boolean boolean8 = numberAxis0.isVisible();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (byte) 100);
        categoryPlot10.setAnchorValue((double) (short) 0);
        categoryPlot10.setAnchorValue((double) 10.0f);
        boolean boolean17 = categoryPlot10.getDrawSharedDomainAxis();
        double double18 = categoryPlot10.getAnchorValue();
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot();
        double double20 = ringPlot19.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle21.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle21.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setWeight((int) (byte) 100);
        categoryPlot24.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot24.setDomainAxis((int) (byte) 0, categoryAxis31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot24.getRangeAxisEdge();
        categoryPlot24.setBackgroundAlpha((float) 2);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        categoryPlot24.drawBackgroundImage(graphics2D36, rectangle2D37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setUpperBound((double) 0L);
        boolean boolean42 = numberAxis39.isAutoRange();
        org.jfree.data.Range range43 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis39);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot24.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace46 = numberAxis0.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) categoryPlot10, rectangle2D23, rectangleEdge44, axisSpace45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        org.jfree.chart.block.BlockContainer blockContainer3 = legendTitle2.getItemContainer();
        boolean boolean4 = blockContainer3.isEmpty();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        double double8 = textTitle7.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle7);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        textTitle7.setFrame((org.jfree.chart.block.BlockFrame) lineBorder10);
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int15 = color14.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (byte) 100);
        categoryPlot16.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot16.setDomainAxis((int) (byte) 0, categoryAxis23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot16.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double30 = rectangleInsets28.calculateLeftInset((-1.0d));
        double double31 = rectangleInsets28.getLeft();
        double double33 = rectangleInsets28.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("ClassContext", font13, (java.awt.Paint) color14, rectangleEdge25, horizontalAlignment26, verticalAlignment27, rectangleInsets28);
        boolean boolean35 = textTitle7.equals((java.lang.Object) verticalAlignment27);
        blockContainer3.add(block5, (java.lang.Object) verticalAlignment27);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(blockContainer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(verticalAlignment27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 2.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot();
        double double7 = ringPlot6.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot6);
        java.awt.Paint paint9 = legendTitle8.getBackgroundPaint();
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle8.getItemContainer();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedHeight(10.0d);
        double double15 = rectangleConstraint14.getHeight();
        org.jfree.chart.util.Size2D size2D16 = flowArrangement5.arrange(blockContainer10, graphics2D11, rectangleConstraint14);
        java.lang.Object obj17 = blockContainer10.clone();
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        columnArrangement4.add((org.jfree.chart.block.Block) blockContainer10, (java.lang.Object) verticalAlignment18);
        blockContainer10.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(blockContainer10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(verticalAlignment18);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setWeight((int) (byte) 100);
        categoryPlot16.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot16.setDomainAxis((int) (byte) 0, categoryAxis23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot16.setRenderer(categoryItemRenderer25);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot16.getRangeAxisLocation(10);
        categoryPlot0.setDomainAxisLocation(axisLocation28, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot31.clearDomainMarkers(2);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot31.setRangeCrosshairStroke(stroke34);
        categoryPlot0.setDomainGridlineStroke(stroke34);
        float float37 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("");
        double double42 = textTitle41.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent43 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle41);
        org.jfree.chart.block.LineBorder lineBorder44 = new org.jfree.chart.block.LineBorder();
        textTitle41.setFrame((org.jfree.chart.block.BlockFrame) lineBorder44);
        java.awt.Stroke stroke46 = lineBorder44.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color39, stroke46);
        java.awt.Font font48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        valueMarker47.setLabelFont(font48);
        java.awt.Stroke stroke50 = valueMarker47.getOutlineStroke();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker47);
        categoryPlot0.clearRangeMarkers(8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=255,g=200,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=255,g=200,b=0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers(2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot2.setRangeCrosshairStroke(stroke5);
        java.awt.Paint paint7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5, paint7, stroke8, 0.0f);
        valueMarker10.setValue((double) (-1));
        valueMarker10.setLabel("RectangleAnchor.RIGHT");
        valueMarker10.setAlpha((float) (byte) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        java.util.List list8 = xYPlot4.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot4.getFixedLegendItems();
        boolean boolean13 = xYPlot4.isRangeCrosshairVisible();
        int int14 = xYPlot4.getSeriesCount();
        java.awt.Stroke stroke15 = xYPlot4.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.clearDomainMarkers(2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot2.setRangeCrosshairStroke(stroke5);
        java.awt.Paint paint7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5, paint7, stroke8, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.geom.Point2D point2D18 = xYPlot17.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot17.getRenderer(1);
        xYPlot17.configureDomainAxes();
        xYPlot17.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot17.getDomainAxis((int) (short) 1);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.CrosshairState crosshairState35 = null;
        boolean boolean36 = xYPlot30.render(graphics2D31, rectangle2D32, 8, plotRenderingInfo34, crosshairState35);
        boolean boolean37 = xYPlot30.isDomainCrosshairVisible();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setUpperBound((double) 0L);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape42 = numberAxis41.getRightArrow();
        float float43 = numberAxis41.getTickMarkInsideLength();
        double double44 = numberAxis41.getLabelAngle();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D46.configure();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        numberAxis48.setUpperBound((double) 0L);
        boolean boolean51 = numberAxis48.getAutoRangeIncludesZero();
        float float52 = numberAxis48.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        numberAxis53.setUpperBound((double) 0L);
        boolean boolean56 = numberAxis53.isAutoRange();
        numberAxis53.setLowerBound((double) 1);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { numberAxis38, numberAxis41, numberAxis3D46, numberAxis48, numberAxis53 };
        xYPlot30.setDomainAxes(valueAxisArray59);
        xYPlot17.setRangeAxes(valueAxisArray59);
        java.awt.Paint paint62 = xYPlot17.getDomainZeroBaselinePaint();
        valueMarker10.setLabelPaint(paint62);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot();
        java.lang.String str17 = ringPlot16.getNoDataMessage();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) ringPlot16);
        java.lang.Object obj19 = plotChangeEvent18.getSource();
        jFreeChart15.plotChanged(plotChangeEvent18);
        boolean boolean21 = jFreeChart15.isNotify();
        java.awt.RenderingHints renderingHints22 = jFreeChart15.getRenderingHints();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(renderingHints22);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        boolean boolean2 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setSeparatorsVisible(false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color5);
        ringPlot0.setInnerSeparatorExtension((double) (byte) 0);
        java.awt.Paint paint9 = ringPlot0.getLabelLinkPaint();
        java.awt.Paint paint10 = ringPlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        double double5 = textTitle4.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle4);
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        textTitle4.setFrame((org.jfree.chart.block.BlockFrame) lineBorder7);
        java.awt.Stroke stroke9 = lineBorder7.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color2, stroke9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        valueMarker10.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D13.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = null;
        piePlot3D13.setLabelGenerator(pieSectionLabelGenerator16);
        java.awt.Shape shape18 = piePlot3D13.getLegendItemShape();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=200,b=0]");
        org.jfree.chart.PaintMap paintMap21 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D23.setTickMarkOutsideLength((float) '4');
        boolean boolean26 = paintMap21.equals((java.lang.Object) numberAxis3D23);
        java.awt.Shape shape27 = numberAxis3D23.getUpArrow();
        org.jfree.data.Range range28 = numberAxis3D23.getDefaultAutoRange();
        org.jfree.data.Range range31 = org.jfree.data.Range.expand(range28, (double) 1L, 0.0d);
        dateAxis20.setRange(range31, false, false);
        boolean boolean35 = dateAxis20.isPositiveArrowVisible();
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        dateAxis20.setTickMarkPaint(paint36);
        piePlot3D13.setLabelBackgroundPaint(paint36);
        java.lang.Class<?> wildcardClass39 = piePlot3D13.getClass();
        java.util.EventListener[] eventListenerArray40 = valueMarker10.getListeners((java.lang.Class) wildcardClass39);
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", (java.lang.Class) wildcardClass39);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(eventListenerArray40);
        org.junit.Assert.assertNull(inputStream41);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("{0}");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle9.getBounds();
        categoryPlot0.drawBackgroundImage(graphics2D7, rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str9 = textAnchor8.toString();
        boolean boolean10 = rectangleInsets5.equals((java.lang.Object) str9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color11);
        ringPlot0.setShadowPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        ringPlot0.handleClick((int) (byte) 10, 2, plotRenderingInfo16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = ringPlot0.getLegendLabelGenerator();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        ringPlot0.setBaseSectionOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color22 = java.awt.Color.GRAY;
        java.awt.Color color23 = color22.brighter();
        ringPlot21.setLabelBackgroundPaint((java.awt.Paint) color23);
        float float25 = ringPlot21.getForegroundAlpha();
        ringPlot21.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation28 = ringPlot21.getDirection();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        boolean boolean31 = rotation28.equals((java.lang.Object) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        ringPlot0.setDirection(rotation28);
        java.awt.Color color34 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot35.clearDomainMarkers(2);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot35.setRangeCrosshairStroke(stroke38);
        java.awt.Paint paint40 = null;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color34, stroke38, paint40, stroke41, 0.0f);
        ringPlot0.setSeparatorStroke(stroke38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str9.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str6 = textAnchor5.toString();
        boolean boolean7 = rectangleInsets2.equals((java.lang.Object) str6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(rectangleInsets2, (java.awt.Paint) color8);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateLeftInset((-1.0d));
        double double17 = rectangleInsets14.getBottom();
        textTitle13.setMargin(rectangleInsets14);
        java.lang.Object obj19 = textTitle13.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = textTitle13.getPadding();
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(unitType21, (double) 2, (double) 8, (double) (short) -1, (double) 0.5f);
        java.awt.Color color28 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.clearDomainMarkers(2);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot29.setRangeCrosshairStroke(stroke32);
        java.awt.Paint paint34 = null;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32, paint34, stroke35, 0.0f);
        valueMarker37.setValue((double) (-1));
        valueMarker37.setLabel("RectangleAnchor.RIGHT");
        java.awt.Stroke stroke42 = valueMarker37.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = valueMarker37.getLabelOffset();
        org.jfree.chart.plot.RingPlot ringPlot44 = new org.jfree.chart.plot.RingPlot();
        double double45 = ringPlot44.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendTitle46.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D48 = legendTitle46.getBounds();
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets43.createInsetRectangle(rectangle2D48, false, true);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets26.createInsetRectangle(rectangle2D48);
        lineBorder10.draw(graphics2D11, rectangle2D48);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str6.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 90.0d + "'", double45 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.util.TableOrder tableOrder14 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot9.getPieChart();
        jFreeChart15.setNotify(false);
        jFreeChart15.setBackgroundImageAlpha((float) (byte) 100);
        boolean boolean20 = jFreeChart15.isBorderVisible();
        java.lang.Object obj21 = jFreeChart15.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart15.removeProgressListener(chartProgressListener22);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(tableOrder14);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot0);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D7 = legendTitle2.arrange(graphics2D3, rectangleConstraint6);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        legendTitle2.setItemFont(font8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle2.getLegendItemGraphicLocation();
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        legendTitle2.setItemFont(font12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray5 = new java.awt.Paint[] { color0, color1, color2, color3, color4 };
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color6, color7, color8 };
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color10 };
        java.awt.Stroke[] strokeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray14 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray5, paintArray9, paintArray11, strokeArray12, strokeArray13, shapeArray14);
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextFillPaint();
        java.awt.Paint paint17 = defaultDrawingSupplier15.getNextPaint();
        java.lang.Object obj18 = defaultDrawingSupplier15.clone();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setUpperBound((double) 0L);
        boolean boolean22 = numberAxis19.isAutoRange();
        boolean boolean23 = numberAxis19.isAutoRange();
        boolean boolean24 = defaultDrawingSupplier15.equals((java.lang.Object) boolean23);
        java.lang.Object obj25 = defaultDrawingSupplier15.clone();
        try {
            java.awt.Stroke stroke26 = defaultDrawingSupplier15.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(shapeArray14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        boolean boolean2 = ringPlot1.isCircular();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot1.setShadowPaint((java.awt.Paint) color3);
        java.awt.Stroke stroke5 = ringPlot1.getSeparatorStroke();
        ringPlot0.setLabelOutlineStroke(stroke5);
        ringPlot0.setSeparatorsVisible(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = ringPlot0.getLegendLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot4.getRangeAxis(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = xYPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder8);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot4.getRenderer(1);
        xYPlot4.configureDomainAxes();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint13 = categoryAxis12.getTickLabelPaint();
        categoryAxis12.setAxisLineVisible(false);
        categoryAxis12.setTickLabelsVisible(false);
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis12.setTickMarkStroke(stroke18);
        xYPlot4.setDomainZeroBaselineStroke(stroke18);
        boolean boolean21 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot4.getRangeAxisEdge((int) '4');
        double double24 = xYPlot4.getRangeCrosshairValue();
        java.awt.Paint paint25 = xYPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) (byte) 100);
        blockParams0.setTranslateY((double) 10L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        java.lang.Object obj7 = textTitle1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getPadding();
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 2, (double) 8, (double) (short) -1, (double) 0.5f);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) 0L, (double) 4, (double) 0, 86.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes(10.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str16 = textAnchor15.toString();
        boolean boolean17 = rectangleInsets12.equals((java.lang.Object) str16);
        legendTitle11.setItemLabelPadding(rectangleInsets12);
        java.lang.Object obj19 = null;
        boolean boolean20 = legendTitle11.equals(obj19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle11.arrange(graphics2D21, rectangleConstraint22);
        java.awt.Paint paint24 = legendTitle11.getItemPaint();
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str16.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot4.setRenderer((int) (short) 10, xYItemRenderer9);
        xYPlot4.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.geom.Point2D point2D17 = xYPlot16.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        xYPlot16.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot16.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot16.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot16.getRangeAxisLocation(2);
        java.awt.Color color27 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.clearDomainMarkers(2);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot28.setRangeCrosshairStroke(stroke31);
        java.awt.Paint paint33 = null;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color27, stroke31, paint33, stroke34, 0.0f);
        valueMarker36.setValue((double) (-1));
        valueMarker36.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer41 = null;
        xYPlot16.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker36, layer41);
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color44 = java.awt.Color.GRAY;
        java.awt.Color color45 = color44.brighter();
        ringPlot43.setLabelBackgroundPaint((java.awt.Paint) color45);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator47 = ringPlot43.getLegendLabelURLGenerator();
        java.awt.Paint paint48 = ringPlot43.getBaseSectionPaint();
        java.awt.Font font49 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot43.setNoDataMessageFont(font49);
        valueMarker36.setLabelFont(font49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = null;
        valueMarker36.notifyListeners(markerChangeEvent52);
        valueMarker36.setLabel("");
        try {
            boolean boolean56 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(pieURLGenerator47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int4 = color3.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot5.setDomainAxis((int) (byte) 0, categoryAxis12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateLeftInset((-1.0d));
        double double20 = rectangleInsets17.getLeft();
        double double22 = rectangleInsets17.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("ClassContext", font2, (java.awt.Paint) color3, rectangleEdge14, horizontalAlignment15, verticalAlignment16, rectangleInsets17);
        java.awt.Color color24 = java.awt.Color.white;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color24);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("");
        double double28 = textTitle27.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent29 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle27);
        double double30 = textTitle27.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = textTitle27.getPosition();
        boolean boolean32 = textBlock25.equals((java.lang.Object) rectangleEdge31);
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("");
        textBlock25.addLine(textLine34);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str14 = categoryAxis13.getLabelToolTip();
        categoryPlot0.setDomainAxis((int) (byte) 10, categoryAxis13, true);
        categoryAxis13.setLowerMargin(100.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        ringPlot0.setPieIndex((int) (short) 0);
        double double6 = ringPlot0.getLabelLinkMargin();
        ringPlot0.setCircular(true, false);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        ringPlot0.setSeparatorStroke(stroke10);
        boolean boolean12 = ringPlot0.getSeparatorsVisible();
        java.awt.Paint paint13 = ringPlot0.getSeparatorPaint();
        java.awt.Paint paint14 = null;
        ringPlot0.setLabelShadowPaint(paint14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint5 = categoryAxis4.getTickLabelPaint();
        categoryAxis4.setAxisLineVisible(false);
        boolean boolean8 = numberAxis0.equals((java.lang.Object) false);
        org.jfree.chart.plot.Plot plot9 = numberAxis0.getPlot();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range11 = rectangleConstraint10.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedHeight((double) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint13.toUnconstrainedHeight();
        boolean boolean15 = numberAxis0.equals((java.lang.Object) rectangleConstraint14);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setAnchorValue((double) 10.0f);
        int int7 = categoryPlot0.getWeight();
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomDomainAxes((double) 0.0f, (double) (-1.0f), plotRenderingInfo13, point2D14);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor5 = new org.jfree.chart.plot.PieLabelDistributor(0);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor5);
        java.lang.String str7 = pieLabelDistributor5.toString();
        pieLabelDistributor5.sort();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        boolean boolean6 = xYPlot4.isDomainZeroBaselineVisible();
        xYPlot4.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot0.zoomRangeAxes(2.0d, (double) (-1.0f), plotRenderingInfo13, point2D14);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot0.getIndexOf(categoryItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.geom.Point2D point2D24 = xYPlot23.getQuadrantOrigin();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot23.getRenderer(1);
        xYPlot23.configureDomainAxes();
        xYPlot23.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot23.getDomainAxis((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.setWeight((int) (byte) 100);
        categoryPlot32.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot32.setDomainAxis((int) (byte) 0, categoryAxis39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot32.setRenderer(categoryItemRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot32.getRangeAxisLocation(10);
        xYPlot23.setDomainAxisLocation(axisLocation44);
        categoryPlot0.setRangeAxisLocation(axisLocation44, true);
        org.jfree.chart.ui.ProjectInfo projectInfo48 = org.jfree.chart.JFreeChart.INFO;
        projectInfo48.setVersion("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Image image51 = projectInfo48.getLogo();
        categoryPlot0.setBackgroundImage(image51);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(projectInfo48);
        org.junit.Assert.assertNotNull(image51);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 10, 10.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1656) + "'", int3 == (-1656));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        java.lang.String str3 = numberAxis0.getLabel();
        boolean boolean4 = numberAxis0.isVisible();
        double double5 = numberAxis0.getFixedAutoRange();
        try {
            numberAxis0.setRange(90.0d, (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (90.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getStartAngle();
        boolean boolean2 = ringPlot0.getIgnoreNullValues();
        ringPlot0.setSeparatorsVisible(false);
        double double6 = ringPlot0.getExplodePercent((java.lang.Comparable) 0);
        ringPlot0.setPieIndex(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.isCircular();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot0.setShadowPaint((java.awt.Paint) color2);
        double double4 = ringPlot0.getShadowYOffset();
        ringPlot0.setExplodePercent((java.lang.Comparable) 0, 2.0d);
        java.awt.Paint paint8 = ringPlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot();
        boolean boolean11 = ringPlot10.isCircular();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        ringPlot10.setShadowPaint((java.awt.Paint) color12);
        java.awt.Stroke stroke14 = ringPlot10.getSeparatorStroke();
        ringPlot9.setLabelOutlineStroke(stroke14);
        ringPlot0.setLabelLinkStroke(stroke14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int3 = color2.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setWeight((int) (byte) 100);
        categoryPlot4.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateLeftInset((-1.0d));
        double double19 = rectangleInsets16.getLeft();
        double double21 = rectangleInsets16.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("ClassContext", font1, (java.awt.Paint) color2, rectangleEdge13, horizontalAlignment14, verticalAlignment15, rectangleInsets16);
        int int23 = color2.getAlpha();
        int int24 = color2.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder25 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-16777024) + "'", int24 == (-16777024));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(0);
        java.lang.String str13 = categoryAxis11.getCategoryLabelToolTip((java.lang.Comparable) "Pie 3D Plot");
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(categoryAxis11);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        categoryPlot3.clearRangeMarkers((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot3.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot3.getDomainAxisForDataset((int) '#');
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot3);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(categoryAxis19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickMarkOutsideLength((float) '4');
        numberAxis3D1.setVerticalTickLabels(true);
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        numberAxis3D1.setLabelPaint(paint6);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperBound((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint5 = categoryAxis4.getTickLabelPaint();
        categoryAxis4.setAxisLineVisible(false);
        boolean boolean8 = numberAxis0.equals((java.lang.Object) false);
        org.jfree.chart.plot.Plot plot9 = numberAxis0.getPlot();
        boolean boolean10 = numberAxis0.isAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D12.setTickMarkOutsideLength((float) '4');
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) 10, (float) 10, 0.0f);
        numberAxis3D12.setTickLabelPaint((java.awt.Paint) color18);
        numberAxis0.setTickLabelPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot9.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot9.getDataset();
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot9, (org.jfree.chart.block.Arrangement) flowArrangement15, (org.jfree.chart.block.Arrangement) flowArrangement16);
        org.jfree.chart.block.BlockContainer blockContainer18 = null;
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint20.toFixedHeight(10.0d);
        double double23 = rectangleConstraint20.getWidth();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range28 = org.jfree.data.Range.shift(range25, 0.05d, false);
        org.jfree.chart.plot.RingPlot ringPlot29 = new org.jfree.chart.plot.RingPlot();
        double double30 = ringPlot29.getStartAngle();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ringPlot29);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint33.toFixedHeight(10.0d);
        org.jfree.chart.util.Size2D size2D36 = legendTitle31.arrange(graphics2D32, rectangleConstraint35);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType37 = rectangleConstraint35.getWidthConstraintType();
        org.jfree.chart.PaintMap paintMap39 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D41.setTickMarkOutsideLength((float) '4');
        boolean boolean44 = paintMap39.equals((java.lang.Object) numberAxis3D41);
        java.awt.Shape shape45 = numberAxis3D41.getUpArrow();
        org.jfree.data.Range range46 = numberAxis3D41.getDefaultAutoRange();
        org.jfree.data.Range range49 = org.jfree.data.Range.expand(range46, (double) 1L, 0.0d);
        boolean boolean51 = range46.contains((double) (byte) 0);
        org.jfree.data.Range range52 = null;
        org.jfree.data.Range range53 = org.jfree.data.Range.combine(range46, range52);
        double double54 = range46.getUpperBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType55 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint(0.0d, range25, lengthConstraintType37, (double) (byte) 10, range46, lengthConstraintType55);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = rectangleConstraint20.toRangeWidth(range25);
        try {
            org.jfree.chart.util.Size2D size2D58 = flowArrangement16.arrange(blockContainer18, graphics2D19, rectangleConstraint57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 90.0d + "'", double30 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertNotNull(lengthConstraintType37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType55);
        org.junit.Assert.assertNotNull(rectangleConstraint57);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        categoryPlot0.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setBackgroundAlpha((float) 2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer((-1));
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.CrosshairState crosshairState23 = null;
        boolean boolean24 = xYPlot18.render(graphics2D19, rectangle2D20, 8, plotRenderingInfo22, crosshairState23);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers(2);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot27.setRangeCrosshairStroke(stroke30);
        java.awt.Paint paint32 = null;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30, paint32, stroke33, 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker35.setLabelTextAnchor(textAnchor36);
        xYPlot18.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35, layer39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets();
        valueMarker35.setLabelOffset(rectangleInsets41);
        java.lang.String str43 = valueMarker35.getLabel();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str43);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        paintMap0.clear();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        numberAxis7.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setWeight((int) (byte) 100);
        categoryPlot10.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot10.setDomainAxis((int) (byte) 0, categoryAxis17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot10.getAxisOffset();
        numberAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearRangeMarkers((int) (short) 1);
        categoryPlot10.clearDomainMarkers((int) (byte) 100);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot10.getRangeMarkers(0, layer27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot10.getFixedDomainAxisSpace();
        boolean boolean30 = paintMap0.equals((java.lang.Object) categoryPlot10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        org.jfree.data.general.DatasetGroup datasetGroup6 = ringPlot0.getDatasetGroup();
        java.awt.Paint paint7 = ringPlot0.getLabelShadowPaint();
        ringPlot0.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setWeight((int) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(1, categoryItemRenderer5, false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        int int5 = ringPlot0.getPieIndex();
        java.awt.Color color6 = java.awt.Color.GRAY;
        ringPlot0.setShadowPaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = ringPlot0.getSectionPaint((java.lang.Comparable) 3.0d);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setNegativeArrowVisible(false);
        java.lang.String str13 = numberAxis10.getLabel();
        java.awt.Paint paint14 = numberAxis10.getTickLabelPaint();
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        java.awt.Shape shape16 = numberAxis10.getDownArrow();
        ringPlot0.setLegendItemShape(shape16);
        java.awt.Paint paint18 = ringPlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor5 = new org.jfree.chart.plot.PieLabelDistributor(0);
        ringPlot0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor5);
        java.lang.String str7 = pieLabelDistributor5.toString();
        int int8 = pieLabelDistributor5.getItemCount();
        java.lang.String str9 = pieLabelDistributor5.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int4 = color3.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot5.setDomainAxis((int) (byte) 0, categoryAxis12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot5.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets17.calculateLeftInset((-1.0d));
        double double20 = rectangleInsets17.getLeft();
        double double22 = rectangleInsets17.trimHeight(4.0d);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("ClassContext", font2, (java.awt.Paint) color3, rectangleEdge14, horizontalAlignment15, verticalAlignment16, rectangleInsets17);
        java.awt.Color color24 = java.awt.Color.white;
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, (java.awt.Paint) color24);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("");
        textBlock25.addLine(textLine27);
        java.util.List list29 = textBlock25.getLines();
        java.util.List list30 = textBlock25.getLines();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor34 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        try {
            java.awt.Shape shape38 = textBlock25.calculateBounds(graphics2D31, (float) (byte) 10, 0.0f, textBlockAnchor34, 2.0f, (float) '#', (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(textBlockAnchor34);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setWeight((int) (byte) 100);
        categoryPlot3.setAnchorValue((double) (short) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        categoryPlot3.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot3.getAxisOffset();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot3);
        numberAxis0.setRange(0.0d, (double) (byte) 10);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color18, color19, color20, color21, color22 };
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray27 = new java.awt.Paint[] { color24, color25, color26 };
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color28 };
        java.awt.Stroke[] strokeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray23, paintArray27, paintArray29, strokeArray30, strokeArray31, shapeArray32);
        java.awt.Paint paint34 = defaultDrawingSupplier33.getNextFillPaint();
        java.awt.Paint paint35 = defaultDrawingSupplier33.getNextPaint();
        java.awt.Stroke stroke36 = defaultDrawingSupplier33.getNextStroke();
        java.lang.Object obj37 = defaultDrawingSupplier33.clone();
        boolean boolean38 = numberAxis0.equals(obj37);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paintArray27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartChangeEvent[source=10.0]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        int int2 = objectList0.size();
        objectList0.clear();
        java.lang.Object obj5 = null;
        objectList0.set((int) (byte) 100, obj5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("");
        double double4 = textTitle3.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle3);
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) lineBorder6);
        java.awt.Stroke stroke8 = lineBorder6.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10L, (java.awt.Paint) color1, stroke8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        valueMarker9.setLabelFont(font10);
        java.awt.Paint paint12 = valueMarker9.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        double double16 = textTitle15.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent17 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle15);
        textTitle15.setURLText("");
        org.jfree.chart.block.BlockFrame blockFrame20 = textTitle15.getFrame();
        boolean boolean21 = textAnchor13.equals((java.lang.Object) blockFrame20);
        valueMarker9.setLabelTextAnchor(textAnchor13);
        double double23 = valueMarker9.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockFrame20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateLeftInset((-1.0d));
        double double5 = rectangleInsets2.getBottom();
        textTitle1.setMargin(rectangleInsets2);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.calculateLeftInset((-1.0d));
        textTitle1.setMargin(rectangleInsets7);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        textTitle1.setFont(font11);
        java.lang.String str13 = textTitle1.getText();
        java.lang.Object obj14 = textTitle1.clone();
        double double15 = textTitle1.getHeight();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D1.setTickMarkOutsideLength((float) '4');
        numberAxis3D1.setVerticalTickLabels(true);
        java.awt.Shape shape6 = numberAxis3D1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("poly", font3);
        int int5 = objectList0.indexOf((java.lang.Object) "poly");
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D2.setTickMarkOutsideLength((float) '4');
        boolean boolean5 = paintMap0.equals((java.lang.Object) numberAxis3D2);
        numberAxis3D2.setFixedAutoRange((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        xYPlot0.rendererChanged(rendererChangeEvent1);
        boolean boolean3 = xYPlot0.isRangeCrosshairLockedOnData();
        xYPlot0.clearRangeMarkers(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        java.awt.Paint paint3 = waferMapPlot1.getBackgroundPaint();
        boolean boolean4 = projectInfo0.equals((java.lang.Object) paint3);
        java.lang.String str5 = projectInfo0.getVersion();
        java.util.List list6 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLabelAngle(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setWeight((int) (byte) 100);
        categoryPlot5.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes(10.0d, plotRenderingInfo11, point2D12, false);
        boolean boolean15 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot5);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        categoryPlot5.axisChanged(axisChangeEvent18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint22 = categoryAxis21.getTickLabelPaint();
        categoryAxis21.setLabelURL("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint26 = null;
        categoryAxis21.setTickLabelPaint((java.lang.Comparable) (short) 10, paint26);
        boolean boolean28 = categoryPlot5.equals((java.lang.Object) categoryAxis21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot5.setRenderer(categoryItemRenderer29, true);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (short) 0, (float) (-1L), textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setNegativeArrowVisible(false);
        boolean boolean3 = numberAxis0.isTickMarksVisible();
        org.jfree.chart.PaintMap paintMap4 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D6.setTickMarkOutsideLength((float) '4');
        boolean boolean9 = paintMap4.equals((java.lang.Object) numberAxis3D6);
        java.awt.Shape shape10 = numberAxis3D6.getUpArrow();
        org.jfree.data.Range range11 = numberAxis3D6.getDefaultAutoRange();
        numberAxis0.setDefaultAutoRange(range11);
        numberAxis0.resizeRange((double) 100);
        numberAxis0.setLowerBound(0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color1 = java.awt.Color.GRAY;
        java.awt.Color color2 = color1.brighter();
        ringPlot0.setLabelBackgroundPaint((java.awt.Paint) color2);
        float float4 = ringPlot0.getForegroundAlpha();
        ringPlot0.setSeparatorsVisible(true);
        org.jfree.chart.util.Rotation rotation7 = ringPlot0.getDirection();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = multiplePiePlot9.getDataset();
        java.awt.Font font11 = multiplePiePlot9.getNoDataMessageFont();
        boolean boolean12 = rotation7.equals((java.lang.Object) multiplePiePlot9);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot9.getPieChart();
        jFreeChart13.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jFreeChart13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape10 = numberAxis9.getRightArrow();
        float float11 = numberAxis9.getTickMarkInsideLength();
        org.jfree.chart.PaintMap paintMap12 = new org.jfree.chart.PaintMap();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("hi!");
        numberAxis3D14.setTickMarkOutsideLength((float) '4');
        boolean boolean17 = paintMap12.equals((java.lang.Object) numberAxis3D14);
        java.awt.Shape shape18 = numberAxis3D14.getUpArrow();
        org.jfree.data.Range range19 = numberAxis3D14.getDefaultAutoRange();
        org.jfree.data.Range range22 = org.jfree.data.Range.expand(range19, (double) 1L, 0.0d);
        numberAxis9.setRangeWithMargins(range19);
        boolean boolean24 = numberAxis9.getAutoRangeStickyZero();
        org.jfree.data.Range range25 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setUpperBound((double) 0L);
        numberAxis26.setLowerBound((double) (short) -1);
        numberAxis26.setVerticalTickLabels(true);
        boolean boolean33 = numberAxis26.isTickMarksVisible();
        int int34 = xYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.geom.Point2D point2D5 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot4.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot4.getRangeAxisLocation(3);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(2);
        java.awt.Color color15 = java.awt.Color.gray;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainMarkers(2);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot16.setRangeCrosshairStroke(stroke19);
        java.awt.Paint paint21 = null;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19, paint21, stroke22, 0.0f);
        valueMarker24.setValue((double) (-1));
        valueMarker24.setLabel("RectangleAnchor.RIGHT");
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer29);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot();
        java.awt.Color color32 = java.awt.Color.GRAY;
        java.awt.Color color33 = color32.brighter();
        ringPlot31.setLabelBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator35 = ringPlot31.getLegendLabelURLGenerator();
        java.awt.Paint paint36 = ringPlot31.getBaseSectionPaint();
        java.awt.Font font37 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        ringPlot31.setNoDataMessageFont(font37);
        valueMarker24.setLabelFont(font37);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent40 = null;
        valueMarker24.notifyListeners(markerChangeEvent40);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.setWeight((int) (byte) 100);
        categoryPlot42.setAnchorValue((double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot42.zoomDomainAxes(10.0d, plotRenderingInfo48, point2D49, false);
        org.jfree.data.general.DatasetGroup datasetGroup52 = categoryPlot42.getDatasetGroup();
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot42);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double56 = rectangleInsets54.calculateLeftInset((-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str58 = textAnchor57.toString();
        boolean boolean59 = rectangleInsets54.equals((java.lang.Object) str58);
        legendTitle53.setItemLabelPadding(rectangleInsets54);
        java.lang.Object obj61 = null;
        boolean boolean62 = legendTitle53.equals(obj61);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = legendTitle53.getLegendItemGraphicAnchor();
        valueMarker24.setLabelAnchor(rectangleAnchor63);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(pieURLGenerator35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(datasetGroup52);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 4.0d + "'", double56 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str58.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
    }
}

