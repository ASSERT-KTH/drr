import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
        boolean boolean6 = month2.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar5 = null;
        try {
            day4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 10L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 10L);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = new java.lang.Object();
        boolean boolean2 = year0.equals(obj1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (short) 0);
        java.util.Date date4 = year1.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        try {
            java.lang.Number number12 = timeSeries1.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) "");
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        try {
            timeSeries1.delete(2, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.addChangeListener(seriesChangeListener9);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 9999, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        try {
            java.lang.Number number19 = timeSeries1.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, (int) (short) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getMonth();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year16.previous();
        long long21 = year16.getLastMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.Calendar calendar11 = null;
        fixedMillisecond5.peg(calendar11);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        try {
            timeSeries1.delete((int) (byte) -1, (int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        try {
            timeSeries1.delete(2019, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "" + "'", comparable6.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "" + "'", comparable6.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar22 = null;
        fixedMillisecond21.peg(calendar22);
        java.util.Calendar calendar24 = null;
        fixedMillisecond21.peg(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, regularTimePeriod26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.Object obj4 = new java.lang.Object();
        boolean boolean5 = year3.equals(obj4);
        int int6 = year0.compareTo((java.lang.Object) boolean5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 2019, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries29.createCopy((int) ' ', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year2.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        try {
            timeSeries1.delete(2019, (int) ' ', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            timeSeries29.add(regularTimePeriod32, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getSerialIndex();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month16.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 23640L + "'", long18 == 23640L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries1.add(regularTimePeriod19, (double) 100L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getDayOfMonth();
        java.util.Calendar calendar7 = null;
        try {
            day4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        long long15 = month8.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            month8.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        int int5 = year4.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.removeAgedItems(100L, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        int int19 = month14.getYearValue();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 2019L);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month14.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        try {
            java.lang.Number number9 = timeSeries1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (-1L));
        timeSeriesDataItem13.setSelected(false);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long19 = month18.getFirstMillisecond();
        int int20 = month18.getYearValue();
        long long21 = month18.getSerialIndex();
        boolean boolean22 = timeSeriesDataItem13.equals((java.lang.Object) month18);
        java.lang.Object obj23 = timeSeriesDataItem13.clone();
        int int24 = month2.compareTo(obj23);
        int int25 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62143689600000L) + "'", long10 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62143689600000L) + "'", long19 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        int int8 = year0.compareTo((java.lang.Object) 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        java.lang.Comparable comparable12 = timeSeries1.getKey();
        try {
            timeSeries1.update(11, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "" + "'", comparable12.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        try {
            timeSeries7.delete(11, (int) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        int int6 = day0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            day0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        boolean boolean3 = year1.equals((java.lang.Object) 10);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            java.lang.Number number33 = timeSeries31.getValue(regularTimePeriod32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        java.util.Calendar calendar6 = null;
        try {
            year2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries25.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        try {
            timeSeries1.delete((int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double22 = timeSeries21.getMinY();
        java.lang.String str23 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) ' ');
        java.util.List list31 = timeSeries21.getItems();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(2);
        boolean boolean35 = year33.equals((java.lang.Object) 10);
        timeSeries21.update((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) (short) 10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year33, (double) 100L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Year year7 = month2.getYear();
        long long8 = month2.getFirstMillisecond();
        int int9 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62143689600000L) + "'", long8 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = month20.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries8.add(regularTimePeriod20, (double) 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.Object obj3 = timeSeries1.clone();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) (short) 0);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) (-1L), false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long17 = month16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 2019L);
        java.lang.String str21 = timeSeries13.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.addAndOrUpdate(timeSeries13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62143689600000L) + "'", long17 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries20 = null;
        try {
            java.util.Collection collection21 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 2019, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) (short) 0);
        boolean boolean12 = month8.equals((java.lang.Object) year9);
        boolean boolean13 = day4.equals((java.lang.Object) month8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day4.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.util.Calendar calendar8 = null;
        try {
            month2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = new java.lang.Object();
        boolean boolean2 = year0.equals(obj1);
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        long long28 = month20.getLastMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62109475200001L) + "'", long28 == (-62109475200001L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double35 = timeSeries34.getMinY();
        java.lang.String str36 = timeSeries34.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int41 = fixedMillisecond38.compareTo((java.lang.Object) (byte) 100);
        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) ' ');
        java.util.List list44 = timeSeries34.getItems();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(2);
        boolean boolean48 = year46.equals((java.lang.Object) 10);
        timeSeries34.update((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) (short) 10);
        java.lang.String str51 = timeSeries34.getDescription();
        timeSeries34.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long56 = fixedMillisecond55.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int61 = fixedMillisecond58.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond58.getLastMillisecond(calendar62);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond58);
        timeSeries34.delete(0, 0);
        int int68 = fixedMillisecond32.compareTo((java.lang.Object) 0);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 10L, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 52L + "'", long63 == 52L);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 100 + "'", obj2.equals((byte) 100));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getDayOfMonth();
        long long7 = day4.getFirstMillisecond();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        java.util.Calendar calendar10 = null;
        try {
            day4.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43830L + "'", long8 == 43830L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
        java.lang.String str19 = timeSeries11.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) 52L);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long33 = month32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        timeSeries7.add(timeSeriesDataItem36);
        try {
            org.jfree.data.time.TimeSeries timeSeries41 = timeSeries7.createCopy((int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62143689600000L) + "'", long33 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) (short) 0);
        boolean boolean12 = month8.equals((java.lang.Object) year9);
        boolean boolean13 = day4.equals((java.lang.Object) month8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day4.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
        boolean boolean6 = month2.equals((java.lang.Object) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
        long long8 = year3.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 2019L);
        java.lang.Class class18 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar21 = null;
        fixedMillisecond20.peg(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone24);
        boolean boolean26 = year3.equals((java.lang.Object) date23);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "" + "'", comparable6.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 2019L);
        java.lang.String str27 = timeSeries19.getRangeDescription();
        java.lang.Class class28 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.addAndOrUpdate(timeSeries19);
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries29.createCopy(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar29 = null;
        fixedMillisecond28.peg(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        java.util.Date date32 = fixedMillisecond28.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        int int34 = year33.getYear();
        try {
            timeSeries25.update((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        java.util.Date date15 = month8.getStart();
        long long16 = month8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62143689600000L) + "'", long16 == (-62143689600000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeries1.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        double double21 = timeSeries1.getMinY();
        double double22 = timeSeries1.getMaxY();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        int int56 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2147483647 + "'", int56 == 2147483647);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        timeSeries1.setDescription("Value");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long7 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (double) (-1L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar13 = null;
        fixedMillisecond12.peg(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.util.Date date16 = fixedMillisecond12.getStart();
        boolean boolean17 = timeSeriesDataItem10.equals((java.lang.Object) fixedMillisecond12);
        timeSeries1.add(timeSeriesDataItem10, false);
        timeSeries1.setMaximumItemCount(100);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.removeAgedItems(100L, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        int int19 = month14.getYearValue();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 2019L);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        java.lang.String str2 = year1.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2" + "'", str2.equals("2"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        try {
            timeSeries8.delete((int) (short) 100, (int) (short) 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        long long15 = month8.getFirstMillisecond();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, number16);
        long long18 = month8.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        timeSeries8.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries8.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "Value", "Time");
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date3, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        timeSeries31.setRangeDescription("2");
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond33.getFirstMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond33.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
        java.util.Date date40 = fixedMillisecond39.getTime();
        try {
            timeSeries29.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        int int6 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long11 = month10.getFirstMillisecond();
        int int12 = month10.getYearValue();
        long long13 = month10.getSerialIndex();
        java.lang.String str14 = month10.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10);
        java.lang.String str16 = timeSeries15.getDescription();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long20 = month19.getFirstMillisecond();
        int int21 = month19.getYearValue();
        long long22 = month19.getSerialIndex();
        java.lang.String str23 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
        java.util.Collection collection25 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double28 = timeSeries27.getMinY();
        java.lang.String str29 = timeSeries27.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int34 = fixedMillisecond31.compareTo((java.lang.Object) (byte) 100);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) ' ');
        java.util.List list37 = timeSeries27.getItems();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(2);
        boolean boolean41 = year39.equals((java.lang.Object) 10);
        timeSeries27.update((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) 10);
        java.lang.String str44 = timeSeries27.getDescription();
        timeSeries27.setMaximumItemCount((int) 'a');
        java.util.Collection collection47 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        java.util.List list48 = timeSeries24.getItems();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double51 = timeSeries50.getMinY();
        java.lang.String str52 = timeSeries50.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double55 = timeSeries54.getMinY();
        java.lang.String str56 = timeSeries54.getDomainDescription();
        timeSeries54.setDomainDescription("");
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(2);
        boolean boolean63 = year61.equals((java.lang.Object) 10);
        int int64 = day59.compareTo((java.lang.Object) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day59.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries54.createCopy((org.jfree.data.time.RegularTimePeriod) day59, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries50.addAndOrUpdate(timeSeries54);
        timeSeries69.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent76 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int77 = fixedMillisecond74.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar78 = null;
        long long79 = fixedMillisecond74.getLastMillisecond(calendar78);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries69.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74);
        long long81 = fixedMillisecond74.getSerialIndex();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (java.lang.Number) 9, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        boolean boolean88 = fixedMillisecond86.equals((java.lang.Object) "October 0");
        try {
            org.jfree.data.time.TimeSeries timeSeries89 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62143689600000L) + "'", long11 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "October 0" + "'", str14.equals("October 0"));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143689600000L) + "'", long20 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 0" + "'", str23.equals("October 0"));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Time" + "'", str56.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(timeSeries69);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 52L + "'", long79 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 52L + "'", long81 == 52L);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        long long5 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) calendar6, "org.jfree.data.time.TimePeriodFormatException: hi!", "2");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem6.getPeriod();
        java.lang.Object obj8 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        long long5 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
        timeSeries29.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(class31);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        try {
            java.lang.Number number28 = timeSeries1.getValue((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long6 = month5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month5.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (double) (-1L));
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long13 = month12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (double) (-1L));
        timeSeriesDataItem16.setSelected(false);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long22 = month21.getFirstMillisecond();
        int int23 = month21.getYearValue();
        long long24 = month21.getSerialIndex();
        boolean boolean25 = timeSeriesDataItem16.equals((java.lang.Object) month21);
        java.lang.Object obj26 = timeSeriesDataItem16.clone();
        int int27 = month5.compareTo(obj26);
        java.util.Date date28 = month5.getEnd();
        boolean boolean29 = fixedMillisecond1.equals((java.lang.Object) month5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62143689600000L) + "'", long6 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62143689600000L) + "'", long13 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62143689600000L) + "'", long22 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int6 = year1.compareTo((java.lang.Object) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(5, year1);
        java.lang.Object obj8 = null;
        int int9 = month7.compareTo(obj8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "org.jfree.data.event.SeriesChangeEvent[source=100]", "hi!");
        try {
            timeSeries9.delete(0, 5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        java.lang.String str10 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) (short) 0);
        boolean boolean17 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        int int23 = day18.compareTo((java.lang.Object) year20);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1L));
        int int31 = year20.compareTo((java.lang.Object) month26);
        int int32 = month26.getYearValue();
        long long33 = month26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) month26);
        try {
            java.lang.Number number36 = timeSeries7.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62143689600000L) + "'", long33 == (-62143689600000L));
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getMonth();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.createCopy(12, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1L));
        timeSeriesDataItem22.setSelected(false);
        timeSeries15.add(timeSeriesDataItem22, false);
        try {
            timeSeries15.delete(2019, 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62143689600000L) + "'", long19 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Year year7 = month2.getYear();
        long long8 = year7.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year7.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond28.getLastMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond28.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int39 = fixedMillisecond36.compareTo((java.lang.Object) (byte) 100);
        int int40 = fixedMillisecond28.compareTo((java.lang.Object) fixedMillisecond36);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (-1L), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period Wed Dec 31 16:00:00 PST 1969 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double12 = timeSeries11.getMinY();
        java.lang.Object obj13 = timeSeries11.clone();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) (short) 0);
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (-1L), false);
        int int22 = year9.compareTo((java.lang.Object) (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "2", "");
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double22 = timeSeries21.getMinY();
        java.lang.String str23 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double26 = timeSeries25.getMinY();
        java.lang.String str27 = timeSeries25.getDomainDescription();
        timeSeries25.setDomainDescription("");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(2);
        boolean boolean34 = year32.equals((java.lang.Object) 10);
        int int35 = day30.compareTo((java.lang.Object) year32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day30.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries21.addAndOrUpdate(timeSeries25);
        timeSeries40.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int48 = fixedMillisecond45.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond45.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        long long52 = fixedMillisecond45.getSerialIndex();
        boolean boolean53 = fixedMillisecond14.equals((java.lang.Object) long52);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean53);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 52L + "'", long52 == 52L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        java.util.Date date15 = month8.getStart();
        java.util.TimeZone timeZone16 = null;
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date15, timeZone16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        boolean boolean10 = year8.equals((java.lang.Object) (short) 0);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getFirstMillisecond();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        boolean boolean19 = year17.equals((java.lang.Object) (short) 0);
        boolean boolean20 = month16.equals((java.lang.Object) year17);
        boolean boolean21 = day12.equals((java.lang.Object) month16);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 2019);
        java.lang.Comparable comparable24 = null;
        try {
            timeSeries1.setKey(comparable24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577779200000L + "'", long13 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        timeSeries8.fireSeriesChanged();
        timeSeries8.setNotify(false);
        timeSeries8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries1.getTimePeriodClass();
        java.lang.String str32 = timeSeries1.getDescription();
        timeSeries1.update(0, (java.lang.Number) (-62143689600000L));
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        long long15 = month8.getFirstMillisecond();
        long long16 = month8.getSerialIndex();
        java.util.Calendar calendar17 = null;
        try {
            month8.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        java.lang.Object obj10 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
        java.util.List list15 = timeSeries5.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        java.lang.String str22 = timeSeries5.getDescription();
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond26.getFirstMillisecond(calendar37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond26.previous();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries1.setDomainDescription("June 2019");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener33);
        java.lang.Class class35 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class35);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        try {
            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy(7, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43626L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long37 = month36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1L));
        timeSeriesDataItem40.setSelected(false);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long46 = month45.getFirstMillisecond();
        int int47 = month45.getYearValue();
        long long48 = month45.getSerialIndex();
        boolean boolean49 = timeSeriesDataItem40.equals((java.lang.Object) month45);
        java.lang.Object obj50 = timeSeriesDataItem40.clone();
        timeSeriesDataItem40.setSelected(false);
        try {
            timeSeries31.add(timeSeriesDataItem40, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62143689600000L) + "'", long37 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-62143689600000L) + "'", long46 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        java.lang.Comparable comparable12 = timeSeries1.getKey();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long16 = month15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) (-1L));
        org.jfree.data.time.Year year20 = month15.getYear();
        long long21 = month15.getFirstMillisecond();
        org.jfree.data.time.Year year22 = month15.getYear();
        long long23 = month15.getFirstMillisecond();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + "" + "'", comparable12.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62143689600000L) + "'", long16 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
        java.lang.String str19 = timeSeries11.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) 52L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.previous();
        java.util.Calendar calendar31 = null;
        try {
            month26.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62143689600000L) + "'", long6 == (-62143689600000L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.lang.Object obj4 = new java.lang.Object();
        boolean boolean5 = year3.equals(obj4);
        int int6 = year0.compareTo((java.lang.Object) boolean5);
        java.lang.Class<?> wildcardClass7 = year0.getClass();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "Value", "Time");
        double double9 = timeSeries8.getMaxY();
        timeSeries8.setMaximumItemAge((long) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        long long14 = year9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year9, regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date8 = fixedMillisecond7.getTime();
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date8, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date4, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, 4, 2019);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getSerialIndex();
        long long7 = day4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "Value", "Time");
        java.util.TimeZone timeZone9 = null;
        java.util.Locale locale10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date3, timeZone9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        java.lang.Number number22 = timeSeriesDataItem17.getValue();
        java.lang.Number number23 = timeSeriesDataItem17.getValue();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries1.getTimePeriodClass();
        java.lang.String str32 = timeSeries1.getDescription();
        timeSeries1.update(0, (java.lang.Number) (-62143689600000L));
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("31-December-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        timeSeries55.setDomainDescription("2019");
        org.jfree.data.time.TimeSeries timeSeries58 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries59 = timeSeries55.addAndOrUpdate(timeSeries58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries1.removeChangeListener(seriesChangeListener28);
        try {
            timeSeries1.delete((int) (short) 1, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (byte) 100);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) ' ');
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(2);
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        java.lang.String str36 = timeSeries19.getDescription();
        timeSeries19.setMaximumItemCount((int) 'a');
        java.util.Collection collection39 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list40 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double43 = timeSeries42.getMinY();
        java.lang.String str44 = timeSeries42.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double47 = timeSeries46.getMinY();
        java.lang.String str48 = timeSeries46.getDomainDescription();
        timeSeries46.setDomainDescription("");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(2);
        boolean boolean55 = year53.equals((java.lang.Object) 10);
        int int56 = day51.compareTo((java.lang.Object) year53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day51.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries42.addAndOrUpdate(timeSeries46);
        timeSeries61.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int69 = fixedMillisecond66.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar70 = null;
        long long71 = fixedMillisecond66.getLastMillisecond(calendar70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
        long long73 = fixedMillisecond66.getSerialIndex();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 9, false);
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond66.getMiddleMillisecond(calendar77);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 52L + "'", long71 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 52L + "'", long73 == 52L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 52L + "'", long78 == 52L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getLastMillisecond();
        java.util.Date date7 = month2.getStart();
        java.util.Calendar calendar8 = null;
        try {
            month2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) (short) 0);
        java.util.Date date35 = year32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        long long37 = day36.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 3);
        timeSeries29.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long45 = month44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month44, (double) (-1L));
        int int50 = timeSeriesDataItem48.compareTo((java.lang.Object) (short) 0);
        java.lang.Object obj51 = timeSeriesDataItem48.clone();
        java.lang.Object obj52 = timeSeriesDataItem48.clone();
        try {
            timeSeries29.add(timeSeriesDataItem48);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62143689600000L) + "'", long45 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        long long8 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (short) 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(2);
        boolean boolean5 = year3.equals((java.lang.Object) 10);
        int int6 = day1.compareTo((java.lang.Object) year3);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (-1L));
        int int14 = year3.compareTo((java.lang.Object) month9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) (short) 0);
        java.util.Date date18 = year15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        int int20 = year3.compareTo((java.lang.Object) date18);
        try {
            org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 0, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62143689600000L) + "'", long10 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries1.getTimePeriodClass();
        java.lang.String str32 = timeSeries1.getDescription();
        timeSeries1.update(0, (java.lang.Number) (-62143689600000L));
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double38 = timeSeries37.getMinY();
        java.lang.Object obj39 = timeSeries37.clone();
        java.util.Collection collection40 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long44 = month43.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month43, (double) 1.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period October 0 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        timeSeries1.setRangeDescription("2");
        int int30 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year32, regularTimePeriod33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond9);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond9.getLastMillisecond(calendar14);
        long long16 = fixedMillisecond9.getSerialIndex();
        long long17 = fixedMillisecond9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        timeSeriesDataItem6.setSelected(false);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        boolean boolean15 = timeSeriesDataItem6.equals((java.lang.Object) month11);
        timeSeriesDataItem6.setValue((java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        boolean boolean8 = month2.equals((java.lang.Object) 1.0d);
        long long9 = month2.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14);
        double double20 = timeSeries19.getMaxY();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long24 = month23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (double) (-1L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar30 = null;
        fixedMillisecond29.peg(calendar30);
        java.util.Date date32 = fixedMillisecond29.getTime();
        java.util.Date date33 = fixedMillisecond29.getStart();
        boolean boolean34 = timeSeriesDataItem27.equals((java.lang.Object) fixedMillisecond29);
        timeSeries19.add(timeSeriesDataItem27);
        try {
            timeSeries1.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62143689600000L) + "'", long24 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "org.jfree.data.event.SeriesChangeEvent[source=100]", "hi!");
        timeSeriesDataItem6.setSelected(true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (byte) 100);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) ' ');
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(2);
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        java.lang.String str36 = timeSeries19.getDescription();
        timeSeries19.setMaximumItemCount((int) 'a');
        java.util.Collection collection39 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list40 = timeSeries16.getItems();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double43 = timeSeries42.getMinY();
        java.lang.String str44 = timeSeries42.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double47 = timeSeries46.getMinY();
        java.lang.String str48 = timeSeries46.getDomainDescription();
        timeSeries46.setDomainDescription("");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(2);
        boolean boolean55 = year53.equals((java.lang.Object) 10);
        int int56 = day51.compareTo((java.lang.Object) year53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day51.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries42.addAndOrUpdate(timeSeries46);
        timeSeries61.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int69 = fixedMillisecond66.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar70 = null;
        long long71 = fixedMillisecond66.getLastMillisecond(calendar70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
        long long73 = fixedMillisecond66.getSerialIndex();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, (java.lang.Number) 9, false);
        long long77 = fixedMillisecond66.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 52L + "'", long71 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 52L + "'", long73 == 52L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 52L + "'", long77 == 52L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
        java.lang.String str19 = timeSeries11.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) 52L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.previous();
        long long31 = regularTimePeriod30.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-3945600001L) + "'", long31 == (-3945600001L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        boolean boolean19 = timeSeries1.getNotify();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
        java.util.List list15 = timeSeries5.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        java.lang.String str22 = timeSeries5.getDescription();
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
        long long37 = fixedMillisecond26.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 10L);
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
        java.util.List list15 = timeSeries5.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        java.lang.String str22 = timeSeries5.getDescription();
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
        try {
            org.jfree.data.time.TimeSeries timeSeries39 = timeSeries1.createCopy(5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.removeAgedItems(100L, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        int int19 = month14.getYearValue();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 2019L);
        java.lang.String str22 = month14.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "October 0" + "'", str22.equals("October 0"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str24 = timePeriodFormatException23.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        boolean boolean32 = timeSeriesDataItem6.equals((java.lang.Object) timePeriodFormatException20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        timeSeries55.setDomainDescription("2019");
        java.lang.Class class58 = timeSeries55.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNull(class58);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day4.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day4.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException4.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            java.lang.Number number14 = timeSeries1.getValue(regularTimePeriod13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = seriesChangeEvent31.getSummary();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(seriesChangeInfo32);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries1.removeChangeListener(seriesChangeListener28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        timeSeries1.setKey((java.lang.Comparable) month5);
        int int7 = month5.getMonth();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        timeSeries1.setKey((java.lang.Comparable) month5);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        java.lang.String str19 = timeSeries8.getDescription();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) (short) 0);
        boolean boolean27 = month23.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year24.previous();
        try {
            timeSeries8.add(regularTimePeriod28, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        long long4 = year0.getSerialIndex();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (byte) 100);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) ' ');
        java.util.List list20 = timeSeries10.getItems();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(2);
        boolean boolean24 = year22.equals((java.lang.Object) 10);
        timeSeries10.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries7.addAndOrUpdate(timeSeries10);
        timeSeries27.clear();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries27.addChangeListener(seriesChangeListener29);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        int int8 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month26, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period October 0 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
        java.util.List list15 = timeSeries5.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        java.lang.String str22 = timeSeries5.getDescription();
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        boolean boolean39 = day37.equals((java.lang.Object) "");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) (short) 0);
        boolean boolean43 = day37.equals((java.lang.Object) boolean42);
        int int44 = day37.getYear();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double47 = timeSeries46.getMinY();
        java.lang.String str48 = timeSeries46.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double51 = timeSeries50.getMinY();
        java.lang.String str52 = timeSeries50.getDomainDescription();
        timeSeries50.setDomainDescription("");
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(2);
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        int int60 = day55.compareTo((java.lang.Object) year57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day55.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) day55, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries46.addAndOrUpdate(timeSeries50);
        timeSeries65.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int73 = fixedMillisecond70.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        long long77 = fixedMillisecond70.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond70.previous();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day37, regularTimePeriod78);
        java.util.Calendar calendar80 = null;
        try {
            long long81 = day37.getFirstMillisecond(calendar80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem76);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 52L + "'", long77 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(timeSeries79);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
        boolean boolean32 = timeSeries29.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.removeAgedItems((long) (short) 0, true);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long24 = month23.getFirstMillisecond();
        int int25 = month23.getYearValue();
        long long26 = month23.getSerialIndex();
        java.lang.String str27 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23);
        java.lang.String str29 = timeSeries28.getDescription();
        java.lang.String str30 = timeSeries28.getDescription();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long36 = month35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.next();
        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 2019L);
        java.lang.String str40 = timeSeries32.getRangeDescription();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        boolean boolean43 = year41.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date46 = fixedMillisecond45.getTime();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, (double) 52L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month47.next();
        java.util.Calendar calendar54 = null;
        try {
            long long55 = month47.getLastMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62143689600000L) + "'", long24 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "October 0" + "'", str27.equals("October 0"));
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62143689600000L) + "'", long36 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1969, (int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getSerialIndex();
        java.lang.Object obj7 = null;
        int int8 = day4.compareTo(obj7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) 2019L);
        java.lang.String str18 = timeSeries10.getRangeDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        boolean boolean21 = year19.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) month25);
        long long27 = month25.getSerialIndex();
        boolean boolean28 = day4.equals((java.lang.Object) month25);
        long long29 = month25.getSerialIndex();
        java.lang.String str30 = month25.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 23640L + "'", long27 == 23640L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 23640L + "'", long29 == 23640L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "December 1969" + "'", str30.equals("December 1969"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond4.peg(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        java.util.Date date8 = fixedMillisecond4.getStart();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 9223372036854775807L, true);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double9 = timeSeries8.getMinY();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int15 = fixedMillisecond12.compareTo((java.lang.Object) (byte) 100);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) ' ');
        java.util.List list18 = timeSeries8.getItems();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long28 = month27.getFirstMillisecond();
        int int29 = month27.getYearValue();
        long long30 = month27.getSerialIndex();
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27);
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries8.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timeSeriesDataItem6.equals((java.lang.Object) seriesChangeListener35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62143689600000L) + "'", long28 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "October 0" + "'", str31.equals("October 0"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        java.lang.String str16 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long20 = month19.getFirstMillisecond();
        int int21 = month19.getYearValue();
        long long22 = month19.getSerialIndex();
        java.lang.String str23 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
        java.lang.String str25 = timeSeries24.getDescription();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long29 = month28.getFirstMillisecond();
        int int30 = month28.getYearValue();
        long long31 = month28.getSerialIndex();
        java.lang.String str32 = month28.toString();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28);
        java.util.Collection collection34 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries36.removePropertyChangeListener(propertyChangeListener41);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long46 = month45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month45.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (double) (-1L));
        timeSeriesDataItem49.setSelected(false);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long55 = month54.getFirstMillisecond();
        int int56 = month54.getYearValue();
        long long57 = month54.getSerialIndex();
        boolean boolean58 = timeSeriesDataItem49.equals((java.lang.Object) month54);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long62 = month61.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month61.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month61, (double) (-1L));
        boolean boolean67 = month61.equals((java.lang.Object) 1.0d);
        int int68 = timeSeriesDataItem49.compareTo((java.lang.Object) boolean67);
        timeSeries36.add(timeSeriesDataItem49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries33.addOrUpdate(timeSeriesDataItem49);
        timeSeries1.add(timeSeriesDataItem49, false);
        boolean boolean73 = timeSeriesDataItem49.isSelected();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143689600000L) + "'", long20 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 0" + "'", str23.equals("October 0"));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62143689600000L) + "'", long29 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "October 0" + "'", str32.equals("October 0"));
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-62143689600000L) + "'", long46 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62143689600000L) + "'", long55 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-62143689600000L) + "'", long62 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long4, "org.jfree.data.event.SeriesChangeEvent[source=100]", "Time");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) (short) 0);
        boolean boolean9 = timeSeriesDataItem6.isSelected();
        java.lang.Object obj10 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
        java.lang.String str19 = timeSeries11.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) 52L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.previous();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = month26.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) (short) 0);
        java.util.Date date35 = year32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        long long37 = day36.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 3);
        boolean boolean40 = timeSeries29.getNotify();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long50 = month49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month49.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month49, (double) (-1L));
        int int54 = year43.compareTo((java.lang.Object) month49);
        int int55 = month49.getYearValue();
        long long56 = month49.getLastMillisecond();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) month49);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62143689600000L) + "'", long50 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62109475200001L) + "'", long56 == (-62109475200001L));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100 + "'", obj2.equals(100));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100 + "'", obj3.equals(100));
        org.junit.Assert.assertNull(seriesChangeInfo6);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
//        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        java.util.Calendar calendar10 = null;
//        fixedMillisecond9.peg(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        java.util.Date date13 = fixedMillisecond9.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        int int15 = year14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        boolean boolean17 = day0.equals((java.lang.Object) regularTimePeriod16);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = day0.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        long long11 = fixedMillisecond5.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond5.getLastMillisecond(calendar12);
        long long14 = fixedMillisecond5.getMiddleMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond25.getMiddleMillisecond(calendar32);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond25.getMiddleMillisecond(calendar34);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        int int27 = timeSeries25.getItemCount();
        try {
            timeSeries25.update((-1), (java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int6 = year1.compareTo((java.lang.Object) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(5, year1);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        boolean boolean3 = fixedMillisecond0.equals((java.lang.Object) 1969);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560184642536L + "'", long1 == 1560184642536L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.util.Date date18 = year13.getEnd();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond9);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond9.getLastMillisecond(calendar14);
        long long16 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long20 = month19.getFirstMillisecond();
        int int21 = month19.getYearValue();
        long long22 = month19.getSerialIndex();
        java.lang.String str23 = month19.toString();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
        double double25 = timeSeries24.getMaxY();
        timeSeries24.setNotify(true);
        boolean boolean28 = fixedMillisecond9.equals((java.lang.Object) timeSeries24);
        java.lang.String str29 = timeSeries24.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143689600000L) + "'", long20 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 0" + "'", str23.equals("October 0"));
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        seriesChangeEvent17.setSummary(seriesChangeInfo18);
        java.lang.Object obj20 = seriesChangeEvent17.getSource();
        boolean boolean21 = day6.equals(obj20);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + (byte) 100 + "'", obj20.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
        int int14 = year9.compareTo((java.lang.Object) 100);
        int int15 = timeSeriesDataItem6.compareTo((java.lang.Object) 100);
        java.lang.Number number16 = timeSeriesDataItem6.getValue();
        java.lang.Number number17 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-1.0d) + "'", number16.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1.0d) + "'", number17.equals((-1.0d)));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries7.setKey((java.lang.Comparable) 100.0f);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        java.lang.Number number23 = null;
        try {
            timeSeries1.update(regularTimePeriod22, number23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getLastMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int20 = fixedMillisecond17.compareTo((java.lang.Object) (byte) 100);
        int int21 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 0.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 5);
        timeSeries7.setRangeDescription("October 0");
        try {
            timeSeries7.removeAgedItems((long) 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getDayOfMonth();
//        int int8 = day0.getMonth();
//        long long9 = day0.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            day0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double22 = timeSeries21.getMinY();
        java.lang.String str23 = timeSeries21.getDomainDescription();
        timeSeries21.setDomainDescription("");
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(2);
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        int int31 = day26.compareTo((java.lang.Object) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day26.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.lang.String str36 = timeSeries21.getRangeDescription();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long40 = month39.getFirstMillisecond();
        int int41 = month39.getYearValue();
        long long42 = month39.getSerialIndex();
        java.lang.String str43 = month39.toString();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39);
        java.lang.String str45 = timeSeries44.getDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long49 = month48.getFirstMillisecond();
        int int50 = month48.getYearValue();
        long long51 = month48.getSerialIndex();
        java.lang.String str52 = month48.toString();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48);
        java.util.Collection collection54 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double57 = timeSeries56.getMinY();
        java.lang.String str58 = timeSeries56.getDomainDescription();
        timeSeries56.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timeSeries56.removePropertyChangeListener(propertyChangeListener61);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long66 = month65.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month65.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month65, (double) (-1L));
        timeSeriesDataItem69.setSelected(false);
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long75 = month74.getFirstMillisecond();
        int int76 = month74.getYearValue();
        long long77 = month74.getSerialIndex();
        boolean boolean78 = timeSeriesDataItem69.equals((java.lang.Object) month74);
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long82 = month81.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = month81.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month81, (double) (-1L));
        boolean boolean87 = month81.equals((java.lang.Object) 1.0d);
        int int88 = timeSeriesDataItem69.compareTo((java.lang.Object) boolean87);
        timeSeries56.add(timeSeriesDataItem69);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem90 = timeSeries53.addOrUpdate(timeSeriesDataItem69);
        timeSeries21.add(timeSeriesDataItem69, false);
        int int93 = timeSeriesDataItem19.compareTo((java.lang.Object) false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62143689600000L) + "'", long40 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "October 0" + "'", str43.equals("October 0"));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-62143689600000L) + "'", long49 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "October 0" + "'", str52.equals("October 0"));
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Time" + "'", str58.equals("Time"));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62143689600000L) + "'", long66 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62143689600000L) + "'", long75 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-62143689600000L) + "'", long82 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem90);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        long long11 = fixedMillisecond5.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond5.getLastMillisecond(calendar12);
        java.util.Calendar calendar14 = null;
        fixedMillisecond5.peg(calendar14);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("1969");
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone18 = null;
        java.util.Locale locale19 = null;
        try {
            org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date14, timeZone18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("2");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            java.lang.Number number3 = timeSeries1.getValue(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        long long18 = month16.getSerialIndex();
        int int19 = month16.getMonth();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 23640L + "'", long18 == 23640L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year13.next();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        timeSeries5.setDomainDescription("");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(2);
        boolean boolean14 = year12.equals((java.lang.Object) 10);
        int int15 = day10.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries5);
        try {
            timeSeries20.delete(0, (int) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        timeSeriesDataItem6.setSelected(false);
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem6.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        timeSeries1.update(0, (java.lang.Number) 10L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean17 = year15.equals((java.lang.Object) (short) 0);
        boolean boolean18 = month14.equals((java.lang.Object) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year15, regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        double double21 = timeSeries1.getMinY();
        try {
            timeSeries1.delete((int) '#', (int) (short) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        int int2 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        long long7 = day0.getFirstMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560150000000L + "'", long7 == 1560150000000L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 1969);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar12 = null;
        fixedMillisecond11.peg(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date14, timeZone15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date14);
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond23.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond23.getStart();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        int int30 = day29.getMonth();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (org.jfree.data.time.RegularTimePeriod) month39);
        java.lang.Object obj41 = timeSeries40.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) (-1L));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 100.0f);
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries1.setDomainDescription("June 2019");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener33);
        double double35 = timeSeries1.getMaxY();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2019.0d + "'", double35 == 2019.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        java.util.Date date15 = month8.getStart();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        java.lang.String str17 = month16.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "October 1" + "'", str17.equals("October 1"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        timeSeriesDataItem6.setSelected(false);
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem6.getClass();
        java.lang.Number number10 = null;
        timeSeriesDataItem6.setValue(number10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Year year7 = month2.getYear();
        long long8 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year9 = month2.getYear();
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62143689600000L) + "'", long8 == (-62143689600000L));
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.Object obj3 = timeSeries1.clone();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) (short) 0);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) (-1L), false);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double14 = timeSeries13.getMinY();
        java.lang.String str15 = timeSeries13.getDomainDescription();
        timeSeries13.setDomainDescription("");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        int int23 = day18.compareTo((java.lang.Object) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day18.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long31 = month30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (double) (-1L));
        timeSeriesDataItem34.setSelected(false);
        timeSeries27.add(timeSeriesDataItem34, false);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        boolean boolean41 = year39.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year39.previous();
        timeSeries27.setKey((java.lang.Comparable) year39);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long47 = month46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month46, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries27.addOrUpdate(regularTimePeriod51, (double) 11);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries1.addOrUpdate(regularTimePeriod51, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62143689600000L) + "'", long31 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62143689600000L) + "'", long47 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date2, seriesChangeInfo3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
        boolean boolean6 = month2.equals((java.lang.Object) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
        long long8 = year3.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year3.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getLastMillisecond();
        java.util.Date date7 = month2.getStart();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (byte) 100);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) ' ');
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(2);
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        java.lang.String str36 = timeSeries19.getDescription();
        timeSeries19.setMaximumItemCount((int) 'a');
        java.util.Collection collection39 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.setMaximumItemAge(43626L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeries19.getTimePeriod((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getSerialIndex();
        java.lang.Object obj7 = null;
        boolean boolean8 = day4.equals(obj7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 2019L);
        java.lang.String str27 = timeSeries19.getRangeDescription();
        java.lang.Class class28 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.addAndOrUpdate(timeSeries19);
        try {
            org.jfree.data.time.TimeSeries timeSeries32 = timeSeries19.createCopy(3, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy(11, 2019);
        java.util.List list11 = timeSeries1.getItems();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
        timeSeries29.clear();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(class31);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        try {
            timeSeries1.delete((int) ' ', 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.Object obj3 = timeSeries1.clone();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) (short) 0);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        long long9 = day8.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar13 = null;
        fixedMillisecond12.peg(calendar13);
        boolean boolean15 = day8.equals((java.lang.Object) calendar13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 23640L, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577779200000L + "'", long9 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        int int9 = month4.getYearValue();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        double double20 = timeSeries1.getMinY();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double23 = timeSeries22.getMinY();
        java.lang.String str24 = timeSeries22.getDomainDescription();
        timeSeries22.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long32 = month31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) (-1L));
        timeSeriesDataItem35.setSelected(false);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long41 = month40.getFirstMillisecond();
        int int42 = month40.getYearValue();
        long long43 = month40.getSerialIndex();
        boolean boolean44 = timeSeriesDataItem35.equals((java.lang.Object) month40);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (double) (-1L));
        boolean boolean53 = month47.equals((java.lang.Object) 1.0d);
        int int54 = timeSeriesDataItem35.compareTo((java.lang.Object) boolean53);
        timeSeries22.add(timeSeriesDataItem35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.addOrUpdate(timeSeriesDataItem35);
        timeSeries1.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2019.0d + "'", double20 == 2019.0d);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62143689600000L) + "'", long32 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62143689600000L) + "'", long41 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62143689600000L) + "'", long48 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        double double31 = timeSeries1.getMinY();
        java.lang.String str32 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2019.0d + "'", double31 == 2019.0d);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        timeSeries19.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries19.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long29 = month28.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) (-1L));
        timeSeriesDataItem32.setSelected(false);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long38 = month37.getFirstMillisecond();
        int int39 = month37.getYearValue();
        long long40 = month37.getSerialIndex();
        boolean boolean41 = timeSeriesDataItem32.equals((java.lang.Object) month37);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long45 = month44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month44, (double) (-1L));
        boolean boolean50 = month44.equals((java.lang.Object) 1.0d);
        int int51 = timeSeriesDataItem32.compareTo((java.lang.Object) boolean50);
        timeSeries19.add(timeSeriesDataItem32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries16.addOrUpdate(timeSeriesDataItem32);
        boolean boolean54 = timeSeriesDataItem32.isSelected();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62143689600000L) + "'", long29 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-62143689600000L) + "'", long38 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62143689600000L) + "'", long45 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean13 = year11.equals((java.lang.Object) (short) 0);
        java.util.Date date14 = year11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
        int int17 = day15.getDayOfMonth();
        long long18 = day15.getFirstMillisecond();
        java.lang.Number number19 = null;
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day15, number19);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577779200000L + "'", long18 == 1577779200000L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Year year7 = month2.getYear();
        long long8 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year9 = month2.getYear();
        int int10 = year9.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62143689600000L) + "'", long8 == (-62143689600000L));
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.createCopy(11, 2019);
        timeSeries1.removeAgedItems(true);
        try {
            java.lang.Number number14 = timeSeries1.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.util.Date date8 = month2.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getSerialIndex();
        java.lang.Object obj7 = null;
        int int8 = day4.compareTo(obj7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        timeSeries16.setRangeDescription("10-June-2019");
        boolean boolean19 = day4.equals((java.lang.Object) timeSeries16);
        int int20 = day4.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int2 = year1.getYear();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        java.lang.String str18 = month16.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "December 1969" + "'", str18.equals("December 1969"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.Object obj3 = timeSeries1.clone();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean6 = year4.equals((java.lang.Object) (short) 0);
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) (-1L), false);
        java.lang.String str12 = timeSeries1.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (-1.0d), false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
//        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
//        java.lang.String str7 = day0.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        timeSeries1.setRangeDescription("2");
        int int30 = timeSeries1.getMaximumItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries1.addChangeListener(seriesChangeListener31);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        boolean boolean3 = year1.equals((java.lang.Object) 10);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long7 = month6.getFirstMillisecond();
        int int8 = month6.getYearValue();
        long long9 = month6.getSerialIndex();
        java.lang.String str10 = month6.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6);
        java.lang.String str12 = timeSeries11.getDescription();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 2019L);
        java.lang.String str23 = timeSeries15.getRangeDescription();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean26 = year24.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) 52L);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long37 = month36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (double) (-1L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem40.getPeriod();
        timeSeries11.add(timeSeriesDataItem40);
        java.lang.Number number43 = timeSeriesDataItem40.getValue();
        int int44 = year1.compareTo((java.lang.Object) timeSeriesDataItem40);
        timeSeriesDataItem40.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October 0" + "'", str10.equals("October 0"));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62143689600000L) + "'", long19 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62143689600000L) + "'", long37 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (-1.0d) + "'", number43.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date34 = fixedMillisecond33.getTime();
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond33.getMiddleMillisecond(calendar35);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 23640L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date2, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        try {
            timeSeries1.update(8, (java.lang.Number) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries1.setDomainDescription("Value");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) (byte) 100);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) ' ');
        java.util.List list20 = timeSeries10.getItems();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(2);
        boolean boolean24 = year22.equals((java.lang.Object) 10);
        timeSeries10.update((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries7.addAndOrUpdate(timeSeries10);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double2 = timeSeries1.getMinY();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
//        java.util.List list11 = timeSeries1.getItems();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
//        boolean boolean15 = year13.equals((java.lang.Object) 10);
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
//        long long21 = month20.getFirstMillisecond();
//        int int22 = month20.getYearValue();
//        long long23 = month20.getSerialIndex();
//        java.lang.String str24 = month20.toString();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
//        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries1.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double31 = timeSeries30.getMinY();
//        timeSeries30.fireSeriesChanged();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        boolean boolean38 = year36.equals((java.lang.Object) (short) 0);
//        boolean boolean39 = day33.equals((java.lang.Object) boolean38);
//        java.lang.String str40 = day33.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond42.peg(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getTime();
//        java.util.Date date46 = fixedMillisecond42.getStart();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        int int48 = year47.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year47.next();
//        boolean boolean50 = day33.equals((java.lang.Object) regularTimePeriod49);
//        int int51 = timeSeries30.getIndex(regularTimePeriod49);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries1.addOrUpdate(regularTimePeriod49, (double) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (byte) 100);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) ' ');
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(2);
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        java.lang.String str36 = timeSeries19.getDescription();
        timeSeries19.setMaximumItemCount((int) 'a');
        java.util.Collection collection39 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        int int40 = timeSeries16.getMaximumItemCount();
        java.lang.Object obj41 = timeSeries16.clone();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent(obj41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2147483647 + "'", int40 == 2147483647);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double4 = timeSeries3.getMinY();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 100);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) ' ');
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        boolean boolean17 = year15.equals((java.lang.Object) 10);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        int int24 = month22.getYearValue();
        long long25 = month22.getSerialIndex();
        java.lang.String str26 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22);
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        int int29 = year0.compareTo((java.lang.Object) timeSeries3);
        timeSeries3.setNotify(true);
        try {
            java.lang.Number number33 = timeSeries3.getValue(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "October 0" + "'", str26.equals("October 0"));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean11 = year9.equals((java.lang.Object) (short) 0);
        boolean boolean12 = month8.equals((java.lang.Object) year9);
        boolean boolean13 = day4.equals((java.lang.Object) month8);
        java.lang.Class<?> wildcardClass14 = month8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
        long long21 = fixedMillisecond16.getMiddleMillisecond();
        java.util.Date date22 = fixedMillisecond16.getTime();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date22, timeZone23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double2 = timeSeries1.getMinY();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        boolean boolean9 = year7.equals((java.lang.Object) (short) 0);
//        boolean boolean10 = day4.equals((java.lang.Object) boolean9);
//        java.lang.String str11 = day4.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond13.peg(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Date date17 = fixedMillisecond13.getStart();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        int int19 = year18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
//        boolean boolean21 = day4.equals((java.lang.Object) regularTimePeriod20);
//        int int22 = timeSeries1.getIndex(regularTimePeriod20);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener23);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double4 = timeSeries3.getMinY();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 100);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) ' ');
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        boolean boolean17 = year15.equals((java.lang.Object) 10);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        int int24 = month22.getYearValue();
        long long25 = month22.getSerialIndex();
        java.lang.String str26 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22);
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        int int29 = year0.compareTo((java.lang.Object) timeSeries3);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year33 = month32.getYear();
        int int35 = year33.compareTo((java.lang.Object) (byte) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar38 = null;
        fixedMillisecond37.peg(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        try {
            org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) year41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "October 0" + "'", str26.equals("October 0"));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.clear();
        try {
            timeSeries7.update(3, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        double double20 = timeSeries1.getMinY();
        timeSeries1.setMaximumItemAge(0L);
        timeSeries1.setMaximumItemCount(9999);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2019.0d + "'", double20 == 2019.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int24 = fixedMillisecond21.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getLastMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond21.getTime();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        java.lang.Number number29 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.previous();
        java.util.Calendar calendar31 = null;
        try {
            day28.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getDayOfMonth();
        long long7 = day4.getFirstMillisecond();
        long long8 = day4.getSerialIndex();
        int int9 = day4.getYear();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day4.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577779200000L + "'", long7 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43830L + "'", long8 == 43830L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getDayOfMonth();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
//        java.lang.Object obj11 = seriesChangeEvent9.getSource();
//        java.lang.Object obj12 = seriesChangeEvent9.getSource();
//        boolean boolean13 = day0.equals((java.lang.Object) seriesChangeEvent9);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double16 = timeSeries15.getMinY();
//        java.lang.String str17 = timeSeries15.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int22 = fixedMillisecond19.compareTo((java.lang.Object) (byte) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) ' ');
//        java.util.List list25 = timeSeries15.getItems();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(2);
//        boolean boolean29 = year27.equals((java.lang.Object) 10);
//        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) (short) 10);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(10, (int) (short) 0);
//        long long35 = month34.getFirstMillisecond();
//        int int36 = month34.getYearValue();
//        long long37 = month34.getSerialIndex();
//        java.lang.String str38 = month34.toString();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34);
//        timeSeries15.update((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 2019L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener42);
//        timeSeries15.setMaximumItemAge((long) (byte) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener46);
//        boolean boolean48 = day0.equals((java.lang.Object) timeSeries15);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//        org.junit.Assert.assertNull(seriesChangeInfo10);
//        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 100 + "'", obj11.equals(100));
//        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + 100 + "'", obj12.equals(100));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62143689600000L) + "'", long35 == (-62143689600000L));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "October 0" + "'", str38.equals("October 0"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getSerialIndex();
        int int4 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        int int6 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        long long15 = month8.getFirstMillisecond();
        long long16 = month8.getSerialIndex();
        java.lang.Class<?> wildcardClass17 = month8.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(2);
        java.lang.String str20 = year19.toString();
        java.util.Date date21 = year19.getStart();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2" + "'", str20.equals("2"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries1.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.String str20 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str23 = timePeriodFormatException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        java.lang.String str10 = day9.toString();
        int int11 = day9.getDayOfMonth();
        long long12 = day9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-2019" + "'", str10.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
        java.util.List list15 = timeSeries5.getItems();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
        boolean boolean19 = year17.equals((java.lang.Object) 10);
        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
        java.lang.String str22 = timeSeries5.getDescription();
        timeSeries5.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        boolean boolean39 = day37.equals((java.lang.Object) "");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean42 = year40.equals((java.lang.Object) (short) 0);
        boolean boolean43 = day37.equals((java.lang.Object) boolean42);
        int int44 = day37.getYear();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double47 = timeSeries46.getMinY();
        java.lang.String str48 = timeSeries46.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double51 = timeSeries50.getMinY();
        java.lang.String str52 = timeSeries50.getDomainDescription();
        timeSeries50.setDomainDescription("");
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(2);
        boolean boolean59 = year57.equals((java.lang.Object) 10);
        int int60 = day55.compareTo((java.lang.Object) year57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day55.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) day55, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries46.addAndOrUpdate(timeSeries50);
        timeSeries65.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int73 = fixedMillisecond70.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        long long77 = fixedMillisecond70.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond70.previous();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day37, regularTimePeriod78);
        try {
            timeSeries1.update((int) (short) 0, (java.lang.Number) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem76);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 52L + "'", long77 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(timeSeries79);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "2", "");
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double22 = timeSeries21.getMinY();
        java.lang.String str23 = timeSeries21.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double26 = timeSeries25.getMinY();
        java.lang.String str27 = timeSeries25.getDomainDescription();
        timeSeries25.setDomainDescription("");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(2);
        boolean boolean34 = year32.equals((java.lang.Object) 10);
        int int35 = day30.compareTo((java.lang.Object) year32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day30.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) day30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries21.addAndOrUpdate(timeSeries25);
        timeSeries40.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int48 = fixedMillisecond45.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond45.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        long long52 = fixedMillisecond45.getSerialIndex();
        boolean boolean53 = fixedMillisecond14.equals((java.lang.Object) long52);
        java.util.Calendar calendar54 = null;
        fixedMillisecond14.peg(calendar54);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 52L + "'", long52 == 52L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "2", "");
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double22 = timeSeries21.getMinY();
        java.lang.String str23 = timeSeries21.getDomainDescription();
        timeSeries21.setDomainDescription("");
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(2);
        boolean boolean30 = year28.equals((java.lang.Object) 10);
        int int31 = day26.compareTo((java.lang.Object) year28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day26.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond34.next();
        int int37 = fixedMillisecond14.compareTo((java.lang.Object) regularTimePeriod36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond14.getFirstMillisecond(calendar38);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        timeSeries29.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        java.util.List list8 = timeSeries1.getItems();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        java.util.Collection collection26 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        timeSeries25.setDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timeSeries25.fireSeriesChanged();
        timeSeries25.setMaximumItemAge(24233L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries8.addChangeListener(seriesChangeListener16);
        int int18 = timeSeriesDataItem6.compareTo((java.lang.Object) timeSeries8);
        java.lang.String str19 = timeSeries8.getDescription();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long24 = month23.getFirstMillisecond();
        int int25 = month23.getYearValue();
        long long26 = month23.getSerialIndex();
        java.lang.String str27 = month23.toString();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23);
        timeSeries28.removeAgedItems(false);
        java.lang.String str31 = timeSeries28.getRangeDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        boolean boolean37 = year35.equals((java.lang.Object) (short) 0);
        boolean boolean38 = month34.equals((java.lang.Object) year35);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(2);
        boolean boolean43 = year41.equals((java.lang.Object) 10);
        int int44 = day39.compareTo((java.lang.Object) year41);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long48 = month47.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (double) (-1L));
        int int52 = year41.compareTo((java.lang.Object) month47);
        int int53 = month47.getYearValue();
        long long54 = month47.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) year35, (org.jfree.data.time.RegularTimePeriod) month47);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries8.addAndOrUpdate(timeSeries55);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean63 = year61.equals((java.lang.Object) (short) 0);
        boolean boolean64 = month60.equals((java.lang.Object) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year61.previous();
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(7, year61);
        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62143689600000L) + "'", long24 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "October 0" + "'", str27.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62143689600000L) + "'", long48 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62143689600000L) + "'", long54 == (-62143689600000L));
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Date date3 = year1.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries1.setDomainDescription("June 2019");
        timeSeries1.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries1.getDataItem(regularTimePeriod35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeEvent1, seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100 + "'", obj2.equals(100));
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double2 = timeSeries1.getMinY();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double6 = timeSeries5.getMinY();
//        java.lang.String str7 = timeSeries5.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) ' ');
//        java.util.List list15 = timeSeries5.getItems();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2);
//        boolean boolean19 = year17.equals((java.lang.Object) 10);
//        timeSeries5.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) 10);
//        java.lang.String str22 = timeSeries5.getDescription();
//        timeSeries5.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long27 = fixedMillisecond26.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int32 = fixedMillisecond29.compareTo((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        boolean boolean36 = timeSeries1.equals((java.lang.Object) fixedMillisecond26);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        boolean boolean39 = day37.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        boolean boolean42 = year40.equals((java.lang.Object) (short) 0);
//        boolean boolean43 = day37.equals((java.lang.Object) boolean42);
//        int int44 = day37.getYear();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double47 = timeSeries46.getMinY();
//        java.lang.String str48 = timeSeries46.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double51 = timeSeries50.getMinY();
//        java.lang.String str52 = timeSeries50.getDomainDescription();
//        timeSeries50.setDomainDescription("");
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(2);
//        boolean boolean59 = year57.equals((java.lang.Object) 10);
//        int int60 = day55.compareTo((java.lang.Object) year57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day55.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) day55, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries46.addAndOrUpdate(timeSeries50);
//        timeSeries65.removeAgedItems((long) (-9999), true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int73 = fixedMillisecond70.compareTo((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries65.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
//        long long77 = fixedMillisecond70.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond70.previous();
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day37, regularTimePeriod78);
//        long long80 = day37.getLastMillisecond();
//        java.util.Calendar calendar81 = null;
//        try {
//            long long82 = day37.getFirstMillisecond(calendar81);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
//        org.junit.Assert.assertEquals((double) double51, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Time" + "'", str52.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 52L + "'", long77 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560236399999L + "'", long80 == 1560236399999L);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        double double8 = timeSeries7.getMaxY();
        timeSeries7.removeAgedItems(100L, true);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        int int19 = month14.getYearValue();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 2019L);
        long long22 = month14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double2 = timeSeries1.getMinY();
//        java.lang.String str3 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double6 = timeSeries5.getMinY();
//        java.lang.String str7 = timeSeries5.getDomainDescription();
//        timeSeries5.setDomainDescription("");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(2);
//        boolean boolean14 = year12.equals((java.lang.Object) 10);
//        int int15 = day10.compareTo((java.lang.Object) year12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries5);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(2);
//        boolean boolean25 = year23.equals((java.lang.Object) 10);
//        int int26 = day21.compareTo((java.lang.Object) year23);
//        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
//        long long28 = day21.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate29 = day21.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, regularTimePeriod30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43626L + "'", long28 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate29);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long59 = month58.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = month58.next();
        int int61 = month58.getMonth();
        org.jfree.data.time.Year year62 = month58.getYear();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (double) 0, false);
        long long66 = month58.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62143689600000L) + "'", long59 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62109475200001L) + "'", long66 == (-62109475200001L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener4);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1L));
        timeSeriesDataItem22.setSelected(false);
        timeSeries15.add(timeSeriesDataItem22, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        timeSeries15.setKey((java.lang.Comparable) year27);
        java.util.List list32 = timeSeries15.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62143689600000L) + "'", long19 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries51);
        try {
            timeSeries51.delete(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date8 = fixedMillisecond7.getTime();
        long long9 = fixedMillisecond7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long11 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1L));
        timeSeriesDataItem14.setSelected(false);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long20 = month19.getFirstMillisecond();
        int int21 = month19.getYearValue();
        long long22 = month19.getSerialIndex();
        boolean boolean23 = timeSeriesDataItem14.equals((java.lang.Object) month19);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1L));
        boolean boolean32 = month26.equals((java.lang.Object) 1.0d);
        int int33 = timeSeriesDataItem14.compareTo((java.lang.Object) boolean32);
        timeSeries1.add(timeSeriesDataItem14);
        int int35 = timeSeries1.getItemCount();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) (short) 0);
        java.util.Date date39 = year36.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        long long42 = day40.getSerialIndex();
        java.lang.Object obj43 = null;
        int int44 = day40.compareTo(obj43);
        long long45 = day40.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getLastMillisecond(calendar48);
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getFirstMillisecond(calendar50);
        long long52 = fixedMillisecond47.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond47.previous();
        int int54 = day40.compareTo((java.lang.Object) fixedMillisecond47);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (-1), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62143689600000L) + "'", long11 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143689600000L) + "'", long20 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 43830L + "'", long42 == 43830L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43830L + "'", long45 == 43830L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1L + "'", long49 == 1L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.next();
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 2019L);
        java.lang.String str27 = timeSeries19.getRangeDescription();
        java.lang.Class class28 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.addAndOrUpdate(timeSeries19);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo31 = null;
        seriesChangeEvent30.setSummary(seriesChangeInfo31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        java.lang.Object obj9 = null;
        boolean boolean10 = day8.equals(obj9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond9.getLastMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int20 = fixedMillisecond17.compareTo((java.lang.Object) (byte) 100);
        int int21 = fixedMillisecond9.compareTo((java.lang.Object) fixedMillisecond17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 0.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 5);
        timeSeries7.setRangeDescription("October 0");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long31 = month30.getFirstMillisecond();
        int int32 = month30.getMonth();
        long long33 = month30.getSerialIndex();
        long long34 = month30.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month30.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (-62104204800000L), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62143689600000L) + "'", long31 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        java.lang.String str18 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        int int3 = year1.compareTo((java.lang.Object) (byte) 1);
        long long4 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (double) 0.0f);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        timeSeriesDataItem6.setSelected(false);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        boolean boolean15 = timeSeriesDataItem6.equals((java.lang.Object) month11);
        long long16 = month11.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62109475200001L) + "'", long16 == (-62109475200001L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.previous();
        boolean boolean11 = fixedMillisecond4.equals((java.lang.Object) regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar9 = null;
        fixedMillisecond8.peg(calendar9);
        boolean boolean11 = day4.equals((java.lang.Object) calendar9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14);
        java.lang.String str20 = timeSeries19.getDescription();
        java.lang.String str21 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 2019L);
        java.lang.String str31 = timeSeries23.getRangeDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) month38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 52L);
        java.lang.Class class42 = timeSeries19.getTimePeriodClass();
        int int43 = day4.compareTo((java.lang.Object) timeSeries19);
        long long44 = day4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long7 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2019L);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries1.setKey((java.lang.Comparable) year12);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year12.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int6 = year1.compareTo((java.lang.Object) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(5, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        long long9 = month7.getSerialIndex();
        long long10 = month7.getLastMillisecond();
        long long11 = month7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 24233L + "'", long9 == 24233L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372399999L + "'", long10 == 1559372399999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1556694000000L + "'", long11 == 1556694000000L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        timeSeries1.setRangeDescription("2");
        int int30 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        int int55 = timeSeries51.getMaximumItemCount();
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long59 = month58.getFirstMillisecond();
        int int60 = month58.getYearValue();
        long long61 = month58.getSerialIndex();
        java.lang.String str62 = month58.toString();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month58);
        long long64 = month58.getLastMillisecond();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) 7);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month58);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener68 = null;
        timeSeries1.addChangeListener(seriesChangeListener68);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2147483647 + "'", int55 == 2147483647);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62143689600000L) + "'", long59 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "October 0" + "'", str62.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-62109475200001L) + "'", long64 == (-62109475200001L));
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        int int8 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double9 = timeSeries8.getMinY();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int15 = fixedMillisecond12.compareTo((java.lang.Object) (byte) 100);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) ' ');
        java.util.List list18 = timeSeries8.getItems();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long28 = month27.getFirstMillisecond();
        int int29 = month27.getYearValue();
        long long30 = month27.getSerialIndex();
        java.lang.String str31 = month27.toString();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27);
        timeSeries8.update((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries8.removeChangeListener(seriesChangeListener35);
        timeSeries8.setMaximumItemAge((long) (byte) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
        timeSeries8.removeChangeListener(seriesChangeListener39);
        int int41 = year5.compareTo((java.lang.Object) timeSeries8);
        java.util.Calendar calendar42 = null;
        try {
            year5.peg(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62143689600000L) + "'", long28 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "October 0" + "'", str31.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int12 = fixedMillisecond9.compareTo((java.lang.Object) (byte) 100);
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem15.getPeriod();
        timeSeriesDataItem15.setSelected(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        timeSeries1.clear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) (-1L));
        timeSeriesDataItem17.setSelected(false);
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(timeSeriesDataItem17);
        boolean boolean22 = timeSeriesDataItem17.isSelected();
        java.lang.Object obj23 = timeSeriesDataItem17.clone();
        java.lang.Number number24 = timeSeriesDataItem17.getValue();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (-1.0d) + "'", number24.equals((-1.0d)));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        int int13 = month11.getYearValue();
        long long14 = month11.getSerialIndex();
        java.lang.String str15 = month11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11);
        java.util.Collection collection17 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double20 = timeSeries19.getMinY();
        java.lang.String str21 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) (byte) 100);
        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) ' ');
        java.util.List list29 = timeSeries19.getItems();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(2);
        boolean boolean33 = year31.equals((java.lang.Object) 10);
        timeSeries19.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (short) 10);
        java.lang.String str36 = timeSeries19.getDescription();
        timeSeries19.setMaximumItemCount((int) 'a');
        java.util.Collection collection39 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.util.List list40 = timeSeries16.getItems();
        timeSeries16.setMaximumItemAge(1560184642536L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long7 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2019L);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries1.setKey((java.lang.Comparable) year12);
        java.util.Date date21 = year12.getEnd();
        java.util.TimeZone timeZone22 = null;
        try {
            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        java.lang.String str10 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) (short) 0);
        boolean boolean17 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        int int23 = day18.compareTo((java.lang.Object) year20);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1L));
        int int31 = year20.compareTo((java.lang.Object) month26);
        int int32 = month26.getYearValue();
        long long33 = month26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) month26);
        long long35 = month26.getFirstMillisecond();
        long long36 = month26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62143689600000L) + "'", long33 == (-62143689600000L));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62143689600000L) + "'", long35 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-62109475200001L) + "'", long36 == (-62109475200001L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        double double20 = timeSeries1.getMinY();
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(2);
        boolean boolean27 = year25.equals((java.lang.Object) 10);
        int int28 = day23.compareTo((java.lang.Object) year25);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long32 = month31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) (-1L));
        int int36 = year25.compareTo((java.lang.Object) month31);
        int int37 = month31.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 100.0f);
        java.lang.String str40 = month31.toString();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2019.0d + "'", double20 == 2019.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62143689600000L) + "'", long32 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "October 0" + "'", str40.equals("October 0"));
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
//        double double3 = timeSeries2.getMinY();
//        java.lang.String str4 = timeSeries2.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int9 = fixedMillisecond6.compareTo((java.lang.Object) (byte) 100);
//        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) ' ');
//        java.util.List list12 = timeSeries2.getItems();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(2);
//        boolean boolean16 = year14.equals((java.lang.Object) 10);
//        timeSeries2.update((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (short) 10);
//        java.lang.String str19 = timeSeries2.getDescription();
//        timeSeries2.setMaximumItemCount((int) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long24 = fixedMillisecond23.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
//        int int29 = fixedMillisecond26.compareTo((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond26.getLastMillisecond(calendar30);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        timeSeries2.delete(0, 0);
//        int int36 = fixedMillisecond0.compareTo((java.lang.Object) 0);
//        long long37 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560184654915L + "'", long37 == 1560184654915L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.removeAgedItems((long) (short) 0, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getFirstMillisecond(calendar25);
        long long27 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date28 = fixedMillisecond22.getTime();
        boolean boolean29 = timeSeries1.equals((java.lang.Object) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year30.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        long long10 = fixedMillisecond9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double11 = timeSeries10.getMinY();
        java.lang.String str12 = timeSeries10.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double15 = timeSeries14.getMinY();
        java.lang.String str16 = timeSeries14.getDomainDescription();
        timeSeries14.setDomainDescription("");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) day19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries14);
        java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
        int int32 = timeSeries29.getMaximumItemCount();
        boolean boolean33 = timeSeries29.getNotify();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemCount(2147483647);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date4 = fixedMillisecond3.getTime();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        timeSeries1.setKey((java.lang.Comparable) month5);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long12 = month11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (double) (-1L));
        int int17 = timeSeriesDataItem15.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        boolean boolean20 = year18.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
        int int23 = year18.compareTo((java.lang.Object) 100);
        int int24 = timeSeriesDataItem15.compareTo((java.lang.Object) 100);
        boolean boolean25 = timeSeriesDataItem15.isSelected();
        timeSeries1.add(timeSeriesDataItem15, false);
        java.lang.Number number28 = timeSeriesDataItem15.getValue();
        java.lang.Number number29 = timeSeriesDataItem15.getValue();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62143689600000L) + "'", long12 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (-1.0d) + "'", number29.equals((-1.0d)));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        int int8 = timeSeriesDataItem6.compareTo((java.lang.Object) (short) 0);
        timeSeriesDataItem6.setSelected(false);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long16 = month15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 2019L);
        java.lang.String str20 = timeSeries12.getRangeDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean23 = year21.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) month27);
        long long29 = timeSeries28.getMaximumItemAge();
        boolean boolean30 = timeSeriesDataItem6.equals((java.lang.Object) long29);
        java.lang.Object obj31 = null;
        int int32 = timeSeriesDataItem6.compareTo(obj31);
        java.lang.Object obj33 = timeSeriesDataItem6.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62143689600000L) + "'", long16 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "Value", "Time");
        double double9 = timeSeries8.getMaxY();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        int int15 = month13.getYearValue();
        long long16 = month13.getSerialIndex();
        java.lang.String str17 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13);
        java.lang.String str19 = timeSeries18.getDescription();
        java.util.Collection collection20 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        java.lang.String str21 = timeSeries8.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "October 0" + "'", str17.equals("October 0"));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        timeSeries7.setKey((java.lang.Comparable) 100.0f);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: Time");
        java.lang.String str16 = timeSeries7.getDescription();
        java.lang.String str17 = timeSeries7.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.createCopy(31, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 10L);
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        timeSeries5.setDomainDescription("");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(2);
        boolean boolean14 = year12.equals((java.lang.Object) 10);
        int int15 = day10.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        double double20 = timeSeries19.getMinY();
        boolean boolean21 = year0.equals((java.lang.Object) timeSeries19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        java.lang.String str18 = timeSeries1.getDescription();
        timeSeries1.setMaximumItemCount((int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long23 = fixedMillisecond22.getLastMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        try {
            timeSeries31.delete(31, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        long long6 = day4.getSerialIndex();
        java.lang.Object obj7 = null;
        int int8 = day4.compareTo(obj7);
        java.lang.String str9 = day4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43830L + "'", long6 == 43830L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-2019" + "'", str9.equals("31-December-2019"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        int int7 = month2.getYearValue();
        int int8 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) "");
//        long long3 = day0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.lang.String str8 = timeSeries7.getDescription();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
        java.lang.String str19 = timeSeries11.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        boolean boolean22 = year20.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (double) 52L);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double32 = timeSeries31.getMinY();
        java.lang.String str33 = timeSeries31.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int38 = fixedMillisecond35.compareTo((java.lang.Object) (byte) 100);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) ' ');
        java.util.List list41 = timeSeries31.getItems();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        timeSeries31.update((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) (short) 10);
        java.lang.String str48 = timeSeries31.getDescription();
        timeSeries31.setMaximumItemCount((int) 'a');
        double double51 = timeSeries31.getMinY();
        boolean boolean52 = timeSeries31.getNotify();
        int int53 = month26.compareTo((java.lang.Object) boolean52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.0d + "'", double51 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long9 = month8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (double) (-1L));
        int int13 = year2.compareTo((java.lang.Object) month8);
        int int14 = month8.getYearValue();
        long long15 = month8.getFirstMillisecond();
        long long16 = month8.getSerialIndex();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month8.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62143689600000L) + "'", long9 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        timeSeries1.setRangeDescription("2");
        int int30 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double33 = timeSeries32.getMinY();
        java.lang.String str34 = timeSeries32.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double37 = timeSeries36.getMinY();
        java.lang.String str38 = timeSeries36.getDomainDescription();
        timeSeries36.setDomainDescription("");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(2);
        boolean boolean45 = year43.equals((java.lang.Object) 10);
        int int46 = day41.compareTo((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries32.addAndOrUpdate(timeSeries36);
        timeSeries51.removeAgedItems((long) (-9999), true);
        int int55 = timeSeries51.getMaximumItemCount();
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long59 = month58.getFirstMillisecond();
        int int60 = month58.getYearValue();
        long long61 = month58.getSerialIndex();
        java.lang.String str62 = month58.toString();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month58);
        long long64 = month58.getLastMillisecond();
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) 7);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month58);
        try {
            timeSeries1.delete(2019, (int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2147483647 + "'", int55 == 2147483647);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62143689600000L) + "'", long59 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 10L + "'", long61 == 10L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "October 0" + "'", str62.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-62109475200001L) + "'", long64 == (-62109475200001L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        timeSeriesDataItem6.setValue((java.lang.Number) 4);
        timeSeriesDataItem6.setValue((java.lang.Number) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double13 = timeSeries12.getMinY();
        java.lang.String str14 = timeSeries12.getDomainDescription();
        timeSeries12.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries12.createCopy(11, 2019);
        boolean boolean22 = timeSeriesDataItem6.equals((java.lang.Object) 2019);
        java.lang.Object obj23 = null;
        boolean boolean24 = timeSeriesDataItem6.equals(obj23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (double) (-1L));
        org.jfree.data.time.Year year25 = month20.getYear();
        long long26 = month20.getFirstMillisecond();
        org.jfree.data.time.Year year27 = month20.getYear();
        timeSeries1.setKey((java.lang.Comparable) month20);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62143689600000L) + "'", long26 == (-62143689600000L));
        org.junit.Assert.assertNotNull(year27);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560184656452L + "'", long2 == 1560184656452L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double4 = timeSeries3.getMinY();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int10 = fixedMillisecond7.compareTo((java.lang.Object) (byte) 100);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) ' ');
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        boolean boolean17 = year15.equals((java.lang.Object) 10);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long23 = month22.getFirstMillisecond();
        int int24 = month22.getYearValue();
        long long25 = month22.getSerialIndex();
        java.lang.String str26 = month22.toString();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22);
        java.util.Collection collection28 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        int int29 = year0.compareTo((java.lang.Object) timeSeries3);
        timeSeries3.setNotify(true);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62143689600000L) + "'", long23 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "October 0" + "'", str26.equals("October 0"));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        boolean boolean8 = month0.equals((java.lang.Object) fixedMillisecond5);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, "Value", "Time");
        double double9 = timeSeries8.getMaxY();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long14 = month13.getFirstMillisecond();
        int int15 = month13.getYearValue();
        long long16 = month13.getSerialIndex();
        java.lang.String str17 = month13.toString();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13);
        java.lang.String str19 = timeSeries18.getDescription();
        java.util.Collection collection20 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        long long21 = timeSeries18.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62143689600000L) + "'", long14 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "October 0" + "'", str17.equals("October 0"));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) "");
//        int int7 = fixedMillisecond1.compareTo((java.lang.Object) day4);
//        long long8 = day4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        timeSeries19.setKey((java.lang.Comparable) month23);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries19.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long30 = month29.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month29, (double) (-1L));
        int int35 = timeSeriesDataItem33.compareTo((java.lang.Object) (short) 0);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        boolean boolean38 = year36.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year36.previous();
        int int41 = year36.compareTo((java.lang.Object) 100);
        int int42 = timeSeriesDataItem33.compareTo((java.lang.Object) 100);
        boolean boolean43 = timeSeriesDataItem33.isSelected();
        timeSeries19.add(timeSeriesDataItem33, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries1.addOrUpdate(timeSeriesDataItem33);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62143689600000L) + "'", long30 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getFirstMillisecond();
        long long6 = year4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        java.util.Date date8 = month2.getEnd();
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        boolean boolean3 = year1.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int6 = year1.compareTo((java.lang.Object) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(5, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Year year9 = month7.getYear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year11 = month10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        int int14 = year9.compareTo((java.lang.Object) year11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.removeAgedItems((long) (short) 0, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond22.getFirstMillisecond(calendar25);
        long long27 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date28 = fixedMillisecond22.getTime();
        boolean boolean29 = timeSeries1.equals((java.lang.Object) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year30);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double6 = timeSeries5.getMinY();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        timeSeries5.setDomainDescription("");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(2);
        boolean boolean14 = year12.equals((java.lang.Object) 10);
        int int15 = day10.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day10.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries20.removeAgedItems((long) (-9999), true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int28 = fixedMillisecond25.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        long long32 = fixedMillisecond25.getSerialIndex();
        long long33 = fixedMillisecond25.getLastMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getFirstMillisecond();
        int int6 = year4.getYear();
        java.lang.String str7 = year4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Date date3 = year1.getStart();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
//        boolean boolean4 = year2.equals((java.lang.Object) 10);
//        int int5 = day0.compareTo((java.lang.Object) year2);
//        int int6 = day0.getYear();
//        java.lang.String str7 = day0.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
//        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(2);
//        boolean boolean12 = year10.equals((java.lang.Object) 10);
//        int int13 = day8.compareTo((java.lang.Object) year10);
//        org.jfree.data.time.SerialDate serialDate14 = day8.getSerialDate();
//        long long15 = day8.getSerialIndex();
//        int int16 = day0.compareTo((java.lang.Object) long15);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43626L + "'", long15 == 43626L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        java.lang.String str10 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean16 = year14.equals((java.lang.Object) (short) 0);
        boolean boolean17 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(2);
        boolean boolean22 = year20.equals((java.lang.Object) 10);
        int int23 = day18.compareTo((java.lang.Object) year20);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1L));
        int int31 = year20.compareTo((java.lang.Object) month26);
        int int32 = month26.getYearValue();
        long long33 = month26.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) year14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-62143689600000L) + "'", long33 == (-62143689600000L));
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long11 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) (-1L));
        timeSeriesDataItem14.setSelected(false);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long20 = month19.getFirstMillisecond();
        int int21 = month19.getYearValue();
        long long22 = month19.getSerialIndex();
        boolean boolean23 = timeSeriesDataItem14.equals((java.lang.Object) month19);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month26, (double) (-1L));
        boolean boolean32 = month26.equals((java.lang.Object) 1.0d);
        int int33 = timeSeriesDataItem14.compareTo((java.lang.Object) boolean32);
        timeSeries1.add(timeSeriesDataItem14);
        timeSeries1.removeAgedItems((-62143689600000L), true);
        timeSeries1.clear();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62143689600000L) + "'", long11 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62143689600000L) + "'", long20 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int14 = fixedMillisecond11.compareTo((java.lang.Object) (byte) 100);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond11.getLastMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond11.getTime();
        java.util.Date date18 = fixedMillisecond11.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2);
        boolean boolean23 = year21.equals((java.lang.Object) 10);
        int int24 = day19.compareTo((java.lang.Object) year21);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long28 = month27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) (-1L));
        int int32 = year21.compareTo((java.lang.Object) month27);
        int int33 = month27.getYearValue();
        long long34 = month27.getFirstMillisecond();
        long long35 = month27.getSerialIndex();
        boolean boolean36 = fixedMillisecond11.equals((java.lang.Object) month27);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month27, 0.0d, false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62143689600000L) + "'", long28 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62143689600000L) + "'", long34 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.Year year9 = month4.getYear();
        long long10 = year9.getLastMillisecond();
        java.lang.String str11 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62104204800001L) + "'", long10 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo4);
        java.lang.String str6 = seriesChangeEvent1.toString();
        java.lang.Object obj7 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100 + "'", obj2.equals(100));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100 + "'", obj3.equals(100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + 100 + "'", obj7.equals(100));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        int int7 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        boolean boolean4 = year2.equals((java.lang.Object) 10);
        int int5 = day0.compareTo((java.lang.Object) year2);
        int int6 = day0.getYear();
        java.util.Date date7 = day0.getEnd();
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getYearValue();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2);
        timeSeries7.removeAgedItems(false);
        java.lang.String str10 = timeSeries7.getRangeDescription();
        timeSeries7.setDescription("org.jfree.data.time.TimePeriodFormatException: Time");
        timeSeries7.clear();
        double double14 = timeSeries7.getMaxY();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 0" + "'", str6.equals("October 0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) (-1L));
        org.jfree.data.time.Year year7 = month2.getYear();
        long long8 = year7.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            year7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62143689600000L) + "'", long3 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long19 = month18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) (-1L));
        timeSeriesDataItem22.setSelected(false);
        timeSeries15.add(timeSeriesDataItem22, false);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        boolean boolean29 = year27.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        timeSeries15.setKey((java.lang.Comparable) year27);
        long long32 = year27.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62143689600000L) + "'", long19 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) "");
//        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
//        boolean boolean5 = year3.equals((java.lang.Object) (short) 0);
//        boolean boolean6 = day0.equals((java.lang.Object) boolean5);
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        org.jfree.data.time.Year year9 = month4.getYear();
        long long10 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }
}

