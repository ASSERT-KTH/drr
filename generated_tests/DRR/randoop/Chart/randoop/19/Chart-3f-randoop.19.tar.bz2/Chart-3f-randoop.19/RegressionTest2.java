import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) ' ');
        java.util.List list11 = timeSeries1.getItems();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        boolean boolean15 = year13.equals((java.lang.Object) 10);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) (short) 10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long21 = month20.getFirstMillisecond();
        int int22 = month20.getYearValue();
        long long23 = month20.getSerialIndex();
        java.lang.String str24 = month20.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) 2019L);
        timeSeries1.setRangeDescription("2");
        java.lang.Comparable comparable30 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond32.getFirstMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond32.getStart();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond32.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond32.getTime();
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond32.getMiddleMillisecond(calendar41);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) (byte) 1, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62143689600000L) + "'", long21 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + comparable30 + "' != '" + "" + "'", comparable30.equals(""));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar9 = null;
        fixedMillisecond8.peg(calendar9);
        boolean boolean11 = day4.equals((java.lang.Object) calendar9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14);
        java.lang.String str20 = timeSeries19.getDescription();
        java.lang.String str21 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 2019L);
        java.lang.String str31 = timeSeries23.getRangeDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) month38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 52L);
        java.lang.Class class42 = timeSeries19.getTimePeriodClass();
        int int43 = day4.compareTo((java.lang.Object) timeSeries19);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long49 = month48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month48.next();
        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries45.addChangeListener(seriesChangeListener53);
        double double55 = timeSeries45.getMinY();
        java.util.Collection collection56 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries45);
        timeSeries19.setDescription("October 0");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries19.removeChangeListener(seriesChangeListener59);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-62143689600000L) + "'", long49 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2019.0d + "'", double55 == 2019.0d);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        boolean boolean18 = year16.equals((java.lang.Object) (short) 0);
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        long long21 = day20.getFirstMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(10, (int) (short) 0);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        boolean boolean27 = year25.equals((java.lang.Object) (short) 0);
        boolean boolean28 = month24.equals((java.lang.Object) year25);
        boolean boolean29 = day20.equals((java.lang.Object) month24);
        int int30 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long34 = month33.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long43 = month42.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month42.next();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries39.addChangeListener(seriesChangeListener47);
        int int49 = timeSeriesDataItem37.compareTo((java.lang.Object) timeSeries39);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long53 = month52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month52.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month52, (double) (-1L));
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem56, "org.jfree.data.event.SeriesChangeEvent[source=100]", "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries39.addOrUpdate(timeSeriesDataItem56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries1.addOrUpdate(timeSeriesDataItem56);
        try {
            org.jfree.data.time.TimeSeries timeSeries64 = timeSeries1.createCopy((int) '4', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577779200000L + "'", long21 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-62143689600000L) + "'", long34 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-62143689600000L) + "'", long43 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62143689600000L) + "'", long53 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertNull(timeSeriesDataItem61);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.Class class9 = timeSeries1.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long7 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 2019L);
        java.lang.String str11 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean14 = year12.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) month18);
        timeSeries1.setKey((java.lang.Comparable) year12);
        java.lang.String str21 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond4.peg(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        java.util.Date date8 = fixedMillisecond4.getStart();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 9223372036854775807L, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        double double2 = timeSeries1.getMinY();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        boolean boolean10 = year8.equals((java.lang.Object) 10);
        int int11 = day6.compareTo((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "2", "");
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(class20);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str5 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("Time");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str10 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Time" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Time"));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long5 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 2019L);
        java.lang.String str9 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        boolean boolean12 = year10.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setMaximumItemAge((long) (byte) 100);
        double double20 = timeSeries1.getMinY();
        timeSeries1.setMaximumItemAge(0L);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(2);
        boolean boolean27 = year25.equals((java.lang.Object) 10);
        int int28 = day23.compareTo((java.lang.Object) year25);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long32 = month31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (double) (-1L));
        int int36 = year25.compareTo((java.lang.Object) month31);
        int int37 = month31.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 100.0f);
        org.jfree.data.time.Year year40 = month31.getYear();
        long long41 = month31.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62143689600000L) + "'", long5 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2019.0d + "'", double20 == 2019.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62143689600000L) + "'", long32 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 100);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo2);
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) 100 + "'", obj4.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 100 + "'", obj5.equals((byte) 100));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) (short) 0);
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        long long5 = day4.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Calendar calendar9 = null;
        fixedMillisecond8.peg(calendar9);
        boolean boolean11 = day4.equals((java.lang.Object) calendar9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long15 = month14.getFirstMillisecond();
        int int16 = month14.getYearValue();
        long long17 = month14.getSerialIndex();
        java.lang.String str18 = month14.toString();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14);
        java.lang.String str20 = timeSeries19.getDescription();
        java.lang.String str21 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (short) 0);
        long long27 = month26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.next();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 2019L);
        java.lang.String str31 = timeSeries23.getRangeDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        boolean boolean34 = year32.equals((java.lang.Object) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Date date37 = fixedMillisecond36.getTime();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) year32, (org.jfree.data.time.RegularTimePeriod) month38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (double) 52L);
        java.lang.Class class42 = timeSeries19.getTimePeriodClass();
        int int43 = day4.compareTo((java.lang.Object) timeSeries19);
        java.lang.Object obj44 = timeSeries19.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577779200000L + "'", long5 == 1577779200000L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62143689600000L) + "'", long15 == (-62143689600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 0" + "'", str18.equals("October 0"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62143689600000L) + "'", long27 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(obj44);
    }
}

