import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int4 = week0.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        java.util.Date date5 = regularTimePeriod3.getStart();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = regularTimePeriod3.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62075779200001L) + "'", long3 == (-62075779200001L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62075779200001L) + "'", long3 == (-62075779200001L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException10.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        java.util.Date date3 = week1.getEnd();
        java.util.Date date4 = week1.getEnd();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 7, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        int int2 = week0.getWeek();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.Date date5 = week0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int2 = week0.getYearValue();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        java.lang.String str4 = week2.toString();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 100, 1" + "'", str4.equals("Week 100, 1"));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        int int4 = week0.compareTo((java.lang.Object) 7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException8);
        java.lang.String str12 = timePeriodFormatException8.toString();
        java.lang.String str13 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int2 = week0.getYearValue();
        int int3 = week0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.Date date5 = week0.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        int int14 = week8.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date15 = week8.getStart();
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date15, timeZone16);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164382400001L) + "'", long4 == (-62164382400001L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int3 = week0.getWeek();
//        int int5 = week0.compareTo((java.lang.Object) (-17));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        long long8 = week5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        int int11 = week5.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date12 = week5.getStart();
//        int int13 = week4.compareTo((java.lang.Object) week5);
//        java.lang.Class<?> wildcardClass14 = week4.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-17) + "'", int13 == (-17));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        long long8 = week5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        int int11 = week5.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date12 = week5.getStart();
//        int int13 = week4.compareTo((java.lang.Object) week5);
//        java.util.Calendar calendar14 = null;
//        try {
//            week5.peg(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-17) + "'", int13 == (-17));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 5");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        long long5 = week4.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1545552000000L + "'", long5 == 1545552000000L);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test084");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        java.lang.String str4 = week3.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 25, 2019" + "'", str4.equals("Week 25, 2019"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, (int) (short) 100);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        org.jfree.data.time.Year year6 = week4.getYear();
        boolean boolean7 = week3.equals((java.lang.Object) year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 1, year6);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        int int4 = week0.compareTo((java.lang.Object) 7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.util.Date date6 = week4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone8);
        int int11 = week10.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week4.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 100, 1" + "'", str4.equals("Week 100, 1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62076081600001L) + "'", long5 == (-62076081600001L));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        int int2 = week0.getWeek();
//        java.lang.String str3 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.lang.String str8 = week4.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 7, 2019" + "'", str8.equals("Week 7, 2019"));
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        long long6 = week3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
//        int int9 = week3.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date10 = week3.getStart();
//        int int11 = week2.compareTo((java.lang.Object) date10);
//        long long12 = week2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59009443200000L) + "'", long12 == (-59009443200000L));
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        int int4 = week2.compareTo((java.lang.Object) 6L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str13 = week12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException17.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
        int int23 = week12.compareTo((java.lang.Object) class20);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = regularTimePeriod25.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        java.util.Date date34 = week32.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date26, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date5, timeZone36);
        java.lang.Class class41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date45 = week44.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date45, timeZone46);
        java.util.Locale locale48 = null;
        try {
            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date5, timeZone46, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 7, 0" + "'", str13.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        java.lang.String str7 = week2.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week2.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 5" + "'", str7.equals("Week 24, 5"));
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        java.util.Calendar calendar5 = null;
        try {
            week4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int2 = week0.getYearValue();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.Year year4 = week0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        long long6 = week5.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063599999L + "'", long6 == 1560063599999L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = regularTimePeriod6.getStart();
//        int int8 = week0.compareTo((java.lang.Object) regularTimePeriod6);
//        java.lang.String str9 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        long long6 = week3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
//        int int9 = week3.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date10 = week3.getStart();
//        int int11 = week2.compareTo((java.lang.Object) date10);
//        int int12 = week2.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104507200001L) + "'", long3 == (-62104507200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800001L) + "'", long4 == (-62104204800001L));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str6 = week5.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        int int16 = week5.compareTo((java.lang.Object) class13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        java.util.Date date19 = regularTimePeriod18.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date24 = week23.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
//        java.util.Date date27 = week25.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date27, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date24, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date19, timeZone29);
//        java.util.Locale locale33 = null;
//        try {
//            org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date2, timeZone29, locale33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 0" + "'", str6.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getFirstMillisecond();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 25, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        org.jfree.data.time.Year year3 = week0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        java.util.Date date7 = week5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        boolean boolean10 = week2.equals((java.lang.Object) regularTimePeriod9);
        java.lang.Class<?> wildcardClass11 = week2.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.Object obj7 = null;
//        boolean boolean8 = week0.equals(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        int int4 = week0.compareTo((java.lang.Object) "Week 24, 2019");
//        java.lang.String str5 = week0.toString();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year6);
//        int int9 = week7.compareTo((java.lang.Object) 100.0d);
//        long long10 = week7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1547971200000L + "'", long10 == 1547971200000L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            week4.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        int int4 = week0.compareTo((java.lang.Object) 7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException8);
        java.lang.String str12 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getFirstMillisecond();
//        long long5 = week3.getMiddleMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week3.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.String str7 = week0.toString();
//        long long8 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        java.util.Calendar calendar6 = null;
//        try {
//            week4.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(year5);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            week4.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 7, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getWeek();
//        java.util.Date date4 = week0.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        java.util.Locale locale16 = null;
//        try {
//            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date4, timeZone13, locale16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date15 = week14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        java.util.Locale locale18 = null;
        try {
            org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date4, timeZone16, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        long long6 = week3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
//        int int9 = week3.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date10 = week3.getStart();
//        int int11 = week2.compareTo((java.lang.Object) date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getSerialIndex();
//        boolean boolean12 = week4.equals((java.lang.Object) long11);
//        boolean boolean13 = week0.equals((java.lang.Object) boolean12);
//        int int14 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        int int13 = week2.compareTo((java.lang.Object) class10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = week22.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.util.Date date32 = week30.getEnd();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getWeek();
        int int5 = week2.getYearValue();
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 7, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getSerialIndex();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        boolean boolean10 = week6.equals((java.lang.Object) year9);
//        java.util.Date date11 = week6.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.lang.Class class13 = null;
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        java.util.Date date17 = week15.getEnd();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str26 = week25.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException30.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        int int36 = week25.compareTo((java.lang.Object) class33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = regularTimePeriod38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date18, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date11, timeZone49);
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 7, 0" + "'", str26.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(class55);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        int int13 = week0.compareTo((java.lang.Object) regularTimePeriod12);
//        int int14 = week0.getYearValue();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week0.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        int int13 = week0.compareTo((java.lang.Object) regularTimePeriod12);
//        int int14 = week0.getYearValue();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week0.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62164080000000L) + "'", long3 == (-62164080000000L));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week4.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164382400001L) + "'", long4 == (-62164382400001L));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) "hi!");
//        int int7 = week3.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        int int14 = week10.compareTo((java.lang.Object) wildcardClass13);
//        boolean boolean15 = week3.equals((java.lang.Object) wildcardClass13);
//        long long16 = week3.getMiddleMillisecond();
//        java.util.Date date17 = week3.getStart();
//        boolean boolean18 = week0.equals((java.lang.Object) week3);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(class4);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        long long7 = week2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61995945600000L) + "'", long7 == (-61995945600000L));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date2, timeZone4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date2, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        int int4 = week0.compareTo((java.lang.Object) "Week 24, 2019");
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getWeek();
//        java.util.Date date4 = week0.getStart();
//        java.lang.Class<?> wildcardClass5 = date4.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        int int3 = week1.compareTo((java.lang.Object) "hi!");
        java.lang.Class<?> wildcardClass4 = week1.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = null;
        java.lang.Class class7 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        java.util.Date date10 = week8.getEnd();
        java.util.Date date11 = week8.getEnd();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date11, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
        java.util.Date date18 = week16.getEnd();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date18, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone20);
        java.util.Locale locale23 = null;
        try {
            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date0, timeZone20, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        long long5 = week4.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107014L + "'", long5 == 107014L);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.lang.String str16 = week15.toString();
//        java.lang.Class<?> wildcardClass17 = week15.getClass();
//        java.util.Date date18 = week15.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.util.Date date29 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        java.lang.String str31 = week30.toString();
//        java.lang.Class<?> wildcardClass32 = week30.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        org.jfree.data.time.Year year39 = week37.getYear();
//        boolean boolean40 = week36.equals((java.lang.Object) year39);
//        java.util.Date date41 = week36.getEnd();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
//        java.lang.Class class43 = null;
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        java.util.Date date48 = week45.getEnd();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone49);
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date48, timeZone51);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str56 = week55.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException58.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
//        java.lang.Class<?> wildcardClass62 = timePeriodFormatException60.getClass();
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass62);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize(class63);
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize(class63);
//        int int66 = week55.compareTo((java.lang.Object) class63);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
//        java.util.Date date69 = regularTimePeriod68.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date74 = week73.getStart();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.next();
//        java.util.Date date77 = week75.getEnd();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date77);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date77, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date74, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date69, timeZone79);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date48, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date41, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date18, timeZone79);
//        java.util.Locale locale87 = null;
//        try {
//            org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date7, timeZone79, locale87);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 7, 0" + "'", str56.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        java.util.Date date5 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        boolean boolean10 = week6.equals((java.lang.Object) year9);
//        java.util.Date date11 = week6.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.lang.Class class13 = null;
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        java.util.Date date17 = week15.getEnd();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str26 = week25.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException30.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        int int36 = week25.compareTo((java.lang.Object) class33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = regularTimePeriod38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date18, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale57 = null;
//        try {
//            org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date11, timeZone56, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 7, 0" + "'", str26.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(timeZone56);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(0, (int) (short) 100);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        org.jfree.data.time.Year year6 = week4.getYear();
        boolean boolean7 = week3.equals((java.lang.Object) year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        long long5 = week4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1550390399999L + "'", long5 == 1550390399999L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        java.util.Date date3 = week0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        java.util.Date date7 = week5.getEnd();
        java.util.Date date8 = week5.getEnd();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date8, timeZone9);
        java.lang.Class class11 = null;
        java.lang.Class class12 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.util.Date date16 = week13.getEnd();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str24 = week23.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Class<?> wildcardClass30 = timePeriodFormatException28.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize(class31);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class31);
        int int34 = week23.compareTo((java.lang.Object) class31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
        java.util.Date date37 = regularTimePeriod36.getEnd();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date42 = week41.getStart();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
        java.util.Date date45 = week43.getEnd();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date45, timeZone47);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date42, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date37, timeZone47);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date16, timeZone47);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date8, timeZone47);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date3, timeZone47);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week 7, 0" + "'", str24.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.String str6 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date8 = week7.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.util.Date date11 = week9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone13);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week16.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        java.util.Date date9 = regularTimePeriod7.getStart();
//        java.util.Date date10 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        boolean boolean12 = week0.equals((java.lang.Object) week11);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559761199999L + "'", long8 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getFirstMillisecond();
//        long long5 = week3.getMiddleMillisecond();
//        java.lang.String str6 = week3.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date4, timeZone13);
//        long long17 = week16.getLastMillisecond();
//        long long18 = week16.getLastMillisecond();
//        java.lang.String str19 = week16.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063599999L + "'", long17 == 1560063599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063599999L + "'", long18 == 1560063599999L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 23, 2019" + "'", str19.equals("Week 23, 2019"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
        java.lang.String str13 = timePeriodFormatException5.toString();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException17.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.String str23 = timePeriodFormatException17.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        int int13 = week2.compareTo((java.lang.Object) class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        long long32 = week30.getSerialIndex();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        int int35 = week33.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week33.previous();
//        long long37 = regularTimePeriod36.getMiddleMillisecond();
//        java.util.Date date38 = regularTimePeriod36.getStart();
//        java.util.Date date39 = regularTimePeriod36.getStart();
//        int int40 = week30.compareTo((java.lang.Object) regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107032L + "'", long32 == 107032L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559761199999L + "'", long37 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date4, timeZone13);
//        long long17 = week16.getLastMillisecond();
//        long long18 = week16.getLastMillisecond();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week16.getMiddleMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063599999L + "'", long17 == 1560063599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560063599999L + "'", long18 == 1560063599999L);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        java.lang.String str13 = week0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test179");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getSerialIndex();
//        boolean boolean12 = week4.equals((java.lang.Object) long11);
//        boolean boolean13 = week0.equals((java.lang.Object) boolean12);
//        long long14 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        int int5 = week2.compareTo((java.lang.Object) '4');
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        long long8 = week4.getSerialIndex();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week4.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107014L + "'", long8 == 107014L);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = regularTimePeriod4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62103902400001L) + "'", long5 == (-62103902400001L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable throwable8 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        java.util.Date date5 = regularTimePeriod3.getStart();
//        java.util.Date date6 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        java.util.Date date9 = week7.getEnd();
//        java.util.Date date10 = week7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        java.util.Date date14 = week12.getEnd();
//        java.util.Date date15 = week12.getEnd();
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone16);
//        java.lang.Class class18 = null;
//        java.lang.Class class19 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        java.util.Date date22 = week20.getEnd();
//        java.util.Date date23 = week20.getEnd();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone24);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str31 = week30.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
//        java.lang.Class<?> wildcardClass37 = timePeriodFormatException35.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
//        int int41 = week30.compareTo((java.lang.Object) class38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
//        java.util.Date date44 = regularTimePeriod43.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date49 = week48.getStart();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.next();
//        java.util.Date date52 = week50.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date52, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date49, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date44, timeZone54);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date23, timeZone54);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date15, timeZone54);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date10, timeZone54);
//        java.util.Locale locale61 = null;
//        try {
//            org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date6, timeZone54, locale61);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 7, 0" + "'", str31.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = regularTimePeriod8.getMiddleMillisecond();
//        java.util.Date date10 = regularTimePeriod8.getStart();
//        boolean boolean11 = week0.equals((java.lang.Object) date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        long long15 = week12.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.previous();
//        int int17 = week0.compareTo((java.lang.Object) week12);
//        long long18 = week12.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559761199999L + "'", long9 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
//        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        long long13 = week0.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str4 = week3.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException8.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        int int14 = week3.compareTo((java.lang.Object) class11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        java.util.Date date17 = regularTimePeriod16.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date22 = week21.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
//        java.util.Date date25 = week23.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date25, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date22, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date17, timeZone27);
//        java.util.Date date31 = regularTimePeriod30.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.lang.String str36 = week35.toString();
//        java.lang.Class<?> wildcardClass37 = week35.getClass();
//        int int38 = week34.compareTo((java.lang.Object) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int42 = week40.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week40.previous();
//        java.util.Date date44 = week40.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        java.lang.Class<?> wildcardClass46 = date44.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
//        java.lang.Class<?> wildcardClass52 = timePeriodFormatException50.getClass();
//        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize(class53);
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize(class53);
//        java.util.Date date56 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.next();
//        java.util.Date date59 = week57.getEnd();
//        long long60 = week57.getFirstMillisecond();
//        org.jfree.data.time.Year year61 = week57.getYear();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        int int64 = week62.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = week62.previous();
//        long long66 = regularTimePeriod65.getMiddleMillisecond();
//        java.util.Date date67 = regularTimePeriod65.getStart();
//        boolean boolean68 = week57.equals((java.lang.Object) date67);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date72 = week71.getStart();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week73.next();
//        java.util.Date date75 = week73.getEnd();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date75);
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date75, timeZone77);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date72, timeZone77);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date67, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date56, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date44, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date31, timeZone77);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 7, 0" + "'", str4.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertNotNull(class54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560063600000L + "'", long60 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1559761199999L + "'", long66 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
//        boolean boolean8 = week0.equals((java.lang.Object) week7);
//        java.util.Calendar calendar9 = null;
//        try {
//            week7.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        long long2 = week0.getFirstMillisecond();
//        java.lang.String str3 = week0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.util.TimeZone timeZone6 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.util.Date date21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.lang.String str23 = week22.toString();
//        java.lang.Class<?> wildcardClass24 = week22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        org.jfree.data.time.Year year31 = week29.getYear();
//        boolean boolean32 = week28.equals((java.lang.Object) year31);
//        java.util.Date date33 = week28.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.lang.Class class35 = null;
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = week37.getEnd();
//        java.util.Date date40 = week37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date40, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str48 = week47.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
//        java.lang.Class<?> wildcardClass54 = timePeriodFormatException52.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        int int58 = week47.compareTo((java.lang.Object) class55);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
//        java.util.Date date61 = regularTimePeriod60.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date66 = week65.getStart();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
//        java.util.Date date69 = week67.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date69, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date66, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date40, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone71);
//        java.util.Locale locale78 = null;
//        try {
//            org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date5, timeZone71, locale78);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 7, 0" + "'", str48.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) -1, year3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        java.lang.String str7 = week2.toString();
//        int int8 = week2.getWeek();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 5" + "'", str7.equals("Week 24, 5"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62075779200001L) + "'", long4 == (-62075779200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.lang.Class<?> wildcardClass6 = date4.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.util.Date date10 = week7.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
        java.util.Date date20 = null;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date24 = week23.getStart();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.util.Date date27 = week25.getEnd();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date27, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date24, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date10, timeZone29);
        java.util.Locale locale34 = null;
        try {
            org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date4, timeZone29, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1549483199999L + "'", long8 == 1549483199999L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        int int13 = week2.compareTo((java.lang.Object) class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        long long32 = week30.getSerialIndex();
//        long long33 = week30.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107032L + "'", long32 == 107032L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 107032L + "'", long33 == 107032L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        long long4 = week1.getSerialIndex();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date8 = week7.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        boolean boolean10 = week1.equals((java.lang.Object) regularTimePeriod9);
//        long long11 = week1.getLastMillisecond();
//        int int12 = week1.getWeek();
//        org.jfree.data.time.Year year13 = week1.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(7, year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 100, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        int int6 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
//        int int6 = week0.compareTo((java.lang.Object) timePeriodFormatException5);
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(throwableArray7);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 24, 5");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        int int13 = week0.compareTo((java.lang.Object) regularTimePeriod12);
//        int int14 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.previous();
//        long long16 = week0.getFirstMillisecond();
//        java.lang.String str17 = week0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException9.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.Throwable[] throwableArray16 = timePeriodFormatException9.getSuppressed();
//        boolean boolean17 = week0.equals((java.lang.Object) timePeriodFormatException9);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week0.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(throwableArray16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getMiddleMillisecond();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = week8.getEnd();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        java.util.Date date33 = week31.getEnd();
//        long long34 = week31.getFirstMillisecond();
//        org.jfree.data.time.Year year35 = week31.getYear();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        int int38 = week36.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.previous();
//        long long40 = regularTimePeriod39.getMiddleMillisecond();
//        java.util.Date date41 = regularTimePeriod39.getStart();
//        boolean boolean42 = week31.equals((java.lang.Object) date41);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date46 = week45.getStart();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
//        java.util.Date date49 = week47.getEnd();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date49, timeZone51);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date46, timeZone51);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date41, timeZone51);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
//        java.util.Date date57 = week55.getEnd();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date57, timeZone59);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date41, timeZone59);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date21, timeZone59);
//        java.util.Locale locale63 = null;
//        try {
//            org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date11, timeZone59, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1559761199999L + "'", long40 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone59);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date4 = week3.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
//        java.util.Date date16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        java.util.Date date19 = week17.getEnd();
//        long long20 = week17.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = week17.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int24 = week22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week22.previous();
//        long long26 = regularTimePeriod25.getMiddleMillisecond();
//        java.util.Date date27 = regularTimePeriod25.getStart();
//        boolean boolean28 = week17.equals((java.lang.Object) date27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date32 = week31.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        java.util.Date date35 = week33.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date32, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date16, timeZone37);
//        java.util.Locale locale42 = null;
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date4, timeZone37, locale42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559761199999L + "'", long26 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(4, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(11, year9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) 'a', year9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 1, year9);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException26.getSuppressed();
        java.lang.String str28 = timePeriodFormatException26.toString();
        java.lang.String str29 = timePeriodFormatException26.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.String str31 = timePeriodFormatException26.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getYearValue();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        long long8 = week5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        int int11 = week5.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date12 = week5.getStart();
//        int int13 = week4.compareTo((java.lang.Object) week5);
//        long long14 = week4.getFirstMillisecond();
//        int int15 = week4.getYearValue();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-17) + "'", int13 == (-17));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549785600000L + "'", long14 == 1549785600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        int int13 = week0.compareTo((java.lang.Object) regularTimePeriod12);
//        long long14 = week0.getMiddleMillisecond();
//        int int15 = week0.getWeek();
//        long long16 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date7 = week6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        java.util.Date date10 = week8.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone12);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        java.util.Date date19 = week17.getEnd();
//        long long20 = week17.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = week17.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int24 = week22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week22.previous();
//        long long26 = regularTimePeriod25.getMiddleMillisecond();
//        java.util.Date date27 = regularTimePeriod25.getStart();
//        boolean boolean28 = week17.equals((java.lang.Object) date27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date32 = week31.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        java.util.Date date35 = week33.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date32, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27, timeZone37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = week41.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date43, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date27, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date7, timeZone45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559761199999L + "'", long26 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        long long5 = week4.getLastMillisecond();
//        int int6 = week0.compareTo((java.lang.Object) long5);
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62075779200001L) + "'", long5 == (-62075779200001L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 5, 100" + "'", str3.equals("Week 5, 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 5);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str10 = week9.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        int int20 = week9.compareTo((java.lang.Object) class17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        java.util.Date date23 = regularTimePeriod22.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        java.util.Date date31 = week29.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date28, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone33);
//        java.lang.Class class37 = null;
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        java.util.Date date41 = week39.getEnd();
//        java.util.Date date42 = week39.getEnd();
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date42, timeZone43);
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date42, timeZone45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str50 = week49.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException52.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException54.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize(class57);
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize(class57);
//        int int60 = week49.compareTo((java.lang.Object) class57);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
//        java.util.Date date63 = regularTimePeriod62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date68 = week67.getStart();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.next();
//        java.util.Date date71 = week69.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date71, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date68, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date63, timeZone73);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date42, timeZone73);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException79 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException81 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException79.addSuppressed((java.lang.Throwable) timePeriodFormatException81);
//        java.lang.Class<?> wildcardClass83 = timePeriodFormatException81.getClass();
//        java.lang.Class class84 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass83);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date88 = week87.getStart();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass83, date88, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date42, timeZone89);
//        int int92 = week0.compareTo((java.lang.Object) regularTimePeriod91);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 7, 0" + "'", str10.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 7, 0" + "'", str50.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(wildcardClass83);
//        org.junit.Assert.assertNotNull(class84);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62164080000000L) + "'", long3 == (-62164080000000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62164080000000L) + "'", long4 == (-62164080000000L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getWeek();
        int int5 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Date date5 = week3.getEnd();
//        java.util.Date date6 = week3.getEnd();
//        long long7 = week3.getLastMillisecond();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2019) + "'", int8 == (-2019));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 53);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60480316800001L) + "'", long3 == (-60480316800001L));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        long long6 = week3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
//        int int9 = week3.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date10 = week3.getStart();
//        int int11 = week2.compareTo((java.lang.Object) date10);
//        long long12 = week2.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5305L + "'", long12 == 5305L);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.String str6 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 5, 100");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 5" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 5"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
//        java.util.Date date12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        java.util.Date date15 = week13.getEnd();
//        long long16 = week13.getFirstMillisecond();
//        org.jfree.data.time.Year year17 = week13.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        int int20 = week18.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        boolean boolean24 = week13.equals((java.lang.Object) date23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        java.util.Date date31 = week29.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date28, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date23, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone33);
//        java.util.Locale locale38 = null;
//        try {
//            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date2, timeZone33, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559761199999L + "'", long22 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 2019);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date8 = week7.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.util.Date date11 = week9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date4, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        long long3 = week2.getLastMillisecond();
        int int5 = week2.compareTo((java.lang.Object) 100.0f);
        long long6 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.lang.Class<?> wildcardClass3 = week1.getClass();
//        java.util.Date date4 = week1.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str8 = week7.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
//        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        int int18 = week7.compareTo((java.lang.Object) class15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        java.util.Date date21 = regularTimePeriod20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date26 = week25.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        java.util.Date date29 = week27.getEnd();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date29, timeZone31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date26, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone31);
//        java.lang.Class class35 = null;
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = week37.getEnd();
//        java.util.Date date40 = week37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date40, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str48 = week47.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
//        java.lang.Class<?> wildcardClass54 = timePeriodFormatException52.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        int int58 = week47.compareTo((java.lang.Object) class55);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
//        java.util.Date date61 = regularTimePeriod60.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date66 = week65.getStart();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
//        java.util.Date date69 = week67.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date69, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date66, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date40, timeZone71);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException77 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException79 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException77.addSuppressed((java.lang.Throwable) timePeriodFormatException79);
//        java.lang.Class<?> wildcardClass81 = timePeriodFormatException79.getClass();
//        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass81);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date86 = week85.getStart();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date40, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone87);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 7, 0" + "'", str8.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 7, 0" + "'", str48.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(wildcardClass81);
//        org.junit.Assert.assertNotNull(class82);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (byte) 10);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        java.util.Date date4 = week0.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        int int3 = week1.getYearValue();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        java.util.Date date20 = week18.getEnd();
//        long long21 = week18.getFirstMillisecond();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int25 = week23.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.previous();
//        long long27 = regularTimePeriod26.getMiddleMillisecond();
//        java.util.Date date28 = regularTimePeriod26.getStart();
//        boolean boolean29 = week18.equals((java.lang.Object) date28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date33 = week32.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
//        java.util.Date date36 = week34.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date36, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date33, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date28, timeZone38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
//        java.util.Date date44 = week42.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date28, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date8, timeZone46);
//        java.util.Locale locale50 = null;
//        try {
//            org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date0, timeZone46, locale50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559761199999L + "'", long27 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone46);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        long long10 = week0.getLastMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week0.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        java.util.Date date7 = regularTimePeriod6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int10 = week8.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
//        java.util.Date date12 = regularTimePeriod11.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date16 = week15.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        java.util.Date date19 = week17.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date19, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date16, timeZone21);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date12, timeZone21);
//        java.util.Locale locale25 = null;
//        try {
//            org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date7, timeZone21, locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone21);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        int int13 = week2.compareTo((java.lang.Object) class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        long long32 = week30.getSerialIndex();
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = week30.getLastMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107032L + "'", long32 == 107032L);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        long long8 = regularTimePeriod7.getMiddleMillisecond();
//        java.util.Date date9 = regularTimePeriod7.getStart();
//        java.util.Date date10 = regularTimePeriod7.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        boolean boolean12 = week0.equals((java.lang.Object) week11);
//        int int13 = week11.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559761199999L + "'", long8 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getFirstMillisecond();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62164080000000L) + "'", long6 == (-62164080000000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(8, year4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.String str7 = week0.toString();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        long long8 = week5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        int int11 = week5.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date12 = week5.getStart();
//        int int13 = week4.compareTo((java.lang.Object) week5);
//        long long14 = week4.getFirstMillisecond();
//        int int15 = week4.getWeek();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-17) + "'", int13 == (-17));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1549785600000L + "'", long14 == 1549785600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        int int4 = week0.compareTo((java.lang.Object) "Week 24, 2019");
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(4, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(2019, year7);
//        long long10 = week9.getSerialIndex();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week9.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 106978L + "'", long10 == 106978L);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.util.Date date6 = week4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone8);
        long long11 = week10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61995643200001L) + "'", long11 == (-61995643200001L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 3);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getSerialIndex();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        org.jfree.data.time.Year year8 = week6.getYear();
//        long long9 = week6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
//        int int12 = week6.compareTo((java.lang.Object) 1.0d);
//        int int13 = week6.getYearValue();
//        java.util.Date date14 = week6.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.lang.String str16 = week15.toString();
//        java.lang.Class<?> wildcardClass17 = week15.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.util.Date date19 = null;
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.lang.String str23 = week22.toString();
//        java.lang.Class<?> wildcardClass24 = week22.getClass();
//        java.util.Date date25 = week22.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        java.lang.Class<?> wildcardClass31 = timePeriodFormatException29.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
//        java.util.Date date36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.lang.String str38 = week37.toString();
//        java.lang.Class<?> wildcardClass39 = week37.getClass();
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
//        org.jfree.data.time.Year year46 = week44.getYear();
//        boolean boolean47 = week43.equals((java.lang.Object) year46);
//        java.util.Date date48 = week43.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        java.lang.Class class50 = null;
//        java.lang.Class class51 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
//        java.util.Date date54 = week52.getEnd();
//        java.util.Date date55 = week52.getEnd();
//        java.util.TimeZone timeZone56 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date55, timeZone56);
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date55, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str63 = week62.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException67 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException65.addSuppressed((java.lang.Throwable) timePeriodFormatException67);
//        java.lang.Class<?> wildcardClass69 = timePeriodFormatException67.getClass();
//        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
//        java.lang.Class class71 = org.jfree.data.time.RegularTimePeriod.downsize(class70);
//        java.lang.Class class72 = org.jfree.data.time.RegularTimePeriod.downsize(class70);
//        int int73 = week62.compareTo((java.lang.Object) class70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.next();
//        java.util.Date date76 = regularTimePeriod75.getEnd();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date81 = week80.getStart();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = week82.next();
//        java.util.Date date84 = week82.getEnd();
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date84);
//        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date84, timeZone86);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date81, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date76, timeZone86);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date55, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date48, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date36, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date25, timeZone86);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone86);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Week 7, 0" + "'", str63.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(class70);
//        org.junit.Assert.assertNotNull(class71);
//        org.junit.Assert.assertNotNull(class72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone86);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.util.Date date13 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date17 = week16.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        java.util.Date date20 = week18.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date17, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date3, timeZone22);
//        int int27 = week26.getWeek();
//        long long28 = week26.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560063600000L + "'", long28 == 1560063600000L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getMiddleMillisecond();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        java.util.Date date11 = week8.getEnd();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        int int17 = week15.getYearValue();
//        int int18 = week15.getWeek();
//        java.util.Date date19 = week15.getStart();
//        java.lang.Class<?> wildcardClass20 = date19.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        java.lang.Class class31 = null;
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        java.util.Date date35 = week33.getEnd();
//        java.util.Date date36 = week33.getEnd();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date36, timeZone37);
//        java.util.TimeZone timeZone39 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date36, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date36);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date45 = week44.getStart();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
//        java.util.Date date48 = week46.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date48, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date45, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date36, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone50);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.String str15 = timePeriodFormatException13.toString();
        java.lang.String str16 = timePeriodFormatException13.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.String str24 = timePeriodFormatException23.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str27 = timePeriodFormatException13.toString();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 5" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 5"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(4, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(11, year7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        int int11 = week9.getYearValue();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 1");
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.String str7 = week0.toString();
//        int int8 = week0.getWeek();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getMiddleMillisecond();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int23 = week21.compareTo((java.lang.Object) "hi!");
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        java.util.Date date26 = null;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.lang.String str28 = week27.toString();
//        java.util.Date date29 = week27.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException33.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        java.util.Date date37 = null;
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
//        int int40 = week27.compareTo((java.lang.Object) regularTimePeriod39);
//        long long41 = week27.getMiddleMillisecond();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date45 = week44.getStart();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
//        java.util.Date date48 = week46.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date48, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date45, timeZone50);
//        boolean boolean53 = week27.equals((java.lang.Object) timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date18, timeZone50);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560365999999L + "'", long41 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getSerialIndex();
//        java.lang.String str4 = week2.toString();
//        boolean boolean5 = week0.equals((java.lang.Object) str4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.String str15 = timePeriodFormatException13.toString();
        java.lang.String str16 = timePeriodFormatException13.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException19.getSuppressed();
        java.lang.String str21 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.String str24 = timePeriodFormatException23.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException13.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 5" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 5"));
        org.junit.Assert.assertNotNull(throwableArray27);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        int int10 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 25, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 25, 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 25, 2019"));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        int int5 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.String str7 = week0.toString();
//        int int9 = week0.compareTo((java.lang.Object) 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getYearValue();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        int int2 = week0.getWeek();
//        java.lang.String str3 = week0.toString();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(2019, year7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        long long13 = week0.getMiddleMillisecond();
//        int int14 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        boolean boolean10 = week6.equals((java.lang.Object) year9);
//        java.util.Date date11 = week6.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.lang.Class class13 = null;
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        java.util.Date date17 = week15.getEnd();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str26 = week25.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException30.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        int int36 = week25.compareTo((java.lang.Object) class33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = regularTimePeriod38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date18, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        java.util.Date date56 = week55.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 7, 0" + "'", str26.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        int int4 = week3.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getFirstMillisecond();
//        long long5 = week3.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 5, 100");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        long long8 = week4.getSerialIndex();
//        org.jfree.data.time.Year year9 = week4.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107014L + "'", long8 == 107014L);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        long long7 = week2.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 289L + "'", long7 == 289L);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        long long10 = week0.getLastMillisecond();
//        int int11 = week0.getWeek();
//        java.util.Date date12 = week0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 1, year5);
//        long long9 = week8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107008L + "'", long9 == 107008L);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = regularTimePeriod1.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107032L + "'", long4 == 107032L);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 7, 0");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(4, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 1, year7);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week9.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        java.lang.String str5 = week0.toString();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.Year year2 = week0.getYear();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str11 = week10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
        int int21 = week10.compareTo((java.lang.Object) class18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = regularTimePeriod23.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date29 = week28.getStart();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = week30.getEnd();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date32, timeZone34);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date29, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date24, timeZone34);
        java.lang.Class class38 = null;
        java.lang.Class class39 = null;
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
        java.util.Date date42 = week40.getEnd();
        java.util.Date date43 = week40.getEnd();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone44);
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone46);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str51 = week50.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        java.lang.Class<?> wildcardClass57 = timePeriodFormatException55.getClass();
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize(class58);
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class58);
        int int61 = week50.compareTo((java.lang.Object) class58);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.next();
        java.util.Date date64 = regularTimePeriod63.getEnd();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date64);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date69 = week68.getStart();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = week70.next();
        java.util.Date date72 = week70.getEnd();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date72);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date72, timeZone74);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date69, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date64, timeZone74);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date43, timeZone74);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException80 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException82 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException80.addSuppressed((java.lang.Throwable) timePeriodFormatException82);
        java.lang.Class<?> wildcardClass84 = timePeriodFormatException82.getClass();
        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass84);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date89 = week88.getStart();
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass84, date89, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date43, timeZone90);
        java.util.Locale locale93 = null;
        try {
            org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date7, timeZone90, locale93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 7, 0" + "'", str11.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 7, 0" + "'", str51.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.util.TimeZone timeZone6 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5);
//        long long11 = week10.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        long long13 = week0.getMiddleMillisecond();
//        long long14 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week0.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = week0.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
//        long long5 = week2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.util.Date date13 = regularTimePeriod10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week2.equals((java.lang.Object) date13);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559761199999L + "'", long11 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-17), year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = regularTimePeriod8.getMiddleMillisecond();
//        java.util.Date date10 = regularTimePeriod8.getStart();
//        boolean boolean11 = week0.equals((java.lang.Object) date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        long long15 = week12.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.previous();
//        int int17 = week0.compareTo((java.lang.Object) week12);
//        java.lang.Class<?> wildcardClass18 = week12.getClass();
//        long long19 = week12.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559761199999L + "'", long9 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((-17), year7);
//        java.util.Date date9 = year7.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        java.lang.String str17 = timePeriodFormatException15.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.String str20 = timePeriodFormatException19.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 5" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 5"));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(1, year3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year3.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = regularTimePeriod8.getMiddleMillisecond();
//        java.util.Date date10 = regularTimePeriod8.getStart();
//        boolean boolean11 = week0.equals((java.lang.Object) date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        int int14 = week12.getYearValue();
//        boolean boolean15 = week0.equals((java.lang.Object) int14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week0.previous();
//        org.jfree.data.time.Year year17 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559761199999L + "'", long9 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year17);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException17.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.String str23 = timePeriodFormatException17.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 100, 1" + "'", str7.equals("Week 100, 1"));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week3.equals((java.lang.Object) long10);
//        int int12 = week0.compareTo((java.lang.Object) week3);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week3.equals((java.lang.Object) long10);
//        int int12 = week0.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week3.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getSerialIndex();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
//        long long4 = week3.getFirstMillisecond();
//        int int5 = week3.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getSerialIndex();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 7, 0" + "'", str7.equals("Week 7, 0"));
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getMiddleMillisecond();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(4, year11);
//        int int14 = week12.compareTo((java.lang.Object) 100.0d);
//        boolean boolean15 = week0.equals((java.lang.Object) int14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week0.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException20.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        java.lang.Class<?> wildcardClass26 = timePeriodFormatException20.getClass();
//        boolean boolean27 = week0.equals((java.lang.Object) wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class14 = null;
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        java.util.Date date18 = week16.getEnd();
//        java.util.Date date19 = week16.getEnd();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date19, timeZone20);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone22);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date19);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        java.util.Date date31 = week29.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date28, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date19, timeZone33);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException44);
//        java.lang.Class<?> wildcardClass46 = timePeriodFormatException44.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date51 = week50.getStart();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date51, timeZone52);
//        int int54 = week39.compareTo((java.lang.Object) timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date19, timeZone52);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.next();
//        org.jfree.data.time.Year year58 = week56.getYear();
//        long long59 = week56.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week56.next();
//        java.util.Date date61 = week56.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        java.util.TimeZone timeZone63 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date61, timeZone63);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 107031L + "'", long59 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        long long11 = week8.getSerialIndex();
//        boolean boolean12 = week4.equals((java.lang.Object) long11);
//        boolean boolean13 = week0.equals((java.lang.Object) boolean12);
//        java.lang.String str14 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException5.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str21 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException25.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException34.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.String str42 = timePeriodFormatException29.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date10 = week9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.util.Date date8 = week6.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
        java.lang.Class<?> wildcardClass12 = week11.getClass();
        boolean boolean13 = week2.equals((java.lang.Object) wildcardClass12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        java.util.Date date3 = week2.getEnd();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62075779200001L) + "'", long4 == (-62075779200001L));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        int int3 = week1.getYearValue();
//        java.lang.Class<?> wildcardClass4 = week1.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone16);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        java.util.Date date20 = week18.getEnd();
//        long long21 = week18.getFirstMillisecond();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int25 = week23.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.previous();
//        long long27 = regularTimePeriod26.getMiddleMillisecond();
//        java.util.Date date28 = regularTimePeriod26.getStart();
//        boolean boolean29 = week18.equals((java.lang.Object) date28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date33 = week32.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
//        java.util.Date date36 = week34.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date36, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date33, timeZone38);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date28, timeZone38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
//        java.util.Date date44 = week42.getEnd();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date44, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date28, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559761199999L + "'", long27 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        int int5 = week0.getYearValue();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int5 = week3.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week3.equals((java.lang.Object) long10);
//        int int12 = week0.compareTo((java.lang.Object) week3);
//        long long13 = week3.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int6 = week0.compareTo((java.lang.Object) 1.0d);
//        java.lang.String str7 = week0.toString();
//        int int8 = week0.getWeek();
//        long long9 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getEnd();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.util.Date date6 = week4.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone8);
        long long11 = week10.getSerialIndex();
        long long12 = week10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 289L + "'", long11 == 289L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61995643200001L) + "'", long12 == (-61995643200001L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 1);
        int int3 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 153L + "'", long5 == 153L);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        org.jfree.data.time.Year year13 = week11.getYear();
//        boolean boolean14 = week10.equals((java.lang.Object) year13);
//        java.util.Date date15 = week10.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.lang.Class class17 = null;
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        java.util.Date date21 = week19.getEnd();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str30 = week29.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException34.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
//        int int40 = week29.compareTo((java.lang.Object) class37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = regularTimePeriod42.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date48 = week47.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        java.util.Date date51 = week49.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date51, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date48, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone53);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date22, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date15, timeZone53);
//        java.util.Locale locale59 = null;
//        try {
//            org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date3, timeZone53, locale59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 7, 0" + "'", str30.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        java.lang.String str5 = week4.toString();
//        java.lang.String str6 = week4.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week4.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 7, 2019" + "'", str5.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 7, 2019" + "'", str6.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        int int6 = week2.compareTo((java.lang.Object) wildcardClass5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date10 = week9.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
//        long long12 = week9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.next();
//        java.util.Date date14 = week9.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.lang.String str16 = week15.toString();
//        java.lang.Class<?> wildcardClass17 = week15.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class29 = null;
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        java.util.Date date33 = week31.getEnd();
//        java.util.Date date34 = week31.getEnd();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date34, timeZone35);
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date43 = week42.getStart();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
//        java.util.Date date46 = week44.getEnd();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date46, timeZone48);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date43, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date34, timeZone48);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException59);
//        java.lang.Class<?> wildcardClass61 = timePeriodFormatException59.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date66 = week65.getStart();
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date66, timeZone67);
//        int int69 = week54.compareTo((java.lang.Object) timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date34, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone67);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 153L + "'", long12 == 153L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getLastMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        java.lang.String str6 = week0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 2019);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        int int5 = week0.compareTo((java.lang.Object) 10L);
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
        java.lang.String str3 = week2.toString();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 5, 100" + "'", str3.equals("Week 5, 100"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(7, year3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        long long8 = week5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week5.next();
//        int int11 = week5.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date12 = week5.getStart();
//        int int13 = week4.compareTo((java.lang.Object) week5);
//        int int14 = week5.getYearValue();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        long long17 = week15.getFirstMillisecond();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        int int20 = week18.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        long long25 = week22.getSerialIndex();
//        boolean boolean26 = week18.equals((java.lang.Object) long25);
//        int int27 = week15.compareTo((java.lang.Object) week18);
//        boolean boolean28 = week5.equals((java.lang.Object) week15);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-17) + "'", int13 == (-17));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 5, 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        long long10 = week0.getLastMillisecond();
//        java.util.Date date11 = week0.getStart();
//        long long12 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        int int13 = week2.compareTo((java.lang.Object) class10);
        long long14 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62164080000000L) + "'", long14 == (-62164080000000L));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2);
        long long3 = week2.getMiddleMillisecond();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104507200001L) + "'", long3 == (-62104507200001L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 0, 2" + "'", str4.equals("Week 0, 2"));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int6 = week4.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.util.Date date8 = week4.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        java.lang.Class<?> wildcardClass10 = date8.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int13 = week11.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.previous();
//        long long15 = regularTimePeriod14.getMiddleMillisecond();
//        java.util.Date date16 = regularTimePeriod14.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException20.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
//        java.util.Date date27 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.lang.String str29 = week28.toString();
//        java.lang.Class<?> wildcardClass30 = week28.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        org.jfree.data.time.Year year37 = week35.getYear();
//        boolean boolean38 = week34.equals((java.lang.Object) year37);
//        java.util.Date date39 = week34.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.lang.Class class41 = null;
//        java.lang.Class class42 = null;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
//        java.util.Date date45 = week43.getEnd();
//        java.util.Date date46 = week43.getEnd();
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date46, timeZone47);
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str54 = week53.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException56.addSuppressed((java.lang.Throwable) timePeriodFormatException58);
//        java.lang.Class<?> wildcardClass60 = timePeriodFormatException58.getClass();
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass60);
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize(class61);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize(class61);
//        int int64 = week53.compareTo((java.lang.Object) class61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week65.next();
//        java.util.Date date67 = regularTimePeriod66.getEnd();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date67);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date72 = week71.getStart();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week73.next();
//        java.util.Date date75 = week73.getEnd();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date75);
//        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date75, timeZone77);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date72, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date67, timeZone77);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date46, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date39, timeZone77);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date27, timeZone77);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date16, timeZone77);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date8, timeZone77);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date3, timeZone77);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559761199999L + "'", long15 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 24, 2019" + "'", str29.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Week 7, 0" + "'", str54.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone77);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        long long13 = week0.getMiddleMillisecond();
//        java.util.Date date14 = week0.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str18 = week17.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        java.lang.Class<?> wildcardClass24 = timePeriodFormatException22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
//        int int28 = week17.compareTo((java.lang.Object) class25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        java.util.Date date31 = regularTimePeriod30.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date36 = week35.getStart();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = week37.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date36, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date31, timeZone41);
//        java.util.Locale locale45 = null;
//        try {
//            org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date14, timeZone41, locale45);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 7, 0" + "'", str18.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone14);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        int int8 = week0.getWeek();
//        int int9 = week0.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 5, 100");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 5, 100" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 5, 100"));
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test364");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = regularTimePeriod8.getMiddleMillisecond();
//        java.util.Date date10 = regularTimePeriod8.getStart();
//        boolean boolean11 = week0.equals((java.lang.Object) date10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date16 = week15.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
//        java.util.Locale locale19 = null;
//        try {
//            org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date10, timeZone17, locale19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559761199999L + "'", long9 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.Class<?> wildcardClass20 = timePeriodFormatException18.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.util.Date date25 = null;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.lang.String str27 = week26.toString();
//        java.lang.Class<?> wildcardClass28 = week26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        org.jfree.data.time.Year year35 = week33.getYear();
//        boolean boolean36 = week32.equals((java.lang.Object) year35);
//        java.util.Date date37 = week32.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        java.lang.Class class39 = null;
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = week41.getEnd();
//        java.util.Date date44 = week41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date44, timeZone45);
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date44, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str52 = week51.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
//        java.lang.Class<?> wildcardClass58 = timePeriodFormatException56.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
//        int int62 = week51.compareTo((java.lang.Object) class59);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        java.util.Date date65 = regularTimePeriod64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date70 = week69.getStart();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        java.util.Date date73 = week71.getEnd();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date73, timeZone75);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date70, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date65, timeZone75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date44, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date37, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date14, timeZone75);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date3, timeZone75);
//        org.jfree.data.time.Year year84 = week83.getYear();
//        java.util.Date date85 = year84.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Week 7, 0" + "'", str52.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(year84);
//        org.junit.Assert.assertNotNull(date85);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        java.util.Date date3 = week0.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.util.Date date13 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date17, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone22);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date3, timeZone22);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str30 = week29.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Class<?> wildcardClass36 = timePeriodFormatException34.getClass();
        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
        int int40 = week29.compareTo((java.lang.Object) class37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = regularTimePeriod42.getEnd();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date48 = week47.getStart();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        java.util.Date date51 = week49.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date51, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date48, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone53);
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
        boolean boolean59 = week26.equals((java.lang.Object) class37);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 7, 0" + "'", str30.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(class37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        long long5 = week0.getMiddleMillisecond();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
//        int int11 = week7.getYearValue();
//        boolean boolean12 = week0.equals((java.lang.Object) int11);
//        java.lang.String str13 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getYearValue();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        java.lang.String str4 = week3.toString();
//        java.lang.Class<?> wildcardClass5 = week3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        boolean boolean13 = week9.equals((java.lang.Object) year12);
//        java.util.Date date14 = week9.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        java.lang.Class class16 = null;
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        java.util.Date date20 = week18.getEnd();
//        java.util.Date date21 = week18.getEnd();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone22);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date21, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str29 = week28.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException33.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize(class36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class36);
//        int int39 = week28.compareTo((java.lang.Object) class36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        java.util.Date date42 = regularTimePeriod41.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date47 = week46.getStart();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
//        java.util.Date date50 = week48.getEnd();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date50, timeZone52);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date47, timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date42, timeZone52);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date21, timeZone52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone52);
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date14, timeZone58);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 7, 0" + "'", str29.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable throwable13 = null;
        try {
            timePeriodFormatException10.addSuppressed(throwable13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 5, 100");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 5, 100" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 5, 100"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 5, 100" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 5, 100"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        java.util.Date date3 = week1.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date9 = week8.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date3, timeZone14);
        org.jfree.data.time.Year year18 = week17.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(9, year18);
        int int20 = week19.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        int int9 = week7.getYearValue();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException13.getSuppressed();
        java.lang.String str15 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 5");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str20 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 25, 2019");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 24, 5" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: Week 24, 5"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        java.util.Date date7 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 0);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        java.util.Date date5 = regularTimePeriod3.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException9.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.util.Date date16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.lang.String str18 = week17.toString();
//        java.lang.Class<?> wildcardClass19 = week17.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        org.jfree.data.time.Year year26 = week24.getYear();
//        boolean boolean27 = week23.equals((java.lang.Object) year26);
//        java.util.Date date28 = week23.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        java.lang.Class class30 = null;
//        java.lang.Class class31 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        java.util.Date date34 = week32.getEnd();
//        java.util.Date date35 = week32.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone36);
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str43 = week42.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        java.lang.Class<?> wildcardClass49 = timePeriodFormatException47.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class50);
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize(class50);
//        int int53 = week42.compareTo((java.lang.Object) class50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        java.util.Date date56 = regularTimePeriod55.getEnd();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date61 = week60.getStart();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.next();
//        java.util.Date date64 = week62.getEnd();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date64);
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date64, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date61, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date56, timeZone66);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date35, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date28, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone66);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date5, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week73.next();
//        java.util.Calendar calendar75 = null;
//        try {
//            long long76 = week73.getMiddleMillisecond(calendar75);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 7, 0" + "'", str43.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNotNull(class52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (short) 100);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.Year year9 = week7.getYear();
//        boolean boolean10 = week6.equals((java.lang.Object) year9);
//        java.util.Date date11 = week6.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.lang.Class class13 = null;
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
//        java.util.Date date17 = week15.getEnd();
//        java.util.Date date18 = week15.getEnd();
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str26 = week25.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass32 = timePeriodFormatException30.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize(class33);
//        int int36 = week25.compareTo((java.lang.Object) class33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = regularTimePeriod38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date18, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date11, timeZone49);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date11);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 7, 0" + "'", str26.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.lang.String str5 = week0.toString();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.util.Date date10 = null;
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
//        int int13 = week0.compareTo((java.lang.Object) regularTimePeriod12);
//        long long14 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date18 = week17.getStart();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        java.util.Date date21 = week19.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date21, timeZone23);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date18, timeZone23);
//        boolean boolean26 = week0.equals((java.lang.Object) timeZone23);
//        int int27 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(4, year3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date8 = week7.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.util.Date date11 = week9.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date2, timeZone13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        int int4 = week0.getYearValue();
        org.jfree.data.time.Year year5 = week0.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 2);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Date date3 = week0.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        java.lang.Class<?> wildcardClass6 = week4.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        java.lang.String str12 = week11.toString();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.Class<?> wildcardClass20 = timePeriodFormatException18.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class21);
//        java.util.Date date25 = null;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        java.lang.String str27 = week26.toString();
//        java.lang.Class<?> wildcardClass28 = week26.getClass();
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        org.jfree.data.time.Year year35 = week33.getYear();
//        boolean boolean36 = week32.equals((java.lang.Object) year35);
//        java.util.Date date37 = week32.getEnd();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
//        java.lang.Class class39 = null;
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = week41.getEnd();
//        java.util.Date date44 = week41.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date44, timeZone45);
//        java.util.TimeZone timeZone47 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date44, timeZone47);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str52 = week51.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
//        java.lang.Class<?> wildcardClass58 = timePeriodFormatException56.getClass();
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
//        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class59);
//        int int62 = week51.compareTo((java.lang.Object) class59);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
//        java.util.Date date65 = regularTimePeriod64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date70 = week69.getStart();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
//        java.util.Date date73 = week71.getEnd();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date73);
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date73, timeZone75);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date70, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date65, timeZone75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date44, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date37, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date14, timeZone75);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date3, timeZone75);
//        java.util.Calendar calendar84 = null;
//        try {
//            long long85 = week83.getLastMillisecond(calendar84);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week 24, 2019" + "'", str27.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Week 7, 0" + "'", str52.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNotNull(class61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.Date date5 = week0.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
//        boolean boolean8 = week0.equals((java.lang.Object) week7);
//        java.util.Date date9 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str19 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.String str40 = timePeriodFormatException27.toString();
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException27.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = week0.getEnd();
        java.util.Date date5 = week0.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Date date3 = week0.getEnd();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getMiddleMillisecond();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(0, year3);
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546156799999L + "'", long6 == 1546156799999L);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(25, year7);
//        int int10 = week9.getWeek();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        java.lang.String str5 = week0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        java.lang.Class class11 = null;
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        java.util.Date date15 = week13.getEnd();
//        java.util.Date date16 = week13.getEnd();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone19);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        java.util.Date date23 = week21.getEnd();
//        long long24 = week21.getFirstMillisecond();
//        org.jfree.data.time.Year year25 = week21.getYear();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int28 = week26.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week26.previous();
//        long long30 = regularTimePeriod29.getMiddleMillisecond();
//        java.util.Date date31 = regularTimePeriod29.getStart();
//        boolean boolean32 = week21.equals((java.lang.Object) date31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date36 = week35.getStart();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = week37.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date36, timeZone41);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date31, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date16, timeZone41);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559761199999L + "'", long30 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date8 = week7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11, timeZone13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date4, timeZone13);
//        long long17 = week16.getLastMillisecond();
//        long long18 = week16.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063599999L + "'", long17 == 1560063599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559458800000L + "'", long18 == 1559458800000L);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        long long4 = week1.getSerialIndex();
//        int int5 = week1.getWeek();
//        java.lang.String str6 = week1.toString();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) 'a', year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        java.lang.Class<?> wildcardClass6 = date4.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException16.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
//        java.util.Date date23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.lang.String str25 = week24.toString();
//        java.lang.Class<?> wildcardClass26 = week24.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        org.jfree.data.time.Year year33 = week31.getYear();
//        boolean boolean34 = week30.equals((java.lang.Object) year33);
//        java.util.Date date35 = week30.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.lang.Class class37 = null;
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        java.util.Date date41 = week39.getEnd();
//        java.util.Date date42 = week39.getEnd();
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date42, timeZone43);
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date42, timeZone45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str50 = week49.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException52.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
//        java.lang.Class<?> wildcardClass56 = timePeriodFormatException54.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize(class57);
//        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize(class57);
//        int int60 = week49.compareTo((java.lang.Object) class57);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
//        java.util.Date date63 = regularTimePeriod62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date68 = week67.getStart();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.next();
//        java.util.Date date71 = week69.getEnd();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date71);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date71, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date68, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date63, timeZone73);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date42, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date35, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone73);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date12, timeZone73);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date4, timeZone73);
//        java.util.Date date82 = week81.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559761199999L + "'", long11 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 24, 2019" + "'", str25.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 7, 0" + "'", str50.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(class59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(date82);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str19 = timePeriodFormatException16.toString();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException16.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        int int2 = week0.getYearValue();
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date7 = week6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        java.util.Date date10 = week8.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date7, timeZone12);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
//        java.util.Date date19 = week17.getEnd();
//        long long20 = week17.getFirstMillisecond();
//        org.jfree.data.time.Year year21 = week17.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int24 = week22.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week22.previous();
//        long long26 = regularTimePeriod25.getMiddleMillisecond();
//        java.util.Date date27 = regularTimePeriod25.getStart();
//        boolean boolean28 = week17.equals((java.lang.Object) date27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date32 = week31.getStart();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        java.util.Date date35 = week33.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date32, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date27, timeZone37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = week41.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date43, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date27, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date7, timeZone45);
//        java.util.Calendar calendar49 = null;
//        try {
//            week48.peg(calendar49);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1559761199999L + "'", long26 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        long long10 = week0.getLastMillisecond();
//        int int11 = week0.getWeek();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week0.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
//        java.lang.Class<?> wildcardClass8 = timePeriodFormatException6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
//        java.util.Date date12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        java.util.Date date15 = week13.getEnd();
//        long long16 = week13.getFirstMillisecond();
//        org.jfree.data.time.Year year17 = week13.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        int int20 = week18.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        long long22 = regularTimePeriod21.getMiddleMillisecond();
//        java.util.Date date23 = regularTimePeriod21.getStart();
//        boolean boolean24 = week13.equals((java.lang.Object) date23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        java.util.Date date31 = week29.getEnd();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date31, timeZone33);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date28, timeZone33);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date23, timeZone33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone33);
//        java.util.Locale locale38 = null;
//        try {
//            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date2, timeZone33, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559761199999L + "'", long22 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 10);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
        java.util.Date date3 = week1.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date9 = week8.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date12, timeZone14);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date3, timeZone14);
        org.jfree.data.time.Year year18 = week17.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(9, year18);
        int int20 = week19.getYearValue();
        long long21 = week19.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1551297599999L + "'", long21 == 1551297599999L);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.String str2 = week0.toString();
//        int int4 = week0.compareTo((java.lang.Object) "Week 24, 2019");
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.previous();
//        long long11 = week8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week8.next();
//        try {
//            int int13 = week0.compareTo((java.lang.Object) week8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 153L + "'", long11 == 153L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        int int4 = week3.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        long long5 = week4.getMiddleMillisecond();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(4, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2019, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(2, year8);
//        java.lang.Class<?> wildcardClass12 = year8.getClass();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        long long2 = week0.getSerialIndex();
//        int int3 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getSerialIndex();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62163475200001L) + "'", long5 == (-62163475200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62164080000000L) + "'", long8 == (-62164080000000L));
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        int int13 = week2.compareTo((java.lang.Object) class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
//        long long32 = week30.getMiddleMillisecond();
//        java.util.Date date33 = week30.getEnd();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560970799999L + "'", long32 == 1560970799999L);
//        org.junit.Assert.assertNotNull(date33);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.lang.String str10 = week9.toString();
//        java.lang.Class<?> wildcardClass11 = week9.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        org.jfree.data.time.Year year18 = week16.getYear();
//        boolean boolean19 = week15.equals((java.lang.Object) year18);
//        java.util.Date date20 = week15.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date20);
//        java.lang.Class class22 = null;
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        java.util.Date date26 = week24.getEnd();
//        java.util.Date date27 = week24.getEnd();
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date27, timeZone28);
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str35 = week34.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
//        java.lang.Class<?> wildcardClass41 = timePeriodFormatException39.getClass();
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass41);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        int int45 = week34.compareTo((java.lang.Object) class42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
//        java.util.Date date48 = regularTimePeriod47.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date53 = week52.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
//        java.util.Date date56 = week54.getEnd();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date56, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date53, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date48, timeZone58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date27, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date20, timeZone58);
//        boolean boolean64 = week8.equals((java.lang.Object) timeZone58);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 7, 0" + "'", str35.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.util.TimeZone timeZone6 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
//        java.util.TimeZone timeZone8 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str13 = week12.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException17.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize(class20);
//        int int23 = week12.compareTo((java.lang.Object) class20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
//        java.util.Date date26 = regularTimePeriod25.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date31 = week30.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        java.util.Date date34 = week32.getEnd();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date26, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date5, timeZone36);
//        java.lang.Class<?> wildcardClass41 = date5.getClass();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        java.lang.String str43 = week42.toString();
//        java.lang.Class<?> wildcardClass44 = week42.getClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        org.jfree.data.time.Year year51 = week49.getYear();
//        boolean boolean52 = week48.equals((java.lang.Object) year51);
//        java.util.Date date53 = week48.getEnd();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date53);
//        java.lang.Class class55 = null;
//        java.lang.Class class56 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.next();
//        java.util.Date date59 = week57.getEnd();
//        java.util.Date date60 = week57.getEnd();
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date60, timeZone61);
//        java.util.TimeZone timeZone63 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date60, timeZone63);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str68 = week67.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException70.addSuppressed((java.lang.Throwable) timePeriodFormatException72);
//        java.lang.Class<?> wildcardClass74 = timePeriodFormatException72.getClass();
//        java.lang.Class class75 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass74);
//        java.lang.Class class76 = org.jfree.data.time.RegularTimePeriod.downsize(class75);
//        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize(class75);
//        int int78 = week67.compareTo((java.lang.Object) class75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week79.next();
//        java.util.Date date81 = regularTimePeriod80.getEnd();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date81);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date86 = week85.getStart();
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = week87.next();
//        java.util.Date date89 = week87.getEnd();
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date89);
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date89, timeZone91);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date86, timeZone91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date81, timeZone91);
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date60, timeZone91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date53, timeZone91);
//        org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date5, timeZone91);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 7, 0" + "'", str13.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Week 7, 0" + "'", str68.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(class75);
//        org.junit.Assert.assertNotNull(class76);
//        org.junit.Assert.assertNotNull(class77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 100, year5);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 53);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60480619200001L) + "'", long3 == (-60480619200001L));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 100, 1);
//        java.util.Date date7 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        boolean boolean9 = week0.equals((java.lang.Object) regularTimePeriod8);
//        long long10 = week0.getLastMillisecond();
//        java.util.Date date11 = week0.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        try {
//            int int16 = week0.compareTo((java.lang.Object) regularTimePeriod15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = year6.getMiddleMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(6, year6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(25, 11);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        int int5 = week3.getYearValue();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int9 = week7.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
//        long long11 = regularTimePeriod10.getMiddleMillisecond();
//        java.util.Date date12 = regularTimePeriod10.getStart();
//        java.util.Date date13 = regularTimePeriod10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        boolean boolean15 = week3.equals((java.lang.Object) week14);
//        org.jfree.data.time.Year year16 = week3.getYear();
//        java.lang.Class<?> wildcardClass17 = year16.getClass();
//        boolean boolean18 = week2.equals((java.lang.Object) wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559761199999L + "'", long11 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        java.util.Date date8 = year5.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((-1), year5);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
//        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
//        java.lang.String str3 = timePeriodFormatException1.toString();
//        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getEnd();
//        java.util.Date date10 = week5.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.lang.String str13 = week12.toString();
//        java.util.Date date14 = week12.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        java.lang.Class<?> wildcardClass23 = timePeriodFormatException21.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        java.lang.Throwable[] throwableArray28 = timePeriodFormatException21.getSuppressed();
//        boolean boolean29 = week12.equals((java.lang.Object) timePeriodFormatException21);
//        int int30 = week11.compareTo((java.lang.Object) timePeriodFormatException21);
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        org.junit.Assert.assertNotNull(throwableArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
//        org.junit.Assert.assertNotNull(throwableArray4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(throwableArray28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        long long4 = week2.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        int int8 = week6.getYearValue();
//        int int9 = week6.getWeek();
//        java.util.Date date10 = week6.getStart();
//        java.lang.Class<?> wildcardClass11 = date10.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        java.lang.Class<?> wildcardClass17 = timePeriodFormatException15.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date22 = week21.getStart();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone23);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163475200001L) + "'", long4 == (-62163475200001L));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        java.util.Date date2 = week0.getEnd();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, (int) (byte) 0);
        java.lang.String str8 = week7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        int int18 = week7.compareTo((java.lang.Object) class15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = regularTimePeriod20.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date26 = week25.getStart();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
        java.util.Date date29 = week27.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date29, timeZone31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date26, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone31);
        boolean boolean35 = week3.equals((java.lang.Object) date21);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 7, 0" + "'", str8.equals("Week 7, 0"));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.lang.Class<?> wildcardClass6 = date4.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException10.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        java.lang.Class class17 = null;
        java.lang.Class class18 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = week19.getEnd();
        java.util.Date date22 = week19.getEnd();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(24, 5);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        java.util.Date date34 = week32.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date34, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date31, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date22, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date4, timeZone36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        long long3 = week2.getLastMillisecond();
//        long long4 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        java.util.Date date7 = week5.getEnd();
//        long long8 = week5.getFirstMillisecond();
//        org.jfree.data.time.Year year9 = week5.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        int int12 = week10.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
//        long long14 = regularTimePeriod13.getMiddleMillisecond();
//        java.util.Date date15 = regularTimePeriod13.getStart();
//        boolean boolean16 = week5.equals((java.lang.Object) date15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date20 = week19.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        java.util.Date date23 = week21.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date23, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date20, timeZone25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date15, timeZone25);
//        int int29 = week2.compareTo((java.lang.Object) week28);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62163475200001L) + "'", long3 == (-62163475200001L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62163777600001L) + "'", long4 == (-62163777600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559761199999L + "'", long14 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2019) + "'", int29 == (-2019));
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        long long7 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560365999999L + "'", long1 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        long long8 = week7.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week7.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1551600000000L + "'", long8 == 1551600000000L);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        int int8 = week0.getWeek();
//        int int9 = week0.getYearValue();
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class3);
//        java.lang.Class class8 = null;
//        java.lang.Class class9 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        java.util.Date date12 = week10.getEnd();
//        java.util.Date date13 = week10.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date13, timeZone14);
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date13, timeZone16);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date13, timeZone18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
//        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
//        java.lang.Class class30 = null;
//        java.lang.Class class31 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        java.util.Date date34 = week32.getEnd();
//        java.util.Date date35 = week32.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date35, timeZone36);
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date44 = week43.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        java.util.Date date47 = week45.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date44, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date35, timeZone49);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date13, timeZone49);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 7, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException11.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str18 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 7, 0" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 7, 0"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date5, timeZone6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Year year11 = week10.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year11);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, year4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 1, year4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        int int4 = week0.compareTo((java.lang.Object) 7);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, 5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week7.compareTo((java.lang.Object) wildcardClass10);
//        boolean boolean12 = week0.equals((java.lang.Object) wildcardClass10);
//        long long13 = week0.getMiddleMillisecond();
//        java.util.Date date14 = week0.getStart();
//        long long15 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560365999999L + "'", long15 == 1560365999999L);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
//        java.util.Date date8 = week6.getEnd();
//        java.util.Date date9 = week6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
//        java.util.Date date13 = week11.getEnd();
//        java.util.Date date14 = week11.getEnd();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        java.lang.Class class17 = null;
//        java.lang.Class class18 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
//        java.util.Date date21 = week19.getEnd();
//        java.util.Date date22 = week19.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str30 = week29.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException34.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class37);
//        int int40 = week29.compareTo((java.lang.Object) class37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = regularTimePeriod42.getEnd();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date48 = week47.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
//        java.util.Date date51 = week49.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date51, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date48, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone53);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date22, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date14, timeZone53);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date9, timeZone53);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date5, timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 7, 0" + "'", str30.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 0);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        long long12 = week9.getFirstMillisecond();
//        org.jfree.data.time.Year year13 = week9.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        int int16 = week14.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.previous();
//        long long18 = regularTimePeriod17.getMiddleMillisecond();
//        java.util.Date date19 = regularTimePeriod17.getStart();
//        boolean boolean20 = week9.equals((java.lang.Object) date19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date19, timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559761199999L + "'", long18 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str3 = week2.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
//        java.lang.Class<?> wildcardClass9 = timePeriodFormatException7.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        int int13 = week2.compareTo((java.lang.Object) class10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date21 = week20.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        java.util.Date date24 = week22.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24, timeZone26);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date16);
//        int int31 = week30.getWeek();
//        org.jfree.data.time.Year year32 = week30.getYear();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 7, 0" + "'", str3.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 25 + "'", int31 == 25);
//        org.junit.Assert.assertNotNull(year32);
//    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        java.lang.Class<?> wildcardClass3 = week0.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.util.Date date5 = null;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
//        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        int int19 = week6.compareTo((java.lang.Object) regularTimePeriod18);
//        long long20 = week6.getMiddleMillisecond();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date24 = week23.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
//        java.util.Date date27 = week25.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date27, timeZone29);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date24, timeZone29);
//        boolean boolean32 = week6.equals((java.lang.Object) timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone29);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560365999999L + "'", long20 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(class34);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.next();
//        java.util.Date date3 = week1.getEnd();
//        java.util.Date date4 = week1.getEnd();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        java.lang.Class class7 = null;
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        java.util.Date date12 = week9.getEnd();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date12, timeZone13);
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date12, timeZone15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str20 = week19.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
//        java.lang.Class<?> wildcardClass26 = timePeriodFormatException24.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
//        int int30 = week19.compareTo((java.lang.Object) class27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
//        java.util.Date date33 = regularTimePeriod32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date38 = week37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        java.util.Date date41 = week39.getEnd();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date41, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date38, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date12, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date4, timeZone43);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date4);
//        int int50 = week49.getWeek();
//        int int51 = week49.getWeek();
//        org.jfree.data.time.Year year52 = week49.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 7, 0" + "'", str20.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 24 + "'", int50 == 24);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertNotNull(year52);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.Year year7 = week5.getYear();
//        boolean boolean8 = week0.equals((java.lang.Object) week5);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getMiddleMillisecond();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year12);
//        java.lang.String str14 = week13.toString();
//        java.lang.String str15 = week13.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        int int17 = week5.compareTo((java.lang.Object) week13);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560365999999L + "'", long11 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 7, 2019" + "'", str14.equals("Week 7, 2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 7, 2019" + "'", str15.equals("Week 7, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 17 + "'", int17 == 17);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        org.jfree.data.time.Year year5 = week3.getYear();
//        long long6 = week3.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week3.next();
//        int int9 = week3.compareTo((java.lang.Object) 1.0d);
//        java.util.Date date10 = week3.getStart();
//        int int11 = week2.compareTo((java.lang.Object) date10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str15 = week14.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        java.lang.Class<?> wildcardClass21 = timePeriodFormatException19.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
//        int int25 = week14.compareTo((java.lang.Object) class22);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        java.util.Date date28 = regularTimePeriod27.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date33 = week32.getStart();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
//        java.util.Date date36 = week34.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date36, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date33, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date28, timeZone38);
//        java.lang.Class class42 = null;
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
//        java.util.Date date46 = week44.getEnd();
//        java.util.Date date47 = week44.getEnd();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone48);
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date47, timeZone50);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str55 = week54.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException59);
//        java.lang.Class<?> wildcardClass61 = timePeriodFormatException59.getClass();
//        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize(class62);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize(class62);
//        int int65 = week54.compareTo((java.lang.Object) class62);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.next();
//        java.util.Date date68 = regularTimePeriod67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date73 = week72.getStart();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.next();
//        java.util.Date date76 = week74.getEnd();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date76);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date76, timeZone78);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date73, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone78);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date47, timeZone78);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException84 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException86 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException84.addSuppressed((java.lang.Throwable) timePeriodFormatException86);
//        java.lang.Class<?> wildcardClass88 = timePeriodFormatException86.getClass();
//        java.lang.Class class89 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass88);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date93 = week92.getStart();
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass88, date93, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date47, timeZone94);
//        boolean boolean97 = week2.equals((java.lang.Object) timeZone94);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 7, 0" + "'", str15.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 7, 0" + "'", str55.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(class62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(wildcardClass88);
//        org.junit.Assert.assertNotNull(class89);
//        org.junit.Assert.assertNotNull(date93);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 100);
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Year year5 = week3.getYear();
        boolean boolean6 = week2.equals((java.lang.Object) year5);
        java.util.Date date7 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        boolean boolean12 = week2.equals((java.lang.Object) week10);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week2.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException3.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException12.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str19 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException32.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Class<?> wildcardClass45 = timePeriodFormatException43.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        java.lang.String str49 = timePeriodFormatException43.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        java.lang.Throwable[] throwableArray53 = timePeriodFormatException51.getSuppressed();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str49.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray53);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        long long4 = regularTimePeriod3.getMiddleMillisecond();
//        java.util.Date date5 = regularTimePeriod3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559761199999L + "'", long4 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        long long3 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Year year4 = week2.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-17), year6);
//        int int8 = week7.getWeek();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-17) + "'", int8 == (-17));
//    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.util.Date date4 = null;
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        java.util.Date date10 = week7.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException14.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class17);
//        java.util.Date date21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.lang.String str23 = week22.toString();
//        java.lang.Class<?> wildcardClass24 = week22.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(0, (int) (short) 100);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
//        org.jfree.data.time.Year year31 = week29.getYear();
//        boolean boolean32 = week28.equals((java.lang.Object) year31);
//        java.util.Date date33 = week28.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.lang.Class class35 = null;
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
//        java.util.Date date39 = week37.getEnd();
//        java.util.Date date40 = week37.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date40, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(7, (int) (byte) 0);
//        java.lang.String str48 = week47.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
//        java.lang.Class<?> wildcardClass54 = timePeriodFormatException52.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize(class55);
//        int int58 = week47.compareTo((java.lang.Object) class55);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
//        java.util.Date date61 = regularTimePeriod60.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(24, 5);
//        java.util.Date date66 = week65.getStart();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
//        java.util.Date date69 = week67.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date69, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date66, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date40, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date21, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date10, timeZone71);
//        java.lang.Class<?> wildcardClass79 = date10.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(class3);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 7, 0" + "'", str48.equals("Week 7, 0"));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(class56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        int int4 = week0.getWeek();
//        java.util.Date date5 = week0.getStart();
//        java.util.Date date6 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
        int int2 = week0.getYearValue();
        java.lang.Class<?> wildcardClass3 = week0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.next();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int7 = week5.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        long long9 = regularTimePeriod8.getMiddleMillisecond();
//        java.util.Date date10 = regularTimePeriod8.getStart();
//        boolean boolean11 = week0.equals((java.lang.Object) date10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        long long15 = week12.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week12.previous();
//        int int17 = week0.compareTo((java.lang.Object) week12);
//        java.lang.Class<?> wildcardClass18 = week12.getClass();
//        int int19 = week12.getYearValue();
//        java.lang.String str20 = week12.toString();
//        java.lang.String str21 = week12.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559761199999L + "'", long9 == 1559761199999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//    }
//}

