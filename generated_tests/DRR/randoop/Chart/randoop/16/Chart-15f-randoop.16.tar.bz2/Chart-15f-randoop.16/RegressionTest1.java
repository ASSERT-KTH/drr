import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot24.setRangeGridlineStroke(stroke26);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = null;
        xYPlot24.axisChanged(axisChangeEvent28);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.clearRangeAxes();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot31.setRangeGridlineStroke(stroke33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot31.setRangeZeroBaselinePaint((java.awt.Paint) color35);
        boolean boolean37 = xYPlot31.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        xYPlot31.setRangeAxisLocation((int) (short) 1, axisLocation39, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot31.zoomRangeAxes(0.0d, plotRenderingInfo43, point2D44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot31.getDomainAxisLocation();
        xYPlot24.setRangeAxisLocation(64, axisLocation46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D51 = xYPlot50.getQuadrantOrigin();
        xYPlot24.zoomRangeAxes(0.14d, plotRenderingInfo49, point2D51, true);
        try {
            categoryPlot15.zoomRangeAxes((double) 10, plotRenderingInfo23, point2D51, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=128,g=128,b=255]", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "1.2.0-pre");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str5.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1), keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        multiplePiePlot1.zoom((-5.0d));
        double double7 = multiplePiePlot1.getLimit();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        chartEntity9.setToolTipText("");
        java.lang.String str12 = chartEntity9.getToolTipText();
        boolean boolean13 = multiplePiePlot1.equals((java.lang.Object) chartEntity9);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        double double16 = categoryAxis15.getCategoryMargin();
        java.lang.String str18 = categoryAxis15.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis20.setTickUnit(numberTickUnit21, false, false);
        numberAxis20.resizeRange((double) 255);
        java.awt.Shape shape27 = numberAxis20.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot29.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray37, numberArray40, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray44);
        categoryPlot29.setDataset(1, categoryDataset45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        multiplePiePlot1.setDataset(categoryDataset45);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        double double9 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean6 = numberAxis1.equals((java.lang.Object) color5);
        numberAxis1.setAutoRangeMinimumSize(1.0E-8d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot1.setURLGenerator(pieURLGenerator3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearRangeAxes();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double14 = categoryAxis8.getCategoryStart(255, (int) (short) -1, rectangle2D12, rectangleEdge13);
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        xYPlot5.draw(graphics2D7, rectangle2D12, point2D15, plotState16, plotRenderingInfo17);
        java.awt.Stroke stroke19 = xYPlot5.getDomainCrosshairStroke();
        ringPlot1.setSeparatorStroke(stroke19);
        java.awt.Stroke stroke21 = ringPlot1.getSeparatorStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        java.awt.Paint paint12 = xYPlot0.getDomainGridlinePaint();
        xYPlot0.setWeight(3);
        boolean boolean15 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        textTitle0.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
        piePlotState1.setPieWRadius((double) 10);
        piePlotState1.setPieWRadius((double) 500);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Color color5 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", (int) 'a');
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        int int12 = color10.getAlpha();
        float[] floatArray21 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray22 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray21);
        float[] floatArray23 = color10.getColorComponents(floatArray22);
        float[] floatArray24 = color5.getComponents(floatArray22);
        float[] floatArray25 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) ' ', (int) (short) 10, floatArray22);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.toString();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image4 = null;
//        projectInfo3.setLogo(image4);
//        basicProjectInfo2.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo2);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP" + "'", str1.equals("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP"));
//        org.junit.Assert.assertNotNull(projectInfo3);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        boolean boolean4 = textLine1.equals((java.lang.Object) (short) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        textLine1.addFragment(textFragment7);
        float float9 = textFragment7.getBaselineOffset();
        float float10 = textFragment7.getBaselineOffset();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            float float13 = textFragment7.calculateBaselineOffset(graphics2D11, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = null;
        projectInfo6.setLogo(image7);
        projectInfo6.setName("1.2.0-pre");
        java.util.List list11 = projectInfo6.getContributors();
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setUpperMargin(1.0d);
        numberAxis14.setAutoTickUnitSelection(true, false);
        java.text.NumberFormat numberFormat20 = null;
        numberAxis14.setNumberFormatOverride(numberFormat20);
        java.awt.Shape shape22 = numberAxis14.getRightArrow();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (-1), 0.0d, 0.0d);
        double double17 = rectangleInsets15.trimHeight((double) 10L);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        xYPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D3, true);
        xYPlot0.setRangeCrosshairValue((double) 10.0f, true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        java.awt.Stroke stroke6 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "{0}");
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray12 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray12);
        float[] floatArray14 = color3.getComponents(floatArray12);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape17);
        numberAxis16.setUpArrow(shape17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean21 = numberAxis16.equals((java.lang.Object) color20);
        int int22 = color20.getGreen();
        java.awt.color.ColorSpace colorSpace23 = color20.getColorSpace();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("", font26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("hi!", font26, (java.awt.Paint) color28);
        int int30 = color28.getAlpha();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray40 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray41 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray40);
        float[] floatArray42 = color31.getComponents(floatArray40);
        float[] floatArray43 = color28.getRGBComponents(floatArray42);
        float[] floatArray44 = color3.getComponents(colorSpace23, floatArray43);
        float[] floatArray45 = java.awt.Color.RGBtoHSB((int) (short) -1, (int) (short) 0, (int) '4', floatArray44);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double16 = rectangleInsets14.calculateRightOutset((double) 'a');
        piePlot0.setInsets(rectangleInsets14, true);
        double double19 = piePlot0.getLabelGap();
        boolean boolean20 = piePlot0.getSimpleLabels();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-48.743718592964825d) + "'", double16 == (-48.743718592964825d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.025d + "'", double19 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        boolean boolean4 = textLine1.equals((java.lang.Object) (short) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        textLine1.addFragment(textFragment7);
        float float9 = textFragment7.getBaselineOffset();
        float float10 = textFragment7.getBaselineOffset();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker15.getLabelOffset();
        valueMarker15.setValue(0.2d);
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker15.getLabelTextAnchor();
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor19, jFreeChart20);
        try {
            textFragment7.draw(graphics2D11, 0.0f, (float) 1, textAnchor19, (-1.0f), 0.0f, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("java.awt.Color[r=128,g=128,b=255]");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        float float5 = textFragment4.getBaselineOffset();
        java.awt.Font font6 = textFragment4.getFont();
        textLine1.addFragment(textFragment4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeAxes();
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        xYPlot4.zoomRangeAxes((double) 0L, plotRenderingInfo9, point2D10);
        java.awt.Stroke stroke12 = xYPlot4.getRangeCrosshairStroke();
        polarPlot3.setAngleGridlineStroke(stroke12);
        try {
            polarPlot3.zoom((double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color13);
        int int15 = color13.getAlpha();
        float[] floatArray24 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray25 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray24);
        float[] floatArray26 = color13.getColorComponents(floatArray25);
        org.jfree.chart.text.TextLine textLine27 = new org.jfree.chart.text.TextLine("{0}", font8, (java.awt.Paint) color13);
        java.awt.Paint paint28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font8, paint28);
        polarPlot3.setAngleLabelFont(font8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color3 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", (int) 'a');
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart3.clearSubtitles();
        java.awt.Paint paint5 = null;
        jFreeChart3.setBackgroundPaint(paint5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle3.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double6 = categoryAxis0.getCategoryStart(255, (int) (short) -1, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit11, false, false);
        numberAxis10.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setExpandToFitSpace(false);
        java.lang.String str20 = textTitle17.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle17.getBounds();
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge23);
        double double25 = categoryAxis0.getCategoryEnd(0, (int) (short) 100, rectangle2D21, rectangleEdge23);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis0.getTickLabelInsets();
        double double30 = rectangleInsets28.trimHeight((double) '4');
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 48.0d + "'", double30 == 48.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        xYPlot0.setRangeCrosshairVisible(true);
        xYPlot0.setDomainCrosshairVisible(true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker14.getLabelOffset();
        java.awt.Paint paint16 = valueMarker14.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot17.getLabelDistributor();
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("", font21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("hi!", font21, (java.awt.Paint) color23);
        piePlot17.setLabelOutlinePaint((java.awt.Paint) color23);
        java.awt.Paint paint26 = piePlot17.getBaseSectionOutlinePaint();
        piePlot17.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot17.setMinimumArcAngleToDraw((double) 100L);
        valueMarker14.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot17);
        org.jfree.chart.util.Layer layer33 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker14, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        boolean boolean5 = jFreeChart3.isBorderVisible();
        java.awt.RenderingHints renderingHints6 = null;
        try {
            jFreeChart3.setRenderingHints(renderingHints6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 3, (double) 100L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        int int8 = color6.getAlpha();
        float[] floatArray17 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray17);
        float[] floatArray19 = color6.getColorComponents(floatArray18);
        try {
            float[] floatArray20 = color0.getComponents(colorSpace1, floatArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image2 = null;
        projectInfo1.setLogo(image2);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str5 = basicProjectInfo0.getLicenceName();
        basicProjectInfo0.setName("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setCircular(true, false);
        org.jfree.data.general.WaferMapDataset waferMapDataset14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = jFreeChart16.getPadding();
        boolean boolean18 = jFreeChart16.isBorderVisible();
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle21.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str24 = rectangleEdge23.toString();
        textTitle21.setPosition(rectangleEdge23);
        double double26 = textTitle21.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle21.setTextAlignment(horizontalAlignment27);
        try {
            jFreeChart16.addSubtitle(500, (org.jfree.chart.title.Title) textTitle21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.TOP" + "'", str24.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        numberAxis2.setUpArrow(shape3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean7 = numberAxis2.equals((java.lang.Object) color6);
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList();
        int int10 = objectList8.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int12 = objectList8.indexOf((java.lang.Object) stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color6, stroke11);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        valueMarker13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.clearDomainMarkers();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) valueMarker13, (java.lang.Object) xYPlot16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot16.getDomainAxisEdge(3);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        double double7 = piePlot0.getLabelGap();
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot9.setRenderer(3, categoryItemRenderer11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot13.getLabelDistributor();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("", font17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("hi!", font17, (java.awt.Paint) color19);
        piePlot13.setLabelOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = piePlot13.getBaseSectionOutlinePaint();
        piePlot13.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setUpperMargin(1.0d);
        numberAxis27.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke33 = numberAxis27.getTickMarkStroke();
        piePlot13.setLabelOutlineStroke(stroke33);
        categoryPlot9.setRangeGridlineStroke(stroke33);
        try {
            piePlot0.setSectionOutlineStroke(comparable8, stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", font1, (org.jfree.chart.plot.Plot) xYPlot2, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.clearRangeAxes();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot26.setRangeZeroBaselinePaint((java.awt.Paint) color30);
        boolean boolean32 = xYPlot26.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        xYPlot26.setRangeAxisLocation((int) (short) 1, axisLocation34, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot26.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D46 = xYPlot45.getQuadrantOrigin();
        xYPlot26.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo44, point2D46);
        xYPlot2.zoomRangeAxes((double) '#', 101.0d, plotRenderingInfo25, point2D46);
        xYPlot2.mapDatasetToRangeAxis(2, 3);
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = xYPlot2.getRendererForDataset(xYDataset52);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNull(xYItemRenderer53);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets12.createOutsetRectangle(rectangle2D14, true, true);
        piePlotState1.setLinkArea(rectangle2D17);
        int int19 = piePlotState1.getPassesRequired();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        boolean boolean2 = categoryAxis3D1.isTickMarksVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.general.WaferMapDataset waferMapDataset6 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = jFreeChart8.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets10.getUnitType();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle12.getBounds();
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets10.createInsetRectangle(rectangle2D13);
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets9.createInsetRectangle(rectangle2D13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType19 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets(unitType19, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType31 = rectangleInsets30.getUnitType();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle32.getBounds();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets30.createInsetRectangle(rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets29.createOutsetRectangle(rectangle2D33, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double39 = categoryAxis16.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D37, rectangleEdge38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis16.setTickLabelPaint((java.awt.Paint) color40);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis45.setTickUnit(numberTickUnit46, false, false);
        numberAxis45.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle();
        textTitle52.setExpandToFitSpace(false);
        java.lang.String str55 = textTitle52.getURLText();
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle52.getBounds();
        numberAxis45.setDownArrow((java.awt.Shape) rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        double double60 = categoryAxis16.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D56, rectangleEdge59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType64 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = new org.jfree.chart.util.RectangleInsets(unitType64, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = new org.jfree.chart.util.RectangleInsets(unitType64, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType76 = rectangleInsets75.getUnitType();
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle77.getBounds();
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets75.createInsetRectangle(rectangle2D78);
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets74.createOutsetRectangle(rectangle2D78, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double84 = categoryAxis61.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D82, rectangleEdge83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        try {
            org.jfree.chart.axis.AxisState axisState86 = categoryAxis3D1.draw(graphics2D3, (-48.743718592964825d), rectangle2D13, rectangle2D56, rectangleEdge83, plotRenderingInfo85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(numberTickUnit46);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(unitType64);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(unitType76);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setWeight((int) (byte) 10);
        xYPlot0.setDomainCrosshairValue((double) (byte) 100);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis10.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean15 = numberAxis10.equals((java.lang.Object) color14);
        org.jfree.data.RangeType rangeType16 = numberAxis10.getRangeType();
        numberAxis1.setRangeType(rangeType16);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rangeType16);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        xYPlot0.setWeight((int) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        int int11 = color9.getGreen();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color9);
        boolean boolean13 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 64 + "'", int11 == 64);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        java.awt.Stroke stroke6 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "{0}");
        try {
            piePlot0.setBackgroundImageAlpha((float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        java.util.List list17 = categoryPlot15.getCategories();
        java.awt.Paint paint18 = categoryPlot15.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint13.toRangeWidth(range22);
        double double24 = rectangleConstraint23.getHeight();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        java.util.List list17 = categoryPlot15.getAnnotations();
        categoryPlot15.setRangeCrosshairValue((double) (short) 0, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image2 = null;
        projectInfo1.setLogo(image2);
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setLicenceName("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        double double24 = categoryAxis23.getCategoryMargin();
        java.lang.String str26 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit29, false, false);
        numberAxis28.resizeRange((double) 255);
        java.awt.Shape shape35 = numberAxis28.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer36);
        java.awt.Paint paint38 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot37.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray45, numberArray48, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray52);
        categoryPlot37.setDataset(1, categoryDataset53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot15.getRendererForDataset(categoryDataset53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot15.getRangeAxisForDataset(500);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(valueAxis58);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
        pieSectionEntity11.setPieIndex((int) (short) 10);
        int int14 = pieSectionEntity11.getPieIndex();
        int int15 = pieSectionEntity11.getPieIndex();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.awt.Image image1 = null;
//        projectInfo0.setLogo(image1);
//        java.lang.String str3 = projectInfo0.getVersion();
//        java.lang.String str4 = projectInfo0.getCopyright();
//        projectInfo0.setLicenceText("RectangleEdge.TOP");
//        projectInfo0.addOptionalLibrary("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:hi!\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2.0-pre" + "'", str3.equals("1.2.0-pre"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str4.equals("Rotation.ANTICLOCKWISE"));
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.util.Locale locale1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.Class<?> wildcardClass3 = textBlockAnchor2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.util.ResourceBundle.Control control5 = null;
        try {
            java.util.ResourceBundle resourceBundle6 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", locale1, classLoader4, control5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setDepthFactor((-5.0d));
        boolean boolean4 = piePlot3D0.getDarkerSides();
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color3);
        double double5 = piePlot0.getMaximumExplodePercent();
        double double6 = piePlot0.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle8.getSources();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setVerticalTickLabels(false);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font18, (java.awt.Paint) color20);
        int int22 = color20.getAlpha();
        float[] floatArray31 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray32 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray31);
        float[] floatArray33 = color20.getColorComponents(floatArray32);
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("{0}", font15, (java.awt.Paint) color20);
        numberAxis11.setLabelFont(font15);
        legendTitle8.setItemFont(font15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        float float5 = multiplePiePlot1.getBackgroundAlpha();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        double double7 = multiplePiePlot1.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = multiplePiePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        boolean boolean3 = textTitle0.equals((java.lang.Object) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createOutsetRectangle(rectangle2D17, true, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor24 = piePlot23.getLabelDistributor();
        java.awt.Paint paint25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot23.setLabelBackgroundPaint(paint25);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator27 = piePlot23.getLegendLabelURLGenerator();
        java.awt.Paint paint28 = piePlot23.getBaseSectionOutlinePaint();
        boolean boolean29 = rectangleInsets21.equals((java.lang.Object) piePlot23);
        org.jfree.chart.util.UnitType unitType30 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets(unitType30, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets(unitType30, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType42 = rectangleInsets41.getUnitType();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets41.createInsetRectangle(rectangle2D44);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets40.createOutsetRectangle(rectangle2D44, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets21.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType49, lengthAdjustmentType50);
        java.lang.Object obj52 = textTitle0.draw(graphics2D4, rectangle2D17, (java.lang.Object) lengthAdjustmentType49);
        textTitle0.setHeight((double) (-1L));
        textTitle0.setWidth((-48.743718592964825d));
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(pieURLGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNull(obj52);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        categoryAxis3D1.configure();
        categoryAxis3D1.setLowerMargin((double) 'a');
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        polarPlot0.clearCornerTextItems();
        org.junit.Assert.assertNotNull(numberTickUnit1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart3.removeProgressListener(chartProgressListener5);
        int int7 = jFreeChart3.getSubtitleCount();
        java.awt.Paint paint8 = jFreeChart3.getBorderPaint();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot0.setDataset(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeAxes();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot4.setRangeGridlineStroke(stroke6);
        piePlot0.setBaseSectionOutlineStroke(stroke6);
        double double9 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterY();
        org.jfree.chart.entity.EntityCollection entityCollection3 = piePlotState1.getEntityCollection();
        double double4 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(entityCollection3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        int int6 = jFreeChart3.getSubtitleCount();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.setUpperMargin(0.025d);
        org.jfree.data.RangeType rangeType8 = numberAxis1.getRangeType();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets24.getUnitType();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets24.createInsetRectangle(rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets23.createOutsetRectangle(rectangle2D27, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis10.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D31, rectangleEdge32);
        dateAxis9.setDownArrow((java.awt.Shape) rectangle2D31);
        numberAxis1.setLeftArrow((java.awt.Shape) rectangle2D31);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart4.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart4.removeProgressListener(chartProgressListener6);
        int int8 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1L, jFreeChart4);
        java.lang.Object obj10 = chartChangeEvent9.getSource();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + 1L + "'", obj10.equals(1L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape12);
        numberAxis11.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean16 = numberAxis11.equals((java.lang.Object) color15);
        org.jfree.chart.util.ObjectList objectList17 = new org.jfree.chart.util.ObjectList();
        int int19 = objectList17.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int21 = objectList17.indexOf((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color15, stroke20);
        java.awt.Stroke stroke23 = valueMarker22.getStroke();
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean25 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker22, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets10.createOutsetRectangle(rectangle2D12, true, true);
        org.jfree.chart.block.BlockBorder blockBorder16 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean17 = rectangleInsets10.equals((java.lang.Object) blockBorder16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder16.getInsets();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(blockBorder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        java.util.Date date25 = dateAxis0.getMinimumDate();
        org.jfree.data.Range range26 = dateAxis0.getRange();
        java.lang.Object obj27 = null;
        boolean boolean28 = dateAxis0.equals(obj27);
        double double29 = dateAxis0.getFixedAutoRange();
        boolean boolean30 = dateAxis0.isAutoRange();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getLabelPadding();
        double double15 = rectangleInsets13.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot1.setDataset(waferMapDataset4);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection6 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot1.getInsets();
        double double6 = multiplePiePlot1.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = multiplePiePlot1.getLegendItems();
        java.lang.Object obj8 = legendItemCollection7.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        boolean boolean5 = polarPlot3.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
        pieSectionEntity11.setSectionIndex(64);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setUpperMargin(1.0d);
        double double18 = numberAxis15.getFixedDimension();
        java.awt.Paint paint19 = numberAxis15.getLabelPaint();
        boolean boolean20 = pieSectionEntity11.equals((java.lang.Object) numberAxis15);
        java.lang.String str21 = pieSectionEntity11.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        double double13 = categoryAxis12.getCategoryMargin();
        java.lang.String str15 = categoryAxis12.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis17.setTickUnit(numberTickUnit18, false, false);
        numberAxis17.resizeRange((double) 255);
        java.awt.Shape shape24 = numberAxis17.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis17, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot26.getRenderer(0);
        java.lang.Number[] numberArray34 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray34, numberArray37, numberArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray41);
        categoryPlot26.setDataset(categoryDataset42);
        categoryPlot0.setDataset(categoryDataset42);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset(2);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        double double6 = rectangleInsets3.calculateRightInset((double) (byte) 0);
        categoryAxis0.setTickLabelInsets(rectangleInsets3);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine();
        boolean boolean10 = color8.equals((java.lang.Object) textLine9);
        boolean boolean12 = textLine9.equals((java.lang.Object) (short) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font14);
        textLine9.addFragment(textFragment15);
        org.jfree.chart.text.TextFragment textFragment17 = textLine9.getLastTextFragment();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) textFragment17);
        java.awt.Paint paint19 = textFragment17.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(textFragment17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke7 = numberAxis1.getTickMarkStroke();
        numberAxis1.setTickMarkInsideLength((float) ' ');
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation6, true);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj15 = dateAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        dateAxis14.setRange(range22, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint13.toRangeWidth(range22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint26.toUnconstrainedWidth();
        java.lang.String str28 = rectangleConstraint27.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]" + "'", str28.equals("RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        int int46 = categoryPlot15.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        java.awt.Paint paint15 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 10L, (double) (byte) 0, (double) (-1L), paint15);
        piePlot0.setSectionPaint((java.lang.Comparable) (-1.0d), paint15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot0.removeChangeListener(plotChangeListener18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean6 = blockBorder4.equals((java.lang.Object) textAnchor5);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", graphics2D1, 0.0f, (float) (-1), textAnchor5, (double) ' ', (float) 10, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit16, false, false);
        numberAxis15.resizeRange((double) 255);
        java.awt.Shape shape22 = numberAxis15.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot24.getFixedRangeAxisSpace();
        java.util.List list26 = categoryPlot24.getCategories();
        categoryPlot24.zoom(90.0d);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot24);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNull(list26);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot15.getRangeAxisForDataset((int) (byte) 100);
        categoryPlot15.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(valueAxis19);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = null;
        projectInfo6.setLogo(image7);
        projectInfo6.setName("1.2.0-pre");
        java.util.List list11 = projectInfo6.getContributors();
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list11);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.clearRangeAxes();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot14.setRangeGridlineStroke(stroke16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        xYPlot14.axisChanged(axisChangeEvent18);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.clearRangeAxes();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeGridlineStroke(stroke23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color25);
        boolean boolean27 = xYPlot21.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setRangeAxisLocation((int) (short) 1, axisLocation29, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot21.zoomRangeAxes(0.0d, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot21.getDomainAxisLocation();
        xYPlot14.setRangeAxisLocation(64, axisLocation36);
        try {
            xYPlot0.setRangeAxisLocation((-16744448), axisLocation36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextPaint();
        boolean boolean13 = unitType0.equals((java.lang.Object) defaultDrawingSupplier11);
        java.lang.Object obj14 = defaultDrawingSupplier11.clone();
        java.awt.Paint paint15 = defaultDrawingSupplier11.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.clearRangeAxes();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        boolean boolean13 = xYPlot7.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        xYPlot7.setRangeAxisLocation((int) (short) 1, axisLocation15, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot7.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(64, axisLocation22);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(seriesRenderingOrder24);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        boolean boolean3 = ringPlot1.getSeparatorsVisible();
        ringPlot1.setMaximumLabelWidth(2.0d);
        boolean boolean6 = ringPlot1.getSeparatorsVisible();
        ringPlot1.setSeparatorsVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset(2);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        double double6 = rectangleInsets3.calculateRightInset((double) (byte) 0);
        categoryAxis0.setTickLabelInsets(rectangleInsets3);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine();
        boolean boolean10 = color8.equals((java.lang.Object) textLine9);
        boolean boolean12 = textLine9.equals((java.lang.Object) (short) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font14);
        textLine9.addFragment(textFragment15);
        org.jfree.chart.text.TextFragment textFragment17 = textLine9.getLastTextFragment();
        boolean boolean18 = categoryAxis0.equals((java.lang.Object) textFragment17);
        java.lang.String str20 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(textFragment17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        java.lang.Object obj4 = chartChangeEvent2.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        java.lang.Object obj6 = chartChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 0 + "'", obj4.equals((short) 0));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 0 + "'", obj6.equals((short) 0));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double13 = dateRange12.getLength();
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange12, (double) 0L);
        dateAxis0.setRangeWithMargins(range15, false, true);
        dateAxis0.setLowerBound((double) (short) 100);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        boolean boolean2 = blockContainer1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        boolean boolean3 = jFreeChartResources0.containsKey("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setDepthFactor((-5.0d));
        piePlot3D0.setShadowXOffset((double) 0.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterY();
        piePlotState1.setPassesRequired(0);
        double double5 = piePlotState1.getTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint4 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot0.setSectionOutlinesVisible(false);
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelLinkPaint(paint15);
        double double17 = piePlot0.getLabelGap();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.clearRangeAxes();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle25.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double28 = categoryAxis22.getCategoryStart(255, (int) (short) -1, rectangle2D26, rectangleEdge27);
        java.awt.geom.Point2D point2D29 = null;
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        xYPlot19.draw(graphics2D21, rectangle2D26, point2D29, plotState30, plotRenderingInfo31);
        java.awt.Color color33 = java.awt.Color.LIGHT_GRAY;
        xYPlot19.setRangeZeroBaselinePaint((java.awt.Paint) color33);
        java.awt.Stroke stroke35 = xYPlot19.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        int int37 = xYPlot19.indexOf(xYDataset36);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType40 = rectangleInsets39.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor42 = piePlot41.getLabelDistributor();
        java.awt.Paint paint43 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot41.setLabelBackgroundPaint(paint43);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator45 = piePlot41.getLegendLabelURLGenerator();
        java.awt.Paint paint46 = piePlot41.getBaseSectionOutlinePaint();
        boolean boolean47 = rectangleInsets39.equals((java.lang.Object) piePlot41);
        org.jfree.chart.util.UnitType unitType48 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = new org.jfree.chart.util.RectangleInsets(unitType48, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets(unitType48, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType60 = rectangleInsets59.getUnitType();
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle61.getBounds();
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets59.createInsetRectangle(rectangle2D62);
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets58.createOutsetRectangle(rectangle2D62, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets39.createAdjustedRectangle(rectangle2D62, lengthAdjustmentType67, lengthAdjustmentType68);
        xYPlot19.drawBackgroundImage(graphics2D38, rectangle2D69);
        try {
            piePlot0.drawBackground(graphics2D18, rectangle2D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.025d + "'", double17 == 0.025d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(unitType40);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(pieURLGenerator45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(unitType48);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(unitType60);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D69);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.lang.Object obj2 = blockContainer0.clone();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = blockContainer0.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.data.Range range3 = null;
        try {
            dateAxis0.setRange(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.lang.Object obj3 = dateAxis0.clone();
        dateAxis0.setInverted(false);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str3 = textTitle0.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot6.getLabelDistributor();
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setLabelBackgroundPaint(paint8);
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        piePlot6.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color11);
        double double13 = piePlot6.getLabelGap();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape17);
        numberAxis16.setUpArrow(shape17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean21 = numberAxis16.equals((java.lang.Object) color20);
        int int22 = color20.getGreen();
        java.awt.color.ColorSpace colorSpace23 = color20.getColorSpace();
        float[] floatArray32 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray32);
        float[] floatArray34 = color14.getColorComponents(colorSpace23, floatArray32);
        piePlot6.setBaseSectionPaint((java.awt.Paint) color14);
        textTitle0.setPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.025d + "'", double13 == 0.025d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        java.lang.String str10 = piePlot0.getPlotType();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot0.getURLGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Pie Plot" + "'", str10.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieURLGenerator11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        double double4 = numberAxis1.getFixedDimension();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        boolean boolean6 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot0.setMinimumArcAngleToDraw((double) 100L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", font1, (org.jfree.chart.plot.Plot) xYPlot2, true);
        java.awt.Image image23 = null;
        jFreeChart22.setBackgroundImage(image23);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        int int2 = abstractPieLabelDistributor1.getItemCount();
        abstractPieLabelDistributor1.clear();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        java.awt.Paint paint55 = xYPlot0.getQuadrantPaint(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D60 = xYPlot59.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (-1L), 0.025d, plotRenderingInfo58, point2D60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot0.getDomainAxisLocation();
        java.awt.Stroke stroke63 = xYPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        xYPlot0.setRangeGridlinesVisible(true);
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        java.awt.Image image5 = null;
        jFreeChart3.setBackgroundImage(image5);
        jFreeChart3.clearSubtitles();
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setUpperMargin(1.0d);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setTickMarkStroke(stroke8);
        categoryPlot0.setDomainGridlineStroke(stroke8);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj3 = standardPieSectionLabelGenerator2.clone();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable6 = null;
        try {
            java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator2.generateAttributedSectionLabel(pieDataset5, comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        piePlot0.setShadowYOffset((double) 10.0f);
        piePlot0.setSimpleLabels(true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        boolean boolean3 = ringPlot1.getSeparatorsVisible();
        ringPlot1.setMaximumLabelWidth(2.0d);
        ringPlot1.setOuterSeparatorExtension(48.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit16, false, false);
        numberAxis15.resizeRange((double) 255);
        java.awt.Shape shape22 = numberAxis15.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getDomainGridlinePaint();
        numberAxis1.setLabelPaint(paint25);
        org.jfree.data.Range range27 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range27, (double) 255);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = valueMarker2.getLabelOffset();
        java.awt.Paint paint4 = valueMarker2.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot5.getLabelDistributor();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("", font9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font9, (java.awt.Paint) color11);
        piePlot5.setLabelOutlinePaint((java.awt.Paint) color11);
        java.awt.Paint paint14 = piePlot5.getBaseSectionOutlinePaint();
        piePlot5.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot5.setMinimumArcAngleToDraw((double) 100L);
        valueMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot5);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("", font26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("hi!", font26, (java.awt.Paint) color28);
        int int30 = color28.getAlpha();
        float[] floatArray39 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray40 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray39);
        float[] floatArray41 = color28.getColorComponents(floatArray40);
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("{0}", font23, (java.awt.Paint) color28);
        java.awt.Paint paint43 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextLine textLine44 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font23, paint43);
        valueMarker2.setPaint(paint43);
        org.jfree.chart.util.Layer layer46 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker2, layer46);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        double double24 = categoryAxis23.getCategoryMargin();
        java.lang.String str26 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit29, false, false);
        numberAxis28.resizeRange((double) 255);
        java.awt.Shape shape35 = numberAxis28.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer36);
        java.awt.Paint paint38 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot37.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray45, numberArray48, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray52);
        categoryPlot37.setDataset(1, categoryDataset53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot15.getRendererForDataset(categoryDataset53);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent56);
        java.awt.Paint paint58 = categoryPlot15.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation59 = null;
        try {
            categoryPlot15.setDomainAxisLocation(axisLocation59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double48 = rectangleInsets46.trimHeight((double) 1L);
        categoryPlot15.setAxisOffset(rectangleInsets46);
        double double51 = rectangleInsets46.calculateLeftInset((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-5.0d) + "'", double48 == (-5.0d));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.0d + "'", double51 == 3.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj3 = dateAxis2.clone();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis2.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis2.setTickUnit(dateTickUnit5, false, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = categoryAxis13.getCategoryStart(255, (int) (short) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot10.draw(graphics2D12, rectangle2D17, point2D20, plotState21, plotRenderingInfo22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        double double26 = dateAxis2.valueToJava2D((double) 1.0f, rectangle2D17, rectangleEdge25);
        java.util.Date date27 = dateAxis2.getMinimumDate();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis2, xYItemRenderer28);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker12.getLabelOffset();
        valueMarker12.setValue(0.2d);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker12.getLabelTextAnchor();
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor16, jFreeChart17);
        try {
            textLine7.draw(graphics2D8, (float) (short) -1, (float) (short) 0, textAnchor16, (float) '#', 100.0f, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
        piePlotState1.setPieWRadius((double) 10);
        double double6 = piePlotState1.getPieHRadius();
        double double7 = piePlotState1.getTotal();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets8.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot10.getLabelDistributor();
        java.awt.Paint paint12 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot10.setLabelBackgroundPaint(paint12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot10.getLegendLabelURLGenerator();
        java.awt.Paint paint15 = piePlot10.getBaseSectionOutlinePaint();
        boolean boolean16 = rectangleInsets8.equals((java.lang.Object) piePlot10);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(unitType17, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType29 = rectangleInsets28.getUnitType();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets28.createInsetRectangle(rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets27.createOutsetRectangle(rectangle2D31, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets8.createAdjustedRectangle(rectangle2D31, lengthAdjustmentType36, lengthAdjustmentType37);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31, "1.2.0-pre", "Rotation.ANTICLOCKWISE");
        piePlotState1.setExplodedPieArea(rectangle2D31);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(pieURLGenerator14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot5 = numberAxis1.getPlot();
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        double double7 = range6.getUpperBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot0.notifyListeners(plotChangeEvent16);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot0.getRenderer(10);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNull(xYItemRenderer21);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getAngleGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot15.getIndexOf(categoryItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot15.zoomRangeAxes((double) 500, plotRenderingInfo21, point2D22, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        boolean boolean2 = categoryAxis3D1.isTickMarksVisible();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets7.getUnitType();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle9.getBounds();
        java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets7.createInsetRectangle(rectangle2D10);
        double double13 = rectangleInsets7.calculateRightOutset((double) (byte) -1);
        double double15 = rectangleInsets7.calculateTopOutset((-5.0d));
        org.jfree.chart.util.UnitType unitType16 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets27.getUnitType();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets27.createInsetRectangle(rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets26.createOutsetRectangle(rectangle2D30, true, false);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets7.createOutsetRectangle(rectangle2D34, true, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType41 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets(unitType41, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets(unitType41, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType53 = rectangleInsets52.getUnitType();
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle54.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets52.createInsetRectangle(rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets51.createOutsetRectangle(rectangle2D55, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double61 = categoryAxis38.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D59, rectangleEdge60);
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis38.setTickLabelPaint((java.awt.Paint) color62);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit68 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis67.setTickUnit(numberTickUnit68, false, false);
        numberAxis67.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle();
        textTitle74.setExpandToFitSpace(false);
        java.lang.String str77 = textTitle74.getURLText();
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle74.getBounds();
        numberAxis67.setDownArrow((java.awt.Shape) rectangle2D78);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge80);
        double double82 = categoryAxis38.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D78, rectangleEdge81);
        try {
            double double83 = categoryAxis3D1.getCategorySeriesMiddle((java.lang.Comparable) 0.12d, (java.lang.Comparable) "hi!", categoryDataset5, (double) 1.0f, rectangle2D37, rectangleEdge81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(unitType28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(unitType53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(numberTickUnit68);
        org.junit.Assert.assertNull(str77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot0.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot0.setURLGenerator(pieURLGenerator11);
        piePlot0.setShadowYOffset(7.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        double double9 = piePlot2.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType23 = rectangleInsets22.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor25 = piePlot24.getLabelDistributor();
        java.awt.Paint paint26 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot24.setLabelBackgroundPaint(paint26);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator28 = piePlot24.getLegendLabelURLGenerator();
        java.awt.Paint paint29 = piePlot24.getBaseSectionOutlinePaint();
        boolean boolean30 = rectangleInsets22.equals((java.lang.Object) piePlot24);
        org.jfree.chart.util.UnitType unitType31 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets(unitType31, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets(unitType31, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType43 = rectangleInsets42.getUnitType();
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle44.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets42.createInsetRectangle(rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets41.createOutsetRectangle(rectangle2D45, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets22.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType50, lengthAdjustmentType51);
        xYPlot2.drawBackgroundImage(graphics2D21, rectangle2D52);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray54 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot2.setRenderers(xYItemRendererArray54);
        java.awt.Stroke stroke56 = xYPlot2.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke56);
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(pieURLGenerator28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(unitType31);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(unitType43);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(xYItemRendererArray54);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double6 = dateRange5.getLength();
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange5, (double) 0L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range14 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange11, (double) (byte) 100, true);
        double double15 = range14.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj17 = dateAxis16.clone();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double20 = numberAxis19.getUpperBound();
        boolean boolean21 = numberAxis19.isTickMarksVisible();
        boolean boolean22 = numberAxis19.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot23 = numberAxis19.getPlot();
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        dateAxis16.setRange(range24, true, false);
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range24, (org.jfree.data.Range) dateRange28);
        java.lang.String str30 = rectangleConstraint29.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint29.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange5, lengthConstraintType9, (double) 1, range14, lengthConstraintType31);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) 64, (org.jfree.data.Range) dateRange5);
        try {
            org.jfree.chart.util.Size2D size2D34 = blockContainer1.arrange(graphics2D2, rectangleConstraint33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 101.0d + "'", double15 == 101.0d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str30.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType31);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = piePlot1.getLabelDistributor();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font5, (java.awt.Paint) color7);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color7);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        java.util.List list11 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setBackgroundAlpha((float) (-1));
        java.awt.Paint paint19 = null;
        xYPlot0.setRangeTickBandPaint(paint19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot0.getRangeMarkers(layer21);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getLength();
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange1, (double) 0L);
        dateAxis0.setRange((org.jfree.data.Range) dateRange1, false, true);
        dateAxis0.setAutoRangeMinimumSize((double) '#');
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot0.setDataset(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeAxes();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot4.setRangeGridlineStroke(stroke6);
        piePlot0.setBaseSectionOutlineStroke(stroke6);
        java.lang.Object obj9 = piePlot0.clone();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        boolean boolean4 = numberAxis1.isAutoRange();
        numberAxis1.resizeRange((double) 4, 90.0d);
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double9 = dateRange8.getLength();
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange8, (double) 0L);
        numberAxis1.setDefaultAutoRange(range11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getRangeMarkers(layer1);
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        categoryPlot15.setRangeCrosshairValue((double) 0.5f);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double36 = rectangleInsets35.getRight();
        categoryPlot15.setInsets(rectangleInsets35);
        double double39 = rectangleInsets35.extendWidth((double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 6.0d + "'", double39 == 6.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot15.setRenderer(categoryItemRenderer17);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font20);
        float float22 = textFragment21.getBaselineOffset();
        java.awt.Font font23 = textFragment21.getFont();
        categoryPlot15.setNoDataMessageFont(font23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.clearRangeAxes();
        xYPlot1.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 0L, plotRenderingInfo6, point2D7);
        java.awt.Stroke stroke9 = xYPlot1.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets10.getUnitType();
        java.lang.String str12 = unitType11.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) 3, (double) 0.0f, 0.0d, 8.0d);
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke9, rectangleInsets17);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.ABSOLUTE" + "'", str12.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getLabelPadding();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor15 = piePlot14.getLabelDistributor();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font18, (java.awt.Paint) color20);
        piePlot14.setLabelOutlinePaint((java.awt.Paint) color20);
        java.awt.Paint paint23 = piePlot14.getBaseSectionOutlinePaint();
        piePlot14.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot14.getLabelPadding();
        piePlot0.setLabelPadding(rectangleInsets27);
        piePlot0.setIgnoreNullValues(false);
        double double31 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0E-5d + "'", double31 == 1.0E-5d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 10.0d;
        size2D0.height = 0.0d;
        size2D0.height = (byte) -1;
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot16.getLabelDistributor();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("hi!", font20, (java.awt.Paint) color22);
        piePlot16.setLabelOutlinePaint((java.awt.Paint) color22);
        java.awt.Paint paint25 = piePlot16.getBaseSectionOutlinePaint();
        xYPlot0.setBackgroundPaint(paint25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        double double31 = categoryAxis30.getCategoryMargin();
        java.lang.String str33 = categoryAxis30.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis35.setTickUnit(numberTickUnit36, false, false);
        numberAxis35.resizeRange((double) 255);
        java.awt.Shape shape42 = numberAxis35.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer43);
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot44.getFixedRangeAxisSpace();
        java.util.List list46 = categoryPlot44.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D27, rectangle2D28, list46);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(numberTickUnit36);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        numberAxis1.setLabelToolTip("");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setExpandToFitSpace(false);
        java.lang.String str13 = textTitle10.getURLText();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle10.getBounds();
        numberAxis1.setRightArrow((java.awt.Shape) rectangle2D14);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        java.lang.Object obj4 = numberAxis1.clone();
        double double5 = numberAxis1.getLabelAngle();
        boolean boolean6 = numberAxis1.isInverted();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation10 = piePlot0.getDirection();
        double double11 = rotation10.getFactor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        multiplePiePlot1.setDataset(categoryDataset2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        multiplePiePlot1.handleClick((int) '#', 10, plotRenderingInfo6);
        java.lang.String str8 = multiplePiePlot1.getPlotType();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setUpperMargin(1.0d);
        numberAxis10.setAutoTickUnitSelection(true);
        boolean boolean15 = multiplePiePlot1.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRGB();
        java.awt.Color color7 = java.awt.Color.getColor("Rotation.ANTICLOCKWISE", (int) 'a');
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font10, (java.awt.Paint) color12);
        int int14 = color12.getAlpha();
        float[] floatArray23 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray23);
        float[] floatArray25 = color12.getColorComponents(floatArray24);
        float[] floatArray26 = color7.getComponents(floatArray24);
        float[] floatArray27 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 10, (int) (byte) 1, floatArray26);
        float[] floatArray28 = color0.getRGBComponents(floatArray26);
        int int29 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16744448) + "'", int1 == (-16744448));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-16744448) + "'", int29 == (-16744448));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        java.lang.String str3 = licences0.getLGPL();
        java.lang.String str4 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        java.lang.Object obj2 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) categoryAxis1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot9.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis14.setTickUnit(numberTickUnit15, false, false);
        numberAxis14.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis14.getLabelInsets();
        java.lang.String str22 = numberAxis14.getLabelToolTip();
        boolean boolean23 = numberAxis14.getAutoRangeStickyZero();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        textTitle24.setExpandToFitSpace(false);
        java.lang.String str27 = textTitle24.getURLText();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle24.getBounds();
        numberAxis14.setDownArrow((java.awt.Shape) rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor10, 100, (int) (byte) 10, rectangle2D28, rectangleEdge30);
        java.awt.Paint paint32 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        textTitle0.setPosition(rectangleEdge2);
        double double5 = textTitle0.getWidth();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle6.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle6.getVerticalAlignment();
        textTitle0.setVerticalAlignment(verticalAlignment9);
        textTitle0.setText("{0}");
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot8.getLabelDistributor();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setLabelBackgroundPaint(paint10);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot8.getLegendLabelURLGenerator();
        java.awt.Paint paint13 = piePlot8.getBaseSectionOutlinePaint();
        boolean boolean14 = rectangleInsets6.equals((java.lang.Object) piePlot8);
        org.jfree.chart.util.UnitType unitType15 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets(unitType15, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType15, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets26.getUnitType();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle28.getBounds();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets26.createInsetRectangle(rectangle2D29);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets25.createOutsetRectangle(rectangle2D29, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets6.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType34, lengthAdjustmentType35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list38 = dateAxis0.refreshTicks(graphics2D4, axisState5, rectangle2D29, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(pieURLGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Stroke stroke4 = valueMarker1.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = piePlot1.getLabelDistributor();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("hi!", font5, (java.awt.Paint) color7);
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color7);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker12.getLabelOffset();
        java.awt.Paint paint14 = valueMarker12.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor16 = piePlot15.getLabelDistributor();
        java.awt.Paint paint17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot15.setLabelBackgroundPaint(paint17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator19 = piePlot15.getLegendLabelURLGenerator();
        boolean boolean20 = valueMarker12.equals((java.lang.Object) piePlot15);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = piePlot15.getLabelPadding();
        categoryPlot0.setAxisOffset(rectangleInsets21);
        categoryPlot0.setAnchorValue(90.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(pieURLGenerator19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        multiplePiePlot1.zoom((-5.0d));
        double double7 = multiplePiePlot1.getLimit();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 10L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextPaint();
        boolean boolean13 = unitType0.equals((java.lang.Object) defaultDrawingSupplier11);
        java.lang.Object obj14 = defaultDrawingSupplier11.clone();
        java.awt.Paint paint15 = defaultDrawingSupplier11.getNextPaint();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        boolean boolean2 = textTitle0.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        textTitle0.setPosition(rectangleEdge3);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str9 = rectangleEdge8.toString();
        textTitle6.setPosition(rectangleEdge8);
        double double11 = textTitle6.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle6.setTextAlignment(horizontalAlignment12);
        textTitle0.setTextAlignment(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.TOP" + "'", str9.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        double double8 = categoryAxis7.getCategoryMargin();
        java.lang.String str10 = categoryAxis7.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit13, false, false);
        numberAxis12.resizeRange((double) 255);
        java.awt.Shape shape19 = numberAxis12.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis12, categoryItemRenderer20);
        boolean boolean22 = categoryPlot0.equals((java.lang.Object) categoryAxis7);
        float float23 = categoryAxis7.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        piePlot2.setIgnoreNullValues(true);
        java.awt.Stroke stroke11 = piePlot2.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = null;
        piePlot2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicLocation();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot16.getLabelDistributor();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot16.setLabelBackgroundPaint(paint18);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot16.getLegendLabelURLGenerator();
        boolean boolean21 = piePlot16.getIgnoreNullValues();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot16.setBaseSectionOutlinePaint((java.awt.Paint) color22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray25 = legendTitle24.getSources();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle24.getSources();
        legendTitle14.setSources(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(pieURLGenerator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(legendItemSourceArray25);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle8.getSources();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle8.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor11);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setNegativeArrowVisible(false);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        numberAxis1.setAxisLineVisible(false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
        pieSectionEntity11.setSectionIndex(64);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        pieSectionEntity11.setDataset(pieDataset14);
        pieSectionEntity11.setSectionIndex(2);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot15.getDomainAxisEdge(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        categoryPlot15.setRangeCrosshairValue((double) 0.5f);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double36 = rectangleInsets35.getRight();
        categoryPlot15.setInsets(rectangleInsets35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType41 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets(unitType41, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets(unitType41, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType53 = rectangleInsets52.getUnitType();
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D55 = textTitle54.getBounds();
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets52.createInsetRectangle(rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets51.createOutsetRectangle(rectangle2D55, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double61 = categoryAxis38.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D59, rectangleEdge60);
        org.jfree.chart.entity.ChartEntity chartEntity64 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D59, "{0}", "org.jfree.chart.event.ChartChangeEvent[source=0]");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets35.createAdjustedRectangle(rectangle2D59, lengthAdjustmentType65, lengthAdjustmentType66);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(unitType53);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        double double2 = textTitle0.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        textTitle0.setPosition(rectangleEdge3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        java.lang.String str7 = rectangleEdge3.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleEdge.TOP" + "'", str7.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range12 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange9, (double) (byte) 100, true);
        double double13 = range12.getUpperBound();
        numberAxis1.setRangeWithMargins(range12);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 101.0d + "'", double13 == 101.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.awt.Stroke stroke12 = jFreeChart11.getBorderStroke();
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart11.getLegend(4);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean2 = columnArrangement0.equals((java.lang.Object) 101.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        double double24 = categoryAxis23.getCategoryMargin();
        java.lang.String str26 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit29, false, false);
        numberAxis28.resizeRange((double) 255);
        java.awt.Shape shape35 = numberAxis28.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer36);
        java.awt.Paint paint38 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace39 = categoryPlot37.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray45 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray52 = new java.lang.Number[][] { numberArray45, numberArray48, numberArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray52);
        categoryPlot37.setDataset(1, categoryDataset53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = categoryPlot15.getRendererForDataset(categoryDataset53);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent56);
        java.awt.Paint paint58 = categoryPlot15.getRangeGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder59 = categoryPlot15.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(axisSpace39);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNull(categoryItemRenderer55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(sortOrder59);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setUpperBound((double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        double double15 = categoryAxis14.getCategoryMargin();
        java.lang.String str17 = categoryAxis14.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis19.setTickUnit(numberTickUnit20, false, false);
        numberAxis19.resizeRange((double) 255);
        java.awt.Shape shape26 = numberAxis19.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D33 = xYPlot32.getQuadrantOrigin();
        categoryPlot28.zoomRangeAxes((double) 0, (double) 0, plotRenderingInfo31, point2D33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge(2);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        double double40 = categoryAxis39.getCategoryMargin();
        java.lang.String str42 = categoryAxis39.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis44.setTickUnit(numberTickUnit45, false, false);
        numberAxis44.resizeRange((double) 255);
        java.awt.Shape shape51 = numberAxis44.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer52);
        java.awt.Paint paint54 = categoryPlot53.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace55 = categoryPlot53.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray61 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray64 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray67 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] { numberArray61, numberArray64, numberArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray68);
        categoryPlot53.setDataset(1, categoryDataset69);
        org.jfree.data.Range range71 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset69);
        categoryPlot28.setDataset(3, categoryDataset69);
        org.jfree.data.Range range73 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset69);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = categoryPlot0.getRendererForDataset(categoryDataset69);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(point2D33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(numberTickUnit45);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(axisSpace55);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNull(categoryItemRenderer74);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double18 = rectangleInsets16.calculateRightOutset((double) 'a');
        piePlot2.setInsets(rectangleInsets16, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset22 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot23 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot23);
        jFreeChart24.removeLegend();
        piePlot2.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        java.lang.Object obj28 = textTitle0.clone();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-48.743718592964825d) + "'", double18 == (-48.743718592964825d));
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1.0f, (double) 0L);
        size2D2.width = (short) 0;
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle7.getBounds();
        java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createInsetRectangle(rectangle2D8);
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createInsetRectangle(rectangle2D8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge11);
        double double13 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D8, rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setUpperMargin(1.0d);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis4.setTickMarkStroke(stroke7);
        polarPlot0.setRadiusGridlineStroke(stroke7);
        boolean boolean10 = polarPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis((int) '4');
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Paint paint12 = xYPlot10.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray14 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer13 };
        xYPlot10.setRenderers(xYItemRendererArray14);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot10.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder16);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(xYItemRendererArray14);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        boolean boolean10 = piePlot0.isCircular();
        java.awt.Paint paint11 = piePlot0.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.equals((java.lang.Object) (-1L));
        java.lang.String str6 = numberAxis1.getLabelURL();
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        double double4 = numberAxis1.getUpperBound();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis1.draw(graphics2D5, (double) 1, rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection12);
        xYPlot0.mapDatasetToRangeAxis(0, (-1));
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker19.getLabelOffset();
        java.awt.Paint paint21 = valueMarker19.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("", font26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine29 = new org.jfree.chart.text.TextLine("hi!", font26, (java.awt.Paint) color28);
        piePlot22.setLabelOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = piePlot22.getBaseSectionOutlinePaint();
        piePlot22.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot22.setMinimumArcAngleToDraw((double) 100L);
        valueMarker19.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot22);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("", font43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("hi!", font43, (java.awt.Paint) color45);
        int int47 = color45.getAlpha();
        float[] floatArray56 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray57 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray56);
        float[] floatArray58 = color45.getColorComponents(floatArray57);
        org.jfree.chart.text.TextLine textLine59 = new org.jfree.chart.text.TextLine("{0}", font40, (java.awt.Paint) color45);
        java.awt.Paint paint60 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.text.TextLine textLine61 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font40, paint60);
        valueMarker19.setPaint(paint60);
        org.jfree.chart.util.Layer layer63 = null;
        try {
            boolean boolean64 = xYPlot0.removeRangeMarker(500, (org.jfree.chart.plot.Marker) valueMarker19, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 255 + "'", int47 == 255);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset31);
        boolean boolean34 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        boolean boolean10 = piePlot0.isCircular();
        double double11 = piePlot0.getInteriorGap();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        xYPlot0.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot7.getLabelDistributor();
        java.awt.Paint paint9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot7.setLabelBackgroundPaint(paint9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot7.getLegendLabelURLGenerator();
        java.awt.Paint paint12 = piePlot7.getBaseSectionOutlinePaint();
        boolean boolean13 = rectangleInsets5.equals((java.lang.Object) piePlot7);
        piePlot7.setIgnoreNullValues(true);
        java.awt.Stroke stroke16 = piePlot7.getLabelLinkStroke();
        xYPlot0.setRangeCrosshairStroke(stroke16);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(pieURLGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        piePlot2.setIgnoreNullValues(true);
        java.awt.Stroke stroke11 = piePlot2.getLabelLinkStroke();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot2.setShadowPaint((java.awt.Paint) color12);
        double double14 = piePlot2.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.14d + "'", double14 == 0.14d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleEdge.BOTTOM", "RectangleEdge.BOTTOM", "Pie Plot", "1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP", "");
        basicProjectInfo5.setName("hi!");
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setExpandToFitSpace(false);
        java.lang.String str5 = textTitle2.getURLText();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot6.getLabelDistributor();
        double double8 = piePlot6.getStartAngle();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot6.setLabelBackgroundPaint((java.awt.Paint) color9);
        double double11 = piePlot6.getMaximumExplodePercent();
        blockContainer1.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) double11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle2.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        double double16 = categoryAxis15.getCategoryMargin();
        java.lang.String str18 = categoryAxis15.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis20.setTickUnit(numberTickUnit21, false, false);
        numberAxis20.resizeRange((double) 255);
        java.awt.Shape shape27 = numberAxis20.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot29.getRenderer(0);
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray37, numberArray40, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray44);
        categoryPlot29.setDataset(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (byte) 1);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity54 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset48, (int) (byte) 10, (int) (short) 10, (java.lang.Comparable) 0.5f, "Pie 3D Plot", "Multiple Pie Plot");
        boolean boolean55 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset48);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        valueMarker1.setValue((-48.743718592964825d));
        valueMarker1.setValue(0.0d);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker9.getLabelOffset();
        java.awt.Paint paint11 = valueMarker9.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor13 = piePlot12.getLabelDistributor();
        java.awt.Paint paint14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot12.setLabelBackgroundPaint(paint14);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot12.getLegendLabelURLGenerator();
        boolean boolean17 = valueMarker9.equals((java.lang.Object) piePlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot12.getLabelPadding();
        valueMarker1.setLabelOffset(rectangleInsets18);
        valueMarker1.setAlpha(0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateTopOutset((double) 'a');
        double double5 = rectangleInsets1.calculateTopInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        boolean boolean7 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        boolean boolean4 = textLine1.equals((java.lang.Object) (short) 1);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textLine1.calculateDimensions(graphics2D5);
        double double7 = size2D6.width;
        size2D6.height = 64;
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        categoryPlot15.setOutlineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot15.getRangeAxis(0);
        java.awt.Stroke stroke21 = categoryPlot15.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = xYPlot0.getDataRange(valueAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape10);
        numberAxis9.setUpArrow(shape10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean14 = numberAxis9.equals((java.lang.Object) color13);
        org.jfree.chart.util.ObjectList objectList15 = new org.jfree.chart.util.ObjectList();
        int int17 = objectList15.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int19 = objectList15.indexOf((java.lang.Object) stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color13, stroke18);
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        valueMarker20.setLabelPaint((java.awt.Paint) color21);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = valueMarker20.getLabelOffsetType();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createInsetRectangle(rectangle2D9);
        double double12 = rectangleInsets6.calculateRightOutset((double) (byte) -1);
        double double14 = rectangleInsets6.calculateTopOutset((double) (short) -1);
        numberAxis1.setLabelInsets(rectangleInsets6);
        java.awt.Paint paint16 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        try {
            java.lang.String str4 = jFreeChartResources0.getString("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key (C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray2 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Pie Plot");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot1.setURLGenerator(pieURLGenerator3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearRangeAxes();
        xYPlot5.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot5.zoomRangeAxes((double) 0L, plotRenderingInfo10, point2D11);
        java.awt.Stroke stroke13 = xYPlot5.getRangeCrosshairStroke();
        ringPlot1.setBaseSectionOutlineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
        pieSectionEntity11.setSectionIndex(64);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setUpperMargin(1.0d);
        double double18 = numberAxis15.getFixedDimension();
        java.awt.Paint paint19 = numberAxis15.getLabelPaint();
        boolean boolean20 = pieSectionEntity11.equals((java.lang.Object) numberAxis15);
        java.text.NumberFormat numberFormat21 = numberAxis15.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(numberFormat21);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis9.setTickUnit(numberTickUnit10, false, false);
        numberAxis9.resizeRange((double) 255);
        java.awt.Shape shape16 = numberAxis9.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D23 = xYPlot22.getQuadrantOrigin();
        categoryPlot18.zoomRangeAxes((double) 0, (double) 0, plotRenderingInfo21, point2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot18.getDomainAxisEdge(2);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity(shape31);
        numberAxis30.setUpArrow(shape31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean35 = numberAxis30.equals((java.lang.Object) color34);
        org.jfree.chart.util.ObjectList objectList36 = new org.jfree.chart.util.ObjectList();
        int int38 = objectList36.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int40 = objectList36.indexOf((java.lang.Object) stroke39);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color34, stroke39);
        java.awt.Stroke stroke42 = valueMarker41.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = valueMarker41.getLabelAnchor();
        org.jfree.chart.util.Layer layer44 = null;
        categoryPlot18.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer44);
        boolean boolean46 = chartEntity1.equals((java.lang.Object) valueMarker41);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D20 = xYPlot19.getQuadrantOrigin();
        categoryPlot15.zoomRangeAxes((double) 0, (double) 0, plotRenderingInfo18, point2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getDomainAxisEdge(2);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        double double27 = categoryAxis26.getCategoryMargin();
        java.lang.String str29 = categoryAxis26.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis31.setTickUnit(numberTickUnit32, false, false);
        numberAxis31.resizeRange((double) 255);
        java.awt.Shape shape38 = numberAxis31.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace42 = categoryPlot40.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray51 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray55 = new java.lang.Number[][] { numberArray48, numberArray51, numberArray54 };
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray55);
        categoryPlot40.setDataset(1, categoryDataset56);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset56);
        categoryPlot15.setDataset(3, categoryDataset56);
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset56);
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset56);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(axisSpace42);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray51);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(categoryDataset56);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(range61);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        java.awt.Paint paint2 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        dateAxis0.setLowerMargin(6.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.equals((java.lang.Object) (-1L));
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double8 = dateRange7.getLength();
        org.jfree.data.Range range10 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange7, (double) 0L);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range16 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange13, (double) (byte) 100, true);
        double double17 = range16.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj19 = dateAxis18.clone();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getUpperBound();
        boolean boolean23 = numberAxis21.isTickMarksVisible();
        boolean boolean24 = numberAxis21.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot25 = numberAxis21.getPlot();
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        dateAxis18.setRange(range26, true, false);
        org.jfree.data.time.DateRange dateRange30 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(range26, (org.jfree.data.Range) dateRange30);
        java.lang.String str32 = rectangleConstraint31.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = rectangleConstraint31.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range) dateRange7, lengthConstraintType11, (double) 1, range16, lengthConstraintType33);
        numberAxis1.setRange(range16);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 101.0d + "'", double17 == 101.0d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(dateRange30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str32.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType33);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setDepthFactor((-5.0d));
        java.awt.Shape shape4 = piePlot3D0.getLegendItemShape();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        java.awt.Stroke stroke3 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers(layer4);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.clearRangeAxes();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        boolean boolean13 = xYPlot7.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        xYPlot7.setRangeAxisLocation((int) (short) 1, axisLocation15, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot7.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(64, axisLocation22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation24);
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor27 = piePlot26.getLabelDistributor();
        java.awt.Paint paint28 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot26.setLabelBackgroundPaint(paint28);
        java.awt.Color color31 = java.awt.Color.LIGHT_GRAY;
        piePlot26.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color31);
        int int33 = piePlot26.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator34 = piePlot26.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor35 = piePlot26.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation36 = piePlot26.getDirection();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean38 = rotation36.equals((java.lang.Object) plotOrientation37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation37);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(pieURLGenerator34);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor35);
        org.junit.Assert.assertNotNull(rotation36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Stroke stroke19 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color20);
        double double22 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 0, (double) 15, (double) 1, 0.025d);
        boolean boolean7 = standardPieSectionLabelGenerator1.equals((java.lang.Object) rectangleInsets6);
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color3);
        double double5 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = valueMarker7.getLabelOffset();
        java.awt.Paint paint9 = valueMarker7.getOutlinePaint();
        piePlot0.setLabelShadowPaint(paint9);
        piePlot0.setIgnoreZeroValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double16 = rectangleInsets14.calculateRightOutset((double) 'a');
        piePlot0.setInsets(rectangleInsets14, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart22.removeLegend();
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        valueMarker26.setLabelPaint((java.awt.Paint) color27);
        piePlot0.setLabelLinkPaint((java.awt.Paint) color27);
        java.awt.Paint paint30 = piePlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-48.743718592964825d) + "'", double16 == (-48.743718592964825d));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        java.util.Date date25 = dateAxis0.getMinimumDate();
        dateAxis0.setAutoRange(true);
        org.jfree.data.Range range28 = null;
        try {
            dateAxis0.setRange(range28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1.0f, (double) 0L);
        size2D2.width = (-16744448);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Paint paint4 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearDomainAxes();
        boolean boolean6 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Font font7 = xYPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot8.getLabelDistributor();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setLabelBackgroundPaint(paint10);
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double24 = rectangleInsets22.calculateRightOutset((double) 'a');
        piePlot8.setInsets(rectangleInsets22, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot29 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot29);
        jFreeChart30.removeLegend();
        piePlot8.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        textTitle6.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        flowArrangement5.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) rectangleAnchor34);
        java.lang.Object obj36 = null;
        boolean boolean37 = flowArrangement5.equals(obj36);
        flowArrangement5.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-48.743718592964825d) + "'", double24 == (-48.743718592964825d));
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setExpandToFitSpace(false);
        java.lang.String str5 = textTitle2.getURLText();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot6.getLabelDistributor();
        double double8 = piePlot6.getStartAngle();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot6.setLabelBackgroundPaint((java.awt.Paint) color9);
        double double11 = piePlot6.getMaximumExplodePercent();
        blockContainer1.add((org.jfree.chart.block.Block) textTitle2, (java.lang.Object) double11);
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle2.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        double double16 = categoryAxis15.getCategoryMargin();
        java.lang.String str18 = categoryAxis15.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis20.setTickUnit(numberTickUnit21, false, false);
        numberAxis20.resizeRange((double) 255);
        java.awt.Shape shape27 = numberAxis20.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot29.getRenderer(0);
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] { numberArray37, numberArray40, numberArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray44);
        categoryPlot29.setDataset(categoryDataset45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (byte) 1);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity54 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset48, (int) (byte) 10, (int) (short) 10, (java.lang.Comparable) 0.5f, "Pie 3D Plot", "Multiple Pie Plot");
        org.jfree.chart.plot.RingPlot ringPlot55 = new org.jfree.chart.plot.RingPlot(pieDataset48);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset48);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.data.general.WaferMapDataset waferMapDataset4 = null;
        waferMapPlot2.setDataset(waferMapDataset4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        numberAxis2.setUpArrow(shape3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean7 = numberAxis2.equals((java.lang.Object) color6);
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList();
        int int10 = objectList8.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int12 = objectList8.indexOf((java.lang.Object) stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color6, stroke11);
        java.awt.Color color14 = java.awt.Color.MAGENTA;
        valueMarker13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.clearDomainMarkers();
        boolean boolean18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) valueMarker13, (java.lang.Object) xYPlot16);
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getTickLabelInsets();
        numberAxis1.setAutoRangeMinimumSize(1.0E-8d, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.awt.Shape shape2 = chartEntity1.getArea();
        chartEntity1.setToolTipText("Rotation.ANTICLOCKWISE");
        java.lang.String str5 = chartEntity1.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str5.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation10 = piePlot0.getDirection();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean12 = rotation10.equals((java.lang.Object) plotOrientation11);
        java.lang.String str13 = plotOrientation11.toString();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(rotation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.VERTICAL" + "'", str13.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        java.awt.Font font6 = numberAxis1.getLabelFont();
        numberAxis1.setLabel("XY Plot");
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot15.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        double double24 = categoryAxis23.getCategoryMargin();
        java.lang.String str26 = categoryAxis23.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis28.setTickUnit(numberTickUnit29, false, false);
        numberAxis28.resizeRange((double) 255);
        java.awt.Shape shape35 = numberAxis28.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D42 = xYPlot41.getQuadrantOrigin();
        categoryPlot37.zoomRangeAxes((double) 0, (double) 0, plotRenderingInfo40, point2D42);
        categoryPlot15.zoomDomainAxes((double) 100L, plotRenderingInfo21, point2D42);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(point2D42);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle8.getSources();
        java.awt.Font font10 = legendTitle8.getItemFont();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("", font12);
        float float14 = textFragment13.getBaselineOffset();
        java.awt.Font font15 = textFragment13.getFont();
        legendTitle8.setItemFont(font15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) (byte) 0);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot8.getLabelDistributor();
        java.awt.Paint paint10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot8.setLabelBackgroundPaint(paint10);
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double24 = rectangleInsets22.calculateRightOutset((double) 'a');
        piePlot8.setInsets(rectangleInsets22, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset28 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot29 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot29);
        jFreeChart30.removeLegend();
        piePlot8.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart30);
        textTitle6.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        flowArrangement5.add((org.jfree.chart.block.Block) textTitle6, (java.lang.Object) rectangleAnchor34);
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer();
        java.util.List list37 = blockContainer36.getBlocks();
        java.lang.Object obj38 = blockContainer36.clone();
        java.util.List list39 = blockContainer36.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockContainer36.getMargin();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = null;
        try {
            org.jfree.chart.util.Size2D size2D43 = flowArrangement5.arrange(blockContainer36, graphics2D41, rectangleConstraint42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-48.743718592964825d) + "'", double24 == (-48.743718592964825d));
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.util.List list2 = blockContainer1.getBlocks();
        java.lang.Object obj3 = blockContainer1.clone();
        blockContainer1.clear();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj7 = dateAxis6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getUpperBound();
        boolean boolean11 = numberAxis9.isTickMarksVisible();
        boolean boolean12 = numberAxis9.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot13 = numberAxis9.getPlot();
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        dateAxis6.setRange(range14, true, false);
        org.jfree.data.time.DateRange dateRange18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(range14, (org.jfree.data.Range) dateRange18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj21 = dateAxis20.clone();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double24 = numberAxis23.getUpperBound();
        boolean boolean25 = numberAxis23.isTickMarksVisible();
        boolean boolean26 = numberAxis23.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot27 = numberAxis23.getPlot();
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        dateAxis20.setRange(range28, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = rectangleConstraint19.toRangeWidth(range28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint32.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = rectangleConstraint33.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D35 = columnArrangement0.arrange(blockContainer1, graphics2D5, rectangleConstraint33);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(dateRange18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint32);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray9 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray10 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray9);
        float[] floatArray11 = color0.getComponents(floatArray9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape15);
        numberAxis14.setUpArrow(shape15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean19 = numberAxis14.equals((java.lang.Object) color18);
        int int20 = color18.getGreen();
        java.awt.color.ColorSpace colorSpace21 = color18.getColorSpace();
        float[] floatArray30 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray31 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray30);
        float[] floatArray32 = color12.getColorComponents(colorSpace21, floatArray30);
        float[] floatArray33 = color0.getRGBColorComponents(floatArray30);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getDomainAxisEdge();
        java.lang.String str9 = rectangleEdge8.toString();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleEdge.BOTTOM" + "'", str9.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset(2);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot3.getLabelDistributor();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setLabelBackgroundPaint(paint5);
        java.awt.Paint paint7 = piePlot3.getLabelShadowPaint();
        java.awt.Stroke stroke8 = piePlot3.getLabelOutlineStroke();
        java.awt.Paint paint9 = piePlot3.getLabelPaint();
        boolean boolean10 = categoryAxis0.equals((java.lang.Object) paint9);
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        abstractPieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = abstractPieLabelDistributor1.getPieLabelRecord((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.Comparable comparable8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
        pieSectionEntity11.setSectionIndex(64);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        pieSectionEntity11.setDataset(pieDataset14);
        java.lang.String str16 = pieSectionEntity11.getShapeCoords();
        pieSectionEntity11.setPieIndex((int) '#');
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str16.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            abstractPieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.5f, (double) 1);
        double double3 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
        piePlotState1.setPieHRadius((double) 100L);
        double double6 = piePlotState1.getPieHRadius();
        org.jfree.chart.entity.EntityCollection entityCollection7 = piePlotState1.getEntityCollection();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNull(entityCollection7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        java.awt.Paint paint55 = xYPlot0.getQuadrantPaint(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D60 = xYPlot59.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (-1L), 0.025d, plotRenderingInfo58, point2D60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot0.getDomainAxisLocation();
        java.awt.Paint paint63 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot0.setBackgroundPaint(paint63);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        java.lang.String str5 = polarPlot3.getPlotType();
        boolean boolean6 = polarPlot3.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Polar Plot" + "'", str5.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        double double6 = categoryAxis5.getCategoryMargin();
        java.lang.String str8 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit11, false, false);
        numberAxis10.resizeRange((double) 255);
        java.awt.Shape shape17 = numberAxis10.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot19.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray27 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray27, numberArray30, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray34);
        categoryPlot19.setDataset(1, categoryDataset35);
        multiplePiePlot1.setDataset(categoryDataset35);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        projectInfo0.setName("1.2.0-pre");
        java.util.List list5 = projectInfo0.getContributors();
        java.lang.String str6 = projectInfo0.getName();
        java.lang.String str7 = projectInfo0.getVersion();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2.0-pre" + "'", str6.equals("1.2.0-pre"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2.0-pre" + "'", str7.equals("1.2.0-pre"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D20 = xYPlot19.getQuadrantOrigin();
        categoryPlot15.zoomRangeAxes((double) 0, (double) 0, plotRenderingInfo18, point2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot15.getDomainAxisEdge(2);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape28);
        numberAxis27.setUpArrow(shape28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean32 = numberAxis27.equals((java.lang.Object) color31);
        org.jfree.chart.util.ObjectList objectList33 = new org.jfree.chart.util.ObjectList();
        int int35 = objectList33.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int37 = objectList33.indexOf((java.lang.Object) stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color31, stroke36);
        java.awt.Stroke stroke39 = valueMarker38.getStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker38.getLabelAnchor();
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot15.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer41);
        categoryPlot15.zoom((double) 0L);
        java.awt.Paint paint45 = categoryPlot15.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.awt.Font font2 = textTitle0.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle0.setTextAlignment(horizontalAlignment3);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double13 = dateRange12.getLength();
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange12, (double) 0L);
        dateAxis0.setRangeWithMargins(range15, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis0.getTickMarkPosition();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj21 = dateAxis20.clone();
        org.jfree.chart.axis.Timeline timeline22 = dateAxis20.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit23, false, false);
        java.util.TimeZone timeZone27 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource28 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone27);
        dateAxis0.setTimeZone(timeZone27);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timeline22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(tickUnitSource28);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeCrosshairValue((double) 1.0f);
        java.awt.Stroke stroke9 = null;
        try {
            xYPlot0.setRangeCrosshairStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint4 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(unitType2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        xYPlot8.setDomainAxisLocation((int) 'a', axisLocation13);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Paint paint4 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.clearDomainAxes();
        java.awt.Paint paint6 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setBackgroundAlpha((float) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot0.getAxisOffset();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = valueMarker22.getLabelOffset();
        java.awt.Paint paint24 = valueMarker22.getOutlinePaint();
        valueMarker22.setValue((-48.743718592964825d));
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.clearRangeAxes();
        xYPlot27.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot27.zoomRangeAxes((double) 0L, plotRenderingInfo32, point2D33);
        valueMarker22.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot27);
        org.jfree.chart.util.Layer layer36 = null;
        xYPlot0.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer36);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = piePlot1.getLabelDistributor();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearRangeAxes();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot5.setRangeGridlineStroke(stroke7);
        piePlot1.setBaseSectionOutlineStroke(stroke7);
        numberAxis0.setTickMarkStroke(stroke7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double13 = dateRange12.getLength();
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange12, (double) 0L);
        dateAxis0.setRangeWithMargins(range15, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis0.getTickMarkPosition();
        java.awt.Shape shape20 = dateAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterY();
        double double3 = piePlotState1.getPieCenterX();
        double double4 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        double double2 = textTitle0.getHeight();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle0.getPadding();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        piePlot2.setIgnoreNullValues(true);
        java.awt.Stroke stroke11 = piePlot2.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot2.getLabelGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot0.setDataset(pieDataset2);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeAxes();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot4.setRangeGridlineStroke(stroke6);
        piePlot0.setBaseSectionOutlineStroke(stroke6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle11.getBounds();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets9.createInsetRectangle(rectangle2D12);
        piePlot0.setSimpleLabelOffset(rectangleInsets9);
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets9.getUnitType();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(unitType15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color7 = java.awt.Color.CYAN;
        piePlot6.setLabelPaint((java.awt.Paint) color7);
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = categoryAxis13.getCategoryStart(255, (int) (short) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot10.draw(graphics2D12, rectangle2D17, point2D20, plotState21, plotRenderingInfo22);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        xYPlot10.setRangeZeroBaselinePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke26 = xYPlot10.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        int int28 = xYPlot10.indexOf(xYDataset27);
        java.awt.Stroke stroke29 = xYPlot10.getDomainCrosshairStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot10.setRangeCrosshairPaint((java.awt.Paint) color30);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot0.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot0.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot13.getLabelDistributor();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot13.setLabelBackgroundPaint(paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot13.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color18);
        int int20 = piePlot13.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot13.getURLGenerator();
        java.awt.Color color23 = java.awt.Color.DARK_GRAY;
        piePlot13.setSectionOutlinePaint((java.lang.Comparable) "Multiple Pie Plot", (java.awt.Paint) color23);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot13.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        java.text.NumberFormat numberFormat27 = standardPieSectionLabelGenerator25.getNumberFormat();
        piePlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        double double29 = piePlot0.getMinimumArcAngleToDraw();
        double double30 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(numberFormat27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-5d + "'", double29 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0E-5d + "'", double30 == 1.0E-5d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) categoryAxis1);
        boolean boolean6 = categoryAxis1.isTickMarksVisible();
        int int7 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj15 = dateAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        dateAxis14.setRange(range22, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint13.toRangeWidth(range22);
        double double27 = rectangleConstraint13.getHeight();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        float float5 = multiplePiePlot1.getBackgroundAlpha();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder7 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterX();
        double double3 = piePlotState1.getPieCenterY();
        piePlotState1.setPieWRadius((double) ' ');
        piePlotState1.setLatestAngle(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        chartEntity1.setToolTipText("");
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle4.getBounds();
        boolean boolean7 = textTitle4.equals((java.lang.Object) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str8 = textTitle4.getText();
        boolean boolean9 = chartEntity1.equals((java.lang.Object) str8);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        double double35 = categoryAxis34.getCategoryMargin();
        java.lang.String str37 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        boolean boolean38 = rectangleAnchor33.equals((java.lang.Object) categoryAxis34);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis34.setTickLabelFont((java.lang.Comparable) (byte) -1, font40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis43.setCategoryLabelPositionOffset(2);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType47 = rectangleInsets46.getUnitType();
        double double49 = rectangleInsets46.calculateRightInset((double) (byte) 0);
        categoryAxis43.setTickLabelInsets(rectangleInsets46);
        boolean boolean51 = legendItemCollection42.equals((java.lang.Object) categoryAxis43);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D52 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D();
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj55 = categoryAxis54.clone();
        categoryAxis54.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray57 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis34, categoryAxis43, categoryAxis3D52, categoryAxis3D53, categoryAxis54 };
        categoryPlot15.setDomainAxes(categoryAxisArray57);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent59 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(unitType47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(categoryAxisArray57);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        categoryPlot15.setRangeCrosshairValue((double) 0.5f);
        categoryPlot15.zoom(10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        categoryPlot15.setOutlineVisible(true);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement20 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement20);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setExpandToFitSpace(false);
        java.lang.String str25 = textTitle22.getURLText();
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor27 = piePlot26.getLabelDistributor();
        double double28 = piePlot26.getStartAngle();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot26.setLabelBackgroundPaint((java.awt.Paint) color29);
        double double31 = piePlot26.getMaximumExplodePercent();
        blockContainer21.add((org.jfree.chart.block.Block) textTitle22, (java.lang.Object) double31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle22.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        double double36 = categoryAxis35.getCategoryMargin();
        java.lang.String str38 = categoryAxis35.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit41 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis40.setTickUnit(numberTickUnit41, false, false);
        numberAxis40.resizeRange((double) 255);
        java.awt.Shape shape47 = numberAxis40.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis40, categoryItemRenderer48);
        java.awt.Paint paint50 = categoryPlot49.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = categoryPlot49.getRenderer(0);
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray64 = new java.lang.Number[][] { numberArray57, numberArray60, numberArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray64);
        categoryPlot49.setDataset(categoryDataset65);
        org.jfree.data.general.PieDataset pieDataset68 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset65, (int) (byte) 1);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity74 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D33, pieDataset68, (int) (byte) 10, (int) (short) 10, (java.lang.Comparable) 0.5f, "Pie 3D Plot", "Multiple Pie Plot");
        try {
            categoryPlot15.drawOutline(graphics2D19, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(numberTickUnit41);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(categoryItemRenderer52);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(pieDataset68);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        piePlot0.setSimpleLabelOffset(rectangleInsets4);
        org.jfree.chart.util.Rotation rotation6 = piePlot0.getDirection();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 15, (double) 'a', 0.0d, (double) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle18.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets17.createOutsetRectangle(rectangle2D19, true, true);
        piePlotState6.setLinkArea(rectangle2D22);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22, "java.awt.Color[r=128,g=128,b=255]");
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets4.createOutsetRectangle(rectangle2D22, false, false);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, (double) 1L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 10.0d;
        size2D0.height = 0.0d;
        double double5 = size2D0.height;
        java.lang.Object obj6 = size2D0.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        java.util.List list17 = categoryPlot15.getCategories();
        boolean boolean18 = categoryPlot15.isDomainZoomable();
        categoryPlot15.configureDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            categoryPlot15.setAxisOffset(rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        java.lang.Object obj19 = dateAxis0.clone();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj21 = dateAxis20.clone();
        org.jfree.chart.axis.Timeline timeline22 = dateAxis20.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis20.setTickUnit(dateTickUnit23, false, false);
        dateAxis0.setTickUnit(dateTickUnit23, false, false);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timeline22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj2 = dateAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperBound();
        boolean boolean6 = numberAxis4.isTickMarksVisible();
        boolean boolean7 = numberAxis4.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot8 = numberAxis4.getPlot();
        org.jfree.data.Range range9 = numberAxis4.getDefaultAutoRange();
        dateAxis1.setRange(range9, true, false);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range9, (org.jfree.data.Range) dateRange13);
        java.lang.String str15 = rectangleConstraint14.toString();
        boolean boolean16 = plotOrientation0.equals((java.lang.Object) str15);
        java.lang.String str17 = plotOrientation0.toString();
        boolean boolean19 = plotOrientation0.equals((java.lang.Object) 100);
        java.awt.Paint paint20 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        boolean boolean21 = plotOrientation0.equals((java.lang.Object) paint20);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str15.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        java.lang.Object obj4 = numberAxis1.clone();
        double double5 = numberAxis1.getLabelAngle();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", font1, (org.jfree.chart.plot.Plot) xYPlot2, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.clearRangeAxes();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot26.setRangeZeroBaselinePaint((java.awt.Paint) color30);
        boolean boolean32 = xYPlot26.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        xYPlot26.setRangeAxisLocation((int) (short) 1, axisLocation34, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot26.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D46 = xYPlot45.getQuadrantOrigin();
        xYPlot26.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo44, point2D46);
        xYPlot2.zoomRangeAxes((double) '#', 101.0d, plotRenderingInfo25, point2D46);
        xYPlot2.mapDatasetToRangeAxis(2, 3);
        java.awt.Stroke stroke52 = xYPlot2.getRangeZeroBaselineStroke();
        xYPlot2.setWeight((int) (short) 0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        double double6 = rectangleInsets5.getRight();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setVerticalTickLabels(false);
        boolean boolean8 = numberAxis4.equals((java.lang.Object) (-1L));
        int int9 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis(255);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        piePlot0.setLabelLinkPaint(paint1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection12);
        boolean boolean14 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot0.zoomDomainAxes((-5.0d), plotRenderingInfo16, point2D17, false);
        xYPlot0.clearAnnotations();
        xYPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot0.markerChanged(markerChangeEvent3);
        java.awt.Shape shape5 = null;
        try {
            piePlot0.setLegendItemShape(shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        boolean boolean6 = color4.equals((java.lang.Object) textLine5);
        float[] floatArray15 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray15);
        float[] floatArray17 = color4.getRGBComponents(floatArray16);
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot0.getDomainMarkers((int) (short) 100, layer22);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double16 = rectangleInsets14.calculateRightOutset((double) 'a');
        piePlot0.setInsets(rectangleInsets14, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart22.removeLegend();
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        double double25 = piePlot0.getStartAngle();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-48.743718592964825d) + "'", double16 == (-48.743718592964825d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 90.0d + "'", double25 == 90.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        double double2 = textTitle0.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        textTitle0.setPosition(rectangleEdge3);
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle0.getBounds();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        categoryPlot15.setRangeAxis(valueAxis46);
        categoryPlot15.clearDomainMarkers(500);
        java.lang.Object obj50 = categoryPlot15.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        boolean boolean5 = piePlot0.getIgnoreNullValues();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot0);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit16, false, false);
        numberAxis15.resizeRange((double) 255);
        java.awt.Shape shape22 = numberAxis15.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot24.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot24.setDataset(categoryDataset27);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = null;
        categoryPlot24.datasetChanged(datasetChangeEvent29);
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        xYPlot33.clearRangeAxes();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double42 = categoryAxis36.getCategoryStart(255, (int) (short) -1, rectangle2D40, rectangleEdge41);
        java.awt.geom.Point2D point2D43 = null;
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        xYPlot33.draw(graphics2D35, rectangle2D40, point2D43, plotState44, plotRenderingInfo45);
        java.awt.Color color47 = java.awt.Color.LIGHT_GRAY;
        xYPlot33.setRangeZeroBaselinePaint((java.awt.Paint) color47);
        java.awt.Stroke stroke49 = xYPlot33.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        int int51 = xYPlot33.indexOf(xYDataset50);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart("1.2.0-pre", font32, (org.jfree.chart.plot.Plot) xYPlot33, true);
        categoryPlot24.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        double double57 = categoryAxis56.getCategoryMargin();
        java.lang.String str59 = categoryAxis56.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        categoryPlot24.setDomainAxis((int) ' ', categoryAxis56);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot24.getDomainAxisEdge();
        java.lang.String str62 = rectangleEdge61.toString();
        legendTitle8.setLegendItemGraphicEdge(rectangleEdge61);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = null;
        try {
            legendTitle8.setItemLabelPadding(rectangleInsets64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.2d + "'", double57 == 0.2d);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "RectangleEdge.BOTTOM" + "'", str62.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        try {
            java.awt.image.BufferedImage bufferedImage6 = jFreeChart3.createBufferedImage(1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit16, false, false);
        numberAxis15.resizeRange((double) 255);
        java.awt.Shape shape22 = numberAxis15.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getDomainGridlinePaint();
        numberAxis1.setLabelPaint(paint25);
        boolean boolean27 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        textTitle0.setPosition(rectangleEdge2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        textTitle0.addChangeListener(titleChangeListener5);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        float float5 = multiplePiePlot1.getBackgroundAlpha();
        java.lang.String str6 = multiplePiePlot1.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = multiplePiePlot1.getLegendItems();
        int int8 = legendItemCollection7.getItemCount();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.ui.ProjectInfo projectInfo11 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo11.getLibraries();
        projectInfo11.setCopyright("Rotation.ANTICLOCKWISE");
        boolean boolean15 = categoryPlot0.equals((java.lang.Object) projectInfo11);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(projectInfo11);
        org.junit.Assert.assertNotNull(libraryArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.clearRangeAxes();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        boolean boolean13 = xYPlot7.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        xYPlot7.setRangeAxisLocation((int) (short) 1, axisLocation15, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot7.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(64, axisLocation22);
        xYPlot0.mapDatasetToRangeAxis(4, (int) ' ');
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer10 = new org.jfree.chart.text.G2TextMeasurer(graphics2D9);
        org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("", font3, (java.awt.Paint) color7, (float) 0L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setVerticalTickLabels(false);
        java.lang.Object obj20 = numberAxis17.clone();
        boolean boolean21 = textBlockAnchor15.equals(obj20);
        java.awt.Shape shape25 = textBlock11.calculateBounds(graphics2D12, (float) (byte) 10, (float) 100L, textBlockAnchor15, (float) (byte) -1, (float) 0, 0.08d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getDomainMarkers(layer6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot8.setDomainAxisLocation((int) (short) 100, axisLocation11, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot8.getDomainMarkers(layer14);
        xYPlot8.clearRangeMarkers((int) (short) 0);
        java.awt.Paint paint18 = xYPlot8.getRangeCrosshairPaint();
        xYPlot0.setDomainCrosshairPaint(paint18);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterX();
        double double3 = piePlotState1.getPieCenterY();
        double double4 = piePlotState1.getPieHRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        xYPlot8.mapDatasetToRangeAxis((int) '4', (int) (byte) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot8.getLegendItems();
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset2);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart4.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart4.removeProgressListener(chartProgressListener6);
        int int8 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 1L, jFreeChart4);
        org.jfree.chart.title.Title title11 = jFreeChart4.getSubtitle(0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(title11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        double double4 = numberAxis1.getFixedDimension();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getLeft();
        numberAxis1.setLabelInsets(rectangleInsets6);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(numberFormat9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        categoryPlot15.setOutlineVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = valueMarker20.getLabelOffset();
        java.awt.Paint paint22 = valueMarker20.getOutlinePaint();
        java.awt.Stroke stroke23 = valueMarker20.getStroke();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        int int7 = categoryPlot0.getIndexOf(categoryItemRenderer6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers(100, layer9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Color color1 = java.awt.Color.CYAN;
        piePlot0.setLabelPaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) 64);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) (byte) 0);
        boolean boolean7 = flowArrangement5.equals((java.lang.Object) "RectangleEdge.TOP");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str11 = rectangleEdge10.toString();
        textTitle8.setPosition(rectangleEdge10);
        double double13 = textTitle8.getWidth();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle14.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle14.getVerticalAlignment();
        textTitle8.setVerticalAlignment(verticalAlignment17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        int int20 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis22.setTickUnit(numberTickUnit23, false, false);
        numberAxis22.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = numberAxis22.getLabelInsets();
        boolean boolean30 = xYPlot19.equals((java.lang.Object) rectangleInsets29);
        java.awt.Paint paint31 = xYPlot19.getDomainGridlinePaint();
        flowArrangement5.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) paint31);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = textTitle33.getHorizontalAlignment();
        textTitle8.setTextAlignment(horizontalAlignment34);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D37 = textTitle36.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str39 = rectangleEdge38.toString();
        textTitle36.setPosition(rectangleEdge38);
        double double41 = textTitle36.getWidth();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = textTitle42.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = textTitle42.getVerticalAlignment();
        textTitle36.setVerticalAlignment(verticalAlignment45);
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment34, verticalAlignment45, 0.0d, (double) 10.0f);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.TOP" + "'", str11.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleEdge.TOP" + "'", str39.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(verticalAlignment45);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot2.setRangeGridlineStroke(stroke4);
        java.awt.Paint paint6 = xYPlot2.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis8.setUpperMargin(1.0d);
        java.lang.String str11 = numberAxis8.getLabelToolTip();
        int int12 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis8);
        boolean boolean13 = objectList1.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj15 = dateAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        dateAxis14.setRange(range22, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint13.toRangeWidth(range22);
        double double27 = rectangleConstraint13.getWidth();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot9 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot9.setOutlineStroke(stroke10);
        org.jfree.data.general.DatasetGroup datasetGroup12 = multiplePiePlot9.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        multiplePiePlot9.setDataset(categoryDataset13);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor16 = piePlot15.getLabelDistributor();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("", font19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("hi!", font19, (java.awt.Paint) color21);
        piePlot15.setLabelOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot15);
        multiplePiePlot9.notifyListeners(plotChangeEvent24);
        java.awt.Paint paint26 = multiplePiePlot9.getAggregatedItemsPaint();
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("XY Plot", font7, paint26, (float) ' ');
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.height;
        double double2 = size2D0.getWidth();
        double double3 = size2D0.width;
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Paint paint4 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot0.getDomainAxis();
        boolean boolean6 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        java.text.AttributedString attributedString3 = standardPieSectionLabelGenerator0.getAttributedLabel((int) (short) 100);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(attributedString3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setUpperMargin(1.0d);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis4.setTickMarkStroke(stroke7);
        polarPlot0.setRadiusGridlineStroke(stroke7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot0.setDataset(xYDataset10);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot4);
        jFreeChart5.removeLegend();
        boolean boolean7 = jFreeChart5.isBorderVisible();
        boolean boolean8 = numberAxis3D1.hasListener((java.util.EventListener) jFreeChart5);
        jFreeChart5.removeLegend();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis15.setTickUnit(numberTickUnit16, false, false);
        numberAxis15.resizeRange((double) 255);
        java.awt.Shape shape22 = numberAxis15.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getDomainGridlinePaint();
        numberAxis1.setLabelPaint(paint25);
        boolean boolean27 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint13.toRangeWidth(range22);
        double double24 = rectangleConstraint13.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint13.toFixedHeight((double) 100.0f);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        piePlot0.setShadowYOffset((double) 10.0f);
        piePlot0.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.setUpperMargin(0.025d);
        numberAxis1.setLowerMargin((double) 0.0f);
        numberAxis1.setUpperMargin((double) 0.0f);
        numberAxis1.resizeRange((double) 10L);
        numberAxis1.setLowerBound((double) (-1));
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", (int) (short) 100);
        int int3 = color2.getAlpha();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        double double48 = categoryAxis47.getCategoryMargin();
        java.lang.String str50 = categoryAxis47.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        categoryPlot15.setDomainAxis((int) ' ', categoryAxis47);
        boolean boolean52 = categoryAxis47.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine();
        boolean boolean8 = color6.equals((java.lang.Object) textLine7);
        boolean boolean9 = rectangleAnchor5.equals((java.lang.Object) color6);
        java.lang.String str10 = rectangleAnchor5.toString();
        valueMarker1.setLabelAnchor(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleAnchor.LEFT" + "'", str10.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        piePlot2.setIgnoreNullValues(true);
        java.awt.Stroke stroke11 = piePlot2.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = null;
        piePlot2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle14.getLegendItemGraphicLocation();
        boolean boolean17 = legendTitle14.equals((java.lang.Object) 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle14.getItemContainer();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(blockContainer18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        piePlot2.setIgnoreNullValues(true);
        java.awt.Stroke stroke11 = piePlot2.getLabelLinkStroke();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        piePlot2.setShadowPaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot16.getLabelDistributor();
        java.awt.Paint paint18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot16.setLabelBackgroundPaint(paint18);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = piePlot16.getLegendLabelURLGenerator();
        java.awt.Paint paint21 = piePlot16.getBaseSectionOutlinePaint();
        boolean boolean22 = rectangleInsets14.equals((java.lang.Object) piePlot16);
        piePlot16.setIgnoreNullValues(true);
        java.awt.Stroke stroke25 = piePlot16.getLabelLinkStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = null;
        piePlot16.setLegendLabelToolTipGenerator(pieSectionLabelGenerator26);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = piePlot16.getLabelGenerator();
        piePlot2.setLabelGenerator(pieSectionLabelGenerator28);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(pieURLGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator28);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.lang.Object obj2 = blockContainer0.clone();
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(arrangement3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getMaximumLabelWidth();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        ringPlot1.setURLGenerator(pieURLGenerator3);
        ringPlot1.setSeparatorsVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14d + "'", double2 == 0.14d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = null;
        int int2 = objectList0.indexOf(obj1);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle3.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double6 = categoryAxis0.getCategoryStart(255, (int) (short) -1, rectangle2D4, rectangleEdge5);
        float float7 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj8 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        boolean boolean3 = textTitle0.equals((java.lang.Object) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createOutsetRectangle(rectangle2D17, true, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor24 = piePlot23.getLabelDistributor();
        java.awt.Paint paint25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot23.setLabelBackgroundPaint(paint25);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator27 = piePlot23.getLegendLabelURLGenerator();
        java.awt.Paint paint28 = piePlot23.getBaseSectionOutlinePaint();
        boolean boolean29 = rectangleInsets21.equals((java.lang.Object) piePlot23);
        org.jfree.chart.util.UnitType unitType30 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets(unitType30, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets(unitType30, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType42 = rectangleInsets41.getUnitType();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets41.createInsetRectangle(rectangle2D44);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets40.createOutsetRectangle(rectangle2D44, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets21.createAdjustedRectangle(rectangle2D44, lengthAdjustmentType49, lengthAdjustmentType50);
        java.lang.Object obj52 = textTitle0.draw(graphics2D4, rectangle2D17, (java.lang.Object) lengthAdjustmentType49);
        textTitle0.setID("1.2.0-pre");
        java.lang.Object obj55 = textTitle0.clone();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(pieURLGenerator27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNull(obj52);
        org.junit.Assert.assertNotNull(obj55);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        java.util.Date date25 = dateAxis0.getMinimumDate();
        org.jfree.data.Range range26 = dateAxis0.getRange();
        java.lang.Object obj27 = null;
        boolean boolean28 = dateAxis0.equals(obj27);
        double double29 = dateAxis0.getFixedAutoRange();
        java.util.Date date30 = null;
        try {
            dateAxis0.setMaximumDate(date30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        projectInfo0.setInfo("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        java.lang.String str2 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot4.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit5);
        polarPlot3.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit5);
        boolean boolean8 = polarPlot3.isRangeZoomable();
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation10 = piePlot0.getDirection();
        piePlot0.setMaximumLabelWidth((-1.0d));
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertNotNull(rotation10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        piePlot0.setSimpleLabelOffset(rectangleInsets4);
        double double6 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        double double10 = rectangleInsets8.calculateBottomInset(10.0d);
        double double12 = rectangleInsets8.calculateTopInset(0.025d);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.0d + "'", double10 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font3);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("{0}");
        textLine7.addFragment(textFragment9);
        org.jfree.chart.text.TextFragment textFragment11 = textLine7.getLastTextFragment();
        java.awt.Paint paint12 = textFragment11.getPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.clearRangeAxes();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle17.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double20 = categoryAxis14.getCategoryStart(255, (int) (short) -1, rectangle2D18, rectangleEdge19);
        java.awt.geom.Point2D point2D21 = null;
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        xYPlot11.draw(graphics2D13, rectangle2D18, point2D21, plotState22, plotRenderingInfo23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        double double27 = dateAxis9.valueToJava2D((double) 10, rectangle2D18, rectangleEdge26);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        categoryPlot0.clearRangeMarkers((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        double double7 = categoryAxis6.getCategoryMargin();
        java.lang.String str9 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit12, false, false);
        numberAxis11.resizeRange((double) 255);
        java.awt.Shape shape18 = numberAxis11.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot20.getDomainAxisLocation(1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot20.setRenderer(categoryItemRenderer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.clearRangeAxes();
        java.awt.Paint paint31 = xYPlot29.getRangeTickBandPaint();
        xYPlot29.setWeight((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        xYPlot37.clearRangeAxes();
        java.awt.Stroke stroke39 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot37.setRangeGridlineStroke(stroke39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot37.setRangeZeroBaselinePaint((java.awt.Paint) color41);
        boolean boolean43 = xYPlot37.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        xYPlot37.setRangeAxisLocation((int) (short) 1, axisLocation45, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        xYPlot37.zoomRangeAxes(0.0d, plotRenderingInfo49, point2D50);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot37.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D57 = xYPlot56.getQuadrantOrigin();
        xYPlot37.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo55, point2D57);
        xYPlot29.zoomRangeAxes((double) 100L, 0.05d, plotRenderingInfo36, point2D57);
        categoryPlot20.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo28, point2D57);
        try {
            polarPlot0.zoomRangeAxes((double) '4', plotRenderingInfo4, point2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(point2D57);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Color color2 = java.awt.Color.getColor("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", 0);
        float[] floatArray14 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(0, 100, 100, floatArray15);
        float[] floatArray17 = color2.getRGBColorComponents(floatArray16);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        jFreeChart44.setTitle("");
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor49 = piePlot48.getLabelDistributor();
        java.awt.Font font52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment53 = new org.jfree.chart.text.TextFragment("", font52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine55 = new org.jfree.chart.text.TextLine("hi!", font52, (java.awt.Paint) color54);
        piePlot48.setLabelOutlinePaint((java.awt.Paint) color54);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent57 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot48);
        java.awt.Paint paint63 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder64 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 10L, (double) (byte) 0, (double) (-1L), paint63);
        piePlot48.setSectionPaint((java.lang.Comparable) (-1.0d), paint63);
        jFreeChart44.setBorderPaint(paint63);
        int int67 = jFreeChart44.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = xYPlot0.isDomainZeroBaselineVisible();
        boolean boolean16 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("{0}", "RectangleEdge.BOTTOM");
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.clearRangeAxes();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot7.setRangeZeroBaselinePaint((java.awt.Paint) color11);
        boolean boolean13 = xYPlot7.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        xYPlot7.setRangeAxisLocation((int) (short) 1, axisLocation15, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot7.getDomainAxisLocation();
        xYPlot0.setRangeAxisLocation(64, axisLocation22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D27 = xYPlot26.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes(0.14d, plotRenderingInfo25, point2D27, true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        xYPlot0.setRangeAxisLocation((int) 'a', axisLocation31);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        valueMarker34.setLabelPaint((java.awt.Paint) color35);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit3);
        java.awt.Paint paint5 = polarPlot0.getAngleGridlinePaint();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=128,g=128,b=255]", graphics2D1, (double) 15, 0.0f, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        piePlot0.setStartAngle(0.2d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        java.awt.Paint paint54 = xYPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot56 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset55);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot56.setOutlineStroke(stroke57);
        java.awt.Paint paint59 = multiplePiePlot56.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = multiplePiePlot56.getInsets();
        double double61 = multiplePiePlot56.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection62 = multiplePiePlot56.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection62);
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = valueMarker66.getLabelOffset();
        java.awt.Paint paint68 = valueMarker66.getOutlinePaint();
        valueMarker66.setValue((-48.743718592964825d));
        valueMarker66.setLabel("");
        java.awt.Stroke stroke73 = valueMarker66.getOutlineStroke();
        org.jfree.chart.util.Layer layer74 = null;
        try {
            xYPlot0.addDomainMarker(15, (org.jfree.chart.plot.Marker) valueMarker66, layer74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
        piePlotState1.setPieWRadius((double) 10);
        double double6 = piePlotState1.getPieHRadius();
        java.awt.geom.Rectangle2D rectangle2D7 = piePlotState1.getLinkArea();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.clearRangeAxes();
        java.awt.Paint paint15 = xYPlot13.getRangeTickBandPaint();
        xYPlot13.setWeight((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.clearRangeAxes();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setRangeGridlineStroke(stroke23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot21.setRangeZeroBaselinePaint((java.awt.Paint) color25);
        boolean boolean27 = xYPlot21.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setRangeAxisLocation((int) (short) 1, axisLocation29, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot21.zoomRangeAxes(0.0d, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot21.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D41 = xYPlot40.getQuadrantOrigin();
        xYPlot21.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo39, point2D41);
        xYPlot13.zoomRangeAxes((double) 100L, 0.05d, plotRenderingInfo20, point2D41);
        categoryPlot0.zoomDomainAxes((double) (byte) 1, plotRenderingInfo12, point2D41);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 0.5f, 0.0d, (java.awt.Paint) color5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.clearRangeAxes();
        xYPlot9.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot9.zoomRangeAxes((double) 0L, plotRenderingInfo14, point2D15);
        java.awt.Stroke stroke17 = xYPlot9.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(48.0d, (java.awt.Paint) color5, stroke7, (java.awt.Paint) color8, stroke17, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterX();
        double double3 = piePlotState1.getPieCenterY();
        piePlotState1.setPieWRadius((double) ' ');
        piePlotState1.setLatestAngle((double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = categoryAxis13.getCategoryStart(255, (int) (short) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot10.draw(graphics2D12, rectangle2D17, point2D20, plotState21, plotRenderingInfo22);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        xYPlot10.setRangeZeroBaselinePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke26 = xYPlot10.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        int int28 = xYPlot10.indexOf(xYDataset27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("1.2.0-pre", font9, (org.jfree.chart.plot.Plot) xYPlot10, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        xYPlot34.clearRangeAxes();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot34.setRangeGridlineStroke(stroke36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot34.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        boolean boolean40 = xYPlot34.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        xYPlot34.setRangeAxisLocation((int) (short) 1, axisLocation42, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot34.zoomRangeAxes(0.0d, plotRenderingInfo46, point2D47);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot34.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D54 = xYPlot53.getQuadrantOrigin();
        xYPlot34.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo52, point2D54);
        xYPlot10.zoomRangeAxes((double) '#', 101.0d, plotRenderingInfo33, point2D54);
        polarPlot3.zoomDomainAxes(1.0d, plotRenderingInfo7, point2D54, false);
        polarPlot3.removeCornerTextItem("TextBlockAnchor.CENTER_LEFT");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean3 = columnArrangement0.equals((java.lang.Object) chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot5.getLabelDistributor();
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot5.setLabelBackgroundPaint(paint7);
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        piePlot5.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color10);
        int int12 = piePlot5.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot5.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot5.getLabelDistributor();
        org.jfree.chart.util.Rotation rotation15 = piePlot5.getDirection();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        boolean boolean17 = rotation15.equals((java.lang.Object) plotOrientation16);
        categoryPlot0.setOrientation(plotOrientation16);
        java.lang.String str19 = plotOrientation16.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(rotation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotOrientation.VERTICAL" + "'", str19.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        multiplePiePlot1.setDataset(categoryDataset5);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot7.getLabelDistributor();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color13);
        piePlot7.setLabelOutlinePaint((java.awt.Paint) color13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot7);
        multiplePiePlot1.notifyListeners(plotChangeEvent16);
        boolean boolean18 = multiplePiePlot1.isSubplot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean20 = multiplePiePlot1.equals((java.lang.Object) color19);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot5 = numberAxis1.getPlot();
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        double double9 = categoryAxis8.getCategoryMargin();
        java.lang.String str11 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit14, false, false);
        numberAxis13.resizeRange((double) 255);
        java.awt.Shape shape20 = numberAxis13.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis13, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot22.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray36 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] { numberArray30, numberArray33, numberArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray37);
        categoryPlot22.setDataset(1, categoryDataset38);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset38);
        org.jfree.data.Range range43 = org.jfree.data.Range.expand(range40, 0.0d, 0.0d);
        org.jfree.data.Range range44 = org.jfree.data.Range.combine(range6, range40);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray36);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.lang.Object obj2 = blockContainer0.clone();
        blockContainer0.clear();
        boolean boolean4 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        java.util.Date date25 = dateAxis0.getMinimumDate();
        org.jfree.data.Range range26 = dateAxis0.getRange();
        java.lang.Object obj27 = null;
        boolean boolean28 = dateAxis0.equals(obj27);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
    }
}

